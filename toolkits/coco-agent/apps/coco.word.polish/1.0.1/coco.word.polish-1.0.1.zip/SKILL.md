---
name: coco-app-word-polish
description: 不改原意地润色措辞、提升通顺度,追加润色版做对照。用户说'润色/改写润饰/优化表达/让语句更通顺'时用。
compatibility: Requires Coco Word with the workflow application runner.
metadata:
  coco.id: coco.word.polish
  display-name: 润色
  version: "1.0.1"
---

# 润色

不改原意地润色措辞、提升通顺度,追加润色版做对照。用户说'润色/改写润饰/优化表达/让语句更通顺'时用。

## 执行规则

- 仅处理当前 Word 文档；存在选区时按工作流自身范围规则处理。
- 参数完整后调用 `execute_application`，应用 ID 为 `coco.word.polish`，资源 ID 为 `run`。
- 不使用 `execute_code`、`execute_file` 或旧 Workflow 入口。
- 工作流弹出选择或确认时，等待用户完成交互后继续。
