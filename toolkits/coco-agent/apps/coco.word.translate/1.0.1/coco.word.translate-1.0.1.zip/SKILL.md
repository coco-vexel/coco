---
name: coco-app-word-translate
description: 把文档或选区翻译成目标语言,在每段后追加译文做双语对照。用户说'翻译/译成X文/中译英/英译中/translate'时用。
compatibility: Requires Coco Word with the workflow application runner.
metadata:
  coco.id: coco.word.translate
  display-name: 翻译
  version: "1.0.1"
---

# 翻译

把文档或选区翻译成目标语言,在每段后追加译文做双语对照。用户说'翻译/译成X文/中译英/英译中/translate'时用。

## 执行规则

- 仅处理当前 Word 文档；存在选区时按工作流自身范围规则处理。
- 参数完整后调用 `execute_application`，应用 ID 为 `coco.word.translate`，资源 ID 为 `run`。
- 不使用 `execute_code`、`execute_file` 或旧 Workflow 入口。
- 工作流弹出选择或确认时，等待用户完成交互后继续。
