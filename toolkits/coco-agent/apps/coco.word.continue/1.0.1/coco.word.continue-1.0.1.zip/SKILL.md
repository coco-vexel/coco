---
name: coco-app-word-continue
description: 顺着文末内容续写后续段落。用户说'续写/接着写/往下写/补充后续内容'时用。
compatibility: Requires Coco Word with the workflow application runner.
metadata:
  coco.id: coco.word.continue
  display-name: 续写
  version: "1.0.1"
---

# 续写

顺着文末内容续写后续段落。用户说'续写/接着写/往下写/补充后续内容'时用。

## 执行规则

- 仅处理当前 Word 文档；存在选区时按工作流自身范围规则处理。
- 参数完整后调用 `execute_application`，应用 ID 为 `coco.word.continue`，资源 ID 为 `run`。
- 不使用 `execute_code`、`execute_file` 或旧 Workflow 入口。
- 工作流弹出选择或确认时，等待用户完成交互后继续。
