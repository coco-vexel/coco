---
name: coco-app-word-labeled-fields-align
description: 自动识别 Word 中连续的“标签：内容”行，统一标签宽度、冒号位置与填写线终点，适用于封面、登记表、申请表等文档。
compatibility: Requires Coco Word with the workflow application runner.
metadata:
  coco.id: coco.word.labeled-fields-align
  display-name: 标签字段对齐
  version: "1.0.7"
---

# 标签字段对齐

自动识别 Word 中连续的“标签：内容”行，统一标签宽度、冒号位置与填写线终点，适用于封面、登记表、申请表等文档。

## 执行规则

- 仅处理当前 Word 文档；存在选区时按工作流自身范围规则处理。
- 这是应用包内部执行契约，不注册为 Agent Skill，也不使用 `load_skill`。
- 入口资源固定为 `run`，由 Coco 应用执行器直接运行其中的 Workflow。
- 工作流弹出选择或确认时，等待用户完成交互后继续。
