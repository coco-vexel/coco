---
name: coco-app-word-doc-cleanup
description: 保守清理段首段尾空白、零宽字符、异常控制字符和中文间连续空格，并通过修订逐条确认。
compatibility: Requires Coco Word with the workflow application runner.
metadata:
  coco.id: coco.word.doc-cleanup
  display-name: 文档清理
  version: "1.0.1"
---

# 文档清理

保守清理段首段尾空白、零宽字符、异常控制字符和中文间连续空格，并通过修订逐条确认。

## 执行规则

- 仅处理当前 Word 文档；存在选区时按工作流自身范围规则处理。
- 这是应用包内部执行契约，不注册为 Agent Skill，也不使用 `load_skill`。
- 入口资源固定为 `run`，由 Coco 应用执行器直接运行其中的 Workflow。
- 工作流弹出选择或确认时，等待用户完成交互后继续。
