import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  AppToolExecutor,
  createExcelScriptRunner,
} from '../../../packages/application-tools/dist/index.js';
import { ExcelWorkbook } from '../../../packages/application-tools/node_modules/@coco-vexel/coco-office/dist/excel.js';

const packageDir = path.dirname(fileURLToPath(import.meta.url));
const userInput = process.argv[2] ?? '用“天地玄黄”生成单行间距描红字帖';
const requestedOutput = process.argv[3];

class DirectoryPackageLoader {
  constructor(root) {
    this.root = root;
  }

  async loadManifest() {
    return JSON.parse(await this.readText('app.json'));
  }

  async readText(relativePath) {
    return fs.readFile(this.resolve(relativePath), 'utf8');
  }

  async readBytes(relativePath) {
    return new Uint8Array(await fs.readFile(this.resolve(relativePath)));
  }

  resolve(relativePath) {
    const resolved = path.resolve(this.root, relativePath);
    if (resolved !== this.root && !resolved.startsWith(`${this.root}${path.sep}`)) {
      throw new Error(`Package path escapes root: ${relativePath}`);
    }
    return resolved;
  }
}

const planner = {
  async plan({ userInput: input }) {
    const spacingMode = /(?:三行间距|拼音字帖)/.test(input)
      ? 'pinyin'
      : /(?:单行间距|隔一行)/.test(input)
        ? 'single'
        : /(?:无间距|连续排列)/.test(input)
          ? 'none'
          : undefined;
    if (!spacingMode) {
      throw new Error('离线 demo 无法调用 ask_user，请在命令中指定“无间距”、“单行间距”或“三行间距（拼音字帖）”。');
    }
    const quoted = input.match(/[“"]([^”"]+)[”"]/)?.[1] ?? '';
    const text = /空白|不输入文字/.test(input) ? '' : quoted.replace(/\s+/g, '');
    const multipleSheets = /多张|每(?:个字|张).{0,5}(?:一张|换一个|一个)/.test(input);
    return {
      resourceId: 'generate',
      inputs: {
        text: multipleSheets ? '' : text,
        ...(multipleSheets ? { sheetTexts: Array.from(text), fillMode: 'single-cell' } : {}),
        spacingMode,
        fileName: text ? `${text}-描红字帖.xlsx` : '空白描红字帖.xlsx',
      },
    };
  },
};

const result = await new AppToolExecutor().execute({
  loader: new DirectoryPackageLoader(packageDir),
  planner,
  runners: [createExcelScriptRunner()],
  userInput,
  target: 'excel',
  document: await createBlankDocument(),
});

async function createBlankDocument() {
  const workbook = await ExcelWorkbook.fromModel({
    sheets: [], sharedStrings: [], definedNames: [],
    styles: {
      numberFormats: [], fonts: [{ name: 'Carlito', size: 11 }],
      fills: [{ patternType: 'none' }, { patternType: 'gray125' }],
      borders: [{}], cellFormats: [{ fontId: 0, fillId: 0, borderId: 0, numberFormatId: 0 }],
    },
  }, { mode: 'inline' });
  try {
    await workbook.worksheets.add('Sheet1');
    return {
      fileName: 'demo.xlsx',
      mediaType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      bytes: await workbook.toZip(),
    };
  } finally {
    await workbook.dispose();
  }
}

const artifact = result.artifacts[0];
const outputPath = path.resolve(
  requestedOutput ?? path.join(packageDir, 'output', artifact.fileName),
);
await fs.mkdir(path.dirname(outputPath), { recursive: true });
await fs.writeFile(outputPath, artifact.bytes);
process.stdout.write(
  `${JSON.stringify(
    {
      appTool: result.manifest.id,
      resource: result.plan.resourceId,
      inputs: result.plan.inputs,
      outputPath,
      bytes: artifact.bytes.byteLength,
      metadata: artifact.metadata,
    },
    null,
    2,
  )}\n`,
);
