async function run(workbook, args) {
  const spacingMode = String(args.spacingMode ?? '');
  const layout = copybookLayout(spacingMode);
  if (!layout) {
    throw new Error('请选择间距模式：无间距、单行间距或三行间距（拼音字帖）。');
  }
  const fillMode = String(args.fillMode ?? 'row-repeat');
  if (!['row-repeat', 'row-full', 'row-head', 'single-cell'].includes(fillMode)) {
    throw new Error('不支持的文字填写方式。');
  }
  const sheetTexts = normalizeSheetTexts(args);
  const generated = [];
  for (let index = 0; index < sheetTexts.length; index += 1) {
    const text = Array.from(sheetTexts[index]);
    const pinyinTexts = pinyinForSheet(args, index, sheetTexts.length, text.length);
    const baseName = sheetTexts.length === 1
      ? '描红字帖'
      : copybookSheetName(sheetTexts[index], index);
    const sheet = selectCopybookSheet(workbook, baseName, index === 0);
    generated.push({ sheet, ...fillCopybookSheet(sheet, text, pinyinTexts, layout, fillMode) });
  }
  const lastGenerated = generated[generated.length - 1];
  selectSheet(workbook, lastGenerated.sheet);

  // Flush ordinary worksheet edits before adding package-backed SDK layout objects.
  await workbook.toZip();
  for (const item of generated) {
    workbook.addWorksheetLines(item.sheet.name(), copybookGuideLines(layout));
    workbook.setWorksheetPrintSetup(item.sheet.name(), {
      paperSize: 9,
      orientation: 'portrait',
      fitToWidth: 1,
      fitToHeight: 1,
      horizontalCentered: true,
      margins: { left: 0, right: 0, top: 0, bottom: 0, header: 0, footer: 0 },
      // Keep one blank safety column on both sides of the copybook grid.
      // The right outline sits on the N/O boundary; ending the print area at
      // column N lets some spreadsheet/printer pipelines clip that line.
      printArea: `$A$1:$O$${layout.lastRow}`,
    });
  }

  return {
    sheetName: lastGenerated.sheet.name(),
    sheetNames: generated.map((item) => item.sheet.name()),
    sheetCount: generated.length,
    spacingMode,
    fillMode,
    written: generated.reduce((sum, item) => sum + item.written, 0),
    truncated: generated.some((item) => item.truncated),
    capacity: fillMode === 'single-cell' ? 1 : layout.gridRows.length,
  };
}

function copybookLayout(spacingMode) {
  if (spacingMode === 'none') {
    return {
      gridRows: range(2, 20, 1),
      pinyinRows: [],
      spacerRows: [],
      lastRow: 21,
    };
  }
  if (spacingMode === 'single') {
    return {
      // A practice gap should be visually useful without consuming another
      // complete 39.75pt Tianzi square. Fourteen rows still fit on one A4 page.
      gridRows: range(2, 28, 2),
      pinyinRows: [],
      spacerRows: range(3, 27, 2),
      lastRow: 29,
    };
  }
  if (spacingMode === 'pinyin') {
    return {
      // Each unit is a 24pt four-line/three-space Pinyin grid followed by a
      // 39.75pt Tianzi grid, with only a compact separator between units.
      pinyinRows: range(2, 29, 3),
      gridRows: range(3, 30, 3),
      spacerRows: range(4, 28, 3),
      lastRow: 31,
    };
  }
  return undefined;
}

function range(start, end, step) {
  const values = [];
  for (let value = start; value <= end; value += step) values.push(value);
  return values;
}

function fillCopybookSheet(sheet, text, pinyinTexts, layout, fillMode) {
  // Keep the Tianzi dimensions calibrated against WPS. The first and last rows
  // remain fixed page margins for every layout.
  sheet.getRange('A:O').setColumnWidth(5.889999866485596);
  sheet.getRange(`1:${layout.lastRow}`).setRowHeight(39.75);
  for (const row of layout.spacerRows) sheet.getRange(`${row}:${row}`).setRowHeight(8);
  for (const row of layout.pinyinRows) sheet.getRange(`${row}:${row}`).setRowHeight(24);
  sheet.setSheetViews([{ workbookViewId: 0, showGridLines: false, selections: [] }]);
  const side = { style: 'thin', color: { rgb: '#2C7A69' } };
  for (const row of layout.gridRows) {
    const grid = sheet.getRange(`B${row}:N${row}`);
    grid.format.border.setValue({ left: side, right: side, top: side, bottom: side });
    grid.format.alignment.setValue({ horizontal: 'center', vertical: 'center' });
    grid.format.font.setValue({ name: 'KaiTi', size: 26, color: { rgb: '#D49A84' } });
    sheet.getRange(`B${row}`).format.font.setColor({ rgb: '#6A4B3B' });
  }
  const capacity = fillMode === 'single-cell' ? 1 : layout.gridRows.length;
  const characters = text.slice(0, capacity);
  for (let index = 0; index < characters.length; index += 1) {
    const row = layout.gridRows[index];
    sheet.getRange(`B${row}`).setValues([[characters[index]]]);
    if (fillMode === 'row-repeat') {
      sheet.getRange(`C${row}:H${row}`).setValues([Array(6).fill(characters[index])]);
    } else if (fillMode === 'row-full') {
      sheet.getRange(`C${row}:N${row}`).setValues([Array(12).fill(characters[index])]);
    }
    const pinyinRow = layout.pinyinRows[index];
    const pinyin = pinyinTexts[index] ?? '';
    if (pinyinRow !== undefined && pinyin) {
      const pinyinGrid = sheet.getRange(`B${pinyinRow}:N${pinyinRow}`);
      pinyinGrid.format.alignment.setValue({ horizontal: 'center', vertical: 'center' });
      pinyinGrid.format.font.setValue({ name: 'Arial', size: 10, color: { rgb: '#D49A84' } });
      sheet.getRange(`B${pinyinRow}`).format.font.setColor({ rgb: '#6A4B3B' });
      sheet.getRange(`B${pinyinRow}`).setValues([[pinyin]]);
      if (fillMode === 'row-repeat') {
        sheet.getRange(`C${pinyinRow}:H${pinyinRow}`).setValues([Array(6).fill(pinyin)]);
      } else if (fillMode === 'row-full') {
        sheet.getRange(`C${pinyinRow}:N${pinyinRow}`).setValues([Array(12).fill(pinyin)]);
      }
    }
  }

  return {
    written: characters.length,
    truncated: text.length > capacity,
  };
}

function pinyinForSheet(args, sheetIndex, sheetCount, characterCount) {
  if (args.pinyinTexts === undefined || args.pinyinTexts === null) return [];
  if (!Array.isArray(args.pinyinTexts)) throw new Error('pinyinTexts 必须是逐字拼音数组。');
  const values = args.pinyinTexts.map((value) => String(value ?? '').trim());
  if (sheetCount === 1) return values.slice(0, characterCount);
  // The common multi-sheet form is one character per sheet. A flat array can
  // therefore stay compatible with the manifest's string-array input type.
  if (characterCount <= 1 && values.length === sheetCount) return [values[sheetIndex] ?? ''];
  return [];
}

function normalizeSheetTexts(args) {
  if (args.sheetTexts === undefined || args.sheetTexts === null) {
    return [String(args.text ?? '').replace(/\s+/g, '')];
  }
  if (!Array.isArray(args.sheetTexts)) throw new Error('sheetTexts 必须是文字数组。');
  if (args.sheetTexts.length === 0) throw new Error('sheetTexts 不能是空数组。');
  if (args.sheetTexts.length > 50) throw new Error('一次最多生成 50 张字帖。');
  return args.sheetTexts.map((value) => String(value ?? '').replace(/\s+/g, ''));
}

function copybookSheetName(text, index) {
  const label = Array.from(text).slice(0, 10).join('').replace(/[\\/*?:\[\]]/g, '-');
  return `描红字帖-${label || index + 1}`.slice(0, 31);
}

function selectCopybookSheet(workbook, baseName, allowReuse) {
  const sheets = workbook.worksheets.items();
  if (sheets.length === 0) return workbook.worksheets.add(baseName);

  const current = sheets.find((candidate) =>
    candidate.sheetViews().some((view) => view.tabSelected === true),
  ) ?? sheets[0];
  const reusable = allowReuse && !hasSheetContent(current) ? current : undefined;
  const name = uniqueSheetName(workbook, baseName, reusable);
  const sheet = reusable ?? workbook.worksheets.add(name);
  if (sheet.name() !== name) sheet.rename(name);
  return sheet;
}

function hasSheetContent(sheet) {
  const model = sheet.toModel();
  const hasCellContent = model.cells.some((cell) =>
    Boolean(cell.formula) || (cell.value !== null && cell.value !== ''),
  );
  return hasCellContent || [
    model.tables,
    model.hyperlinks,
    model.comments,
    model.threadedComments,
    model.drawings,
    model.charts,
    model.images,
  ].some((items) => items.length > 0);
}

function uniqueSheetName(workbook, baseName, reusableSheet) {
  const occupied = new Set(
    workbook.worksheets.items()
      .filter((sheet) => sheet !== reusableSheet)
      .map((sheet) => sheet.name()),
  );
  if (!occupied.has(baseName)) return baseName;
  for (let index = 2; index < 1000; index += 1) {
    const candidate = `${baseName} (${index})`;
    if (!occupied.has(candidate)) return candidate;
  }
  throw new Error('无法为描红字帖创建唯一的工作表名称。');
}

function selectSheet(workbook, selectedSheet) {
  for (const sheet of workbook.worksheets.items()) {
    const views = sheet.sheetViews();
    const nextViews = views.length > 0
      ? views.map((view) => ({ ...view, tabSelected: sheet === selectedSheet }))
      : [{ workbookViewId: 0, tabSelected: sheet === selectedSheet, selections: [] }];
    sheet.setSheetViews(nextViews);
  }
}

function copybookGuideLines(layout) {
  const lines = [];
  for (const rowNumber of layout.gridRows) {
    const row = rowNumber - 1;
    lines.push(...cellRowOutlineLines(`coco-tianzige-outline-${rowNumber}`, row, 504825));
    for (let column = 1; column <= 13; column += 1) {
      lines.push(
        {
          name: `coco-tianzige-horizontal-${row + 1}-${column + 1}`,
          from: { column, columnOffset: 0, row, rowOffset: 252412 },
          to: { column: column + 1, columnOffset: 0, row, rowOffset: 252412 },
          width: 504000,
          height: 0,
          dash: 'dash',
        },
        {
          name: `coco-tianzige-vertical-${row + 1}-${column + 1}`,
          from: { column, columnOffset: 252000, row, rowOffset: 0 },
          to: { column, columnOffset: 252000, row: row + 1, rowOffset: 0 },
          width: 0,
          height: 504825,
          dash: 'dash',
        },
      );
    }
  }
  for (const rowNumber of layout.pinyinRows) {
    const row = rowNumber - 1;
    const rowHeight = 304800;
    lines.push(...cellRowOutlineLines(`coco-pinyin-outline-${rowNumber}`, row, rowHeight));
    for (const [index, rowOffset] of [101600, 203200].entries()) {
      lines.push({
        name: `coco-pinyin-guide-${rowNumber}-${index + 1}`,
        from: { column: 1, columnOffset: 0, row, rowOffset },
        to: { column: 14, columnOffset: 0, row, rowOffset },
        width: 6552000,
        height: 0,
        dash: 'dash',
      });
    }
  }
  return lines;
}

function cellRowOutlineLines(name, row, rowHeight) {
  const solid = { color: '#2C7A69', alpha: 100000, dash: 'solid' };
  const lines = [
    {
      name: `${name}-top`,
      from: { column: 1, columnOffset: 0, row, rowOffset: 0 },
      to: { column: 14, columnOffset: 0, row, rowOffset: 0 },
      width: 6552000,
      height: 0,
      ...solid,
    },
    {
      name: `${name}-bottom`,
      from: { column: 1, columnOffset: 0, row: row + 1, rowOffset: 0 },
      to: { column: 14, columnOffset: 0, row: row + 1, rowOffset: 0 },
      width: 6552000,
      height: 0,
      ...solid,
    },
  ];
  for (let column = 1; column <= 14; column += 1) {
    lines.push({
      name: `${name}-vertical-${column}`,
      from: { column, columnOffset: 0, row, rowOffset: 0 },
      to: { column, columnOffset: 0, row: row + 1, rowOffset: 0 },
      width: 0,
      height: rowHeight,
      ...solid,
    });
  }
  return lines;
}

return await run(workbook, args);
