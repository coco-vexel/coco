---
name: chinese-copybook
description: 生成 A4 Excel 描红田字格，支持无间距、紧凑单行间距和上方四线三格、下方田字格的拼音字帖，以及空白、单格、每行行首和重复描红。用户要求生成描红字帖、红字贴或田字格时使用。
compatibility: Requires the Coco Excel workbook runtime with worksheet line-shape and print-setup APIs. No local filesystem, shell access, or direct OOXML access is required.
metadata:
  coco.id: coco.chinese-copybook
  display-name: 生成描红字帖
  version: "0.4.4"
---

# 生成描红字帖

把用户的自由输入转换为 Excel 描红字帖。

- 没有文字时，`text` 使用空字符串，直接生成空白字帖，不追问。
- 上下页边距固定：页首和页尾各保留一行空白，不向用户询问，也不生成页边距参数。
- 必须确定 `spacingMode` 后才能执行。用户明确要求“无间距”“连续排列”时使用 `none`；明确要求“单行间距”“隔一行”时使用 `single`；明确要求“三行间距”“多行间距”“拼音字帖”时使用 `pinyin`。`pinyin` 的实际纸面结构不是三整行空白，而是上方标准四线三格、下方田字格。
- 如果用户没有明确三种模式中的一种，必须在执行前调用 `ask_user`，选项固定为“无间距”“单行间距”“拼音字帖（四线三格）”。用户只说“带间距”仍然无法区分单行和拼音字帖，必须询问，禁止自行使用默认值。
- `spacingMode` 为 `pinyin` 且有练习文字时，必须同时生成 `pinyinTexts`：按 `text` 的每个汉字提供一个带声调拼音，例如“天地”使用 `["tiān", "dì"]`。多音字按用户语境选择；空白拼音字帖不提供该参数。拼音写在四线三格中，对应汉字写在其下方田字格。
- 只提取用户明确要求写入字帖的文字；去掉空白字符。
- 用户明确要求“多张”“每个字一张”“每张换一个字”或同义表达时，使用 `sheetTexts` 字符串数组，每项生成一个 Sheet。例如“帮我生成几张字帖，每张首行首列文字换一个，为中华人民共和国” → `sheetTexts: ["中", "华", "人", "民", "共", "和", "国"], fillMode: "single-cell"`。此时 `text` 可留空，不要把所有字纵向填入同一个 Sheet。
- 用户只说单张字帖时不提供 `sheetTexts`，继续使用 `text`。一次最多生成 50 个 Sheet。
- 只有工具名称、没有练习文字时，生成空白字帖，不把工具名称写入田字格。
- 用户要求只填一个格子、其余留空，或“第一行第一列给一个字”时，`fillMode` 使用 `single-cell`，只在第一个田字格写一个字，不自动重复。示例：“红字贴，无间距，第一行第一列给一个字‘田’” → `text: "田", spacingMode: "none", fillMode: "single-cell"`。
- 用户说“每一行开头”“每行第一个格子”“第一列分别填上”等时，`fillMode` 必须使用 `row-head`：文字按顺序一字一行，只填每行首格，行内其他格子全部留空，禁止自动重复。例如“红字贴，单行间距，每一行开头分别填上‘天地洪荒宇宙’” → `text: "天地洪荒宇宙", spacingMode: "single", fillMode: "row-head"`。
- 用户说“全部填满”“整行填满”“所有格子都填”“每格都写”等时，`fillMode` 必须使用 `row-full`：每个字占一行，该行 13 个田字格全部写入该字。例如“无间距田字帖，内容‘中华人民共和国’全部填满” → `text: "中华人民共和国", spacingMode: "none", fillMode: "row-full"`。
- 用户未限定填写位置、直接提供练习文字或明确要求普通描红时，`fillMode` 使用 `row-repeat`：每个字占一行，一个深色示范字、六个浅色描红字、六个空白练习格。明确的整行填满、单格或行首要求优先于默认重复行为。
- 所有描红字都必须写入真实文字值，不使用 Excel 公式复制字符。
- 当前填写能力有空白（`text: ""`）、单格（`single-cell`）、每行行首（`row-head`）、普通描红（`row-repeat`）和整行填满（`row-full`）。
- 行列位置指田字格区域内的位置，不包含固定页边留白；无间距和单行间距的第一个田字格对应 Excel 的 B2，拼音字帖的 B2 是拼音格、其下方第一个田字格对应 B3。
- 输出文件名为 `<文字>-描红字帖.xlsx`；空白字帖使用 `空白描红字帖.xlsx`。
- 执行时优先使用当前工作表：当前表没有值、公式或对象时，直接在该表生成；当前表已有内容时，新建工作表，不覆盖原内容。只有样式的空表视为空表。

## 执行与输出

使用本包的 [生成脚本](scripts/generate.js)。标准 Excel Agent 在参数完整后调用 `execute_file`，传入 `path: "chinese-copybook/scripts/generate.js"` 以及包含 `text`、`sheetTexts`、`spacingMode`、`pinyinTexts`、`fillMode` 和 `fileName` 的 `args`；不要把脚本内容拷贝到 `execute_code`。Coco 执行扩展宿主也可选择唯一的 `generate` 资源，并在当前工作簿上调用同一脚本。本工具的 `documentAccess` 为 `current`，宿主没有当前 Excel 工作簿时应停止执行并提示用户先打开文档。执行配置、参数类型和 A4 导出设置位于 [Coco 执行扩展](app.json)。其他 Skill 宿主需要提供兼容的工作簿运行时。

脚本可在一次执行中生成多个 Sheet，每个 Sheet 独立生成 13 列练习格和 A4 打印区域，页首和页尾固定各一空行，左右各保留一列打印安全留白，避免最右侧边框落在打印区域边界而被裁剪。无间距容量为 19 个田字格行；单行间距使用 8pt 紧凑间隔，容量为 14 个田字格行；拼音字帖每组使用 24pt 四线三格拼音格、39.75pt 田字格和 8pt 组间隔，容量为 10 组。每行行首模式每字占一个田字格行；普通描红模式为一个示范字、六个真实文字描红格、六个空白练习格；整行填满模式将该字写入一行全部 13 格。单格模式容量为一个字；超出容量时截断，并通过返回值报告 `sheetNames`、`sheetCount`、`spacingMode`、`written`、`capacity` 和 `truncated`。

输出可编辑 `.xlsx`，使用 A4 纵向单页打印设置，保留 KaiTi 26pt、田字格行高 39.75pt 和与 WPS 校准后的列宽 5.889999866485596。田字格实线外框、中线以及拼音格四线三格均为锁定的可打印图形；单元格仍保留边框样式，确保编辑器和导出文件都能显示外框。
