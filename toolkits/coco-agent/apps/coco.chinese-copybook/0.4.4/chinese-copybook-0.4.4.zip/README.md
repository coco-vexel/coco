# 生成描红字帖 demo

本目录是兼容 Agent Skills 的工具包，名称与目录一致：

```text
chinese-copybook/
├── SKILL.md              # 标准 Skill：元信息、理解规则和使用说明
├── app.json              # 可选的 Coco 执行扩展，本包使用入口驱动
├── scripts/generate.js   # 在当前工作簿的空表或新表生成字帖
├── run-demo.mjs          # 本地离线 demo
└── README.md
```

名称、描述、版本和业务规则只维护在 `SKILL.md`。标准字段为 `name`、`description`、`compatibility`；`metadata.version` 保存版本，`metadata.coco.id` 保持安装 ID，`metadata.display-name` 提供中文展示名称。普通 Skill 加载器可以直接读取此文件；运行脚本需要 Coco Excel 工作簿 API，并非任意 Skill 宿主均可直接运行。

`app.json` 的 `schema: 2` 只声明 Coco 所需的目标文档、访问上下文、参数类型、对话默认值和执行入口。它不再重复声明名称、描述、版本或说明文件。三种布局统一使用 `generate` 入口，由 `spacingMode` 决定；动态 A4 打印区域由脚本通过 Excel SDK 写入，避免固定配置覆盖不同布局。执行器仍兼容旧 schema-1 工具包；纯说明 Skill 可由已有 SkillLoader 使用，不需要执行扩展。

标准 Agent 读取 `SKILL.md` 后，把自由对话转成 `{ text, sheetTexts?, spacingMode, pinyinTexts?, fillMode, fileName }`，再执行 `scripts/generate.js`。用户未指定间距模式时，Skill 要求 Agent 先调用 `ask_user` 询问，而不是让脚本先失败；拼音模式有文字时，由同一轮 LLM 生成逐字带声调拼音，脚本只负责排版。单张字帖使用 `text`；用户明确要求多张、每个字一张或每张换一个字时，`sheetTexts` 的每项生成一个独立 Sheet。工具要求宿主传入当前 Excel 工作簿：首张在当前 Sheet 为空时复用、有内容时新建，其余字帖新建 Sheet，并将结果写回同一工作簿。不包含、也不读取 Excel 模板。田字格实线外框、虚线中线、拼音四线三格和 A4 页面设置均通过 Coco Excel SDK 公共 API 写入，应用脚本不直接访问 OOXML/XML DOM。每个 Sheet 都有独立 A4 打印区域，页首和页尾各固定留一行；字帖可为无间距、紧凑单行间距或“上拼音格、下田字格”的拼音模式。

Web 工具列表和 `/tool` 共用同一包的元信息。Web 安装索引 `public/application-tools/index.json` 只保存包相对路径，不复制名称和说明。脚本布局与参数语义仍由本包维护。

从 `coco-engine` 目录运行：

```bash
corepack pnpm --filter @coco-office/application-tools build
node examples/application-tools/chinese-copybook/run-demo.mjs '用“天地玄黄”生成单行间距描红字帖'
node examples/application-tools/chinese-copybook/run-demo.mjs '为“中华人民共和国”每个字生成一张无间距字帖'
```

CLI 使用离线示例 planner，演示基础文字、间距和“每个字一张”参数。离线 demo 没有 `ask_user`，因此要求命令显式写出模式；真实宿主由 Agent 按 Skill 规则询问。工具包由市场下载安装，不再与 Web 站点源码维护第二份副本。
