---
name: coco-app-word-proofread
description: 校对错别字、标点、语病,默认走修订模式逐条标改。用户说'校对/查错别字/找错字/标点检查/语病'时用。
compatibility: Requires Coco Word with the workflow application runner.
metadata:
  coco.id: coco.word.proofread
  display-name: 校对
  version: "1.0.1"
---

# 校对

校对错别字、标点、语病,默认走修订模式逐条标改。用户说'校对/查错别字/找错字/标点检查/语病'时用。

## 执行规则

- 仅处理当前 Word 文档；存在选区时按工作流自身范围规则处理。
- 参数完整后调用 `execute_application`，应用 ID 为 `coco.word.proofread`，资源 ID 为 `run`。
- 不使用 `execute_code`、`execute_file` 或旧 Workflow 入口。
- 工作流弹出选择或确认时，等待用户完成交互后继续。
