---
name: coco-app-word-numbering-audit
description: 检查条款/标题的编号是否跳号、层级是否错乱、序号方案是否混用,给疑点加批注。用户说'查编号/编号校审/序号有没有错/核对条款号'时用。
compatibility: Requires Coco Word with the workflow application runner.
metadata:
  coco.id: coco.word.numbering-audit
  display-name: 编号校审
  version: "1.0.1"
---

# 编号校审

检查条款/标题的编号是否跳号、层级是否错乱、序号方案是否混用,给疑点加批注。用户说'查编号/编号校审/序号有没有错/核对条款号'时用。

## 执行规则

- 仅处理当前 Word 文档；存在选区时按工作流自身范围规则处理。
- 参数完整后调用 `execute_application`，应用 ID 为 `coco.word.numbering-audit`，资源 ID 为 `run`。
- 不使用 `execute_code`、`execute_file` 或旧 Workflow 入口。
- 工作流弹出选择或确认时，等待用户完成交互后继续。
