---
name: coco-copybook-local
display_name: Coco 描红字帖
display_name_en: Coco Tracing Copybook
description: 在本地生成可编辑的 Excel 描红字帖、田字格和拼音练习格。
description_zh: 用 WorkBuddy 桌面端生成可编辑的 A4 Excel 描红字帖。
description_en: Generate an editable A4 Excel tracing copybook in WorkBuddy Desktop.
examples_zh:
  - "用天地玄黄做一张无间距描红字帖"
  - "生成一张单行间距的空白田字格"
examples_en:
  - "Create a tracing sheet for 天地玄黄 with no gaps."
  - "Make a blank tracing grid with single-line spacing."
version: 0.2.1
author: Coco Office
---

使用本技能目录中的脚本在当前任务目录创建新的 XLSX 文件。

- `text` 是用户要练习的原文，空白字帖传空字符串。用户要求每张分别练习不同内容时传字符串数组 `sheetTexts`。
- `spacingMode` 必填。无间距用 `none`，单行间距用 `single`，拼音字帖用 `pinyin`。用户未选间距时先询问。
- `fillMode` 默认 `row-repeat`，对应每行 1 个示范字和 6 个描红字。整行填写用 `row-full`，只填每行行首用 `row-head`，只填第一个田字格用 `single-cell`。
- 拼音模式有练习文字时，根据原文提供逐字带声调的 `pinyinTexts` 字符串数组。

按当前系统选择一条命令。用 Skill 工具返回的实际 Base directory 替换示例路径。将输入编码为一行 JSON，正文里的换行用 JSON 的 `\n` 表示。

macOS 在任务目录运行下方命令，保留带单引号的 heredoc 标记。

```bash
/bin/sh "/实际技能目录/scripts/run.sh" <<'COCO_SKILL_INPUT'
{"text":"天地玄黄","spacingMode":"none","fillMode":"row-repeat"}
COCO_SKILL_INPUT
```

Windows 在任务目录使用 PowerShell。把 JSON 作为数据写入 UTF-8 临时文件，并保留 here-string 的单引号。

```powershell
$json = @'
{"text":"天地玄黄","spacingMode":"none","fillMode":"row-repeat"}
'@
$inputPath = Join-Path (Get-Location).Path ('.coco-input-' + [guid]::NewGuid() + '.json')
$workbuddy = Get-Process -Name WorkBuddy -ErrorAction SilentlyContinue |
    Where-Object Path | Select-Object -First 1 -ExpandProperty Path
$encoding = [Console]::OutputEncoding
try {
    [IO.File]::WriteAllText($inputPath, $json, [Text.UTF8Encoding]::new($false))
    [Console]::OutputEncoding = [Text.Encoding]::UTF8
    & 'C:\实际技能目录\scripts\run.cmd' $inputPath $workbuddy
    if ($LASTEXITCODE -ne 0) { throw 'Coco Skill failed.' }
} finally {
    [Console]::OutputEncoding = $encoding
    Remove-Item -LiteralPath $inputPath -ErrorAction SilentlyContinue
}
```

成功时直接把脚本输出的 Markdown 文件链接交给用户。失败时说明脚本报告的原因。
