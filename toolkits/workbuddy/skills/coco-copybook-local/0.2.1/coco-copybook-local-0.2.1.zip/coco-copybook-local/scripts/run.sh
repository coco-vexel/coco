#!/bin/sh
set -eu

# Use the system shell utilities and the desktop host's runtime.
PATH=/usr/bin:/bin:/usr/sbin:/sbin
export PATH
script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

for app in "/Applications/WorkBuddy.app" "$HOME/Applications/WorkBuddy.app"; do
  electron="$app/Contents/MacOS/Electron"
  if [ -x "$electron" ]; then
    printf '%s\n' 'Coco Skill runtime: WorkBuddy embedded Electron' >&2
    ELECTRON_RUN_AS_NODE=1
    export ELECTRON_RUN_AS_NODE
    exec "$electron" "$script_dir/run.mjs"
  fi
done

config_dir=${WORKBUDDY_CONFIG_DIR:-"$HOME/.workbuddy"}
for node in "$config_dir"/binaries/node/versions/*/bin/node "$config_dir"/binaries/node/versions/*/node.exe; do
  if [ -x "$node" ]; then
    printf '%s\n' 'Coco Skill runtime: WorkBuddy managed Node' >&2
    exec "$node" "$script_dir/run.mjs"
  fi
done

printf '%s\n' '当前 WorkBuddy 没有提供运行此技能所需的本地运行时。请使用新版 WorkBuddy 桌面客户端。' >&2
exit 1
