@echo off
setlocal EnableExtensions DisableDelayedExpansion

if "%~1"=="" (
  >&2 echo Usage: run.cmd path-to-input.json [path-to-WorkBuddy.exe]
  exit /b 2
)

set "WB_ELECTRON=%~2"
if not exist "%WB_ELECTRON%" set "WB_ELECTRON=%LOCALAPPDATA%\Programs\WorkBuddy\WorkBuddy.exe"
if not exist "%WB_ELECTRON%" set "WB_ELECTRON=%ProgramFiles%\WorkBuddy\WorkBuddy.exe"
if not exist "%WB_ELECTRON%" goto managed

>&2 echo Coco Skill runtime: WorkBuddy embedded Electron
set "ELECTRON_RUN_AS_NODE=1"
"%WB_ELECTRON%" "%~dp0run.mjs" --input-file "%~1"
exit /b %errorlevel%

:managed
if not defined WORKBUDDY_CONFIG_DIR set "WORKBUDDY_CONFIG_DIR=%USERPROFILE%\.workbuddy"
set "WB_NODE="
for /d %%V in ("%WORKBUDDY_CONFIG_DIR%\binaries\node\versions\*") do (
  if exist "%%~fV\node.exe" set "WB_NODE=%%~fV\node.exe"
  if exist "%%~fV\bin\node.exe" set "WB_NODE=%%~fV\bin\node.exe"
)
if not defined WB_NODE (
  >&2 echo WorkBuddy has no local runtime available for this Skill. Use an updated WorkBuddy desktop client.
  exit /b 1
)

>&2 echo Coco Skill runtime: WorkBuddy managed Node
"%WB_NODE%" "%~dp0run.mjs" --input-file "%~1"
exit /b %errorlevel%
