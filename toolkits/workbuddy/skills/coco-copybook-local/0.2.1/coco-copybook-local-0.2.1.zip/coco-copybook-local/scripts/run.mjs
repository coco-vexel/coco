import { createRequire as cocoCreateRequire } from "node:module"; const require = cocoCreateRequire(import.meta.url);
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __require = /* @__PURE__ */ ((x2) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x2, {
  get: (a2, b2) => (typeof require !== "undefined" ? require : a2)[b2]
}) : x2)(function(x2) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x2 + '" is not supported');
});
var __esm = (fn2, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn2 && (res = (0, fn2[__getOwnPropNames(fn2)[0]])(fn2 = 0)), res;
  } catch (e2) {
    throw err = [e2], e2;
  }
};
var __commonJS = (cb, mod) => function __require2() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e2) {
    throw mod = 0, e2;
  }
};
var __copyProps = (to2, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key2 of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to2, key2) && key2 !== except)
        __defProp(to2, key2, { get: () => from[key2], enumerable: !(desc = __getOwnPropDesc(from, key2)) || desc.enumerable });
  }
  return to2;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// <define:COCO_TOOL_CONFIG>
var define_COCO_TOOL_CONFIG_default;
var init_define_COCO_TOOL_CONFIG = __esm({
  "<define:COCO_TOOL_CONFIG>"() {
    define_COCO_TOOL_CONFIG_default = { schema: 2, targets: ["excel"], documentAccess: "current", entry: "generate", inputs: [{ name: "text", type: "string", label: "\u7EC3\u4E60\u6587\u5B57", description: "\u53EA\u586B\u5199\u7528\u6237\u660E\u786E\u8981\u6C42\u5199\u5165\u7530\u5B57\u683C\u7684\u6587\u5B57\uFF1B\u53EA\u6709\u5DE5\u5177\u540D\u79F0\u65F6\u4F7F\u7528\u7A7A\u5B57\u7B26\u4E32", default: "" }, { name: "sheetTexts", type: "string-array", label: "\u591A\u5F20\u5B57\u5E16\u6587\u5B57", description: '\u53EA\u5728\u7528\u6237\u660E\u786E\u8981\u6C42\u591A\u5F20\u3001\u6BCF\u4E2A\u5B57\u4E00\u5F20\u6216\u6BCF\u5F20\u6362\u4E00\u4E2A\u6587\u5B57\u65F6\u4F7F\u7528\u5B57\u7B26\u4E32\u6570\u7EC4\uFF0C\u6570\u7EC4\u6BCF\u9879\u5BF9\u5E94\u4E00\u4E2A Sheet\u3002\u4F8B\u5982\u201C\u6BCF\u5F20\u6362\u4E00\u4E2A\uFF0C\u4E3A\u4E2D\u534E\u4EBA\u6C11\u5171\u548C\u56FD\u201D\u4F7F\u7528 ["\u4E2D","\u534E","\u4EBA","\u6C11","\u5171","\u548C","\u56FD"]\uFF1B\u5355\u5F20\u65F6\u4E0D\u63D0\u4F9B\u6B64\u53C2\u6570' }, { name: "spacingMode", type: "string", label: "\u95F4\u8DDD\u6A21\u5F0F", description: "none \u8868\u793A\u7530\u5B57\u683C\u8FDE\u7EED\u6392\u5217\uFF1Bsingle \u8868\u793A\u7530\u5B57\u683C\u4E4B\u95F4\u7559\u4E00\u4E2A\u7D27\u51D1\u7EC3\u4E60\u95F4\u9694\uFF1Bpinyin \u8868\u793A\u6BCF\u7EC4\u4E0A\u65B9\u4E3A\u56DB\u7EBF\u4E09\u683C\u62FC\u97F3\u683C\u3001\u4E0B\u65B9\u4E3A\u7530\u5B57\u683C\u3002\u7528\u6237\u672A\u660E\u786E\u6A21\u5F0F\u65F6\u5FC5\u987B\u5148\u8C03\u7528 ask_user\uFF0C\u4E0D\u5F97\u81EA\u884C\u9009\u62E9", options: ["none", "single", "pinyin"], required: true }, { name: "pinyinTexts", type: "string-array", label: "\u9010\u5B57\u62FC\u97F3", description: "\u4EC5\u5728 pinyin \u6A21\u5F0F\u4E14\u6709\u7EC3\u4E60\u6587\u5B57\u65F6\u63D0\u4F9B\u3002\u6570\u7EC4\u6309\u7EC3\u4E60\u6587\u5B57\u9010\u5B57\u5BF9\u5E94\uFF0C\u4F7F\u7528\u5E26\u58F0\u8C03\u62FC\u97F3\uFF0C\u4F8B\u5982\u2018\u5929\u5730\u2019\u4F9D\u6B21\u4F7F\u7528 ti\u0101n\u3001d\xEC\uFF1B\u591A\u97F3\u5B57\u6309\u7528\u6237\u8BED\u5883\u9009\u62E9\u3002\u7A7A\u767D\u62FC\u97F3\u5B57\u5E16\u4E0D\u63D0\u4F9B" }, { name: "fillMode", type: "string", label: "\u6587\u5B57\u586B\u5199\u65B9\u5F0F", description: "row-full \u8868\u793A\u6BCF\u4E2A\u5B57\u5360\u4E00\u884C\u4E14\u6574\u884C 13 \u4E2A\u7530\u5B57\u683C\u5168\u90E8\u586B\u6EE1\uFF1B\u7528\u6237\u8BF4\u5168\u90E8\u586B\u6EE1\u3001\u6574\u884C\u586B\u6EE1\u3001\u6240\u6709\u683C\u5B50\u90FD\u586B\u65F6\u5FC5\u987B\u4F7F\u7528 row-full\u3002row-head \u8868\u793A\u6587\u5B57\u4F9D\u6B21\u53EA\u5199\u5728\u6BCF\u884C\u7B2C\u4E00\u4E2A\u7530\u5B57\u683C\uFF0C\u884C\u5185\u5176\u4F59\u683C\u5B50\u7559\u7A7A\u3002single-cell \u8868\u793A\u53EA\u5728\u7B2C\u4E00\u4E2A\u7530\u5B57\u683C\u586B\u5199\u4E00\u4E2A\u5B57\u3001\u5176\u4F59\u5168\u90E8\u7559\u7A7A\u3002row-repeat \u8868\u793A\u6BCF\u4E2A\u5B57\u5360\u4E00\u884C\uFF0C\u586B\u5199\u793A\u8303\u5B57\u548C\u516D\u4E2A\u63CF\u7EA2\u5B57\uFF0C\u540E\u516D\u683C\u7559\u7A7A\uFF1B\u672A\u9650\u5B9A\u586B\u5199\u4F4D\u7F6E\u65F6\u9ED8\u8BA4\u6B64\u9879\u3002\u6240\u6709\u91CD\u590D\u6587\u5B57\u5747\u5199\u5165\u771F\u5B9E\u503C\uFF0C\u4E0D\u4F7F\u7528\u516C\u5F0F", options: ["row-repeat", "row-full", "row-head", "single-cell"], default: "row-repeat" }, { name: "fileName", type: "string", label: "\u8F93\u51FA\u6587\u4EF6\u540D", description: "\u6709\u6587\u5B57\u65F6\u4E3A <\u6587\u5B57>-\u63CF\u7EA2\u5B57\u5E16.xlsx\uFF0C\u65E0\u6587\u5B57\u65F6\u4E3A\u7A7A\u767D\u63CF\u7EA2\u5B57\u5E16.xlsx" }], conversation: { placeholder: "\u8F93\u5165\u60F3\u7EC3\u4E60\u7684\u6587\u5B57\uFF0C\u6216\u76F4\u63A5\u63CF\u8FF0\u5B57\u5E16\u8981\u6C42", examples: ["\u751F\u6210\u4E00\u5F20\u7A7A\u767D\u7530\u5B57\u683C", "\u7528\u201C\u5929\u5730\u7384\u9EC4\u201D\u751F\u6210\u63CF\u7EA2\u5B57\u5E16", "\u4E3A\u201C\u4E2D\u534E\u4EBA\u6C11\u5171\u548C\u56FD\u201D\u6BCF\u4E2A\u5B57\u751F\u6210\u4E00\u5F20\u5B57\u5E16", "\u7528\u201C\u6C38\u201D\u751F\u6210\u65E0\u95F4\u8DDD\u5B57\u5E16"], defaultInput: "\u751F\u6210\u4E00\u5F20\u7A7A\u767D\u63CF\u7EA2\u5B57\u5E16", aliases: ["\u63CF\u7EA2", "\u63CF\u8D34", "\u63CF\u7EA2\u5B57\u5E16", "\u63CF\u8D34\u5B57\u5E16", "\u751F\u6210\u63CF\u7EA2", "\u751F\u6210\u63CF\u8D34"] }, resources: { generate: { type: "excel-script", source: "scripts/generate.js" } } };
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/process-nextick-args/index.js
var require_process_nextick_args = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/process-nextick-args/index.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    if (typeof process === "undefined" || !process.version || process.version.indexOf("v0.") === 0 || process.version.indexOf("v1.") === 0 && process.version.indexOf("v1.8.") !== 0) {
      module.exports = { nextTick };
    } else {
      module.exports = process;
    }
    function nextTick(fn2, arg1, arg2, arg3) {
      if (typeof fn2 !== "function") {
        throw new TypeError('"callback" argument must be a function');
      }
      var len = arguments.length;
      var args, i2;
      switch (len) {
        case 0:
        case 1:
          return process.nextTick(fn2);
        case 2:
          return process.nextTick(function afterTickOne() {
            fn2.call(null, arg1);
          });
        case 3:
          return process.nextTick(function afterTickTwo() {
            fn2.call(null, arg1, arg2);
          });
        case 4:
          return process.nextTick(function afterTickThree() {
            fn2.call(null, arg1, arg2, arg3);
          });
        default:
          args = new Array(len - 1);
          i2 = 0;
          while (i2 < args.length) {
            args[i2++] = arguments[i2];
          }
          return process.nextTick(function afterTick() {
            fn2.apply(null, args);
          });
      }
    }
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/isarray/index.js
var require_isarray = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/isarray/index.js"(exports, module) {
    init_define_COCO_TOOL_CONFIG();
    var toString = {}.toString;
    module.exports = Array.isArray || function(arr) {
      return toString.call(arr) == "[object Array]";
    };
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/readable-stream/lib/internal/streams/stream.js
var require_stream = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/readable-stream/lib/internal/streams/stream.js"(exports, module) {
    init_define_COCO_TOOL_CONFIG();
    module.exports = __require("stream");
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/safe-buffer/index.js
var require_safe_buffer = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/safe-buffer/index.js"(exports, module) {
    init_define_COCO_TOOL_CONFIG();
    var buffer = __require("buffer");
    var Buffer2 = buffer.Buffer;
    function copyProps(src, dst) {
      for (var key2 in src) {
        dst[key2] = src[key2];
      }
    }
    if (Buffer2.from && Buffer2.alloc && Buffer2.allocUnsafe && Buffer2.allocUnsafeSlow) {
      module.exports = buffer;
    } else {
      copyProps(buffer, exports);
      exports.Buffer = SafeBuffer;
    }
    function SafeBuffer(arg, encodingOrOffset, length) {
      return Buffer2(arg, encodingOrOffset, length);
    }
    copyProps(Buffer2, SafeBuffer);
    SafeBuffer.from = function(arg, encodingOrOffset, length) {
      if (typeof arg === "number") {
        throw new TypeError("Argument must not be a number");
      }
      return Buffer2(arg, encodingOrOffset, length);
    };
    SafeBuffer.alloc = function(size, fill, encoding) {
      if (typeof size !== "number") {
        throw new TypeError("Argument must be a number");
      }
      var buf = Buffer2(size);
      if (fill !== void 0) {
        if (typeof encoding === "string") {
          buf.fill(fill, encoding);
        } else {
          buf.fill(fill);
        }
      } else {
        buf.fill(0);
      }
      return buf;
    };
    SafeBuffer.allocUnsafe = function(size) {
      if (typeof size !== "number") {
        throw new TypeError("Argument must be a number");
      }
      return Buffer2(size);
    };
    SafeBuffer.allocUnsafeSlow = function(size) {
      if (typeof size !== "number") {
        throw new TypeError("Argument must be a number");
      }
      return buffer.SlowBuffer(size);
    };
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/core-util-is/lib/util.js
var require_util = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/core-util-is/lib/util.js"(exports) {
    init_define_COCO_TOOL_CONFIG();
    function isArray(arg) {
      if (Array.isArray) {
        return Array.isArray(arg);
      }
      return objectToString(arg) === "[object Array]";
    }
    exports.isArray = isArray;
    function isBoolean(arg) {
      return typeof arg === "boolean";
    }
    exports.isBoolean = isBoolean;
    function isNull(arg) {
      return arg === null;
    }
    exports.isNull = isNull;
    function isNullOrUndefined(arg) {
      return arg == null;
    }
    exports.isNullOrUndefined = isNullOrUndefined;
    function isNumber(arg) {
      return typeof arg === "number";
    }
    exports.isNumber = isNumber;
    function isString(arg) {
      return typeof arg === "string";
    }
    exports.isString = isString;
    function isSymbol(arg) {
      return typeof arg === "symbol";
    }
    exports.isSymbol = isSymbol;
    function isUndefined(arg) {
      return arg === void 0;
    }
    exports.isUndefined = isUndefined;
    function isRegExp(re2) {
      return objectToString(re2) === "[object RegExp]";
    }
    exports.isRegExp = isRegExp;
    function isObject(arg) {
      return typeof arg === "object" && arg !== null;
    }
    exports.isObject = isObject;
    function isDate(d2) {
      return objectToString(d2) === "[object Date]";
    }
    exports.isDate = isDate;
    function isError(e2) {
      return objectToString(e2) === "[object Error]" || e2 instanceof Error;
    }
    exports.isError = isError;
    function isFunction(arg) {
      return typeof arg === "function";
    }
    exports.isFunction = isFunction;
    function isPrimitive(arg) {
      return arg === null || typeof arg === "boolean" || typeof arg === "number" || typeof arg === "string" || typeof arg === "symbol" || // ES6 symbol
      typeof arg === "undefined";
    }
    exports.isPrimitive = isPrimitive;
    exports.isBuffer = __require("buffer").Buffer.isBuffer;
    function objectToString(o2) {
      return Object.prototype.toString.call(o2);
    }
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/inherits/inherits_browser.js
var require_inherits_browser = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/inherits/inherits_browser.js"(exports, module) {
    init_define_COCO_TOOL_CONFIG();
    if (typeof Object.create === "function") {
      module.exports = function inherits(ctor, superCtor) {
        if (superCtor) {
          ctor.super_ = superCtor;
          ctor.prototype = Object.create(superCtor.prototype, {
            constructor: {
              value: ctor,
              enumerable: false,
              writable: true,
              configurable: true
            }
          });
        }
      };
    } else {
      module.exports = function inherits(ctor, superCtor) {
        if (superCtor) {
          ctor.super_ = superCtor;
          var TempCtor = function() {
          };
          TempCtor.prototype = superCtor.prototype;
          ctor.prototype = new TempCtor();
          ctor.prototype.constructor = ctor;
        }
      };
    }
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/inherits/inherits.js
var require_inherits = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/inherits/inherits.js"(exports, module) {
    init_define_COCO_TOOL_CONFIG();
    try {
      util = __require("util");
      if (typeof util.inherits !== "function") throw "";
      module.exports = util.inherits;
    } catch (e2) {
      module.exports = require_inherits_browser();
    }
    var util;
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/readable-stream/lib/internal/streams/BufferList.js
var require_BufferList = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/readable-stream/lib/internal/streams/BufferList.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    function _classCallCheck(instance, Constructor) {
      if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
      }
    }
    var Buffer2 = require_safe_buffer().Buffer;
    var util = __require("util");
    function copyBuffer(src, target, offset) {
      src.copy(target, offset);
    }
    module.exports = (function() {
      function BufferList() {
        _classCallCheck(this, BufferList);
        this.head = null;
        this.tail = null;
        this.length = 0;
      }
      BufferList.prototype.push = function push(v2) {
        var entry = { data: v2, next: null };
        if (this.length > 0) this.tail.next = entry;
        else this.head = entry;
        this.tail = entry;
        ++this.length;
      };
      BufferList.prototype.unshift = function unshift(v2) {
        var entry = { data: v2, next: this.head };
        if (this.length === 0) this.tail = entry;
        this.head = entry;
        ++this.length;
      };
      BufferList.prototype.shift = function shift() {
        if (this.length === 0) return;
        var ret = this.head.data;
        if (this.length === 1) this.head = this.tail = null;
        else this.head = this.head.next;
        --this.length;
        return ret;
      };
      BufferList.prototype.clear = function clear() {
        this.head = this.tail = null;
        this.length = 0;
      };
      BufferList.prototype.join = function join2(s2) {
        if (this.length === 0) return "";
        var p2 = this.head;
        var ret = "" + p2.data;
        while (p2 = p2.next) {
          ret += s2 + p2.data;
        }
        return ret;
      };
      BufferList.prototype.concat = function concat(n2) {
        if (this.length === 0) return Buffer2.alloc(0);
        var ret = Buffer2.allocUnsafe(n2 >>> 0);
        var p2 = this.head;
        var i2 = 0;
        while (p2) {
          copyBuffer(p2.data, ret, i2);
          i2 += p2.data.length;
          p2 = p2.next;
        }
        return ret;
      };
      return BufferList;
    })();
    if (util && util.inspect && util.inspect.custom) {
      module.exports.prototype[util.inspect.custom] = function() {
        var obj = util.inspect({ length: this.length });
        return this.constructor.name + " " + obj;
      };
    }
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/readable-stream/lib/internal/streams/destroy.js
var require_destroy = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/readable-stream/lib/internal/streams/destroy.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var pna = require_process_nextick_args();
    function destroy(err, cb) {
      var _this = this;
      var readableDestroyed = this._readableState && this._readableState.destroyed;
      var writableDestroyed = this._writableState && this._writableState.destroyed;
      if (readableDestroyed || writableDestroyed) {
        if (cb) {
          cb(err);
        } else if (err) {
          if (!this._writableState) {
            pna.nextTick(emitErrorNT, this, err);
          } else if (!this._writableState.errorEmitted) {
            this._writableState.errorEmitted = true;
            pna.nextTick(emitErrorNT, this, err);
          }
        }
        return this;
      }
      if (this._readableState) {
        this._readableState.destroyed = true;
      }
      if (this._writableState) {
        this._writableState.destroyed = true;
      }
      this._destroy(err || null, function(err2) {
        if (!cb && err2) {
          if (!_this._writableState) {
            pna.nextTick(emitErrorNT, _this, err2);
          } else if (!_this._writableState.errorEmitted) {
            _this._writableState.errorEmitted = true;
            pna.nextTick(emitErrorNT, _this, err2);
          }
        } else if (cb) {
          cb(err2);
        }
      });
      return this;
    }
    function undestroy() {
      if (this._readableState) {
        this._readableState.destroyed = false;
        this._readableState.reading = false;
        this._readableState.ended = false;
        this._readableState.endEmitted = false;
      }
      if (this._writableState) {
        this._writableState.destroyed = false;
        this._writableState.ended = false;
        this._writableState.ending = false;
        this._writableState.finalCalled = false;
        this._writableState.prefinished = false;
        this._writableState.finished = false;
        this._writableState.errorEmitted = false;
      }
    }
    function emitErrorNT(self2, err) {
      self2.emit("error", err);
    }
    module.exports = {
      destroy,
      undestroy
    };
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/util-deprecate/node.js
var require_node = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/util-deprecate/node.js"(exports, module) {
    init_define_COCO_TOOL_CONFIG();
    module.exports = __require("util").deprecate;
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/readable-stream/lib/_stream_writable.js
var require_stream_writable = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/readable-stream/lib/_stream_writable.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var pna = require_process_nextick_args();
    module.exports = Writable;
    function CorkedRequest(state) {
      var _this = this;
      this.next = null;
      this.entry = null;
      this.finish = function() {
        onCorkedFinish(_this, state);
      };
    }
    var asyncWrite = !process.browser && ["v0.10", "v0.9."].indexOf(process.version.slice(0, 5)) > -1 ? setImmediate : pna.nextTick;
    var Duplex;
    Writable.WritableState = WritableState;
    var util = Object.create(require_util());
    util.inherits = require_inherits();
    var internalUtil = {
      deprecate: require_node()
    };
    var Stream = require_stream();
    var Buffer2 = require_safe_buffer().Buffer;
    var OurUint8Array = (typeof global !== "undefined" ? global : typeof window !== "undefined" ? window : typeof self !== "undefined" ? self : {}).Uint8Array || function() {
    };
    function _uint8ArrayToBuffer(chunk) {
      return Buffer2.from(chunk);
    }
    function _isUint8Array(obj) {
      return Buffer2.isBuffer(obj) || obj instanceof OurUint8Array;
    }
    var destroyImpl = require_destroy();
    util.inherits(Writable, Stream);
    function nop() {
    }
    function WritableState(options, stream) {
      Duplex = Duplex || require_stream_duplex();
      options = options || {};
      var isDuplex = stream instanceof Duplex;
      this.objectMode = !!options.objectMode;
      if (isDuplex) this.objectMode = this.objectMode || !!options.writableObjectMode;
      var hwm = options.highWaterMark;
      var writableHwm = options.writableHighWaterMark;
      var defaultHwm = this.objectMode ? 16 : 16 * 1024;
      if (hwm || hwm === 0) this.highWaterMark = hwm;
      else if (isDuplex && (writableHwm || writableHwm === 0)) this.highWaterMark = writableHwm;
      else this.highWaterMark = defaultHwm;
      this.highWaterMark = Math.floor(this.highWaterMark);
      this.finalCalled = false;
      this.needDrain = false;
      this.ending = false;
      this.ended = false;
      this.finished = false;
      this.destroyed = false;
      var noDecode = options.decodeStrings === false;
      this.decodeStrings = !noDecode;
      this.defaultEncoding = options.defaultEncoding || "utf8";
      this.length = 0;
      this.writing = false;
      this.corked = 0;
      this.sync = true;
      this.bufferProcessing = false;
      this.onwrite = function(er2) {
        onwrite(stream, er2);
      };
      this.writecb = null;
      this.writelen = 0;
      this.bufferedRequest = null;
      this.lastBufferedRequest = null;
      this.pendingcb = 0;
      this.prefinished = false;
      this.errorEmitted = false;
      this.bufferedRequestCount = 0;
      this.corkedRequestsFree = new CorkedRequest(this);
    }
    WritableState.prototype.getBuffer = function getBuffer() {
      var current = this.bufferedRequest;
      var out = [];
      while (current) {
        out.push(current);
        current = current.next;
      }
      return out;
    };
    (function() {
      try {
        Object.defineProperty(WritableState.prototype, "buffer", {
          get: internalUtil.deprecate(function() {
            return this.getBuffer();
          }, "_writableState.buffer is deprecated. Use _writableState.getBuffer instead.", "DEP0003")
        });
      } catch (_2) {
      }
    })();
    var realHasInstance;
    if (typeof Symbol === "function" && Symbol.hasInstance && typeof Function.prototype[Symbol.hasInstance] === "function") {
      realHasInstance = Function.prototype[Symbol.hasInstance];
      Object.defineProperty(Writable, Symbol.hasInstance, {
        value: function(object) {
          if (realHasInstance.call(this, object)) return true;
          if (this !== Writable) return false;
          return object && object._writableState instanceof WritableState;
        }
      });
    } else {
      realHasInstance = function(object) {
        return object instanceof this;
      };
    }
    function Writable(options) {
      Duplex = Duplex || require_stream_duplex();
      if (!realHasInstance.call(Writable, this) && !(this instanceof Duplex)) {
        return new Writable(options);
      }
      this._writableState = new WritableState(options, this);
      this.writable = true;
      if (options) {
        if (typeof options.write === "function") this._write = options.write;
        if (typeof options.writev === "function") this._writev = options.writev;
        if (typeof options.destroy === "function") this._destroy = options.destroy;
        if (typeof options.final === "function") this._final = options.final;
      }
      Stream.call(this);
    }
    Writable.prototype.pipe = function() {
      this.emit("error", new Error("Cannot pipe, not readable"));
    };
    function writeAfterEnd(stream, cb) {
      var er2 = new Error("write after end");
      stream.emit("error", er2);
      pna.nextTick(cb, er2);
    }
    function validChunk(stream, state, chunk, cb) {
      var valid = true;
      var er2 = false;
      if (chunk === null) {
        er2 = new TypeError("May not write null values to stream");
      } else if (typeof chunk !== "string" && chunk !== void 0 && !state.objectMode) {
        er2 = new TypeError("Invalid non-string/buffer chunk");
      }
      if (er2) {
        stream.emit("error", er2);
        pna.nextTick(cb, er2);
        valid = false;
      }
      return valid;
    }
    Writable.prototype.write = function(chunk, encoding, cb) {
      var state = this._writableState;
      var ret = false;
      var isBuf = !state.objectMode && _isUint8Array(chunk);
      if (isBuf && !Buffer2.isBuffer(chunk)) {
        chunk = _uint8ArrayToBuffer(chunk);
      }
      if (typeof encoding === "function") {
        cb = encoding;
        encoding = null;
      }
      if (isBuf) encoding = "buffer";
      else if (!encoding) encoding = state.defaultEncoding;
      if (typeof cb !== "function") cb = nop;
      if (state.ended) writeAfterEnd(this, cb);
      else if (isBuf || validChunk(this, state, chunk, cb)) {
        state.pendingcb++;
        ret = writeOrBuffer(this, state, isBuf, chunk, encoding, cb);
      }
      return ret;
    };
    Writable.prototype.cork = function() {
      var state = this._writableState;
      state.corked++;
    };
    Writable.prototype.uncork = function() {
      var state = this._writableState;
      if (state.corked) {
        state.corked--;
        if (!state.writing && !state.corked && !state.bufferProcessing && state.bufferedRequest) clearBuffer(this, state);
      }
    };
    Writable.prototype.setDefaultEncoding = function setDefaultEncoding(encoding) {
      if (typeof encoding === "string") encoding = encoding.toLowerCase();
      if (!(["hex", "utf8", "utf-8", "ascii", "binary", "base64", "ucs2", "ucs-2", "utf16le", "utf-16le", "raw"].indexOf((encoding + "").toLowerCase()) > -1)) throw new TypeError("Unknown encoding: " + encoding);
      this._writableState.defaultEncoding = encoding;
      return this;
    };
    function decodeChunk(state, chunk, encoding) {
      if (!state.objectMode && state.decodeStrings !== false && typeof chunk === "string") {
        chunk = Buffer2.from(chunk, encoding);
      }
      return chunk;
    }
    Object.defineProperty(Writable.prototype, "writableHighWaterMark", {
      // making it explicit this property is not enumerable
      // because otherwise some prototype manipulation in
      // userland will fail
      enumerable: false,
      get: function() {
        return this._writableState.highWaterMark;
      }
    });
    function writeOrBuffer(stream, state, isBuf, chunk, encoding, cb) {
      if (!isBuf) {
        var newChunk = decodeChunk(state, chunk, encoding);
        if (chunk !== newChunk) {
          isBuf = true;
          encoding = "buffer";
          chunk = newChunk;
        }
      }
      var len = state.objectMode ? 1 : chunk.length;
      state.length += len;
      var ret = state.length < state.highWaterMark;
      if (!ret) state.needDrain = true;
      if (state.writing || state.corked) {
        var last = state.lastBufferedRequest;
        state.lastBufferedRequest = {
          chunk,
          encoding,
          isBuf,
          callback: cb,
          next: null
        };
        if (last) {
          last.next = state.lastBufferedRequest;
        } else {
          state.bufferedRequest = state.lastBufferedRequest;
        }
        state.bufferedRequestCount += 1;
      } else {
        doWrite(stream, state, false, len, chunk, encoding, cb);
      }
      return ret;
    }
    function doWrite(stream, state, writev, len, chunk, encoding, cb) {
      state.writelen = len;
      state.writecb = cb;
      state.writing = true;
      state.sync = true;
      if (writev) stream._writev(chunk, state.onwrite);
      else stream._write(chunk, encoding, state.onwrite);
      state.sync = false;
    }
    function onwriteError(stream, state, sync, er2, cb) {
      --state.pendingcb;
      if (sync) {
        pna.nextTick(cb, er2);
        pna.nextTick(finishMaybe, stream, state);
        stream._writableState.errorEmitted = true;
        stream.emit("error", er2);
      } else {
        cb(er2);
        stream._writableState.errorEmitted = true;
        stream.emit("error", er2);
        finishMaybe(stream, state);
      }
    }
    function onwriteStateUpdate(state) {
      state.writing = false;
      state.writecb = null;
      state.length -= state.writelen;
      state.writelen = 0;
    }
    function onwrite(stream, er2) {
      var state = stream._writableState;
      var sync = state.sync;
      var cb = state.writecb;
      onwriteStateUpdate(state);
      if (er2) onwriteError(stream, state, sync, er2, cb);
      else {
        var finished = needFinish(state);
        if (!finished && !state.corked && !state.bufferProcessing && state.bufferedRequest) {
          clearBuffer(stream, state);
        }
        if (sync) {
          asyncWrite(afterWrite, stream, state, finished, cb);
        } else {
          afterWrite(stream, state, finished, cb);
        }
      }
    }
    function afterWrite(stream, state, finished, cb) {
      if (!finished) onwriteDrain(stream, state);
      state.pendingcb--;
      cb();
      finishMaybe(stream, state);
    }
    function onwriteDrain(stream, state) {
      if (state.length === 0 && state.needDrain) {
        state.needDrain = false;
        stream.emit("drain");
      }
    }
    function clearBuffer(stream, state) {
      state.bufferProcessing = true;
      var entry = state.bufferedRequest;
      if (stream._writev && entry && entry.next) {
        var l2 = state.bufferedRequestCount;
        var buffer = new Array(l2);
        var holder = state.corkedRequestsFree;
        holder.entry = entry;
        var count = 0;
        var allBuffers = true;
        while (entry) {
          buffer[count] = entry;
          if (!entry.isBuf) allBuffers = false;
          entry = entry.next;
          count += 1;
        }
        buffer.allBuffers = allBuffers;
        doWrite(stream, state, true, state.length, buffer, "", holder.finish);
        state.pendingcb++;
        state.lastBufferedRequest = null;
        if (holder.next) {
          state.corkedRequestsFree = holder.next;
          holder.next = null;
        } else {
          state.corkedRequestsFree = new CorkedRequest(state);
        }
        state.bufferedRequestCount = 0;
      } else {
        while (entry) {
          var chunk = entry.chunk;
          var encoding = entry.encoding;
          var cb = entry.callback;
          var len = state.objectMode ? 1 : chunk.length;
          doWrite(stream, state, false, len, chunk, encoding, cb);
          entry = entry.next;
          state.bufferedRequestCount--;
          if (state.writing) {
            break;
          }
        }
        if (entry === null) state.lastBufferedRequest = null;
      }
      state.bufferedRequest = entry;
      state.bufferProcessing = false;
    }
    Writable.prototype._write = function(chunk, encoding, cb) {
      cb(new Error("_write() is not implemented"));
    };
    Writable.prototype._writev = null;
    Writable.prototype.end = function(chunk, encoding, cb) {
      var state = this._writableState;
      if (typeof chunk === "function") {
        cb = chunk;
        chunk = null;
        encoding = null;
      } else if (typeof encoding === "function") {
        cb = encoding;
        encoding = null;
      }
      if (chunk !== null && chunk !== void 0) this.write(chunk, encoding);
      if (state.corked) {
        state.corked = 1;
        this.uncork();
      }
      if (!state.ending) endWritable(this, state, cb);
    };
    function needFinish(state) {
      return state.ending && state.length === 0 && state.bufferedRequest === null && !state.finished && !state.writing;
    }
    function callFinal(stream, state) {
      stream._final(function(err) {
        state.pendingcb--;
        if (err) {
          stream.emit("error", err);
        }
        state.prefinished = true;
        stream.emit("prefinish");
        finishMaybe(stream, state);
      });
    }
    function prefinish(stream, state) {
      if (!state.prefinished && !state.finalCalled) {
        if (typeof stream._final === "function") {
          state.pendingcb++;
          state.finalCalled = true;
          pna.nextTick(callFinal, stream, state);
        } else {
          state.prefinished = true;
          stream.emit("prefinish");
        }
      }
    }
    function finishMaybe(stream, state) {
      var need = needFinish(state);
      if (need) {
        prefinish(stream, state);
        if (state.pendingcb === 0) {
          state.finished = true;
          stream.emit("finish");
        }
      }
      return need;
    }
    function endWritable(stream, state, cb) {
      state.ending = true;
      finishMaybe(stream, state);
      if (cb) {
        if (state.finished) pna.nextTick(cb);
        else stream.once("finish", cb);
      }
      state.ended = true;
      stream.writable = false;
    }
    function onCorkedFinish(corkReq, state, err) {
      var entry = corkReq.entry;
      corkReq.entry = null;
      while (entry) {
        var cb = entry.callback;
        state.pendingcb--;
        cb(err);
        entry = entry.next;
      }
      state.corkedRequestsFree.next = corkReq;
    }
    Object.defineProperty(Writable.prototype, "destroyed", {
      get: function() {
        if (this._writableState === void 0) {
          return false;
        }
        return this._writableState.destroyed;
      },
      set: function(value) {
        if (!this._writableState) {
          return;
        }
        this._writableState.destroyed = value;
      }
    });
    Writable.prototype.destroy = destroyImpl.destroy;
    Writable.prototype._undestroy = destroyImpl.undestroy;
    Writable.prototype._destroy = function(err, cb) {
      this.end();
      cb(err);
    };
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/readable-stream/lib/_stream_duplex.js
var require_stream_duplex = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/readable-stream/lib/_stream_duplex.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var pna = require_process_nextick_args();
    var objectKeys = Object.keys || function(obj) {
      var keys2 = [];
      for (var key2 in obj) {
        keys2.push(key2);
      }
      return keys2;
    };
    module.exports = Duplex;
    var util = Object.create(require_util());
    util.inherits = require_inherits();
    var Readable = require_stream_readable();
    var Writable = require_stream_writable();
    util.inherits(Duplex, Readable);
    {
      keys = objectKeys(Writable.prototype);
      for (v2 = 0; v2 < keys.length; v2++) {
        method = keys[v2];
        if (!Duplex.prototype[method]) Duplex.prototype[method] = Writable.prototype[method];
      }
    }
    var keys;
    var method;
    var v2;
    function Duplex(options) {
      if (!(this instanceof Duplex)) return new Duplex(options);
      Readable.call(this, options);
      Writable.call(this, options);
      if (options && options.readable === false) this.readable = false;
      if (options && options.writable === false) this.writable = false;
      this.allowHalfOpen = true;
      if (options && options.allowHalfOpen === false) this.allowHalfOpen = false;
      this.once("end", onend);
    }
    Object.defineProperty(Duplex.prototype, "writableHighWaterMark", {
      // making it explicit this property is not enumerable
      // because otherwise some prototype manipulation in
      // userland will fail
      enumerable: false,
      get: function() {
        return this._writableState.highWaterMark;
      }
    });
    function onend() {
      if (this.allowHalfOpen || this._writableState.ended) return;
      pna.nextTick(onEndNT, this);
    }
    function onEndNT(self2) {
      self2.end();
    }
    Object.defineProperty(Duplex.prototype, "destroyed", {
      get: function() {
        if (this._readableState === void 0 || this._writableState === void 0) {
          return false;
        }
        return this._readableState.destroyed && this._writableState.destroyed;
      },
      set: function(value) {
        if (this._readableState === void 0 || this._writableState === void 0) {
          return;
        }
        this._readableState.destroyed = value;
        this._writableState.destroyed = value;
      }
    });
    Duplex.prototype._destroy = function(err, cb) {
      this.push(null);
      this.end();
      pna.nextTick(cb, err);
    };
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/string_decoder/lib/string_decoder.js
var require_string_decoder = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/string_decoder/lib/string_decoder.js"(exports) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var Buffer2 = require_safe_buffer().Buffer;
    var isEncoding = Buffer2.isEncoding || function(encoding) {
      encoding = "" + encoding;
      switch (encoding && encoding.toLowerCase()) {
        case "hex":
        case "utf8":
        case "utf-8":
        case "ascii":
        case "binary":
        case "base64":
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
        case "raw":
          return true;
        default:
          return false;
      }
    };
    function _normalizeEncoding(enc) {
      if (!enc) return "utf8";
      var retried;
      while (true) {
        switch (enc) {
          case "utf8":
          case "utf-8":
            return "utf8";
          case "ucs2":
          case "ucs-2":
          case "utf16le":
          case "utf-16le":
            return "utf16le";
          case "latin1":
          case "binary":
            return "latin1";
          case "base64":
          case "ascii":
          case "hex":
            return enc;
          default:
            if (retried) return;
            enc = ("" + enc).toLowerCase();
            retried = true;
        }
      }
    }
    function normalizeEncoding(enc) {
      var nenc = _normalizeEncoding(enc);
      if (typeof nenc !== "string" && (Buffer2.isEncoding === isEncoding || !isEncoding(enc))) throw new Error("Unknown encoding: " + enc);
      return nenc || enc;
    }
    exports.StringDecoder = StringDecoder;
    function StringDecoder(encoding) {
      this.encoding = normalizeEncoding(encoding);
      var nb;
      switch (this.encoding) {
        case "utf16le":
          this.text = utf16Text;
          this.end = utf16End;
          nb = 4;
          break;
        case "utf8":
          this.fillLast = utf8FillLast;
          nb = 4;
          break;
        case "base64":
          this.text = base64Text;
          this.end = base64End;
          nb = 3;
          break;
        default:
          this.write = simpleWrite;
          this.end = simpleEnd;
          return;
      }
      this.lastNeed = 0;
      this.lastTotal = 0;
      this.lastChar = Buffer2.allocUnsafe(nb);
    }
    StringDecoder.prototype.write = function(buf) {
      if (buf.length === 0) return "";
      var r2;
      var i2;
      if (this.lastNeed) {
        r2 = this.fillLast(buf);
        if (r2 === void 0) return "";
        i2 = this.lastNeed;
        this.lastNeed = 0;
      } else {
        i2 = 0;
      }
      if (i2 < buf.length) return r2 ? r2 + this.text(buf, i2) : this.text(buf, i2);
      return r2 || "";
    };
    StringDecoder.prototype.end = utf8End;
    StringDecoder.prototype.text = utf8Text;
    StringDecoder.prototype.fillLast = function(buf) {
      if (this.lastNeed <= buf.length) {
        buf.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, this.lastNeed);
        return this.lastChar.toString(this.encoding, 0, this.lastTotal);
      }
      buf.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, buf.length);
      this.lastNeed -= buf.length;
    };
    function utf8CheckByte(byte) {
      if (byte <= 127) return 0;
      else if (byte >> 5 === 6) return 2;
      else if (byte >> 4 === 14) return 3;
      else if (byte >> 3 === 30) return 4;
      return byte >> 6 === 2 ? -1 : -2;
    }
    function utf8CheckIncomplete(self2, buf, i2) {
      var j2 = buf.length - 1;
      if (j2 < i2) return 0;
      var nb = utf8CheckByte(buf[j2]);
      if (nb >= 0) {
        if (nb > 0) self2.lastNeed = nb - 1;
        return nb;
      }
      if (--j2 < i2 || nb === -2) return 0;
      nb = utf8CheckByte(buf[j2]);
      if (nb >= 0) {
        if (nb > 0) self2.lastNeed = nb - 2;
        return nb;
      }
      if (--j2 < i2 || nb === -2) return 0;
      nb = utf8CheckByte(buf[j2]);
      if (nb >= 0) {
        if (nb > 0) {
          if (nb === 2) nb = 0;
          else self2.lastNeed = nb - 3;
        }
        return nb;
      }
      return 0;
    }
    function utf8CheckExtraBytes(self2, buf, p2) {
      if ((buf[0] & 192) !== 128) {
        self2.lastNeed = 0;
        return "\uFFFD";
      }
      if (self2.lastNeed > 1 && buf.length > 1) {
        if ((buf[1] & 192) !== 128) {
          self2.lastNeed = 1;
          return "\uFFFD";
        }
        if (self2.lastNeed > 2 && buf.length > 2) {
          if ((buf[2] & 192) !== 128) {
            self2.lastNeed = 2;
            return "\uFFFD";
          }
        }
      }
    }
    function utf8FillLast(buf) {
      var p2 = this.lastTotal - this.lastNeed;
      var r2 = utf8CheckExtraBytes(this, buf, p2);
      if (r2 !== void 0) return r2;
      if (this.lastNeed <= buf.length) {
        buf.copy(this.lastChar, p2, 0, this.lastNeed);
        return this.lastChar.toString(this.encoding, 0, this.lastTotal);
      }
      buf.copy(this.lastChar, p2, 0, buf.length);
      this.lastNeed -= buf.length;
    }
    function utf8Text(buf, i2) {
      var total = utf8CheckIncomplete(this, buf, i2);
      if (!this.lastNeed) return buf.toString("utf8", i2);
      this.lastTotal = total;
      var end = buf.length - (total - this.lastNeed);
      buf.copy(this.lastChar, 0, end);
      return buf.toString("utf8", i2, end);
    }
    function utf8End(buf) {
      var r2 = buf && buf.length ? this.write(buf) : "";
      if (this.lastNeed) return r2 + "\uFFFD";
      return r2;
    }
    function utf16Text(buf, i2) {
      if ((buf.length - i2) % 2 === 0) {
        var r2 = buf.toString("utf16le", i2);
        if (r2) {
          var c2 = r2.charCodeAt(r2.length - 1);
          if (c2 >= 55296 && c2 <= 56319) {
            this.lastNeed = 2;
            this.lastTotal = 4;
            this.lastChar[0] = buf[buf.length - 2];
            this.lastChar[1] = buf[buf.length - 1];
            return r2.slice(0, -1);
          }
        }
        return r2;
      }
      this.lastNeed = 1;
      this.lastTotal = 2;
      this.lastChar[0] = buf[buf.length - 1];
      return buf.toString("utf16le", i2, buf.length - 1);
    }
    function utf16End(buf) {
      var r2 = buf && buf.length ? this.write(buf) : "";
      if (this.lastNeed) {
        var end = this.lastTotal - this.lastNeed;
        return r2 + this.lastChar.toString("utf16le", 0, end);
      }
      return r2;
    }
    function base64Text(buf, i2) {
      var n2 = (buf.length - i2) % 3;
      if (n2 === 0) return buf.toString("base64", i2);
      this.lastNeed = 3 - n2;
      this.lastTotal = 3;
      if (n2 === 1) {
        this.lastChar[0] = buf[buf.length - 1];
      } else {
        this.lastChar[0] = buf[buf.length - 2];
        this.lastChar[1] = buf[buf.length - 1];
      }
      return buf.toString("base64", i2, buf.length - n2);
    }
    function base64End(buf) {
      var r2 = buf && buf.length ? this.write(buf) : "";
      if (this.lastNeed) return r2 + this.lastChar.toString("base64", 0, 3 - this.lastNeed);
      return r2;
    }
    function simpleWrite(buf) {
      return buf.toString(this.encoding);
    }
    function simpleEnd(buf) {
      return buf && buf.length ? this.write(buf) : "";
    }
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/readable-stream/lib/_stream_readable.js
var require_stream_readable = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/readable-stream/lib/_stream_readable.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var pna = require_process_nextick_args();
    module.exports = Readable;
    var isArray = require_isarray();
    var Duplex;
    Readable.ReadableState = ReadableState;
    var EE = __require("events").EventEmitter;
    var EElistenerCount = function(emitter, type) {
      return emitter.listeners(type).length;
    };
    var Stream = require_stream();
    var Buffer2 = require_safe_buffer().Buffer;
    var OurUint8Array = (typeof global !== "undefined" ? global : typeof window !== "undefined" ? window : typeof self !== "undefined" ? self : {}).Uint8Array || function() {
    };
    function _uint8ArrayToBuffer(chunk) {
      return Buffer2.from(chunk);
    }
    function _isUint8Array(obj) {
      return Buffer2.isBuffer(obj) || obj instanceof OurUint8Array;
    }
    var util = Object.create(require_util());
    util.inherits = require_inherits();
    var debugUtil = __require("util");
    var debug = void 0;
    if (debugUtil && debugUtil.debuglog) {
      debug = debugUtil.debuglog("stream");
    } else {
      debug = function() {
      };
    }
    var BufferList = require_BufferList();
    var destroyImpl = require_destroy();
    var StringDecoder;
    util.inherits(Readable, Stream);
    var kProxyEvents = ["error", "close", "destroy", "pause", "resume"];
    function prependListener(emitter, event, fn2) {
      if (typeof emitter.prependListener === "function") return emitter.prependListener(event, fn2);
      if (!emitter._events || !emitter._events[event]) emitter.on(event, fn2);
      else if (isArray(emitter._events[event])) emitter._events[event].unshift(fn2);
      else emitter._events[event] = [fn2, emitter._events[event]];
    }
    function ReadableState(options, stream) {
      Duplex = Duplex || require_stream_duplex();
      options = options || {};
      var isDuplex = stream instanceof Duplex;
      this.objectMode = !!options.objectMode;
      if (isDuplex) this.objectMode = this.objectMode || !!options.readableObjectMode;
      var hwm = options.highWaterMark;
      var readableHwm = options.readableHighWaterMark;
      var defaultHwm = this.objectMode ? 16 : 16 * 1024;
      if (hwm || hwm === 0) this.highWaterMark = hwm;
      else if (isDuplex && (readableHwm || readableHwm === 0)) this.highWaterMark = readableHwm;
      else this.highWaterMark = defaultHwm;
      this.highWaterMark = Math.floor(this.highWaterMark);
      this.buffer = new BufferList();
      this.length = 0;
      this.pipes = null;
      this.pipesCount = 0;
      this.flowing = null;
      this.ended = false;
      this.endEmitted = false;
      this.reading = false;
      this.sync = true;
      this.needReadable = false;
      this.emittedReadable = false;
      this.readableListening = false;
      this.resumeScheduled = false;
      this.destroyed = false;
      this.defaultEncoding = options.defaultEncoding || "utf8";
      this.awaitDrain = 0;
      this.readingMore = false;
      this.decoder = null;
      this.encoding = null;
      if (options.encoding) {
        if (!StringDecoder) StringDecoder = require_string_decoder().StringDecoder;
        this.decoder = new StringDecoder(options.encoding);
        this.encoding = options.encoding;
      }
    }
    function Readable(options) {
      Duplex = Duplex || require_stream_duplex();
      if (!(this instanceof Readable)) return new Readable(options);
      this._readableState = new ReadableState(options, this);
      this.readable = true;
      if (options) {
        if (typeof options.read === "function") this._read = options.read;
        if (typeof options.destroy === "function") this._destroy = options.destroy;
      }
      Stream.call(this);
    }
    Object.defineProperty(Readable.prototype, "destroyed", {
      get: function() {
        if (this._readableState === void 0) {
          return false;
        }
        return this._readableState.destroyed;
      },
      set: function(value) {
        if (!this._readableState) {
          return;
        }
        this._readableState.destroyed = value;
      }
    });
    Readable.prototype.destroy = destroyImpl.destroy;
    Readable.prototype._undestroy = destroyImpl.undestroy;
    Readable.prototype._destroy = function(err, cb) {
      this.push(null);
      cb(err);
    };
    Readable.prototype.push = function(chunk, encoding) {
      var state = this._readableState;
      var skipChunkCheck;
      if (!state.objectMode) {
        if (typeof chunk === "string") {
          encoding = encoding || state.defaultEncoding;
          if (encoding !== state.encoding) {
            chunk = Buffer2.from(chunk, encoding);
            encoding = "";
          }
          skipChunkCheck = true;
        }
      } else {
        skipChunkCheck = true;
      }
      return readableAddChunk(this, chunk, encoding, false, skipChunkCheck);
    };
    Readable.prototype.unshift = function(chunk) {
      return readableAddChunk(this, chunk, null, true, false);
    };
    function readableAddChunk(stream, chunk, encoding, addToFront, skipChunkCheck) {
      var state = stream._readableState;
      if (chunk === null) {
        state.reading = false;
        onEofChunk(stream, state);
      } else {
        var er2;
        if (!skipChunkCheck) er2 = chunkInvalid(state, chunk);
        if (er2) {
          stream.emit("error", er2);
        } else if (state.objectMode || chunk && chunk.length > 0) {
          if (typeof chunk !== "string" && !state.objectMode && Object.getPrototypeOf(chunk) !== Buffer2.prototype) {
            chunk = _uint8ArrayToBuffer(chunk);
          }
          if (addToFront) {
            if (state.endEmitted) stream.emit("error", new Error("stream.unshift() after end event"));
            else addChunk(stream, state, chunk, true);
          } else if (state.ended) {
            stream.emit("error", new Error("stream.push() after EOF"));
          } else {
            state.reading = false;
            if (state.decoder && !encoding) {
              chunk = state.decoder.write(chunk);
              if (state.objectMode || chunk.length !== 0) addChunk(stream, state, chunk, false);
              else maybeReadMore(stream, state);
            } else {
              addChunk(stream, state, chunk, false);
            }
          }
        } else if (!addToFront) {
          state.reading = false;
        }
      }
      return needMoreData(state);
    }
    function addChunk(stream, state, chunk, addToFront) {
      if (state.flowing && state.length === 0 && !state.sync) {
        stream.emit("data", chunk);
        stream.read(0);
      } else {
        state.length += state.objectMode ? 1 : chunk.length;
        if (addToFront) state.buffer.unshift(chunk);
        else state.buffer.push(chunk);
        if (state.needReadable) emitReadable(stream);
      }
      maybeReadMore(stream, state);
    }
    function chunkInvalid(state, chunk) {
      var er2;
      if (!_isUint8Array(chunk) && typeof chunk !== "string" && chunk !== void 0 && !state.objectMode) {
        er2 = new TypeError("Invalid non-string/buffer chunk");
      }
      return er2;
    }
    function needMoreData(state) {
      return !state.ended && (state.needReadable || state.length < state.highWaterMark || state.length === 0);
    }
    Readable.prototype.isPaused = function() {
      return this._readableState.flowing === false;
    };
    Readable.prototype.setEncoding = function(enc) {
      if (!StringDecoder) StringDecoder = require_string_decoder().StringDecoder;
      this._readableState.decoder = new StringDecoder(enc);
      this._readableState.encoding = enc;
      return this;
    };
    var MAX_HWM = 8388608;
    function computeNewHighWaterMark(n2) {
      if (n2 >= MAX_HWM) {
        n2 = MAX_HWM;
      } else {
        n2--;
        n2 |= n2 >>> 1;
        n2 |= n2 >>> 2;
        n2 |= n2 >>> 4;
        n2 |= n2 >>> 8;
        n2 |= n2 >>> 16;
        n2++;
      }
      return n2;
    }
    function howMuchToRead(n2, state) {
      if (n2 <= 0 || state.length === 0 && state.ended) return 0;
      if (state.objectMode) return 1;
      if (n2 !== n2) {
        if (state.flowing && state.length) return state.buffer.head.data.length;
        else return state.length;
      }
      if (n2 > state.highWaterMark) state.highWaterMark = computeNewHighWaterMark(n2);
      if (n2 <= state.length) return n2;
      if (!state.ended) {
        state.needReadable = true;
        return 0;
      }
      return state.length;
    }
    Readable.prototype.read = function(n2) {
      debug("read", n2);
      n2 = parseInt(n2, 10);
      var state = this._readableState;
      var nOrig = n2;
      if (n2 !== 0) state.emittedReadable = false;
      if (n2 === 0 && state.needReadable && (state.length >= state.highWaterMark || state.ended)) {
        debug("read: emitReadable", state.length, state.ended);
        if (state.length === 0 && state.ended) endReadable(this);
        else emitReadable(this);
        return null;
      }
      n2 = howMuchToRead(n2, state);
      if (n2 === 0 && state.ended) {
        if (state.length === 0) endReadable(this);
        return null;
      }
      var doRead = state.needReadable;
      debug("need readable", doRead);
      if (state.length === 0 || state.length - n2 < state.highWaterMark) {
        doRead = true;
        debug("length less than watermark", doRead);
      }
      if (state.ended || state.reading) {
        doRead = false;
        debug("reading or ended", doRead);
      } else if (doRead) {
        debug("do read");
        state.reading = true;
        state.sync = true;
        if (state.length === 0) state.needReadable = true;
        this._read(state.highWaterMark);
        state.sync = false;
        if (!state.reading) n2 = howMuchToRead(nOrig, state);
      }
      var ret;
      if (n2 > 0) ret = fromList(n2, state);
      else ret = null;
      if (ret === null) {
        state.needReadable = true;
        n2 = 0;
      } else {
        state.length -= n2;
      }
      if (state.length === 0) {
        if (!state.ended) state.needReadable = true;
        if (nOrig !== n2 && state.ended) endReadable(this);
      }
      if (ret !== null) this.emit("data", ret);
      return ret;
    };
    function onEofChunk(stream, state) {
      if (state.ended) return;
      if (state.decoder) {
        var chunk = state.decoder.end();
        if (chunk && chunk.length) {
          state.buffer.push(chunk);
          state.length += state.objectMode ? 1 : chunk.length;
        }
      }
      state.ended = true;
      emitReadable(stream);
    }
    function emitReadable(stream) {
      var state = stream._readableState;
      state.needReadable = false;
      if (!state.emittedReadable) {
        debug("emitReadable", state.flowing);
        state.emittedReadable = true;
        if (state.sync) pna.nextTick(emitReadable_, stream);
        else emitReadable_(stream);
      }
    }
    function emitReadable_(stream) {
      debug("emit readable");
      stream.emit("readable");
      flow(stream);
    }
    function maybeReadMore(stream, state) {
      if (!state.readingMore) {
        state.readingMore = true;
        pna.nextTick(maybeReadMore_, stream, state);
      }
    }
    function maybeReadMore_(stream, state) {
      var len = state.length;
      while (!state.reading && !state.flowing && !state.ended && state.length < state.highWaterMark) {
        debug("maybeReadMore read 0");
        stream.read(0);
        if (len === state.length)
          break;
        else len = state.length;
      }
      state.readingMore = false;
    }
    Readable.prototype._read = function(n2) {
      this.emit("error", new Error("_read() is not implemented"));
    };
    Readable.prototype.pipe = function(dest, pipeOpts) {
      var src = this;
      var state = this._readableState;
      switch (state.pipesCount) {
        case 0:
          state.pipes = dest;
          break;
        case 1:
          state.pipes = [state.pipes, dest];
          break;
        default:
          state.pipes.push(dest);
          break;
      }
      state.pipesCount += 1;
      debug("pipe count=%d opts=%j", state.pipesCount, pipeOpts);
      var doEnd = (!pipeOpts || pipeOpts.end !== false) && dest !== process.stdout && dest !== process.stderr;
      var endFn = doEnd ? onend : unpipe;
      if (state.endEmitted) pna.nextTick(endFn);
      else src.once("end", endFn);
      dest.on("unpipe", onunpipe);
      function onunpipe(readable, unpipeInfo) {
        debug("onunpipe");
        if (readable === src) {
          if (unpipeInfo && unpipeInfo.hasUnpiped === false) {
            unpipeInfo.hasUnpiped = true;
            cleanup();
          }
        }
      }
      function onend() {
        debug("onend");
        dest.end();
      }
      var ondrain = pipeOnDrain(src);
      dest.on("drain", ondrain);
      var cleanedUp = false;
      function cleanup() {
        debug("cleanup");
        dest.removeListener("close", onclose);
        dest.removeListener("finish", onfinish);
        dest.removeListener("drain", ondrain);
        dest.removeListener("error", onerror);
        dest.removeListener("unpipe", onunpipe);
        src.removeListener("end", onend);
        src.removeListener("end", unpipe);
        src.removeListener("data", ondata);
        cleanedUp = true;
        if (state.awaitDrain && (!dest._writableState || dest._writableState.needDrain)) ondrain();
      }
      var increasedAwaitDrain = false;
      src.on("data", ondata);
      function ondata(chunk) {
        debug("ondata");
        increasedAwaitDrain = false;
        var ret = dest.write(chunk);
        if (false === ret && !increasedAwaitDrain) {
          if ((state.pipesCount === 1 && state.pipes === dest || state.pipesCount > 1 && indexOf(state.pipes, dest) !== -1) && !cleanedUp) {
            debug("false write response, pause", state.awaitDrain);
            state.awaitDrain++;
            increasedAwaitDrain = true;
          }
          src.pause();
        }
      }
      function onerror(er2) {
        debug("onerror", er2);
        unpipe();
        dest.removeListener("error", onerror);
        if (EElistenerCount(dest, "error") === 0) dest.emit("error", er2);
      }
      prependListener(dest, "error", onerror);
      function onclose() {
        dest.removeListener("finish", onfinish);
        unpipe();
      }
      dest.once("close", onclose);
      function onfinish() {
        debug("onfinish");
        dest.removeListener("close", onclose);
        unpipe();
      }
      dest.once("finish", onfinish);
      function unpipe() {
        debug("unpipe");
        src.unpipe(dest);
      }
      dest.emit("pipe", src);
      if (!state.flowing) {
        debug("pipe resume");
        src.resume();
      }
      return dest;
    };
    function pipeOnDrain(src) {
      return function() {
        var state = src._readableState;
        debug("pipeOnDrain", state.awaitDrain);
        if (state.awaitDrain) state.awaitDrain--;
        if (state.awaitDrain === 0 && EElistenerCount(src, "data")) {
          state.flowing = true;
          flow(src);
        }
      };
    }
    Readable.prototype.unpipe = function(dest) {
      var state = this._readableState;
      var unpipeInfo = { hasUnpiped: false };
      if (state.pipesCount === 0) return this;
      if (state.pipesCount === 1) {
        if (dest && dest !== state.pipes) return this;
        if (!dest) dest = state.pipes;
        state.pipes = null;
        state.pipesCount = 0;
        state.flowing = false;
        if (dest) dest.emit("unpipe", this, unpipeInfo);
        return this;
      }
      if (!dest) {
        var dests = state.pipes;
        var len = state.pipesCount;
        state.pipes = null;
        state.pipesCount = 0;
        state.flowing = false;
        for (var i2 = 0; i2 < len; i2++) {
          dests[i2].emit("unpipe", this, { hasUnpiped: false });
        }
        return this;
      }
      var index = indexOf(state.pipes, dest);
      if (index === -1) return this;
      state.pipes.splice(index, 1);
      state.pipesCount -= 1;
      if (state.pipesCount === 1) state.pipes = state.pipes[0];
      dest.emit("unpipe", this, unpipeInfo);
      return this;
    };
    Readable.prototype.on = function(ev, fn2) {
      var res = Stream.prototype.on.call(this, ev, fn2);
      if (ev === "data") {
        if (this._readableState.flowing !== false) this.resume();
      } else if (ev === "readable") {
        var state = this._readableState;
        if (!state.endEmitted && !state.readableListening) {
          state.readableListening = state.needReadable = true;
          state.emittedReadable = false;
          if (!state.reading) {
            pna.nextTick(nReadingNextTick, this);
          } else if (state.length) {
            emitReadable(this);
          }
        }
      }
      return res;
    };
    Readable.prototype.addListener = Readable.prototype.on;
    function nReadingNextTick(self2) {
      debug("readable nexttick read 0");
      self2.read(0);
    }
    Readable.prototype.resume = function() {
      var state = this._readableState;
      if (!state.flowing) {
        debug("resume");
        state.flowing = true;
        resume(this, state);
      }
      return this;
    };
    function resume(stream, state) {
      if (!state.resumeScheduled) {
        state.resumeScheduled = true;
        pna.nextTick(resume_, stream, state);
      }
    }
    function resume_(stream, state) {
      if (!state.reading) {
        debug("resume read 0");
        stream.read(0);
      }
      state.resumeScheduled = false;
      state.awaitDrain = 0;
      stream.emit("resume");
      flow(stream);
      if (state.flowing && !state.reading) stream.read(0);
    }
    Readable.prototype.pause = function() {
      debug("call pause flowing=%j", this._readableState.flowing);
      if (false !== this._readableState.flowing) {
        debug("pause");
        this._readableState.flowing = false;
        this.emit("pause");
      }
      return this;
    };
    function flow(stream) {
      var state = stream._readableState;
      debug("flow", state.flowing);
      while (state.flowing && stream.read() !== null) {
      }
    }
    Readable.prototype.wrap = function(stream) {
      var _this = this;
      var state = this._readableState;
      var paused = false;
      stream.on("end", function() {
        debug("wrapped end");
        if (state.decoder && !state.ended) {
          var chunk = state.decoder.end();
          if (chunk && chunk.length) _this.push(chunk);
        }
        _this.push(null);
      });
      stream.on("data", function(chunk) {
        debug("wrapped data");
        if (state.decoder) chunk = state.decoder.write(chunk);
        if (state.objectMode && (chunk === null || chunk === void 0)) return;
        else if (!state.objectMode && (!chunk || !chunk.length)) return;
        var ret = _this.push(chunk);
        if (!ret) {
          paused = true;
          stream.pause();
        }
      });
      for (var i2 in stream) {
        if (this[i2] === void 0 && typeof stream[i2] === "function") {
          this[i2] = /* @__PURE__ */ (function(method) {
            return function() {
              return stream[method].apply(stream, arguments);
            };
          })(i2);
        }
      }
      for (var n2 = 0; n2 < kProxyEvents.length; n2++) {
        stream.on(kProxyEvents[n2], this.emit.bind(this, kProxyEvents[n2]));
      }
      this._read = function(n3) {
        debug("wrapped _read", n3);
        if (paused) {
          paused = false;
          stream.resume();
        }
      };
      return this;
    };
    Object.defineProperty(Readable.prototype, "readableHighWaterMark", {
      // making it explicit this property is not enumerable
      // because otherwise some prototype manipulation in
      // userland will fail
      enumerable: false,
      get: function() {
        return this._readableState.highWaterMark;
      }
    });
    Readable._fromList = fromList;
    function fromList(n2, state) {
      if (state.length === 0) return null;
      var ret;
      if (state.objectMode) ret = state.buffer.shift();
      else if (!n2 || n2 >= state.length) {
        if (state.decoder) ret = state.buffer.join("");
        else if (state.buffer.length === 1) ret = state.buffer.head.data;
        else ret = state.buffer.concat(state.length);
        state.buffer.clear();
      } else {
        ret = fromListPartial(n2, state.buffer, state.decoder);
      }
      return ret;
    }
    function fromListPartial(n2, list, hasStrings) {
      var ret;
      if (n2 < list.head.data.length) {
        ret = list.head.data.slice(0, n2);
        list.head.data = list.head.data.slice(n2);
      } else if (n2 === list.head.data.length) {
        ret = list.shift();
      } else {
        ret = hasStrings ? copyFromBufferString(n2, list) : copyFromBuffer(n2, list);
      }
      return ret;
    }
    function copyFromBufferString(n2, list) {
      var p2 = list.head;
      var c2 = 1;
      var ret = p2.data;
      n2 -= ret.length;
      while (p2 = p2.next) {
        var str = p2.data;
        var nb = n2 > str.length ? str.length : n2;
        if (nb === str.length) ret += str;
        else ret += str.slice(0, n2);
        n2 -= nb;
        if (n2 === 0) {
          if (nb === str.length) {
            ++c2;
            if (p2.next) list.head = p2.next;
            else list.head = list.tail = null;
          } else {
            list.head = p2;
            p2.data = str.slice(nb);
          }
          break;
        }
        ++c2;
      }
      list.length -= c2;
      return ret;
    }
    function copyFromBuffer(n2, list) {
      var ret = Buffer2.allocUnsafe(n2);
      var p2 = list.head;
      var c2 = 1;
      p2.data.copy(ret);
      n2 -= p2.data.length;
      while (p2 = p2.next) {
        var buf = p2.data;
        var nb = n2 > buf.length ? buf.length : n2;
        buf.copy(ret, ret.length - n2, 0, nb);
        n2 -= nb;
        if (n2 === 0) {
          if (nb === buf.length) {
            ++c2;
            if (p2.next) list.head = p2.next;
            else list.head = list.tail = null;
          } else {
            list.head = p2;
            p2.data = buf.slice(nb);
          }
          break;
        }
        ++c2;
      }
      list.length -= c2;
      return ret;
    }
    function endReadable(stream) {
      var state = stream._readableState;
      if (state.length > 0) throw new Error('"endReadable()" called on non-empty stream');
      if (!state.endEmitted) {
        state.ended = true;
        pna.nextTick(endReadableNT, state, stream);
      }
    }
    function endReadableNT(state, stream) {
      if (!state.endEmitted && state.length === 0) {
        state.endEmitted = true;
        stream.readable = false;
        stream.emit("end");
      }
    }
    function indexOf(xs, x2) {
      for (var i2 = 0, l2 = xs.length; i2 < l2; i2++) {
        if (xs[i2] === x2) return i2;
      }
      return -1;
    }
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/readable-stream/lib/_stream_transform.js
var require_stream_transform = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/readable-stream/lib/_stream_transform.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    module.exports = Transform;
    var Duplex = require_stream_duplex();
    var util = Object.create(require_util());
    util.inherits = require_inherits();
    util.inherits(Transform, Duplex);
    function afterTransform(er2, data) {
      var ts = this._transformState;
      ts.transforming = false;
      var cb = ts.writecb;
      if (!cb) {
        return this.emit("error", new Error("write callback called multiple times"));
      }
      ts.writechunk = null;
      ts.writecb = null;
      if (data != null)
        this.push(data);
      cb(er2);
      var rs = this._readableState;
      rs.reading = false;
      if (rs.needReadable || rs.length < rs.highWaterMark) {
        this._read(rs.highWaterMark);
      }
    }
    function Transform(options) {
      if (!(this instanceof Transform)) return new Transform(options);
      Duplex.call(this, options);
      this._transformState = {
        afterTransform: afterTransform.bind(this),
        needTransform: false,
        transforming: false,
        writecb: null,
        writechunk: null,
        writeencoding: null
      };
      this._readableState.needReadable = true;
      this._readableState.sync = false;
      if (options) {
        if (typeof options.transform === "function") this._transform = options.transform;
        if (typeof options.flush === "function") this._flush = options.flush;
      }
      this.on("prefinish", prefinish);
    }
    function prefinish() {
      var _this = this;
      if (typeof this._flush === "function") {
        this._flush(function(er2, data) {
          done(_this, er2, data);
        });
      } else {
        done(this, null, null);
      }
    }
    Transform.prototype.push = function(chunk, encoding) {
      this._transformState.needTransform = false;
      return Duplex.prototype.push.call(this, chunk, encoding);
    };
    Transform.prototype._transform = function(chunk, encoding, cb) {
      throw new Error("_transform() is not implemented");
    };
    Transform.prototype._write = function(chunk, encoding, cb) {
      var ts = this._transformState;
      ts.writecb = cb;
      ts.writechunk = chunk;
      ts.writeencoding = encoding;
      if (!ts.transforming) {
        var rs = this._readableState;
        if (ts.needTransform || rs.needReadable || rs.length < rs.highWaterMark) this._read(rs.highWaterMark);
      }
    };
    Transform.prototype._read = function(n2) {
      var ts = this._transformState;
      if (ts.writechunk !== null && ts.writecb && !ts.transforming) {
        ts.transforming = true;
        this._transform(ts.writechunk, ts.writeencoding, ts.afterTransform);
      } else {
        ts.needTransform = true;
      }
    };
    Transform.prototype._destroy = function(err, cb) {
      var _this2 = this;
      Duplex.prototype._destroy.call(this, err, function(err2) {
        cb(err2);
        _this2.emit("close");
      });
    };
    function done(stream, er2, data) {
      if (er2) return stream.emit("error", er2);
      if (data != null)
        stream.push(data);
      if (stream._writableState.length) throw new Error("Calling transform done when ws.length != 0");
      if (stream._transformState.transforming) throw new Error("Calling transform done when still transforming");
      return stream.push(null);
    }
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/readable-stream/lib/_stream_passthrough.js
var require_stream_passthrough = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/readable-stream/lib/_stream_passthrough.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    module.exports = PassThrough;
    var Transform = require_stream_transform();
    var util = Object.create(require_util());
    util.inherits = require_inherits();
    util.inherits(PassThrough, Transform);
    function PassThrough(options) {
      if (!(this instanceof PassThrough)) return new PassThrough(options);
      Transform.call(this, options);
    }
    PassThrough.prototype._transform = function(chunk, encoding, cb) {
      cb(null, chunk);
    };
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/readable-stream/readable.js
var require_readable = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/readable-stream/readable.js"(exports, module) {
    init_define_COCO_TOOL_CONFIG();
    var Stream = __require("stream");
    if (process.env.READABLE_STREAM === "disable" && Stream) {
      module.exports = Stream;
      exports = module.exports = Stream.Readable;
      exports.Readable = Stream.Readable;
      exports.Writable = Stream.Writable;
      exports.Duplex = Stream.Duplex;
      exports.Transform = Stream.Transform;
      exports.PassThrough = Stream.PassThrough;
      exports.Stream = Stream;
    } else {
      exports = module.exports = require_stream_readable();
      exports.Stream = Stream || exports;
      exports.Readable = exports;
      exports.Writable = require_stream_writable();
      exports.Duplex = require_stream_duplex();
      exports.Transform = require_stream_transform();
      exports.PassThrough = require_stream_passthrough();
    }
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/support.js
var require_support = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/support.js"(exports) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    exports.base64 = true;
    exports.array = true;
    exports.string = true;
    exports.arraybuffer = typeof ArrayBuffer !== "undefined" && typeof Uint8Array !== "undefined";
    exports.nodebuffer = typeof Buffer !== "undefined";
    exports.uint8array = typeof Uint8Array !== "undefined";
    if (typeof ArrayBuffer === "undefined") {
      exports.blob = false;
    } else {
      buffer = new ArrayBuffer(0);
      try {
        exports.blob = new Blob([buffer], {
          type: "application/zip"
        }).size === 0;
      } catch (e2) {
        try {
          Builder = self.BlobBuilder || self.WebKitBlobBuilder || self.MozBlobBuilder || self.MSBlobBuilder;
          builder = new Builder();
          builder.append(buffer);
          exports.blob = builder.getBlob("application/zip").size === 0;
        } catch (e3) {
          exports.blob = false;
        }
      }
    }
    var buffer;
    var Builder;
    var builder;
    try {
      exports.nodestream = !!require_readable().Readable;
    } catch (e2) {
      exports.nodestream = false;
    }
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/base64.js
var require_base64 = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/base64.js"(exports) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var utils = require_utils();
    var support = require_support();
    var _keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    exports.encode = function(input) {
      var output = [];
      var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
      var i2 = 0, len = input.length, remainingBytes = len;
      var isArray = utils.getTypeOf(input) !== "string";
      while (i2 < input.length) {
        remainingBytes = len - i2;
        if (!isArray) {
          chr1 = input.charCodeAt(i2++);
          chr2 = i2 < len ? input.charCodeAt(i2++) : 0;
          chr3 = i2 < len ? input.charCodeAt(i2++) : 0;
        } else {
          chr1 = input[i2++];
          chr2 = i2 < len ? input[i2++] : 0;
          chr3 = i2 < len ? input[i2++] : 0;
        }
        enc1 = chr1 >> 2;
        enc2 = (chr1 & 3) << 4 | chr2 >> 4;
        enc3 = remainingBytes > 1 ? (chr2 & 15) << 2 | chr3 >> 6 : 64;
        enc4 = remainingBytes > 2 ? chr3 & 63 : 64;
        output.push(_keyStr.charAt(enc1) + _keyStr.charAt(enc2) + _keyStr.charAt(enc3) + _keyStr.charAt(enc4));
      }
      return output.join("");
    };
    exports.decode = function(input) {
      var chr1, chr2, chr3;
      var enc1, enc2, enc3, enc4;
      var i2 = 0, resultIndex = 0;
      var dataUrlPrefix = "data:";
      if (input.substr(0, dataUrlPrefix.length) === dataUrlPrefix) {
        throw new Error("Invalid base64 input, it looks like a data url.");
      }
      input = input.replace(/[^A-Za-z0-9+/=]/g, "");
      var totalLength = input.length * 3 / 4;
      if (input.charAt(input.length - 1) === _keyStr.charAt(64)) {
        totalLength--;
      }
      if (input.charAt(input.length - 2) === _keyStr.charAt(64)) {
        totalLength--;
      }
      if (totalLength % 1 !== 0) {
        throw new Error("Invalid base64 input, bad content length.");
      }
      var output;
      if (support.uint8array) {
        output = new Uint8Array(totalLength | 0);
      } else {
        output = new Array(totalLength | 0);
      }
      while (i2 < input.length) {
        enc1 = _keyStr.indexOf(input.charAt(i2++));
        enc2 = _keyStr.indexOf(input.charAt(i2++));
        enc3 = _keyStr.indexOf(input.charAt(i2++));
        enc4 = _keyStr.indexOf(input.charAt(i2++));
        chr1 = enc1 << 2 | enc2 >> 4;
        chr2 = (enc2 & 15) << 4 | enc3 >> 2;
        chr3 = (enc3 & 3) << 6 | enc4;
        output[resultIndex++] = chr1;
        if (enc3 !== 64) {
          output[resultIndex++] = chr2;
        }
        if (enc4 !== 64) {
          output[resultIndex++] = chr3;
        }
      }
      return output;
    };
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/nodejsUtils.js
var require_nodejsUtils = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/nodejsUtils.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    module.exports = {
      /**
       * True if this is running in Nodejs, will be undefined in a browser.
       * In a browser, browserify won't include this file and the whole module
       * will be resolved an empty object.
       */
      isNode: typeof Buffer !== "undefined",
      /**
       * Create a new nodejs Buffer from an existing content.
       * @param {Object} data the data to pass to the constructor.
       * @param {String} encoding the encoding to use.
       * @return {Buffer} a new Buffer.
       */
      newBufferFrom: function(data, encoding) {
        if (Buffer.from && Buffer.from !== Uint8Array.from) {
          return Buffer.from(data, encoding);
        } else {
          if (typeof data === "number") {
            throw new Error('The "data" argument must not be a number');
          }
          return new Buffer(data, encoding);
        }
      },
      /**
       * Create a new nodejs Buffer with the specified size.
       * @param {Integer} size the size of the buffer.
       * @return {Buffer} a new Buffer.
       */
      allocBuffer: function(size) {
        if (Buffer.alloc) {
          return Buffer.alloc(size);
        } else {
          var buf = new Buffer(size);
          buf.fill(0);
          return buf;
        }
      },
      /**
       * Find out if an object is a Buffer.
       * @param {Object} b the object to test.
       * @return {Boolean} true if the object is a Buffer, false otherwise.
       */
      isBuffer: function(b2) {
        return Buffer.isBuffer(b2);
      },
      isStream: function(obj) {
        return obj && typeof obj.on === "function" && typeof obj.pause === "function" && typeof obj.resume === "function";
      }
    };
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/immediate/lib/index.js
var require_lib = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/immediate/lib/index.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var Mutation = global.MutationObserver || global.WebKitMutationObserver;
    var scheduleDrain;
    if (process.browser) {
      if (Mutation) {
        called = 0;
        observer = new Mutation(nextTick);
        element = global.document.createTextNode("");
        observer.observe(element, {
          characterData: true
        });
        scheduleDrain = function() {
          element.data = called = ++called % 2;
        };
      } else if (!global.setImmediate && typeof global.MessageChannel !== "undefined") {
        channel = new global.MessageChannel();
        channel.port1.onmessage = nextTick;
        scheduleDrain = function() {
          channel.port2.postMessage(0);
        };
      } else if ("document" in global && "onreadystatechange" in global.document.createElement("script")) {
        scheduleDrain = function() {
          var scriptEl = global.document.createElement("script");
          scriptEl.onreadystatechange = function() {
            nextTick();
            scriptEl.onreadystatechange = null;
            scriptEl.parentNode.removeChild(scriptEl);
            scriptEl = null;
          };
          global.document.documentElement.appendChild(scriptEl);
        };
      } else {
        scheduleDrain = function() {
          setTimeout(nextTick, 0);
        };
      }
    } else {
      scheduleDrain = function() {
        process.nextTick(nextTick);
      };
    }
    var called;
    var observer;
    var element;
    var channel;
    var draining;
    var queue = [];
    function nextTick() {
      draining = true;
      var i2, oldQueue;
      var len = queue.length;
      while (len) {
        oldQueue = queue;
        queue = [];
        i2 = -1;
        while (++i2 < len) {
          oldQueue[i2]();
        }
        len = queue.length;
      }
      draining = false;
    }
    module.exports = immediate;
    function immediate(task) {
      if (queue.push(task) === 1 && !draining) {
        scheduleDrain();
      }
    }
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/lie/lib/index.js
var require_lib2 = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/lie/lib/index.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var immediate = require_lib();
    function INTERNAL() {
    }
    var handlers = {};
    var REJECTED = ["REJECTED"];
    var FULFILLED = ["FULFILLED"];
    var PENDING = ["PENDING"];
    if (!process.browser) {
      UNHANDLED = ["UNHANDLED"];
    }
    var UNHANDLED;
    module.exports = Promise2;
    function Promise2(resolver) {
      if (typeof resolver !== "function") {
        throw new TypeError("resolver must be a function");
      }
      this.state = PENDING;
      this.queue = [];
      this.outcome = void 0;
      if (!process.browser) {
        this.handled = UNHANDLED;
      }
      if (resolver !== INTERNAL) {
        safelyResolveThenable(this, resolver);
      }
    }
    Promise2.prototype.finally = function(callback) {
      if (typeof callback !== "function") {
        return this;
      }
      var p2 = this.constructor;
      return this.then(resolve2, reject2);
      function resolve2(value) {
        function yes() {
          return value;
        }
        return p2.resolve(callback()).then(yes);
      }
      function reject2(reason) {
        function no2() {
          throw reason;
        }
        return p2.resolve(callback()).then(no2);
      }
    };
    Promise2.prototype.catch = function(onRejected) {
      return this.then(null, onRejected);
    };
    Promise2.prototype.then = function(onFulfilled, onRejected) {
      if (typeof onFulfilled !== "function" && this.state === FULFILLED || typeof onRejected !== "function" && this.state === REJECTED) {
        return this;
      }
      var promise = new this.constructor(INTERNAL);
      if (!process.browser) {
        if (this.handled === UNHANDLED) {
          this.handled = null;
        }
      }
      if (this.state !== PENDING) {
        var resolver = this.state === FULFILLED ? onFulfilled : onRejected;
        unwrap(promise, resolver, this.outcome);
      } else {
        this.queue.push(new QueueItem(promise, onFulfilled, onRejected));
      }
      return promise;
    };
    function QueueItem(promise, onFulfilled, onRejected) {
      this.promise = promise;
      if (typeof onFulfilled === "function") {
        this.onFulfilled = onFulfilled;
        this.callFulfilled = this.otherCallFulfilled;
      }
      if (typeof onRejected === "function") {
        this.onRejected = onRejected;
        this.callRejected = this.otherCallRejected;
      }
    }
    QueueItem.prototype.callFulfilled = function(value) {
      handlers.resolve(this.promise, value);
    };
    QueueItem.prototype.otherCallFulfilled = function(value) {
      unwrap(this.promise, this.onFulfilled, value);
    };
    QueueItem.prototype.callRejected = function(value) {
      handlers.reject(this.promise, value);
    };
    QueueItem.prototype.otherCallRejected = function(value) {
      unwrap(this.promise, this.onRejected, value);
    };
    function unwrap(promise, func, value) {
      immediate(function() {
        var returnValue;
        try {
          returnValue = func(value);
        } catch (e2) {
          return handlers.reject(promise, e2);
        }
        if (returnValue === promise) {
          handlers.reject(promise, new TypeError("Cannot resolve promise with itself"));
        } else {
          handlers.resolve(promise, returnValue);
        }
      });
    }
    handlers.resolve = function(self2, value) {
      var result = tryCatch(getThen, value);
      if (result.status === "error") {
        return handlers.reject(self2, result.value);
      }
      var thenable = result.value;
      if (thenable) {
        safelyResolveThenable(self2, thenable);
      } else {
        self2.state = FULFILLED;
        self2.outcome = value;
        var i2 = -1;
        var len = self2.queue.length;
        while (++i2 < len) {
          self2.queue[i2].callFulfilled(value);
        }
      }
      return self2;
    };
    handlers.reject = function(self2, error2) {
      self2.state = REJECTED;
      self2.outcome = error2;
      if (!process.browser) {
        if (self2.handled === UNHANDLED) {
          immediate(function() {
            if (self2.handled === UNHANDLED) {
              process.emit("unhandledRejection", error2, self2);
            }
          });
        }
      }
      var i2 = -1;
      var len = self2.queue.length;
      while (++i2 < len) {
        self2.queue[i2].callRejected(error2);
      }
      return self2;
    };
    function getThen(obj) {
      var then = obj && obj.then;
      if (obj && (typeof obj === "object" || typeof obj === "function") && typeof then === "function") {
        return function appyThen() {
          then.apply(obj, arguments);
        };
      }
    }
    function safelyResolveThenable(self2, thenable) {
      var called = false;
      function onError(value) {
        if (called) {
          return;
        }
        called = true;
        handlers.reject(self2, value);
      }
      function onSuccess(value) {
        if (called) {
          return;
        }
        called = true;
        handlers.resolve(self2, value);
      }
      function tryToUnwrap() {
        thenable(onSuccess, onError);
      }
      var result = tryCatch(tryToUnwrap);
      if (result.status === "error") {
        onError(result.value);
      }
    }
    function tryCatch(func, value) {
      var out = {};
      try {
        out.value = func(value);
        out.status = "success";
      } catch (e2) {
        out.status = "error";
        out.value = e2;
      }
      return out;
    }
    Promise2.resolve = resolve;
    function resolve(value) {
      if (value instanceof this) {
        return value;
      }
      return handlers.resolve(new this(INTERNAL), value);
    }
    Promise2.reject = reject;
    function reject(reason) {
      var promise = new this(INTERNAL);
      return handlers.reject(promise, reason);
    }
    Promise2.all = all;
    function all(iterable) {
      var self2 = this;
      if (Object.prototype.toString.call(iterable) !== "[object Array]") {
        return this.reject(new TypeError("must be an array"));
      }
      var len = iterable.length;
      var called = false;
      if (!len) {
        return this.resolve([]);
      }
      var values = new Array(len);
      var resolved = 0;
      var i2 = -1;
      var promise = new this(INTERNAL);
      while (++i2 < len) {
        allResolver(iterable[i2], i2);
      }
      return promise;
      function allResolver(value, i3) {
        self2.resolve(value).then(resolveFromAll, function(error2) {
          if (!called) {
            called = true;
            handlers.reject(promise, error2);
          }
        });
        function resolveFromAll(outValue) {
          values[i3] = outValue;
          if (++resolved === len && !called) {
            called = true;
            handlers.resolve(promise, values);
          }
        }
      }
    }
    Promise2.race = race;
    function race(iterable) {
      var self2 = this;
      if (Object.prototype.toString.call(iterable) !== "[object Array]") {
        return this.reject(new TypeError("must be an array"));
      }
      var len = iterable.length;
      var called = false;
      if (!len) {
        return this.resolve([]);
      }
      var i2 = -1;
      var promise = new this(INTERNAL);
      while (++i2 < len) {
        resolver(iterable[i2]);
      }
      return promise;
      function resolver(value) {
        self2.resolve(value).then(function(response) {
          if (!called) {
            called = true;
            handlers.resolve(promise, response);
          }
        }, function(error2) {
          if (!called) {
            called = true;
            handlers.reject(promise, error2);
          }
        });
      }
    }
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/external.js
var require_external = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/external.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var ES6Promise = null;
    if (typeof Promise !== "undefined") {
      ES6Promise = Promise;
    } else {
      ES6Promise = require_lib2();
    }
    module.exports = {
      Promise: ES6Promise
    };
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/setimmediate/setImmediate.js
var require_setImmediate = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/setimmediate/setImmediate.js"(exports) {
    init_define_COCO_TOOL_CONFIG();
    (function(global2, undefined2) {
      "use strict";
      if (global2.setImmediate) {
        return;
      }
      var nextHandle = 1;
      var tasksByHandle = {};
      var currentlyRunningATask = false;
      var doc = global2.document;
      var registerImmediate;
      function setImmediate2(callback) {
        if (typeof callback !== "function") {
          callback = new Function("" + callback);
        }
        var args = new Array(arguments.length - 1);
        for (var i2 = 0; i2 < args.length; i2++) {
          args[i2] = arguments[i2 + 1];
        }
        var task = { callback, args };
        tasksByHandle[nextHandle] = task;
        registerImmediate(nextHandle);
        return nextHandle++;
      }
      function clearImmediate(handle) {
        delete tasksByHandle[handle];
      }
      function run(task) {
        var callback = task.callback;
        var args = task.args;
        switch (args.length) {
          case 0:
            callback();
            break;
          case 1:
            callback(args[0]);
            break;
          case 2:
            callback(args[0], args[1]);
            break;
          case 3:
            callback(args[0], args[1], args[2]);
            break;
          default:
            callback.apply(undefined2, args);
            break;
        }
      }
      function runIfPresent(handle) {
        if (currentlyRunningATask) {
          setTimeout(runIfPresent, 0, handle);
        } else {
          var task = tasksByHandle[handle];
          if (task) {
            currentlyRunningATask = true;
            try {
              run(task);
            } finally {
              clearImmediate(handle);
              currentlyRunningATask = false;
            }
          }
        }
      }
      function installNextTickImplementation() {
        registerImmediate = function(handle) {
          process.nextTick(function() {
            runIfPresent(handle);
          });
        };
      }
      function canUsePostMessage() {
        if (global2.postMessage && !global2.importScripts) {
          var postMessageIsAsynchronous = true;
          var oldOnMessage = global2.onmessage;
          global2.onmessage = function() {
            postMessageIsAsynchronous = false;
          };
          global2.postMessage("", "*");
          global2.onmessage = oldOnMessage;
          return postMessageIsAsynchronous;
        }
      }
      function installPostMessageImplementation() {
        var messagePrefix = "setImmediate$" + Math.random() + "$";
        var onGlobalMessage = function(event) {
          if (event.source === global2 && typeof event.data === "string" && event.data.indexOf(messagePrefix) === 0) {
            runIfPresent(+event.data.slice(messagePrefix.length));
          }
        };
        if (global2.addEventListener) {
          global2.addEventListener("message", onGlobalMessage, false);
        } else {
          global2.attachEvent("onmessage", onGlobalMessage);
        }
        registerImmediate = function(handle) {
          global2.postMessage(messagePrefix + handle, "*");
        };
      }
      function installMessageChannelImplementation() {
        var channel = new MessageChannel();
        channel.port1.onmessage = function(event) {
          var handle = event.data;
          runIfPresent(handle);
        };
        registerImmediate = function(handle) {
          channel.port2.postMessage(handle);
        };
      }
      function installReadyStateChangeImplementation() {
        var html = doc.documentElement;
        registerImmediate = function(handle) {
          var script = doc.createElement("script");
          script.onreadystatechange = function() {
            runIfPresent(handle);
            script.onreadystatechange = null;
            html.removeChild(script);
            script = null;
          };
          html.appendChild(script);
        };
      }
      function installSetTimeoutImplementation() {
        registerImmediate = function(handle) {
          setTimeout(runIfPresent, 0, handle);
        };
      }
      var attachTo = Object.getPrototypeOf && Object.getPrototypeOf(global2);
      attachTo = attachTo && attachTo.setTimeout ? attachTo : global2;
      if ({}.toString.call(global2.process) === "[object process]") {
        installNextTickImplementation();
      } else if (canUsePostMessage()) {
        installPostMessageImplementation();
      } else if (global2.MessageChannel) {
        installMessageChannelImplementation();
      } else if (doc && "onreadystatechange" in doc.createElement("script")) {
        installReadyStateChangeImplementation();
      } else {
        installSetTimeoutImplementation();
      }
      attachTo.setImmediate = setImmediate2;
      attachTo.clearImmediate = clearImmediate;
    })(typeof self === "undefined" ? typeof global === "undefined" ? exports : global : self);
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/utils.js
var require_utils = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/utils.js"(exports) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var support = require_support();
    var base64 = require_base64();
    var nodejsUtils = require_nodejsUtils();
    var external = require_external();
    require_setImmediate();
    function string2binary(str) {
      var result = null;
      if (support.uint8array) {
        result = new Uint8Array(str.length);
      } else {
        result = new Array(str.length);
      }
      return stringToArrayLike(str, result);
    }
    exports.newBlob = function(part, type) {
      exports.checkSupport("blob");
      try {
        return new Blob([part], {
          type
        });
      } catch (e2) {
        try {
          var Builder = self.BlobBuilder || self.WebKitBlobBuilder || self.MozBlobBuilder || self.MSBlobBuilder;
          var builder = new Builder();
          builder.append(part);
          return builder.getBlob(type);
        } catch (e3) {
          throw new Error("Bug : can't construct the Blob.");
        }
      }
    };
    function identity(input) {
      return input;
    }
    function stringToArrayLike(str, array) {
      for (var i2 = 0; i2 < str.length; ++i2) {
        array[i2] = str.charCodeAt(i2) & 255;
      }
      return array;
    }
    var arrayToStringHelper = {
      /**
       * Transform an array of int into a string, chunk by chunk.
       * See the performances notes on arrayLikeToString.
       * @param {Array|ArrayBuffer|Uint8Array|Buffer} array the array to transform.
       * @param {String} type the type of the array.
       * @param {Integer} chunk the chunk size.
       * @return {String} the resulting string.
       * @throws Error if the chunk is too big for the stack.
       */
      stringifyByChunk: function(array, type, chunk) {
        var result = [], k2 = 0, len = array.length;
        if (len <= chunk) {
          return String.fromCharCode.apply(null, array);
        }
        while (k2 < len) {
          if (type === "array" || type === "nodebuffer") {
            result.push(String.fromCharCode.apply(null, array.slice(k2, Math.min(k2 + chunk, len))));
          } else {
            result.push(String.fromCharCode.apply(null, array.subarray(k2, Math.min(k2 + chunk, len))));
          }
          k2 += chunk;
        }
        return result.join("");
      },
      /**
       * Call String.fromCharCode on every item in the array.
       * This is the naive implementation, which generate A LOT of intermediate string.
       * This should be used when everything else fail.
       * @param {Array|ArrayBuffer|Uint8Array|Buffer} array the array to transform.
       * @return {String} the result.
       */
      stringifyByChar: function(array) {
        var resultStr = "";
        for (var i2 = 0; i2 < array.length; i2++) {
          resultStr += String.fromCharCode(array[i2]);
        }
        return resultStr;
      },
      applyCanBeUsed: {
        /**
         * true if the browser accepts to use String.fromCharCode on Uint8Array
         */
        uint8array: (function() {
          try {
            return support.uint8array && String.fromCharCode.apply(null, new Uint8Array(1)).length === 1;
          } catch (e2) {
            return false;
          }
        })(),
        /**
         * true if the browser accepts to use String.fromCharCode on nodejs Buffer.
         */
        nodebuffer: (function() {
          try {
            return support.nodebuffer && String.fromCharCode.apply(null, nodejsUtils.allocBuffer(1)).length === 1;
          } catch (e2) {
            return false;
          }
        })()
      }
    };
    function arrayLikeToString(array) {
      var chunk = 65536, type = exports.getTypeOf(array), canUseApply = true;
      if (type === "uint8array") {
        canUseApply = arrayToStringHelper.applyCanBeUsed.uint8array;
      } else if (type === "nodebuffer") {
        canUseApply = arrayToStringHelper.applyCanBeUsed.nodebuffer;
      }
      if (canUseApply) {
        while (chunk > 1) {
          try {
            return arrayToStringHelper.stringifyByChunk(array, type, chunk);
          } catch (e2) {
            chunk = Math.floor(chunk / 2);
          }
        }
      }
      return arrayToStringHelper.stringifyByChar(array);
    }
    exports.applyFromCharCode = arrayLikeToString;
    function arrayLikeToArrayLike(arrayFrom, arrayTo) {
      for (var i2 = 0; i2 < arrayFrom.length; i2++) {
        arrayTo[i2] = arrayFrom[i2];
      }
      return arrayTo;
    }
    var transform = {};
    transform["string"] = {
      "string": identity,
      "array": function(input) {
        return stringToArrayLike(input, new Array(input.length));
      },
      "arraybuffer": function(input) {
        return transform["string"]["uint8array"](input).buffer;
      },
      "uint8array": function(input) {
        return stringToArrayLike(input, new Uint8Array(input.length));
      },
      "nodebuffer": function(input) {
        return stringToArrayLike(input, nodejsUtils.allocBuffer(input.length));
      }
    };
    transform["array"] = {
      "string": arrayLikeToString,
      "array": identity,
      "arraybuffer": function(input) {
        return new Uint8Array(input).buffer;
      },
      "uint8array": function(input) {
        return new Uint8Array(input);
      },
      "nodebuffer": function(input) {
        return nodejsUtils.newBufferFrom(input);
      }
    };
    transform["arraybuffer"] = {
      "string": function(input) {
        return arrayLikeToString(new Uint8Array(input));
      },
      "array": function(input) {
        return arrayLikeToArrayLike(new Uint8Array(input), new Array(input.byteLength));
      },
      "arraybuffer": identity,
      "uint8array": function(input) {
        return new Uint8Array(input);
      },
      "nodebuffer": function(input) {
        return nodejsUtils.newBufferFrom(new Uint8Array(input));
      }
    };
    transform["uint8array"] = {
      "string": arrayLikeToString,
      "array": function(input) {
        return arrayLikeToArrayLike(input, new Array(input.length));
      },
      "arraybuffer": function(input) {
        return input.buffer;
      },
      "uint8array": identity,
      "nodebuffer": function(input) {
        return nodejsUtils.newBufferFrom(input);
      }
    };
    transform["nodebuffer"] = {
      "string": arrayLikeToString,
      "array": function(input) {
        return arrayLikeToArrayLike(input, new Array(input.length));
      },
      "arraybuffer": function(input) {
        return transform["nodebuffer"]["uint8array"](input).buffer;
      },
      "uint8array": function(input) {
        return arrayLikeToArrayLike(input, new Uint8Array(input.length));
      },
      "nodebuffer": identity
    };
    exports.transformTo = function(outputType, input) {
      if (!input) {
        input = "";
      }
      if (!outputType) {
        return input;
      }
      exports.checkSupport(outputType);
      var inputType = exports.getTypeOf(input);
      var result = transform[inputType][outputType](input);
      return result;
    };
    exports.resolve = function(path) {
      var parts = path.split("/");
      var result = [];
      for (var index = 0; index < parts.length; index++) {
        var part = parts[index];
        if (part === "." || part === "" && index !== 0 && index !== parts.length - 1) {
          continue;
        } else if (part === "..") {
          result.pop();
        } else {
          result.push(part);
        }
      }
      return result.join("/");
    };
    exports.getTypeOf = function(input) {
      if (typeof input === "string") {
        return "string";
      }
      var proto = Object.prototype.toString.call(input);
      if (proto === "[object Array]") {
        return "array";
      }
      if (support.nodebuffer && nodejsUtils.isBuffer(input)) {
        return "nodebuffer";
      }
      if (support.uint8array && proto === "[object Uint8Array]") {
        return "uint8array";
      }
      if (support.arraybuffer && proto === "[object ArrayBuffer]") {
        return "arraybuffer";
      }
    };
    exports.checkSupport = function(type) {
      var supported = support[type.toLowerCase()];
      if (!supported) {
        throw new Error(type + " is not supported by this platform");
      }
    };
    exports.MAX_VALUE_16BITS = 65535;
    exports.MAX_VALUE_32BITS = -1;
    exports.pretty = function(str) {
      var res = "", code, i2;
      for (i2 = 0; i2 < (str || "").length; i2++) {
        code = str.charCodeAt(i2);
        res += "\\x" + (code < 16 ? "0" : "") + code.toString(16).toUpperCase();
      }
      return res;
    };
    exports.delay = function(callback, args, self2) {
      setImmediate(function() {
        callback.apply(self2 || null, args || []);
      });
    };
    exports.inherits = function(ctor, superCtor) {
      var Obj = function() {
      };
      Obj.prototype = superCtor.prototype;
      ctor.prototype = new Obj();
    };
    exports.extend = function() {
      var result = {}, i2, attr;
      for (i2 = 0; i2 < arguments.length; i2++) {
        for (attr in arguments[i2]) {
          if (Object.prototype.hasOwnProperty.call(arguments[i2], attr) && typeof result[attr] === "undefined") {
            result[attr] = arguments[i2][attr];
          }
        }
      }
      return result;
    };
    exports.prepareContent = function(name, inputData, isBinary, isOptimizedBinaryString, isBase64) {
      var promise = external.Promise.resolve(inputData).then(function(data) {
        var isBlob = support.blob && (data instanceof Blob || ["[object File]", "[object Blob]"].indexOf(Object.prototype.toString.call(data)) !== -1);
        if (isBlob) {
          if (typeof Blob.prototype.arrayBuffer !== "undefined") {
            return data.arrayBuffer();
          } else if (typeof FileReader !== "undefined") {
            return new external.Promise(function(resolve, reject) {
              var reader = new FileReader();
              reader.onload = function(e2) {
                resolve(e2.target.result);
              };
              reader.onerror = function(e2) {
                reject(e2.target.error);
              };
              reader.readAsArrayBuffer(data);
            });
          } else {
            return external.Promise.reject(
              new Error(name + " is a Blob, but we have no way of reading it.")
            );
          }
        }
        return data;
      });
      return promise.then(function(data) {
        var dataType = exports.getTypeOf(data);
        if (!dataType) {
          return external.Promise.reject(
            new Error("Can't read the data of '" + name + "'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?")
          );
        }
        if (dataType === "arraybuffer") {
          data = exports.transformTo("uint8array", data);
        } else if (dataType === "string") {
          if (isBase64) {
            data = base64.decode(data);
          } else if (isBinary) {
            if (isOptimizedBinaryString !== true) {
              data = string2binary(data);
            }
          }
        }
        return data;
      });
    };
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/stream/GenericWorker.js
var require_GenericWorker = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/stream/GenericWorker.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    function GenericWorker(name) {
      this.name = name || "default";
      this.streamInfo = {};
      this.generatedError = null;
      this.extraStreamInfo = {};
      this.isPaused = true;
      this.isFinished = false;
      this.isLocked = false;
      this._listeners = {
        "data": [],
        "end": [],
        "error": []
      };
      this.previous = null;
    }
    GenericWorker.prototype = {
      /**
       * Push a chunk to the next workers.
       * @param {Object} chunk the chunk to push
       */
      push: function(chunk) {
        this.emit("data", chunk);
      },
      /**
       * End the stream.
       * @return {Boolean} true if this call ended the worker, false otherwise.
       */
      end: function() {
        if (this.isFinished) {
          return false;
        }
        this.flush();
        try {
          this.emit("end");
          this.cleanUp();
          this.isFinished = true;
        } catch (e2) {
          this.emit("error", e2);
        }
        return true;
      },
      /**
       * End the stream with an error.
       * @param {Error} e the error which caused the premature end.
       * @return {Boolean} true if this call ended the worker with an error, false otherwise.
       */
      error: function(e2) {
        if (this.isFinished) {
          return false;
        }
        if (this.isPaused) {
          this.generatedError = e2;
        } else {
          this.isFinished = true;
          this.emit("error", e2);
          if (this.previous) {
            this.previous.error(e2);
          }
          this.cleanUp();
        }
        return true;
      },
      /**
       * Add a callback on an event.
       * @param {String} name the name of the event (data, end, error)
       * @param {Function} listener the function to call when the event is triggered
       * @return {GenericWorker} the current object for chainability
       */
      on: function(name, listener) {
        this._listeners[name].push(listener);
        return this;
      },
      /**
       * Clean any references when a worker is ending.
       */
      cleanUp: function() {
        this.streamInfo = this.generatedError = this.extraStreamInfo = null;
        this._listeners = [];
      },
      /**
       * Trigger an event. This will call registered callback with the provided arg.
       * @param {String} name the name of the event (data, end, error)
       * @param {Object} arg the argument to call the callback with.
       */
      emit: function(name, arg) {
        if (this._listeners[name]) {
          for (var i2 = 0; i2 < this._listeners[name].length; i2++) {
            this._listeners[name][i2].call(this, arg);
          }
        }
      },
      /**
       * Chain a worker with an other.
       * @param {Worker} next the worker receiving events from the current one.
       * @return {worker} the next worker for chainability
       */
      pipe: function(next) {
        return next.registerPrevious(this);
      },
      /**
       * Same as `pipe` in the other direction.
       * Using an API with `pipe(next)` is very easy.
       * Implementing the API with the point of view of the next one registering
       * a source is easier, see the ZipFileWorker.
       * @param {Worker} previous the previous worker, sending events to this one
       * @return {Worker} the current worker for chainability
       */
      registerPrevious: function(previous) {
        if (this.isLocked) {
          throw new Error("The stream '" + this + "' has already been used.");
        }
        this.streamInfo = previous.streamInfo;
        this.mergeStreamInfo();
        this.previous = previous;
        var self2 = this;
        previous.on("data", function(chunk) {
          self2.processChunk(chunk);
        });
        previous.on("end", function() {
          self2.end();
        });
        previous.on("error", function(e2) {
          self2.error(e2);
        });
        return this;
      },
      /**
       * Pause the stream so it doesn't send events anymore.
       * @return {Boolean} true if this call paused the worker, false otherwise.
       */
      pause: function() {
        if (this.isPaused || this.isFinished) {
          return false;
        }
        this.isPaused = true;
        if (this.previous) {
          this.previous.pause();
        }
        return true;
      },
      /**
       * Resume a paused stream.
       * @return {Boolean} true if this call resumed the worker, false otherwise.
       */
      resume: function() {
        if (!this.isPaused || this.isFinished) {
          return false;
        }
        this.isPaused = false;
        var withError = false;
        if (this.generatedError) {
          this.error(this.generatedError);
          withError = true;
        }
        if (this.previous) {
          this.previous.resume();
        }
        return !withError;
      },
      /**
       * Flush any remaining bytes as the stream is ending.
       */
      flush: function() {
      },
      /**
       * Process a chunk. This is usually the method overridden.
       * @param {Object} chunk the chunk to process.
       */
      processChunk: function(chunk) {
        this.push(chunk);
      },
      /**
       * Add a key/value to be added in the workers chain streamInfo once activated.
       * @param {String} key the key to use
       * @param {Object} value the associated value
       * @return {Worker} the current worker for chainability
       */
      withStreamInfo: function(key2, value) {
        this.extraStreamInfo[key2] = value;
        this.mergeStreamInfo();
        return this;
      },
      /**
       * Merge this worker's streamInfo into the chain's streamInfo.
       */
      mergeStreamInfo: function() {
        for (var key2 in this.extraStreamInfo) {
          if (!Object.prototype.hasOwnProperty.call(this.extraStreamInfo, key2)) {
            continue;
          }
          this.streamInfo[key2] = this.extraStreamInfo[key2];
        }
      },
      /**
       * Lock the stream to prevent further updates on the workers chain.
       * After calling this method, all calls to pipe will fail.
       */
      lock: function() {
        if (this.isLocked) {
          throw new Error("The stream '" + this + "' has already been used.");
        }
        this.isLocked = true;
        if (this.previous) {
          this.previous.lock();
        }
      },
      /**
       *
       * Pretty print the workers chain.
       */
      toString: function() {
        var me2 = "Worker " + this.name;
        if (this.previous) {
          return this.previous + " -> " + me2;
        } else {
          return me2;
        }
      }
    };
    module.exports = GenericWorker;
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/utf8.js
var require_utf8 = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/utf8.js"(exports) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var utils = require_utils();
    var support = require_support();
    var nodejsUtils = require_nodejsUtils();
    var GenericWorker = require_GenericWorker();
    var _utf8len = new Array(256);
    for (i2 = 0; i2 < 256; i2++) {
      _utf8len[i2] = i2 >= 252 ? 6 : i2 >= 248 ? 5 : i2 >= 240 ? 4 : i2 >= 224 ? 3 : i2 >= 192 ? 2 : 1;
    }
    var i2;
    _utf8len[254] = _utf8len[254] = 1;
    var string2buf = function(str) {
      var buf, c2, c22, m_pos, i3, str_len = str.length, buf_len = 0;
      for (m_pos = 0; m_pos < str_len; m_pos++) {
        c2 = str.charCodeAt(m_pos);
        if ((c2 & 64512) === 55296 && m_pos + 1 < str_len) {
          c22 = str.charCodeAt(m_pos + 1);
          if ((c22 & 64512) === 56320) {
            c2 = 65536 + (c2 - 55296 << 10) + (c22 - 56320);
            m_pos++;
          }
        }
        buf_len += c2 < 128 ? 1 : c2 < 2048 ? 2 : c2 < 65536 ? 3 : 4;
      }
      if (support.uint8array) {
        buf = new Uint8Array(buf_len);
      } else {
        buf = new Array(buf_len);
      }
      for (i3 = 0, m_pos = 0; i3 < buf_len; m_pos++) {
        c2 = str.charCodeAt(m_pos);
        if ((c2 & 64512) === 55296 && m_pos + 1 < str_len) {
          c22 = str.charCodeAt(m_pos + 1);
          if ((c22 & 64512) === 56320) {
            c2 = 65536 + (c2 - 55296 << 10) + (c22 - 56320);
            m_pos++;
          }
        }
        if (c2 < 128) {
          buf[i3++] = c2;
        } else if (c2 < 2048) {
          buf[i3++] = 192 | c2 >>> 6;
          buf[i3++] = 128 | c2 & 63;
        } else if (c2 < 65536) {
          buf[i3++] = 224 | c2 >>> 12;
          buf[i3++] = 128 | c2 >>> 6 & 63;
          buf[i3++] = 128 | c2 & 63;
        } else {
          buf[i3++] = 240 | c2 >>> 18;
          buf[i3++] = 128 | c2 >>> 12 & 63;
          buf[i3++] = 128 | c2 >>> 6 & 63;
          buf[i3++] = 128 | c2 & 63;
        }
      }
      return buf;
    };
    var utf8border = function(buf, max) {
      var pos;
      max = max || buf.length;
      if (max > buf.length) {
        max = buf.length;
      }
      pos = max - 1;
      while (pos >= 0 && (buf[pos] & 192) === 128) {
        pos--;
      }
      if (pos < 0) {
        return max;
      }
      if (pos === 0) {
        return max;
      }
      return pos + _utf8len[buf[pos]] > max ? pos : max;
    };
    var buf2string = function(buf) {
      var i3, out, c2, c_len;
      var len = buf.length;
      var utf16buf = new Array(len * 2);
      for (out = 0, i3 = 0; i3 < len; ) {
        c2 = buf[i3++];
        if (c2 < 128) {
          utf16buf[out++] = c2;
          continue;
        }
        c_len = _utf8len[c2];
        if (c_len > 4) {
          utf16buf[out++] = 65533;
          i3 += c_len - 1;
          continue;
        }
        c2 &= c_len === 2 ? 31 : c_len === 3 ? 15 : 7;
        while (c_len > 1 && i3 < len) {
          c2 = c2 << 6 | buf[i3++] & 63;
          c_len--;
        }
        if (c_len > 1) {
          utf16buf[out++] = 65533;
          continue;
        }
        if (c2 < 65536) {
          utf16buf[out++] = c2;
        } else {
          c2 -= 65536;
          utf16buf[out++] = 55296 | c2 >> 10 & 1023;
          utf16buf[out++] = 56320 | c2 & 1023;
        }
      }
      if (utf16buf.length !== out) {
        if (utf16buf.subarray) {
          utf16buf = utf16buf.subarray(0, out);
        } else {
          utf16buf.length = out;
        }
      }
      return utils.applyFromCharCode(utf16buf);
    };
    exports.utf8encode = function utf8encode(str) {
      if (support.nodebuffer) {
        return nodejsUtils.newBufferFrom(str, "utf-8");
      }
      return string2buf(str);
    };
    exports.utf8decode = function utf8decode(buf) {
      if (support.nodebuffer) {
        return utils.transformTo("nodebuffer", buf).toString("utf-8");
      }
      buf = utils.transformTo(support.uint8array ? "uint8array" : "array", buf);
      return buf2string(buf);
    };
    function Utf8DecodeWorker() {
      GenericWorker.call(this, "utf-8 decode");
      this.leftOver = null;
    }
    utils.inherits(Utf8DecodeWorker, GenericWorker);
    Utf8DecodeWorker.prototype.processChunk = function(chunk) {
      var data = utils.transformTo(support.uint8array ? "uint8array" : "array", chunk.data);
      if (this.leftOver && this.leftOver.length) {
        if (support.uint8array) {
          var previousData = data;
          data = new Uint8Array(previousData.length + this.leftOver.length);
          data.set(this.leftOver, 0);
          data.set(previousData, this.leftOver.length);
        } else {
          data = this.leftOver.concat(data);
        }
        this.leftOver = null;
      }
      var nextBoundary = utf8border(data);
      var usableData = data;
      if (nextBoundary !== data.length) {
        if (support.uint8array) {
          usableData = data.subarray(0, nextBoundary);
          this.leftOver = data.subarray(nextBoundary, data.length);
        } else {
          usableData = data.slice(0, nextBoundary);
          this.leftOver = data.slice(nextBoundary, data.length);
        }
      }
      this.push({
        data: exports.utf8decode(usableData),
        meta: chunk.meta
      });
    };
    Utf8DecodeWorker.prototype.flush = function() {
      if (this.leftOver && this.leftOver.length) {
        this.push({
          data: exports.utf8decode(this.leftOver),
          meta: {}
        });
        this.leftOver = null;
      }
    };
    exports.Utf8DecodeWorker = Utf8DecodeWorker;
    function Utf8EncodeWorker() {
      GenericWorker.call(this, "utf-8 encode");
    }
    utils.inherits(Utf8EncodeWorker, GenericWorker);
    Utf8EncodeWorker.prototype.processChunk = function(chunk) {
      this.push({
        data: exports.utf8encode(chunk.data),
        meta: chunk.meta
      });
    };
    exports.Utf8EncodeWorker = Utf8EncodeWorker;
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/stream/ConvertWorker.js
var require_ConvertWorker = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/stream/ConvertWorker.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var GenericWorker = require_GenericWorker();
    var utils = require_utils();
    function ConvertWorker(destType) {
      GenericWorker.call(this, "ConvertWorker to " + destType);
      this.destType = destType;
    }
    utils.inherits(ConvertWorker, GenericWorker);
    ConvertWorker.prototype.processChunk = function(chunk) {
      this.push({
        data: utils.transformTo(this.destType, chunk.data),
        meta: chunk.meta
      });
    };
    module.exports = ConvertWorker;
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/nodejs/NodejsStreamOutputAdapter.js
var require_NodejsStreamOutputAdapter = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/nodejs/NodejsStreamOutputAdapter.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var Readable = require_readable().Readable;
    var utils = require_utils();
    utils.inherits(NodejsStreamOutputAdapter, Readable);
    function NodejsStreamOutputAdapter(helper, options, updateCb) {
      Readable.call(this, options);
      this._helper = helper;
      var self2 = this;
      helper.on("data", function(data, meta) {
        if (!self2.push(data)) {
          self2._helper.pause();
        }
        if (updateCb) {
          updateCb(meta);
        }
      }).on("error", function(e2) {
        self2.emit("error", e2);
      }).on("end", function() {
        self2.push(null);
      });
    }
    NodejsStreamOutputAdapter.prototype._read = function() {
      this._helper.resume();
    };
    module.exports = NodejsStreamOutputAdapter;
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/stream/StreamHelper.js
var require_StreamHelper = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/stream/StreamHelper.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var utils = require_utils();
    var ConvertWorker = require_ConvertWorker();
    var GenericWorker = require_GenericWorker();
    var base64 = require_base64();
    var support = require_support();
    var external = require_external();
    var NodejsStreamOutputAdapter = null;
    if (support.nodestream) {
      try {
        NodejsStreamOutputAdapter = require_NodejsStreamOutputAdapter();
      } catch (e2) {
      }
    }
    function transformZipOutput(type, content, mimeType) {
      switch (type) {
        case "blob":
          return utils.newBlob(utils.transformTo("arraybuffer", content), mimeType);
        case "base64":
          return base64.encode(content);
        default:
          return utils.transformTo(type, content);
      }
    }
    function concat(type, dataArray) {
      var i2, index = 0, res = null, totalLength = 0;
      for (i2 = 0; i2 < dataArray.length; i2++) {
        totalLength += dataArray[i2].length;
      }
      switch (type) {
        case "string":
          return dataArray.join("");
        case "array":
          return Array.prototype.concat.apply([], dataArray);
        case "uint8array":
          res = new Uint8Array(totalLength);
          for (i2 = 0; i2 < dataArray.length; i2++) {
            res.set(dataArray[i2], index);
            index += dataArray[i2].length;
          }
          return res;
        case "nodebuffer":
          return Buffer.concat(dataArray);
        default:
          throw new Error("concat : unsupported type '" + type + "'");
      }
    }
    function accumulate2(helper, updateCallback) {
      return new external.Promise(function(resolve, reject) {
        var dataArray = [];
        var chunkType = helper._internalType, resultType = helper._outputType, mimeType = helper._mimeType;
        helper.on("data", function(data, meta) {
          dataArray.push(data);
          if (updateCallback) {
            updateCallback(meta);
          }
        }).on("error", function(err) {
          dataArray = [];
          reject(err);
        }).on("end", function() {
          try {
            var result = transformZipOutput(resultType, concat(chunkType, dataArray), mimeType);
            resolve(result);
          } catch (e2) {
            reject(e2);
          }
          dataArray = [];
        }).resume();
      });
    }
    function StreamHelper(worker, outputType, mimeType) {
      var internalType = outputType;
      switch (outputType) {
        case "blob":
        case "arraybuffer":
          internalType = "uint8array";
          break;
        case "base64":
          internalType = "string";
          break;
      }
      try {
        this._internalType = internalType;
        this._outputType = outputType;
        this._mimeType = mimeType;
        utils.checkSupport(internalType);
        this._worker = worker.pipe(new ConvertWorker(internalType));
        worker.lock();
      } catch (e2) {
        this._worker = new GenericWorker("error");
        this._worker.error(e2);
      }
    }
    StreamHelper.prototype = {
      /**
       * Listen a StreamHelper, accumulate its content and concatenate it into a
       * complete block.
       * @param {Function} updateCb the update callback.
       * @return Promise the promise for the accumulation.
       */
      accumulate: function(updateCb) {
        return accumulate2(this, updateCb);
      },
      /**
       * Add a listener on an event triggered on a stream.
       * @param {String} evt the name of the event
       * @param {Function} fn the listener
       * @return {StreamHelper} the current helper.
       */
      on: function(evt, fn2) {
        var self2 = this;
        if (evt === "data") {
          this._worker.on(evt, function(chunk) {
            fn2.call(self2, chunk.data, chunk.meta);
          });
        } else {
          this._worker.on(evt, function() {
            utils.delay(fn2, arguments, self2);
          });
        }
        return this;
      },
      /**
       * Resume the flow of chunks.
       * @return {StreamHelper} the current helper.
       */
      resume: function() {
        utils.delay(this._worker.resume, [], this._worker);
        return this;
      },
      /**
       * Pause the flow of chunks.
       * @return {StreamHelper} the current helper.
       */
      pause: function() {
        this._worker.pause();
        return this;
      },
      /**
       * Return a nodejs stream for this helper.
       * @param {Function} updateCb the update callback.
       * @return {NodejsStreamOutputAdapter} the nodejs stream.
       */
      toNodejsStream: function(updateCb) {
        utils.checkSupport("nodestream");
        if (this._outputType !== "nodebuffer") {
          throw new Error(this._outputType + " is not supported by this method");
        }
        return new NodejsStreamOutputAdapter(this, {
          objectMode: this._outputType !== "nodebuffer"
        }, updateCb);
      }
    };
    module.exports = StreamHelper;
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/defaults.js
var require_defaults = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/defaults.js"(exports) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    exports.base64 = false;
    exports.binary = false;
    exports.dir = false;
    exports.createFolders = true;
    exports.date = null;
    exports.compression = null;
    exports.compressionOptions = null;
    exports.comment = null;
    exports.unixPermissions = null;
    exports.dosPermissions = null;
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/stream/DataWorker.js
var require_DataWorker = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/stream/DataWorker.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var utils = require_utils();
    var GenericWorker = require_GenericWorker();
    var DEFAULT_BLOCK_SIZE = 16 * 1024;
    function DataWorker(dataP) {
      GenericWorker.call(this, "DataWorker");
      var self2 = this;
      this.dataIsReady = false;
      this.index = 0;
      this.max = 0;
      this.data = null;
      this.type = "";
      this._tickScheduled = false;
      dataP.then(function(data) {
        self2.dataIsReady = true;
        self2.data = data;
        self2.max = data && data.length || 0;
        self2.type = utils.getTypeOf(data);
        if (!self2.isPaused) {
          self2._tickAndRepeat();
        }
      }, function(e2) {
        self2.error(e2);
      });
    }
    utils.inherits(DataWorker, GenericWorker);
    DataWorker.prototype.cleanUp = function() {
      GenericWorker.prototype.cleanUp.call(this);
      this.data = null;
    };
    DataWorker.prototype.resume = function() {
      if (!GenericWorker.prototype.resume.call(this)) {
        return false;
      }
      if (!this._tickScheduled && this.dataIsReady) {
        this._tickScheduled = true;
        utils.delay(this._tickAndRepeat, [], this);
      }
      return true;
    };
    DataWorker.prototype._tickAndRepeat = function() {
      this._tickScheduled = false;
      if (this.isPaused || this.isFinished) {
        return;
      }
      this._tick();
      if (!this.isFinished) {
        utils.delay(this._tickAndRepeat, [], this);
        this._tickScheduled = true;
      }
    };
    DataWorker.prototype._tick = function() {
      if (this.isPaused || this.isFinished) {
        return false;
      }
      var size = DEFAULT_BLOCK_SIZE;
      var data = null, nextIndex = Math.min(this.max, this.index + size);
      if (this.index >= this.max) {
        return this.end();
      } else {
        switch (this.type) {
          case "string":
            data = this.data.substring(this.index, nextIndex);
            break;
          case "uint8array":
            data = this.data.subarray(this.index, nextIndex);
            break;
          case "array":
          case "nodebuffer":
            data = this.data.slice(this.index, nextIndex);
            break;
        }
        this.index = nextIndex;
        return this.push({
          data,
          meta: {
            percent: this.max ? this.index / this.max * 100 : 0
          }
        });
      }
    };
    module.exports = DataWorker;
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/crc32.js
var require_crc32 = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/crc32.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var utils = require_utils();
    function makeTable() {
      var c2, table = [];
      for (var n2 = 0; n2 < 256; n2++) {
        c2 = n2;
        for (var k2 = 0; k2 < 8; k2++) {
          c2 = c2 & 1 ? 3988292384 ^ c2 >>> 1 : c2 >>> 1;
        }
        table[n2] = c2;
      }
      return table;
    }
    var crcTable = makeTable();
    function crc32(crc, buf, len, pos) {
      var t2 = crcTable, end = pos + len;
      crc = crc ^ -1;
      for (var i2 = pos; i2 < end; i2++) {
        crc = crc >>> 8 ^ t2[(crc ^ buf[i2]) & 255];
      }
      return crc ^ -1;
    }
    function crc32str(crc, str, len, pos) {
      var t2 = crcTable, end = pos + len;
      crc = crc ^ -1;
      for (var i2 = pos; i2 < end; i2++) {
        crc = crc >>> 8 ^ t2[(crc ^ str.charCodeAt(i2)) & 255];
      }
      return crc ^ -1;
    }
    module.exports = function crc32wrapper(input, crc) {
      if (typeof input === "undefined" || !input.length) {
        return 0;
      }
      var isArray = utils.getTypeOf(input) !== "string";
      if (isArray) {
        return crc32(crc | 0, input, input.length, 0);
      } else {
        return crc32str(crc | 0, input, input.length, 0);
      }
    };
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/stream/Crc32Probe.js
var require_Crc32Probe = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/stream/Crc32Probe.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var GenericWorker = require_GenericWorker();
    var crc32 = require_crc32();
    var utils = require_utils();
    function Crc32Probe() {
      GenericWorker.call(this, "Crc32Probe");
      this.withStreamInfo("crc32", 0);
    }
    utils.inherits(Crc32Probe, GenericWorker);
    Crc32Probe.prototype.processChunk = function(chunk) {
      this.streamInfo.crc32 = crc32(chunk.data, this.streamInfo.crc32 || 0);
      this.push(chunk);
    };
    module.exports = Crc32Probe;
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/stream/DataLengthProbe.js
var require_DataLengthProbe = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/stream/DataLengthProbe.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var utils = require_utils();
    var GenericWorker = require_GenericWorker();
    function DataLengthProbe(propName) {
      GenericWorker.call(this, "DataLengthProbe for " + propName);
      this.propName = propName;
      this.withStreamInfo(propName, 0);
    }
    utils.inherits(DataLengthProbe, GenericWorker);
    DataLengthProbe.prototype.processChunk = function(chunk) {
      if (chunk) {
        var length = this.streamInfo[this.propName] || 0;
        this.streamInfo[this.propName] = length + chunk.data.length;
      }
      GenericWorker.prototype.processChunk.call(this, chunk);
    };
    module.exports = DataLengthProbe;
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/compressedObject.js
var require_compressedObject = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/compressedObject.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var external = require_external();
    var DataWorker = require_DataWorker();
    var Crc32Probe = require_Crc32Probe();
    var DataLengthProbe = require_DataLengthProbe();
    function CompressedObject(compressedSize, uncompressedSize, crc32, compression, data) {
      this.compressedSize = compressedSize;
      this.uncompressedSize = uncompressedSize;
      this.crc32 = crc32;
      this.compression = compression;
      this.compressedContent = data;
    }
    CompressedObject.prototype = {
      /**
       * Create a worker to get the uncompressed content.
       * @return {GenericWorker} the worker.
       */
      getContentWorker: function() {
        var worker = new DataWorker(external.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new DataLengthProbe("data_length"));
        var that = this;
        worker.on("end", function() {
          if (this.streamInfo["data_length"] !== that.uncompressedSize) {
            throw new Error("Bug : uncompressed data size mismatch");
          }
        });
        return worker;
      },
      /**
       * Create a worker to get the compressed content.
       * @return {GenericWorker} the worker.
       */
      getCompressedWorker: function() {
        return new DataWorker(external.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize", this.compressedSize).withStreamInfo("uncompressedSize", this.uncompressedSize).withStreamInfo("crc32", this.crc32).withStreamInfo("compression", this.compression);
      }
    };
    CompressedObject.createWorkerFrom = function(uncompressedWorker, compression, compressionOptions) {
      return uncompressedWorker.pipe(new Crc32Probe()).pipe(new DataLengthProbe("uncompressedSize")).pipe(compression.compressWorker(compressionOptions)).pipe(new DataLengthProbe("compressedSize")).withStreamInfo("compression", compression);
    };
    module.exports = CompressedObject;
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/zipObject.js
var require_zipObject = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/zipObject.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var StreamHelper = require_StreamHelper();
    var DataWorker = require_DataWorker();
    var utf8 = require_utf8();
    var CompressedObject = require_compressedObject();
    var GenericWorker = require_GenericWorker();
    var ZipObject = function(name, data, options) {
      this.name = name;
      this.dir = options.dir;
      this.date = options.date;
      this.comment = options.comment;
      this.unixPermissions = options.unixPermissions;
      this.dosPermissions = options.dosPermissions;
      this._data = data;
      this._dataBinary = options.binary;
      this.options = {
        compression: options.compression,
        compressionOptions: options.compressionOptions
      };
    };
    ZipObject.prototype = {
      /**
       * Create an internal stream for the content of this object.
       * @param {String} type the type of each chunk.
       * @return StreamHelper the stream.
       */
      internalStream: function(type) {
        var result = null, outputType = "string";
        try {
          if (!type) {
            throw new Error("No output type specified.");
          }
          outputType = type.toLowerCase();
          var askUnicodeString = outputType === "string" || outputType === "text";
          if (outputType === "binarystring" || outputType === "text") {
            outputType = "string";
          }
          result = this._decompressWorker();
          var isUnicodeString = !this._dataBinary;
          if (isUnicodeString && !askUnicodeString) {
            result = result.pipe(new utf8.Utf8EncodeWorker());
          }
          if (!isUnicodeString && askUnicodeString) {
            result = result.pipe(new utf8.Utf8DecodeWorker());
          }
        } catch (e2) {
          result = new GenericWorker("error");
          result.error(e2);
        }
        return new StreamHelper(result, outputType, "");
      },
      /**
       * Prepare the content in the asked type.
       * @param {String} type the type of the result.
       * @param {Function} onUpdate a function to call on each internal update.
       * @return Promise the promise of the result.
       */
      async: function(type, onUpdate) {
        return this.internalStream(type).accumulate(onUpdate);
      },
      /**
       * Prepare the content as a nodejs stream.
       * @param {String} type the type of each chunk.
       * @param {Function} onUpdate a function to call on each internal update.
       * @return Stream the stream.
       */
      nodeStream: function(type, onUpdate) {
        return this.internalStream(type || "nodebuffer").toNodejsStream(onUpdate);
      },
      /**
       * Return a worker for the compressed content.
       * @private
       * @param {Object} compression the compression object to use.
       * @param {Object} compressionOptions the options to use when compressing.
       * @return Worker the worker.
       */
      _compressWorker: function(compression, compressionOptions) {
        if (this._data instanceof CompressedObject && this._data.compression.magic === compression.magic) {
          return this._data.getCompressedWorker();
        } else {
          var result = this._decompressWorker();
          if (!this._dataBinary) {
            result = result.pipe(new utf8.Utf8EncodeWorker());
          }
          return CompressedObject.createWorkerFrom(result, compression, compressionOptions);
        }
      },
      /**
       * Return a worker for the decompressed content.
       * @private
       * @return Worker the worker.
       */
      _decompressWorker: function() {
        if (this._data instanceof CompressedObject) {
          return this._data.getContentWorker();
        } else if (this._data instanceof GenericWorker) {
          return this._data;
        } else {
          return new DataWorker(this._data);
        }
      }
    };
    var removedMethods = ["asText", "asBinary", "asNodeBuffer", "asUint8Array", "asArrayBuffer"];
    var removedFn = function() {
      throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.");
    };
    for (i2 = 0; i2 < removedMethods.length; i2++) {
      ZipObject.prototype[removedMethods[i2]] = removedFn;
    }
    var i2;
    module.exports = ZipObject;
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/pako/lib/utils/common.js
var require_common = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/pako/lib/utils/common.js"(exports) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var TYPED_OK = typeof Uint8Array !== "undefined" && typeof Uint16Array !== "undefined" && typeof Int32Array !== "undefined";
    function _has(obj, key2) {
      return Object.prototype.hasOwnProperty.call(obj, key2);
    }
    exports.assign = function(obj) {
      var sources = Array.prototype.slice.call(arguments, 1);
      while (sources.length) {
        var source = sources.shift();
        if (!source) {
          continue;
        }
        if (typeof source !== "object") {
          throw new TypeError(source + "must be non-object");
        }
        for (var p2 in source) {
          if (_has(source, p2)) {
            obj[p2] = source[p2];
          }
        }
      }
      return obj;
    };
    exports.shrinkBuf = function(buf, size) {
      if (buf.length === size) {
        return buf;
      }
      if (buf.subarray) {
        return buf.subarray(0, size);
      }
      buf.length = size;
      return buf;
    };
    var fnTyped = {
      arraySet: function(dest, src, src_offs, len, dest_offs) {
        if (src.subarray && dest.subarray) {
          dest.set(src.subarray(src_offs, src_offs + len), dest_offs);
          return;
        }
        for (var i2 = 0; i2 < len; i2++) {
          dest[dest_offs + i2] = src[src_offs + i2];
        }
      },
      // Join array of chunks to single array.
      flattenChunks: function(chunks) {
        var i2, l2, len, pos, chunk, result;
        len = 0;
        for (i2 = 0, l2 = chunks.length; i2 < l2; i2++) {
          len += chunks[i2].length;
        }
        result = new Uint8Array(len);
        pos = 0;
        for (i2 = 0, l2 = chunks.length; i2 < l2; i2++) {
          chunk = chunks[i2];
          result.set(chunk, pos);
          pos += chunk.length;
        }
        return result;
      }
    };
    var fnUntyped = {
      arraySet: function(dest, src, src_offs, len, dest_offs) {
        for (var i2 = 0; i2 < len; i2++) {
          dest[dest_offs + i2] = src[src_offs + i2];
        }
      },
      // Join array of chunks to single array.
      flattenChunks: function(chunks) {
        return [].concat.apply([], chunks);
      }
    };
    exports.setTyped = function(on2) {
      if (on2) {
        exports.Buf8 = Uint8Array;
        exports.Buf16 = Uint16Array;
        exports.Buf32 = Int32Array;
        exports.assign(exports, fnTyped);
      } else {
        exports.Buf8 = Array;
        exports.Buf16 = Array;
        exports.Buf32 = Array;
        exports.assign(exports, fnUntyped);
      }
    };
    exports.setTyped(TYPED_OK);
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/pako/lib/zlib/trees.js
var require_trees = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/pako/lib/zlib/trees.js"(exports) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var utils = require_common();
    var Z_FIXED = 4;
    var Z_BINARY = 0;
    var Z_TEXT = 1;
    var Z_UNKNOWN = 2;
    function zero(buf) {
      var len = buf.length;
      while (--len >= 0) {
        buf[len] = 0;
      }
    }
    var STORED_BLOCK = 0;
    var STATIC_TREES = 1;
    var DYN_TREES = 2;
    var MIN_MATCH = 3;
    var MAX_MATCH = 258;
    var LENGTH_CODES = 29;
    var LITERALS = 256;
    var L_CODES = LITERALS + 1 + LENGTH_CODES;
    var D_CODES = 30;
    var BL_CODES = 19;
    var HEAP_SIZE = 2 * L_CODES + 1;
    var MAX_BITS = 15;
    var Buf_size = 16;
    var MAX_BL_BITS = 7;
    var END_BLOCK = 256;
    var REP_3_6 = 16;
    var REPZ_3_10 = 17;
    var REPZ_11_138 = 18;
    var extra_lbits = (
      /* extra bits for each length code */
      [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0]
    );
    var extra_dbits = (
      /* extra bits for each distance code */
      [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13]
    );
    var extra_blbits = (
      /* extra bits for each bit length code */
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 7]
    );
    var bl_order = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15];
    var DIST_CODE_LEN = 512;
    var static_ltree = new Array((L_CODES + 2) * 2);
    zero(static_ltree);
    var static_dtree = new Array(D_CODES * 2);
    zero(static_dtree);
    var _dist_code = new Array(DIST_CODE_LEN);
    zero(_dist_code);
    var _length_code = new Array(MAX_MATCH - MIN_MATCH + 1);
    zero(_length_code);
    var base_length = new Array(LENGTH_CODES);
    zero(base_length);
    var base_dist = new Array(D_CODES);
    zero(base_dist);
    function StaticTreeDesc(static_tree, extra_bits, extra_base, elems, max_length) {
      this.static_tree = static_tree;
      this.extra_bits = extra_bits;
      this.extra_base = extra_base;
      this.elems = elems;
      this.max_length = max_length;
      this.has_stree = static_tree && static_tree.length;
    }
    var static_l_desc;
    var static_d_desc;
    var static_bl_desc;
    function TreeDesc(dyn_tree, stat_desc) {
      this.dyn_tree = dyn_tree;
      this.max_code = 0;
      this.stat_desc = stat_desc;
    }
    function d_code(dist) {
      return dist < 256 ? _dist_code[dist] : _dist_code[256 + (dist >>> 7)];
    }
    function put_short(s2, w2) {
      s2.pending_buf[s2.pending++] = w2 & 255;
      s2.pending_buf[s2.pending++] = w2 >>> 8 & 255;
    }
    function send_bits(s2, value, length) {
      if (s2.bi_valid > Buf_size - length) {
        s2.bi_buf |= value << s2.bi_valid & 65535;
        put_short(s2, s2.bi_buf);
        s2.bi_buf = value >> Buf_size - s2.bi_valid;
        s2.bi_valid += length - Buf_size;
      } else {
        s2.bi_buf |= value << s2.bi_valid & 65535;
        s2.bi_valid += length;
      }
    }
    function send_code(s2, c2, tree) {
      send_bits(
        s2,
        tree[c2 * 2],
        tree[c2 * 2 + 1]
        /*.Len*/
      );
    }
    function bi_reverse(code, len) {
      var res = 0;
      do {
        res |= code & 1;
        code >>>= 1;
        res <<= 1;
      } while (--len > 0);
      return res >>> 1;
    }
    function bi_flush(s2) {
      if (s2.bi_valid === 16) {
        put_short(s2, s2.bi_buf);
        s2.bi_buf = 0;
        s2.bi_valid = 0;
      } else if (s2.bi_valid >= 8) {
        s2.pending_buf[s2.pending++] = s2.bi_buf & 255;
        s2.bi_buf >>= 8;
        s2.bi_valid -= 8;
      }
    }
    function gen_bitlen(s2, desc) {
      var tree = desc.dyn_tree;
      var max_code = desc.max_code;
      var stree = desc.stat_desc.static_tree;
      var has_stree = desc.stat_desc.has_stree;
      var extra = desc.stat_desc.extra_bits;
      var base = desc.stat_desc.extra_base;
      var max_length = desc.stat_desc.max_length;
      var h2;
      var n2, m2;
      var bits;
      var xbits;
      var f2;
      var overflow = 0;
      for (bits = 0; bits <= MAX_BITS; bits++) {
        s2.bl_count[bits] = 0;
      }
      tree[s2.heap[s2.heap_max] * 2 + 1] = 0;
      for (h2 = s2.heap_max + 1; h2 < HEAP_SIZE; h2++) {
        n2 = s2.heap[h2];
        bits = tree[tree[n2 * 2 + 1] * 2 + 1] + 1;
        if (bits > max_length) {
          bits = max_length;
          overflow++;
        }
        tree[n2 * 2 + 1] = bits;
        if (n2 > max_code) {
          continue;
        }
        s2.bl_count[bits]++;
        xbits = 0;
        if (n2 >= base) {
          xbits = extra[n2 - base];
        }
        f2 = tree[n2 * 2];
        s2.opt_len += f2 * (bits + xbits);
        if (has_stree) {
          s2.static_len += f2 * (stree[n2 * 2 + 1] + xbits);
        }
      }
      if (overflow === 0) {
        return;
      }
      do {
        bits = max_length - 1;
        while (s2.bl_count[bits] === 0) {
          bits--;
        }
        s2.bl_count[bits]--;
        s2.bl_count[bits + 1] += 2;
        s2.bl_count[max_length]--;
        overflow -= 2;
      } while (overflow > 0);
      for (bits = max_length; bits !== 0; bits--) {
        n2 = s2.bl_count[bits];
        while (n2 !== 0) {
          m2 = s2.heap[--h2];
          if (m2 > max_code) {
            continue;
          }
          if (tree[m2 * 2 + 1] !== bits) {
            s2.opt_len += (bits - tree[m2 * 2 + 1]) * tree[m2 * 2];
            tree[m2 * 2 + 1] = bits;
          }
          n2--;
        }
      }
    }
    function gen_codes(tree, max_code, bl_count) {
      var next_code = new Array(MAX_BITS + 1);
      var code = 0;
      var bits;
      var n2;
      for (bits = 1; bits <= MAX_BITS; bits++) {
        next_code[bits] = code = code + bl_count[bits - 1] << 1;
      }
      for (n2 = 0; n2 <= max_code; n2++) {
        var len = tree[n2 * 2 + 1];
        if (len === 0) {
          continue;
        }
        tree[n2 * 2] = bi_reverse(next_code[len]++, len);
      }
    }
    function tr_static_init() {
      var n2;
      var bits;
      var length;
      var code;
      var dist;
      var bl_count = new Array(MAX_BITS + 1);
      length = 0;
      for (code = 0; code < LENGTH_CODES - 1; code++) {
        base_length[code] = length;
        for (n2 = 0; n2 < 1 << extra_lbits[code]; n2++) {
          _length_code[length++] = code;
        }
      }
      _length_code[length - 1] = code;
      dist = 0;
      for (code = 0; code < 16; code++) {
        base_dist[code] = dist;
        for (n2 = 0; n2 < 1 << extra_dbits[code]; n2++) {
          _dist_code[dist++] = code;
        }
      }
      dist >>= 7;
      for (; code < D_CODES; code++) {
        base_dist[code] = dist << 7;
        for (n2 = 0; n2 < 1 << extra_dbits[code] - 7; n2++) {
          _dist_code[256 + dist++] = code;
        }
      }
      for (bits = 0; bits <= MAX_BITS; bits++) {
        bl_count[bits] = 0;
      }
      n2 = 0;
      while (n2 <= 143) {
        static_ltree[n2 * 2 + 1] = 8;
        n2++;
        bl_count[8]++;
      }
      while (n2 <= 255) {
        static_ltree[n2 * 2 + 1] = 9;
        n2++;
        bl_count[9]++;
      }
      while (n2 <= 279) {
        static_ltree[n2 * 2 + 1] = 7;
        n2++;
        bl_count[7]++;
      }
      while (n2 <= 287) {
        static_ltree[n2 * 2 + 1] = 8;
        n2++;
        bl_count[8]++;
      }
      gen_codes(static_ltree, L_CODES + 1, bl_count);
      for (n2 = 0; n2 < D_CODES; n2++) {
        static_dtree[n2 * 2 + 1] = 5;
        static_dtree[n2 * 2] = bi_reverse(n2, 5);
      }
      static_l_desc = new StaticTreeDesc(static_ltree, extra_lbits, LITERALS + 1, L_CODES, MAX_BITS);
      static_d_desc = new StaticTreeDesc(static_dtree, extra_dbits, 0, D_CODES, MAX_BITS);
      static_bl_desc = new StaticTreeDesc(new Array(0), extra_blbits, 0, BL_CODES, MAX_BL_BITS);
    }
    function init_block(s2) {
      var n2;
      for (n2 = 0; n2 < L_CODES; n2++) {
        s2.dyn_ltree[n2 * 2] = 0;
      }
      for (n2 = 0; n2 < D_CODES; n2++) {
        s2.dyn_dtree[n2 * 2] = 0;
      }
      for (n2 = 0; n2 < BL_CODES; n2++) {
        s2.bl_tree[n2 * 2] = 0;
      }
      s2.dyn_ltree[END_BLOCK * 2] = 1;
      s2.opt_len = s2.static_len = 0;
      s2.last_lit = s2.matches = 0;
    }
    function bi_windup(s2) {
      if (s2.bi_valid > 8) {
        put_short(s2, s2.bi_buf);
      } else if (s2.bi_valid > 0) {
        s2.pending_buf[s2.pending++] = s2.bi_buf;
      }
      s2.bi_buf = 0;
      s2.bi_valid = 0;
    }
    function copy_block(s2, buf, len, header) {
      bi_windup(s2);
      if (header) {
        put_short(s2, len);
        put_short(s2, ~len);
      }
      utils.arraySet(s2.pending_buf, s2.window, buf, len, s2.pending);
      s2.pending += len;
    }
    function smaller(tree, n2, m2, depth) {
      var _n2 = n2 * 2;
      var _m2 = m2 * 2;
      return tree[_n2] < tree[_m2] || tree[_n2] === tree[_m2] && depth[n2] <= depth[m2];
    }
    function pqdownheap(s2, tree, k2) {
      var v2 = s2.heap[k2];
      var j2 = k2 << 1;
      while (j2 <= s2.heap_len) {
        if (j2 < s2.heap_len && smaller(tree, s2.heap[j2 + 1], s2.heap[j2], s2.depth)) {
          j2++;
        }
        if (smaller(tree, v2, s2.heap[j2], s2.depth)) {
          break;
        }
        s2.heap[k2] = s2.heap[j2];
        k2 = j2;
        j2 <<= 1;
      }
      s2.heap[k2] = v2;
    }
    function compress_block(s2, ltree, dtree) {
      var dist;
      var lc;
      var lx = 0;
      var code;
      var extra;
      if (s2.last_lit !== 0) {
        do {
          dist = s2.pending_buf[s2.d_buf + lx * 2] << 8 | s2.pending_buf[s2.d_buf + lx * 2 + 1];
          lc = s2.pending_buf[s2.l_buf + lx];
          lx++;
          if (dist === 0) {
            send_code(s2, lc, ltree);
          } else {
            code = _length_code[lc];
            send_code(s2, code + LITERALS + 1, ltree);
            extra = extra_lbits[code];
            if (extra !== 0) {
              lc -= base_length[code];
              send_bits(s2, lc, extra);
            }
            dist--;
            code = d_code(dist);
            send_code(s2, code, dtree);
            extra = extra_dbits[code];
            if (extra !== 0) {
              dist -= base_dist[code];
              send_bits(s2, dist, extra);
            }
          }
        } while (lx < s2.last_lit);
      }
      send_code(s2, END_BLOCK, ltree);
    }
    function build_tree(s2, desc) {
      var tree = desc.dyn_tree;
      var stree = desc.stat_desc.static_tree;
      var has_stree = desc.stat_desc.has_stree;
      var elems = desc.stat_desc.elems;
      var n2, m2;
      var max_code = -1;
      var node;
      s2.heap_len = 0;
      s2.heap_max = HEAP_SIZE;
      for (n2 = 0; n2 < elems; n2++) {
        if (tree[n2 * 2] !== 0) {
          s2.heap[++s2.heap_len] = max_code = n2;
          s2.depth[n2] = 0;
        } else {
          tree[n2 * 2 + 1] = 0;
        }
      }
      while (s2.heap_len < 2) {
        node = s2.heap[++s2.heap_len] = max_code < 2 ? ++max_code : 0;
        tree[node * 2] = 1;
        s2.depth[node] = 0;
        s2.opt_len--;
        if (has_stree) {
          s2.static_len -= stree[node * 2 + 1];
        }
      }
      desc.max_code = max_code;
      for (n2 = s2.heap_len >> 1; n2 >= 1; n2--) {
        pqdownheap(s2, tree, n2);
      }
      node = elems;
      do {
        n2 = s2.heap[
          1
          /*SMALLEST*/
        ];
        s2.heap[
          1
          /*SMALLEST*/
        ] = s2.heap[s2.heap_len--];
        pqdownheap(
          s2,
          tree,
          1
          /*SMALLEST*/
        );
        m2 = s2.heap[
          1
          /*SMALLEST*/
        ];
        s2.heap[--s2.heap_max] = n2;
        s2.heap[--s2.heap_max] = m2;
        tree[node * 2] = tree[n2 * 2] + tree[m2 * 2];
        s2.depth[node] = (s2.depth[n2] >= s2.depth[m2] ? s2.depth[n2] : s2.depth[m2]) + 1;
        tree[n2 * 2 + 1] = tree[m2 * 2 + 1] = node;
        s2.heap[
          1
          /*SMALLEST*/
        ] = node++;
        pqdownheap(
          s2,
          tree,
          1
          /*SMALLEST*/
        );
      } while (s2.heap_len >= 2);
      s2.heap[--s2.heap_max] = s2.heap[
        1
        /*SMALLEST*/
      ];
      gen_bitlen(s2, desc);
      gen_codes(tree, max_code, s2.bl_count);
    }
    function scan_tree(s2, tree, max_code) {
      var n2;
      var prevlen = -1;
      var curlen;
      var nextlen = tree[0 * 2 + 1];
      var count = 0;
      var max_count = 7;
      var min_count = 4;
      if (nextlen === 0) {
        max_count = 138;
        min_count = 3;
      }
      tree[(max_code + 1) * 2 + 1] = 65535;
      for (n2 = 0; n2 <= max_code; n2++) {
        curlen = nextlen;
        nextlen = tree[(n2 + 1) * 2 + 1];
        if (++count < max_count && curlen === nextlen) {
          continue;
        } else if (count < min_count) {
          s2.bl_tree[curlen * 2] += count;
        } else if (curlen !== 0) {
          if (curlen !== prevlen) {
            s2.bl_tree[curlen * 2]++;
          }
          s2.bl_tree[REP_3_6 * 2]++;
        } else if (count <= 10) {
          s2.bl_tree[REPZ_3_10 * 2]++;
        } else {
          s2.bl_tree[REPZ_11_138 * 2]++;
        }
        count = 0;
        prevlen = curlen;
        if (nextlen === 0) {
          max_count = 138;
          min_count = 3;
        } else if (curlen === nextlen) {
          max_count = 6;
          min_count = 3;
        } else {
          max_count = 7;
          min_count = 4;
        }
      }
    }
    function send_tree(s2, tree, max_code) {
      var n2;
      var prevlen = -1;
      var curlen;
      var nextlen = tree[0 * 2 + 1];
      var count = 0;
      var max_count = 7;
      var min_count = 4;
      if (nextlen === 0) {
        max_count = 138;
        min_count = 3;
      }
      for (n2 = 0; n2 <= max_code; n2++) {
        curlen = nextlen;
        nextlen = tree[(n2 + 1) * 2 + 1];
        if (++count < max_count && curlen === nextlen) {
          continue;
        } else if (count < min_count) {
          do {
            send_code(s2, curlen, s2.bl_tree);
          } while (--count !== 0);
        } else if (curlen !== 0) {
          if (curlen !== prevlen) {
            send_code(s2, curlen, s2.bl_tree);
            count--;
          }
          send_code(s2, REP_3_6, s2.bl_tree);
          send_bits(s2, count - 3, 2);
        } else if (count <= 10) {
          send_code(s2, REPZ_3_10, s2.bl_tree);
          send_bits(s2, count - 3, 3);
        } else {
          send_code(s2, REPZ_11_138, s2.bl_tree);
          send_bits(s2, count - 11, 7);
        }
        count = 0;
        prevlen = curlen;
        if (nextlen === 0) {
          max_count = 138;
          min_count = 3;
        } else if (curlen === nextlen) {
          max_count = 6;
          min_count = 3;
        } else {
          max_count = 7;
          min_count = 4;
        }
      }
    }
    function build_bl_tree(s2) {
      var max_blindex;
      scan_tree(s2, s2.dyn_ltree, s2.l_desc.max_code);
      scan_tree(s2, s2.dyn_dtree, s2.d_desc.max_code);
      build_tree(s2, s2.bl_desc);
      for (max_blindex = BL_CODES - 1; max_blindex >= 3; max_blindex--) {
        if (s2.bl_tree[bl_order[max_blindex] * 2 + 1] !== 0) {
          break;
        }
      }
      s2.opt_len += 3 * (max_blindex + 1) + 5 + 5 + 4;
      return max_blindex;
    }
    function send_all_trees(s2, lcodes, dcodes, blcodes) {
      var rank;
      send_bits(s2, lcodes - 257, 5);
      send_bits(s2, dcodes - 1, 5);
      send_bits(s2, blcodes - 4, 4);
      for (rank = 0; rank < blcodes; rank++) {
        send_bits(s2, s2.bl_tree[bl_order[rank] * 2 + 1], 3);
      }
      send_tree(s2, s2.dyn_ltree, lcodes - 1);
      send_tree(s2, s2.dyn_dtree, dcodes - 1);
    }
    function detect_data_type(s2) {
      var black_mask = 4093624447;
      var n2;
      for (n2 = 0; n2 <= 31; n2++, black_mask >>>= 1) {
        if (black_mask & 1 && s2.dyn_ltree[n2 * 2] !== 0) {
          return Z_BINARY;
        }
      }
      if (s2.dyn_ltree[9 * 2] !== 0 || s2.dyn_ltree[10 * 2] !== 0 || s2.dyn_ltree[13 * 2] !== 0) {
        return Z_TEXT;
      }
      for (n2 = 32; n2 < LITERALS; n2++) {
        if (s2.dyn_ltree[n2 * 2] !== 0) {
          return Z_TEXT;
        }
      }
      return Z_BINARY;
    }
    var static_init_done = false;
    function _tr_init(s2) {
      if (!static_init_done) {
        tr_static_init();
        static_init_done = true;
      }
      s2.l_desc = new TreeDesc(s2.dyn_ltree, static_l_desc);
      s2.d_desc = new TreeDesc(s2.dyn_dtree, static_d_desc);
      s2.bl_desc = new TreeDesc(s2.bl_tree, static_bl_desc);
      s2.bi_buf = 0;
      s2.bi_valid = 0;
      init_block(s2);
    }
    function _tr_stored_block(s2, buf, stored_len, last) {
      send_bits(s2, (STORED_BLOCK << 1) + (last ? 1 : 0), 3);
      copy_block(s2, buf, stored_len, true);
    }
    function _tr_align(s2) {
      send_bits(s2, STATIC_TREES << 1, 3);
      send_code(s2, END_BLOCK, static_ltree);
      bi_flush(s2);
    }
    function _tr_flush_block(s2, buf, stored_len, last) {
      var opt_lenb, static_lenb;
      var max_blindex = 0;
      if (s2.level > 0) {
        if (s2.strm.data_type === Z_UNKNOWN) {
          s2.strm.data_type = detect_data_type(s2);
        }
        build_tree(s2, s2.l_desc);
        build_tree(s2, s2.d_desc);
        max_blindex = build_bl_tree(s2);
        opt_lenb = s2.opt_len + 3 + 7 >>> 3;
        static_lenb = s2.static_len + 3 + 7 >>> 3;
        if (static_lenb <= opt_lenb) {
          opt_lenb = static_lenb;
        }
      } else {
        opt_lenb = static_lenb = stored_len + 5;
      }
      if (stored_len + 4 <= opt_lenb && buf !== -1) {
        _tr_stored_block(s2, buf, stored_len, last);
      } else if (s2.strategy === Z_FIXED || static_lenb === opt_lenb) {
        send_bits(s2, (STATIC_TREES << 1) + (last ? 1 : 0), 3);
        compress_block(s2, static_ltree, static_dtree);
      } else {
        send_bits(s2, (DYN_TREES << 1) + (last ? 1 : 0), 3);
        send_all_trees(s2, s2.l_desc.max_code + 1, s2.d_desc.max_code + 1, max_blindex + 1);
        compress_block(s2, s2.dyn_ltree, s2.dyn_dtree);
      }
      init_block(s2);
      if (last) {
        bi_windup(s2);
      }
    }
    function _tr_tally(s2, dist, lc) {
      s2.pending_buf[s2.d_buf + s2.last_lit * 2] = dist >>> 8 & 255;
      s2.pending_buf[s2.d_buf + s2.last_lit * 2 + 1] = dist & 255;
      s2.pending_buf[s2.l_buf + s2.last_lit] = lc & 255;
      s2.last_lit++;
      if (dist === 0) {
        s2.dyn_ltree[lc * 2]++;
      } else {
        s2.matches++;
        dist--;
        s2.dyn_ltree[(_length_code[lc] + LITERALS + 1) * 2]++;
        s2.dyn_dtree[d_code(dist) * 2]++;
      }
      return s2.last_lit === s2.lit_bufsize - 1;
    }
    exports._tr_init = _tr_init;
    exports._tr_stored_block = _tr_stored_block;
    exports._tr_flush_block = _tr_flush_block;
    exports._tr_tally = _tr_tally;
    exports._tr_align = _tr_align;
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/pako/lib/zlib/adler32.js
var require_adler32 = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/pako/lib/zlib/adler32.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    function adler32(adler, buf, len, pos) {
      var s1 = adler & 65535 | 0, s2 = adler >>> 16 & 65535 | 0, n2 = 0;
      while (len !== 0) {
        n2 = len > 2e3 ? 2e3 : len;
        len -= n2;
        do {
          s1 = s1 + buf[pos++] | 0;
          s2 = s2 + s1 | 0;
        } while (--n2);
        s1 %= 65521;
        s2 %= 65521;
      }
      return s1 | s2 << 16 | 0;
    }
    module.exports = adler32;
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/pako/lib/zlib/crc32.js
var require_crc322 = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/pako/lib/zlib/crc32.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    function makeTable() {
      var c2, table = [];
      for (var n2 = 0; n2 < 256; n2++) {
        c2 = n2;
        for (var k2 = 0; k2 < 8; k2++) {
          c2 = c2 & 1 ? 3988292384 ^ c2 >>> 1 : c2 >>> 1;
        }
        table[n2] = c2;
      }
      return table;
    }
    var crcTable = makeTable();
    function crc32(crc, buf, len, pos) {
      var t2 = crcTable, end = pos + len;
      crc ^= -1;
      for (var i2 = pos; i2 < end; i2++) {
        crc = crc >>> 8 ^ t2[(crc ^ buf[i2]) & 255];
      }
      return crc ^ -1;
    }
    module.exports = crc32;
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/pako/lib/zlib/messages.js
var require_messages = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/pako/lib/zlib/messages.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    module.exports = {
      2: "need dictionary",
      /* Z_NEED_DICT       2  */
      1: "stream end",
      /* Z_STREAM_END      1  */
      0: "",
      /* Z_OK              0  */
      "-1": "file error",
      /* Z_ERRNO         (-1) */
      "-2": "stream error",
      /* Z_STREAM_ERROR  (-2) */
      "-3": "data error",
      /* Z_DATA_ERROR    (-3) */
      "-4": "insufficient memory",
      /* Z_MEM_ERROR     (-4) */
      "-5": "buffer error",
      /* Z_BUF_ERROR     (-5) */
      "-6": "incompatible version"
      /* Z_VERSION_ERROR (-6) */
    };
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/pako/lib/zlib/deflate.js
var require_deflate = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/pako/lib/zlib/deflate.js"(exports) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var utils = require_common();
    var trees = require_trees();
    var adler32 = require_adler32();
    var crc32 = require_crc322();
    var msg = require_messages();
    var Z_NO_FLUSH = 0;
    var Z_PARTIAL_FLUSH = 1;
    var Z_FULL_FLUSH = 3;
    var Z_FINISH = 4;
    var Z_BLOCK = 5;
    var Z_OK = 0;
    var Z_STREAM_END = 1;
    var Z_STREAM_ERROR = -2;
    var Z_DATA_ERROR = -3;
    var Z_BUF_ERROR = -5;
    var Z_DEFAULT_COMPRESSION = -1;
    var Z_FILTERED = 1;
    var Z_HUFFMAN_ONLY = 2;
    var Z_RLE = 3;
    var Z_FIXED = 4;
    var Z_DEFAULT_STRATEGY = 0;
    var Z_UNKNOWN = 2;
    var Z_DEFLATED = 8;
    var MAX_MEM_LEVEL = 9;
    var MAX_WBITS = 15;
    var DEF_MEM_LEVEL = 8;
    var LENGTH_CODES = 29;
    var LITERALS = 256;
    var L_CODES = LITERALS + 1 + LENGTH_CODES;
    var D_CODES = 30;
    var BL_CODES = 19;
    var HEAP_SIZE = 2 * L_CODES + 1;
    var MAX_BITS = 15;
    var MIN_MATCH = 3;
    var MAX_MATCH = 258;
    var MIN_LOOKAHEAD = MAX_MATCH + MIN_MATCH + 1;
    var PRESET_DICT = 32;
    var INIT_STATE = 42;
    var EXTRA_STATE = 69;
    var NAME_STATE = 73;
    var COMMENT_STATE = 91;
    var HCRC_STATE = 103;
    var BUSY_STATE = 113;
    var FINISH_STATE = 666;
    var BS_NEED_MORE = 1;
    var BS_BLOCK_DONE = 2;
    var BS_FINISH_STARTED = 3;
    var BS_FINISH_DONE = 4;
    var OS_CODE = 3;
    function err(strm, errorCode) {
      strm.msg = msg[errorCode];
      return errorCode;
    }
    function rank(f2) {
      return (f2 << 1) - (f2 > 4 ? 9 : 0);
    }
    function zero(buf) {
      var len = buf.length;
      while (--len >= 0) {
        buf[len] = 0;
      }
    }
    function flush_pending(strm) {
      var s2 = strm.state;
      var len = s2.pending;
      if (len > strm.avail_out) {
        len = strm.avail_out;
      }
      if (len === 0) {
        return;
      }
      utils.arraySet(strm.output, s2.pending_buf, s2.pending_out, len, strm.next_out);
      strm.next_out += len;
      s2.pending_out += len;
      strm.total_out += len;
      strm.avail_out -= len;
      s2.pending -= len;
      if (s2.pending === 0) {
        s2.pending_out = 0;
      }
    }
    function flush_block_only(s2, last) {
      trees._tr_flush_block(s2, s2.block_start >= 0 ? s2.block_start : -1, s2.strstart - s2.block_start, last);
      s2.block_start = s2.strstart;
      flush_pending(s2.strm);
    }
    function put_byte(s2, b2) {
      s2.pending_buf[s2.pending++] = b2;
    }
    function putShortMSB(s2, b2) {
      s2.pending_buf[s2.pending++] = b2 >>> 8 & 255;
      s2.pending_buf[s2.pending++] = b2 & 255;
    }
    function read_buf(strm, buf, start, size) {
      var len = strm.avail_in;
      if (len > size) {
        len = size;
      }
      if (len === 0) {
        return 0;
      }
      strm.avail_in -= len;
      utils.arraySet(buf, strm.input, strm.next_in, len, start);
      if (strm.state.wrap === 1) {
        strm.adler = adler32(strm.adler, buf, len, start);
      } else if (strm.state.wrap === 2) {
        strm.adler = crc32(strm.adler, buf, len, start);
      }
      strm.next_in += len;
      strm.total_in += len;
      return len;
    }
    function longest_match(s2, cur_match) {
      var chain_length = s2.max_chain_length;
      var scan = s2.strstart;
      var match;
      var len;
      var best_len = s2.prev_length;
      var nice_match = s2.nice_match;
      var limit = s2.strstart > s2.w_size - MIN_LOOKAHEAD ? s2.strstart - (s2.w_size - MIN_LOOKAHEAD) : 0;
      var _win = s2.window;
      var wmask = s2.w_mask;
      var prev = s2.prev;
      var strend = s2.strstart + MAX_MATCH;
      var scan_end1 = _win[scan + best_len - 1];
      var scan_end = _win[scan + best_len];
      if (s2.prev_length >= s2.good_match) {
        chain_length >>= 2;
      }
      if (nice_match > s2.lookahead) {
        nice_match = s2.lookahead;
      }
      do {
        match = cur_match;
        if (_win[match + best_len] !== scan_end || _win[match + best_len - 1] !== scan_end1 || _win[match] !== _win[scan] || _win[++match] !== _win[scan + 1]) {
          continue;
        }
        scan += 2;
        match++;
        do {
        } while (_win[++scan] === _win[++match] && _win[++scan] === _win[++match] && _win[++scan] === _win[++match] && _win[++scan] === _win[++match] && _win[++scan] === _win[++match] && _win[++scan] === _win[++match] && _win[++scan] === _win[++match] && _win[++scan] === _win[++match] && scan < strend);
        len = MAX_MATCH - (strend - scan);
        scan = strend - MAX_MATCH;
        if (len > best_len) {
          s2.match_start = cur_match;
          best_len = len;
          if (len >= nice_match) {
            break;
          }
          scan_end1 = _win[scan + best_len - 1];
          scan_end = _win[scan + best_len];
        }
      } while ((cur_match = prev[cur_match & wmask]) > limit && --chain_length !== 0);
      if (best_len <= s2.lookahead) {
        return best_len;
      }
      return s2.lookahead;
    }
    function fill_window(s2) {
      var _w_size = s2.w_size;
      var p2, n2, m2, more, str;
      do {
        more = s2.window_size - s2.lookahead - s2.strstart;
        if (s2.strstart >= _w_size + (_w_size - MIN_LOOKAHEAD)) {
          utils.arraySet(s2.window, s2.window, _w_size, _w_size, 0);
          s2.match_start -= _w_size;
          s2.strstart -= _w_size;
          s2.block_start -= _w_size;
          n2 = s2.hash_size;
          p2 = n2;
          do {
            m2 = s2.head[--p2];
            s2.head[p2] = m2 >= _w_size ? m2 - _w_size : 0;
          } while (--n2);
          n2 = _w_size;
          p2 = n2;
          do {
            m2 = s2.prev[--p2];
            s2.prev[p2] = m2 >= _w_size ? m2 - _w_size : 0;
          } while (--n2);
          more += _w_size;
        }
        if (s2.strm.avail_in === 0) {
          break;
        }
        n2 = read_buf(s2.strm, s2.window, s2.strstart + s2.lookahead, more);
        s2.lookahead += n2;
        if (s2.lookahead + s2.insert >= MIN_MATCH) {
          str = s2.strstart - s2.insert;
          s2.ins_h = s2.window[str];
          s2.ins_h = (s2.ins_h << s2.hash_shift ^ s2.window[str + 1]) & s2.hash_mask;
          while (s2.insert) {
            s2.ins_h = (s2.ins_h << s2.hash_shift ^ s2.window[str + MIN_MATCH - 1]) & s2.hash_mask;
            s2.prev[str & s2.w_mask] = s2.head[s2.ins_h];
            s2.head[s2.ins_h] = str;
            str++;
            s2.insert--;
            if (s2.lookahead + s2.insert < MIN_MATCH) {
              break;
            }
          }
        }
      } while (s2.lookahead < MIN_LOOKAHEAD && s2.strm.avail_in !== 0);
    }
    function deflate_stored(s2, flush) {
      var max_block_size = 65535;
      if (max_block_size > s2.pending_buf_size - 5) {
        max_block_size = s2.pending_buf_size - 5;
      }
      for (; ; ) {
        if (s2.lookahead <= 1) {
          fill_window(s2);
          if (s2.lookahead === 0 && flush === Z_NO_FLUSH) {
            return BS_NEED_MORE;
          }
          if (s2.lookahead === 0) {
            break;
          }
        }
        s2.strstart += s2.lookahead;
        s2.lookahead = 0;
        var max_start = s2.block_start + max_block_size;
        if (s2.strstart === 0 || s2.strstart >= max_start) {
          s2.lookahead = s2.strstart - max_start;
          s2.strstart = max_start;
          flush_block_only(s2, false);
          if (s2.strm.avail_out === 0) {
            return BS_NEED_MORE;
          }
        }
        if (s2.strstart - s2.block_start >= s2.w_size - MIN_LOOKAHEAD) {
          flush_block_only(s2, false);
          if (s2.strm.avail_out === 0) {
            return BS_NEED_MORE;
          }
        }
      }
      s2.insert = 0;
      if (flush === Z_FINISH) {
        flush_block_only(s2, true);
        if (s2.strm.avail_out === 0) {
          return BS_FINISH_STARTED;
        }
        return BS_FINISH_DONE;
      }
      if (s2.strstart > s2.block_start) {
        flush_block_only(s2, false);
        if (s2.strm.avail_out === 0) {
          return BS_NEED_MORE;
        }
      }
      return BS_NEED_MORE;
    }
    function deflate_fast(s2, flush) {
      var hash_head;
      var bflush;
      for (; ; ) {
        if (s2.lookahead < MIN_LOOKAHEAD) {
          fill_window(s2);
          if (s2.lookahead < MIN_LOOKAHEAD && flush === Z_NO_FLUSH) {
            return BS_NEED_MORE;
          }
          if (s2.lookahead === 0) {
            break;
          }
        }
        hash_head = 0;
        if (s2.lookahead >= MIN_MATCH) {
          s2.ins_h = (s2.ins_h << s2.hash_shift ^ s2.window[s2.strstart + MIN_MATCH - 1]) & s2.hash_mask;
          hash_head = s2.prev[s2.strstart & s2.w_mask] = s2.head[s2.ins_h];
          s2.head[s2.ins_h] = s2.strstart;
        }
        if (hash_head !== 0 && s2.strstart - hash_head <= s2.w_size - MIN_LOOKAHEAD) {
          s2.match_length = longest_match(s2, hash_head);
        }
        if (s2.match_length >= MIN_MATCH) {
          bflush = trees._tr_tally(s2, s2.strstart - s2.match_start, s2.match_length - MIN_MATCH);
          s2.lookahead -= s2.match_length;
          if (s2.match_length <= s2.max_lazy_match && s2.lookahead >= MIN_MATCH) {
            s2.match_length--;
            do {
              s2.strstart++;
              s2.ins_h = (s2.ins_h << s2.hash_shift ^ s2.window[s2.strstart + MIN_MATCH - 1]) & s2.hash_mask;
              hash_head = s2.prev[s2.strstart & s2.w_mask] = s2.head[s2.ins_h];
              s2.head[s2.ins_h] = s2.strstart;
            } while (--s2.match_length !== 0);
            s2.strstart++;
          } else {
            s2.strstart += s2.match_length;
            s2.match_length = 0;
            s2.ins_h = s2.window[s2.strstart];
            s2.ins_h = (s2.ins_h << s2.hash_shift ^ s2.window[s2.strstart + 1]) & s2.hash_mask;
          }
        } else {
          bflush = trees._tr_tally(s2, 0, s2.window[s2.strstart]);
          s2.lookahead--;
          s2.strstart++;
        }
        if (bflush) {
          flush_block_only(s2, false);
          if (s2.strm.avail_out === 0) {
            return BS_NEED_MORE;
          }
        }
      }
      s2.insert = s2.strstart < MIN_MATCH - 1 ? s2.strstart : MIN_MATCH - 1;
      if (flush === Z_FINISH) {
        flush_block_only(s2, true);
        if (s2.strm.avail_out === 0) {
          return BS_FINISH_STARTED;
        }
        return BS_FINISH_DONE;
      }
      if (s2.last_lit) {
        flush_block_only(s2, false);
        if (s2.strm.avail_out === 0) {
          return BS_NEED_MORE;
        }
      }
      return BS_BLOCK_DONE;
    }
    function deflate_slow(s2, flush) {
      var hash_head;
      var bflush;
      var max_insert;
      for (; ; ) {
        if (s2.lookahead < MIN_LOOKAHEAD) {
          fill_window(s2);
          if (s2.lookahead < MIN_LOOKAHEAD && flush === Z_NO_FLUSH) {
            return BS_NEED_MORE;
          }
          if (s2.lookahead === 0) {
            break;
          }
        }
        hash_head = 0;
        if (s2.lookahead >= MIN_MATCH) {
          s2.ins_h = (s2.ins_h << s2.hash_shift ^ s2.window[s2.strstart + MIN_MATCH - 1]) & s2.hash_mask;
          hash_head = s2.prev[s2.strstart & s2.w_mask] = s2.head[s2.ins_h];
          s2.head[s2.ins_h] = s2.strstart;
        }
        s2.prev_length = s2.match_length;
        s2.prev_match = s2.match_start;
        s2.match_length = MIN_MATCH - 1;
        if (hash_head !== 0 && s2.prev_length < s2.max_lazy_match && s2.strstart - hash_head <= s2.w_size - MIN_LOOKAHEAD) {
          s2.match_length = longest_match(s2, hash_head);
          if (s2.match_length <= 5 && (s2.strategy === Z_FILTERED || s2.match_length === MIN_MATCH && s2.strstart - s2.match_start > 4096)) {
            s2.match_length = MIN_MATCH - 1;
          }
        }
        if (s2.prev_length >= MIN_MATCH && s2.match_length <= s2.prev_length) {
          max_insert = s2.strstart + s2.lookahead - MIN_MATCH;
          bflush = trees._tr_tally(s2, s2.strstart - 1 - s2.prev_match, s2.prev_length - MIN_MATCH);
          s2.lookahead -= s2.prev_length - 1;
          s2.prev_length -= 2;
          do {
            if (++s2.strstart <= max_insert) {
              s2.ins_h = (s2.ins_h << s2.hash_shift ^ s2.window[s2.strstart + MIN_MATCH - 1]) & s2.hash_mask;
              hash_head = s2.prev[s2.strstart & s2.w_mask] = s2.head[s2.ins_h];
              s2.head[s2.ins_h] = s2.strstart;
            }
          } while (--s2.prev_length !== 0);
          s2.match_available = 0;
          s2.match_length = MIN_MATCH - 1;
          s2.strstart++;
          if (bflush) {
            flush_block_only(s2, false);
            if (s2.strm.avail_out === 0) {
              return BS_NEED_MORE;
            }
          }
        } else if (s2.match_available) {
          bflush = trees._tr_tally(s2, 0, s2.window[s2.strstart - 1]);
          if (bflush) {
            flush_block_only(s2, false);
          }
          s2.strstart++;
          s2.lookahead--;
          if (s2.strm.avail_out === 0) {
            return BS_NEED_MORE;
          }
        } else {
          s2.match_available = 1;
          s2.strstart++;
          s2.lookahead--;
        }
      }
      if (s2.match_available) {
        bflush = trees._tr_tally(s2, 0, s2.window[s2.strstart - 1]);
        s2.match_available = 0;
      }
      s2.insert = s2.strstart < MIN_MATCH - 1 ? s2.strstart : MIN_MATCH - 1;
      if (flush === Z_FINISH) {
        flush_block_only(s2, true);
        if (s2.strm.avail_out === 0) {
          return BS_FINISH_STARTED;
        }
        return BS_FINISH_DONE;
      }
      if (s2.last_lit) {
        flush_block_only(s2, false);
        if (s2.strm.avail_out === 0) {
          return BS_NEED_MORE;
        }
      }
      return BS_BLOCK_DONE;
    }
    function deflate_rle(s2, flush) {
      var bflush;
      var prev;
      var scan, strend;
      var _win = s2.window;
      for (; ; ) {
        if (s2.lookahead <= MAX_MATCH) {
          fill_window(s2);
          if (s2.lookahead <= MAX_MATCH && flush === Z_NO_FLUSH) {
            return BS_NEED_MORE;
          }
          if (s2.lookahead === 0) {
            break;
          }
        }
        s2.match_length = 0;
        if (s2.lookahead >= MIN_MATCH && s2.strstart > 0) {
          scan = s2.strstart - 1;
          prev = _win[scan];
          if (prev === _win[++scan] && prev === _win[++scan] && prev === _win[++scan]) {
            strend = s2.strstart + MAX_MATCH;
            do {
            } while (prev === _win[++scan] && prev === _win[++scan] && prev === _win[++scan] && prev === _win[++scan] && prev === _win[++scan] && prev === _win[++scan] && prev === _win[++scan] && prev === _win[++scan] && scan < strend);
            s2.match_length = MAX_MATCH - (strend - scan);
            if (s2.match_length > s2.lookahead) {
              s2.match_length = s2.lookahead;
            }
          }
        }
        if (s2.match_length >= MIN_MATCH) {
          bflush = trees._tr_tally(s2, 1, s2.match_length - MIN_MATCH);
          s2.lookahead -= s2.match_length;
          s2.strstart += s2.match_length;
          s2.match_length = 0;
        } else {
          bflush = trees._tr_tally(s2, 0, s2.window[s2.strstart]);
          s2.lookahead--;
          s2.strstart++;
        }
        if (bflush) {
          flush_block_only(s2, false);
          if (s2.strm.avail_out === 0) {
            return BS_NEED_MORE;
          }
        }
      }
      s2.insert = 0;
      if (flush === Z_FINISH) {
        flush_block_only(s2, true);
        if (s2.strm.avail_out === 0) {
          return BS_FINISH_STARTED;
        }
        return BS_FINISH_DONE;
      }
      if (s2.last_lit) {
        flush_block_only(s2, false);
        if (s2.strm.avail_out === 0) {
          return BS_NEED_MORE;
        }
      }
      return BS_BLOCK_DONE;
    }
    function deflate_huff(s2, flush) {
      var bflush;
      for (; ; ) {
        if (s2.lookahead === 0) {
          fill_window(s2);
          if (s2.lookahead === 0) {
            if (flush === Z_NO_FLUSH) {
              return BS_NEED_MORE;
            }
            break;
          }
        }
        s2.match_length = 0;
        bflush = trees._tr_tally(s2, 0, s2.window[s2.strstart]);
        s2.lookahead--;
        s2.strstart++;
        if (bflush) {
          flush_block_only(s2, false);
          if (s2.strm.avail_out === 0) {
            return BS_NEED_MORE;
          }
        }
      }
      s2.insert = 0;
      if (flush === Z_FINISH) {
        flush_block_only(s2, true);
        if (s2.strm.avail_out === 0) {
          return BS_FINISH_STARTED;
        }
        return BS_FINISH_DONE;
      }
      if (s2.last_lit) {
        flush_block_only(s2, false);
        if (s2.strm.avail_out === 0) {
          return BS_NEED_MORE;
        }
      }
      return BS_BLOCK_DONE;
    }
    function Config(good_length, max_lazy, nice_length, max_chain, func) {
      this.good_length = good_length;
      this.max_lazy = max_lazy;
      this.nice_length = nice_length;
      this.max_chain = max_chain;
      this.func = func;
    }
    var configuration_table;
    configuration_table = [
      /*      good lazy nice chain */
      new Config(0, 0, 0, 0, deflate_stored),
      /* 0 store only */
      new Config(4, 4, 8, 4, deflate_fast),
      /* 1 max speed, no lazy matches */
      new Config(4, 5, 16, 8, deflate_fast),
      /* 2 */
      new Config(4, 6, 32, 32, deflate_fast),
      /* 3 */
      new Config(4, 4, 16, 16, deflate_slow),
      /* 4 lazy matches */
      new Config(8, 16, 32, 32, deflate_slow),
      /* 5 */
      new Config(8, 16, 128, 128, deflate_slow),
      /* 6 */
      new Config(8, 32, 128, 256, deflate_slow),
      /* 7 */
      new Config(32, 128, 258, 1024, deflate_slow),
      /* 8 */
      new Config(32, 258, 258, 4096, deflate_slow)
      /* 9 max compression */
    ];
    function lm_init(s2) {
      s2.window_size = 2 * s2.w_size;
      zero(s2.head);
      s2.max_lazy_match = configuration_table[s2.level].max_lazy;
      s2.good_match = configuration_table[s2.level].good_length;
      s2.nice_match = configuration_table[s2.level].nice_length;
      s2.max_chain_length = configuration_table[s2.level].max_chain;
      s2.strstart = 0;
      s2.block_start = 0;
      s2.lookahead = 0;
      s2.insert = 0;
      s2.match_length = s2.prev_length = MIN_MATCH - 1;
      s2.match_available = 0;
      s2.ins_h = 0;
    }
    function DeflateState() {
      this.strm = null;
      this.status = 0;
      this.pending_buf = null;
      this.pending_buf_size = 0;
      this.pending_out = 0;
      this.pending = 0;
      this.wrap = 0;
      this.gzhead = null;
      this.gzindex = 0;
      this.method = Z_DEFLATED;
      this.last_flush = -1;
      this.w_size = 0;
      this.w_bits = 0;
      this.w_mask = 0;
      this.window = null;
      this.window_size = 0;
      this.prev = null;
      this.head = null;
      this.ins_h = 0;
      this.hash_size = 0;
      this.hash_bits = 0;
      this.hash_mask = 0;
      this.hash_shift = 0;
      this.block_start = 0;
      this.match_length = 0;
      this.prev_match = 0;
      this.match_available = 0;
      this.strstart = 0;
      this.match_start = 0;
      this.lookahead = 0;
      this.prev_length = 0;
      this.max_chain_length = 0;
      this.max_lazy_match = 0;
      this.level = 0;
      this.strategy = 0;
      this.good_match = 0;
      this.nice_match = 0;
      this.dyn_ltree = new utils.Buf16(HEAP_SIZE * 2);
      this.dyn_dtree = new utils.Buf16((2 * D_CODES + 1) * 2);
      this.bl_tree = new utils.Buf16((2 * BL_CODES + 1) * 2);
      zero(this.dyn_ltree);
      zero(this.dyn_dtree);
      zero(this.bl_tree);
      this.l_desc = null;
      this.d_desc = null;
      this.bl_desc = null;
      this.bl_count = new utils.Buf16(MAX_BITS + 1);
      this.heap = new utils.Buf16(2 * L_CODES + 1);
      zero(this.heap);
      this.heap_len = 0;
      this.heap_max = 0;
      this.depth = new utils.Buf16(2 * L_CODES + 1);
      zero(this.depth);
      this.l_buf = 0;
      this.lit_bufsize = 0;
      this.last_lit = 0;
      this.d_buf = 0;
      this.opt_len = 0;
      this.static_len = 0;
      this.matches = 0;
      this.insert = 0;
      this.bi_buf = 0;
      this.bi_valid = 0;
    }
    function deflateResetKeep(strm) {
      var s2;
      if (!strm || !strm.state) {
        return err(strm, Z_STREAM_ERROR);
      }
      strm.total_in = strm.total_out = 0;
      strm.data_type = Z_UNKNOWN;
      s2 = strm.state;
      s2.pending = 0;
      s2.pending_out = 0;
      if (s2.wrap < 0) {
        s2.wrap = -s2.wrap;
      }
      s2.status = s2.wrap ? INIT_STATE : BUSY_STATE;
      strm.adler = s2.wrap === 2 ? 0 : 1;
      s2.last_flush = Z_NO_FLUSH;
      trees._tr_init(s2);
      return Z_OK;
    }
    function deflateReset(strm) {
      var ret = deflateResetKeep(strm);
      if (ret === Z_OK) {
        lm_init(strm.state);
      }
      return ret;
    }
    function deflateSetHeader(strm, head) {
      if (!strm || !strm.state) {
        return Z_STREAM_ERROR;
      }
      if (strm.state.wrap !== 2) {
        return Z_STREAM_ERROR;
      }
      strm.state.gzhead = head;
      return Z_OK;
    }
    function deflateInit2(strm, level, method, windowBits, memLevel, strategy) {
      if (!strm) {
        return Z_STREAM_ERROR;
      }
      var wrap = 1;
      if (level === Z_DEFAULT_COMPRESSION) {
        level = 6;
      }
      if (windowBits < 0) {
        wrap = 0;
        windowBits = -windowBits;
      } else if (windowBits > 15) {
        wrap = 2;
        windowBits -= 16;
      }
      if (memLevel < 1 || memLevel > MAX_MEM_LEVEL || method !== Z_DEFLATED || windowBits < 8 || windowBits > 15 || level < 0 || level > 9 || strategy < 0 || strategy > Z_FIXED) {
        return err(strm, Z_STREAM_ERROR);
      }
      if (windowBits === 8) {
        windowBits = 9;
      }
      var s2 = new DeflateState();
      strm.state = s2;
      s2.strm = strm;
      s2.wrap = wrap;
      s2.gzhead = null;
      s2.w_bits = windowBits;
      s2.w_size = 1 << s2.w_bits;
      s2.w_mask = s2.w_size - 1;
      s2.hash_bits = memLevel + 7;
      s2.hash_size = 1 << s2.hash_bits;
      s2.hash_mask = s2.hash_size - 1;
      s2.hash_shift = ~~((s2.hash_bits + MIN_MATCH - 1) / MIN_MATCH);
      s2.window = new utils.Buf8(s2.w_size * 2);
      s2.head = new utils.Buf16(s2.hash_size);
      s2.prev = new utils.Buf16(s2.w_size);
      s2.lit_bufsize = 1 << memLevel + 6;
      s2.pending_buf_size = s2.lit_bufsize * 4;
      s2.pending_buf = new utils.Buf8(s2.pending_buf_size);
      s2.d_buf = 1 * s2.lit_bufsize;
      s2.l_buf = (1 + 2) * s2.lit_bufsize;
      s2.level = level;
      s2.strategy = strategy;
      s2.method = method;
      return deflateReset(strm);
    }
    function deflateInit(strm, level) {
      return deflateInit2(strm, level, Z_DEFLATED, MAX_WBITS, DEF_MEM_LEVEL, Z_DEFAULT_STRATEGY);
    }
    function deflate(strm, flush) {
      var old_flush, s2;
      var beg, val;
      if (!strm || !strm.state || flush > Z_BLOCK || flush < 0) {
        return strm ? err(strm, Z_STREAM_ERROR) : Z_STREAM_ERROR;
      }
      s2 = strm.state;
      if (!strm.output || !strm.input && strm.avail_in !== 0 || s2.status === FINISH_STATE && flush !== Z_FINISH) {
        return err(strm, strm.avail_out === 0 ? Z_BUF_ERROR : Z_STREAM_ERROR);
      }
      s2.strm = strm;
      old_flush = s2.last_flush;
      s2.last_flush = flush;
      if (s2.status === INIT_STATE) {
        if (s2.wrap === 2) {
          strm.adler = 0;
          put_byte(s2, 31);
          put_byte(s2, 139);
          put_byte(s2, 8);
          if (!s2.gzhead) {
            put_byte(s2, 0);
            put_byte(s2, 0);
            put_byte(s2, 0);
            put_byte(s2, 0);
            put_byte(s2, 0);
            put_byte(s2, s2.level === 9 ? 2 : s2.strategy >= Z_HUFFMAN_ONLY || s2.level < 2 ? 4 : 0);
            put_byte(s2, OS_CODE);
            s2.status = BUSY_STATE;
          } else {
            put_byte(
              s2,
              (s2.gzhead.text ? 1 : 0) + (s2.gzhead.hcrc ? 2 : 0) + (!s2.gzhead.extra ? 0 : 4) + (!s2.gzhead.name ? 0 : 8) + (!s2.gzhead.comment ? 0 : 16)
            );
            put_byte(s2, s2.gzhead.time & 255);
            put_byte(s2, s2.gzhead.time >> 8 & 255);
            put_byte(s2, s2.gzhead.time >> 16 & 255);
            put_byte(s2, s2.gzhead.time >> 24 & 255);
            put_byte(s2, s2.level === 9 ? 2 : s2.strategy >= Z_HUFFMAN_ONLY || s2.level < 2 ? 4 : 0);
            put_byte(s2, s2.gzhead.os & 255);
            if (s2.gzhead.extra && s2.gzhead.extra.length) {
              put_byte(s2, s2.gzhead.extra.length & 255);
              put_byte(s2, s2.gzhead.extra.length >> 8 & 255);
            }
            if (s2.gzhead.hcrc) {
              strm.adler = crc32(strm.adler, s2.pending_buf, s2.pending, 0);
            }
            s2.gzindex = 0;
            s2.status = EXTRA_STATE;
          }
        } else {
          var header = Z_DEFLATED + (s2.w_bits - 8 << 4) << 8;
          var level_flags = -1;
          if (s2.strategy >= Z_HUFFMAN_ONLY || s2.level < 2) {
            level_flags = 0;
          } else if (s2.level < 6) {
            level_flags = 1;
          } else if (s2.level === 6) {
            level_flags = 2;
          } else {
            level_flags = 3;
          }
          header |= level_flags << 6;
          if (s2.strstart !== 0) {
            header |= PRESET_DICT;
          }
          header += 31 - header % 31;
          s2.status = BUSY_STATE;
          putShortMSB(s2, header);
          if (s2.strstart !== 0) {
            putShortMSB(s2, strm.adler >>> 16);
            putShortMSB(s2, strm.adler & 65535);
          }
          strm.adler = 1;
        }
      }
      if (s2.status === EXTRA_STATE) {
        if (s2.gzhead.extra) {
          beg = s2.pending;
          while (s2.gzindex < (s2.gzhead.extra.length & 65535)) {
            if (s2.pending === s2.pending_buf_size) {
              if (s2.gzhead.hcrc && s2.pending > beg) {
                strm.adler = crc32(strm.adler, s2.pending_buf, s2.pending - beg, beg);
              }
              flush_pending(strm);
              beg = s2.pending;
              if (s2.pending === s2.pending_buf_size) {
                break;
              }
            }
            put_byte(s2, s2.gzhead.extra[s2.gzindex] & 255);
            s2.gzindex++;
          }
          if (s2.gzhead.hcrc && s2.pending > beg) {
            strm.adler = crc32(strm.adler, s2.pending_buf, s2.pending - beg, beg);
          }
          if (s2.gzindex === s2.gzhead.extra.length) {
            s2.gzindex = 0;
            s2.status = NAME_STATE;
          }
        } else {
          s2.status = NAME_STATE;
        }
      }
      if (s2.status === NAME_STATE) {
        if (s2.gzhead.name) {
          beg = s2.pending;
          do {
            if (s2.pending === s2.pending_buf_size) {
              if (s2.gzhead.hcrc && s2.pending > beg) {
                strm.adler = crc32(strm.adler, s2.pending_buf, s2.pending - beg, beg);
              }
              flush_pending(strm);
              beg = s2.pending;
              if (s2.pending === s2.pending_buf_size) {
                val = 1;
                break;
              }
            }
            if (s2.gzindex < s2.gzhead.name.length) {
              val = s2.gzhead.name.charCodeAt(s2.gzindex++) & 255;
            } else {
              val = 0;
            }
            put_byte(s2, val);
          } while (val !== 0);
          if (s2.gzhead.hcrc && s2.pending > beg) {
            strm.adler = crc32(strm.adler, s2.pending_buf, s2.pending - beg, beg);
          }
          if (val === 0) {
            s2.gzindex = 0;
            s2.status = COMMENT_STATE;
          }
        } else {
          s2.status = COMMENT_STATE;
        }
      }
      if (s2.status === COMMENT_STATE) {
        if (s2.gzhead.comment) {
          beg = s2.pending;
          do {
            if (s2.pending === s2.pending_buf_size) {
              if (s2.gzhead.hcrc && s2.pending > beg) {
                strm.adler = crc32(strm.adler, s2.pending_buf, s2.pending - beg, beg);
              }
              flush_pending(strm);
              beg = s2.pending;
              if (s2.pending === s2.pending_buf_size) {
                val = 1;
                break;
              }
            }
            if (s2.gzindex < s2.gzhead.comment.length) {
              val = s2.gzhead.comment.charCodeAt(s2.gzindex++) & 255;
            } else {
              val = 0;
            }
            put_byte(s2, val);
          } while (val !== 0);
          if (s2.gzhead.hcrc && s2.pending > beg) {
            strm.adler = crc32(strm.adler, s2.pending_buf, s2.pending - beg, beg);
          }
          if (val === 0) {
            s2.status = HCRC_STATE;
          }
        } else {
          s2.status = HCRC_STATE;
        }
      }
      if (s2.status === HCRC_STATE) {
        if (s2.gzhead.hcrc) {
          if (s2.pending + 2 > s2.pending_buf_size) {
            flush_pending(strm);
          }
          if (s2.pending + 2 <= s2.pending_buf_size) {
            put_byte(s2, strm.adler & 255);
            put_byte(s2, strm.adler >> 8 & 255);
            strm.adler = 0;
            s2.status = BUSY_STATE;
          }
        } else {
          s2.status = BUSY_STATE;
        }
      }
      if (s2.pending !== 0) {
        flush_pending(strm);
        if (strm.avail_out === 0) {
          s2.last_flush = -1;
          return Z_OK;
        }
      } else if (strm.avail_in === 0 && rank(flush) <= rank(old_flush) && flush !== Z_FINISH) {
        return err(strm, Z_BUF_ERROR);
      }
      if (s2.status === FINISH_STATE && strm.avail_in !== 0) {
        return err(strm, Z_BUF_ERROR);
      }
      if (strm.avail_in !== 0 || s2.lookahead !== 0 || flush !== Z_NO_FLUSH && s2.status !== FINISH_STATE) {
        var bstate = s2.strategy === Z_HUFFMAN_ONLY ? deflate_huff(s2, flush) : s2.strategy === Z_RLE ? deflate_rle(s2, flush) : configuration_table[s2.level].func(s2, flush);
        if (bstate === BS_FINISH_STARTED || bstate === BS_FINISH_DONE) {
          s2.status = FINISH_STATE;
        }
        if (bstate === BS_NEED_MORE || bstate === BS_FINISH_STARTED) {
          if (strm.avail_out === 0) {
            s2.last_flush = -1;
          }
          return Z_OK;
        }
        if (bstate === BS_BLOCK_DONE) {
          if (flush === Z_PARTIAL_FLUSH) {
            trees._tr_align(s2);
          } else if (flush !== Z_BLOCK) {
            trees._tr_stored_block(s2, 0, 0, false);
            if (flush === Z_FULL_FLUSH) {
              zero(s2.head);
              if (s2.lookahead === 0) {
                s2.strstart = 0;
                s2.block_start = 0;
                s2.insert = 0;
              }
            }
          }
          flush_pending(strm);
          if (strm.avail_out === 0) {
            s2.last_flush = -1;
            return Z_OK;
          }
        }
      }
      if (flush !== Z_FINISH) {
        return Z_OK;
      }
      if (s2.wrap <= 0) {
        return Z_STREAM_END;
      }
      if (s2.wrap === 2) {
        put_byte(s2, strm.adler & 255);
        put_byte(s2, strm.adler >> 8 & 255);
        put_byte(s2, strm.adler >> 16 & 255);
        put_byte(s2, strm.adler >> 24 & 255);
        put_byte(s2, strm.total_in & 255);
        put_byte(s2, strm.total_in >> 8 & 255);
        put_byte(s2, strm.total_in >> 16 & 255);
        put_byte(s2, strm.total_in >> 24 & 255);
      } else {
        putShortMSB(s2, strm.adler >>> 16);
        putShortMSB(s2, strm.adler & 65535);
      }
      flush_pending(strm);
      if (s2.wrap > 0) {
        s2.wrap = -s2.wrap;
      }
      return s2.pending !== 0 ? Z_OK : Z_STREAM_END;
    }
    function deflateEnd(strm) {
      var status;
      if (!strm || !strm.state) {
        return Z_STREAM_ERROR;
      }
      status = strm.state.status;
      if (status !== INIT_STATE && status !== EXTRA_STATE && status !== NAME_STATE && status !== COMMENT_STATE && status !== HCRC_STATE && status !== BUSY_STATE && status !== FINISH_STATE) {
        return err(strm, Z_STREAM_ERROR);
      }
      strm.state = null;
      return status === BUSY_STATE ? err(strm, Z_DATA_ERROR) : Z_OK;
    }
    function deflateSetDictionary(strm, dictionary) {
      var dictLength = dictionary.length;
      var s2;
      var str, n2;
      var wrap;
      var avail;
      var next;
      var input;
      var tmpDict;
      if (!strm || !strm.state) {
        return Z_STREAM_ERROR;
      }
      s2 = strm.state;
      wrap = s2.wrap;
      if (wrap === 2 || wrap === 1 && s2.status !== INIT_STATE || s2.lookahead) {
        return Z_STREAM_ERROR;
      }
      if (wrap === 1) {
        strm.adler = adler32(strm.adler, dictionary, dictLength, 0);
      }
      s2.wrap = 0;
      if (dictLength >= s2.w_size) {
        if (wrap === 0) {
          zero(s2.head);
          s2.strstart = 0;
          s2.block_start = 0;
          s2.insert = 0;
        }
        tmpDict = new utils.Buf8(s2.w_size);
        utils.arraySet(tmpDict, dictionary, dictLength - s2.w_size, s2.w_size, 0);
        dictionary = tmpDict;
        dictLength = s2.w_size;
      }
      avail = strm.avail_in;
      next = strm.next_in;
      input = strm.input;
      strm.avail_in = dictLength;
      strm.next_in = 0;
      strm.input = dictionary;
      fill_window(s2);
      while (s2.lookahead >= MIN_MATCH) {
        str = s2.strstart;
        n2 = s2.lookahead - (MIN_MATCH - 1);
        do {
          s2.ins_h = (s2.ins_h << s2.hash_shift ^ s2.window[str + MIN_MATCH - 1]) & s2.hash_mask;
          s2.prev[str & s2.w_mask] = s2.head[s2.ins_h];
          s2.head[s2.ins_h] = str;
          str++;
        } while (--n2);
        s2.strstart = str;
        s2.lookahead = MIN_MATCH - 1;
        fill_window(s2);
      }
      s2.strstart += s2.lookahead;
      s2.block_start = s2.strstart;
      s2.insert = s2.lookahead;
      s2.lookahead = 0;
      s2.match_length = s2.prev_length = MIN_MATCH - 1;
      s2.match_available = 0;
      strm.next_in = next;
      strm.input = input;
      strm.avail_in = avail;
      s2.wrap = wrap;
      return Z_OK;
    }
    exports.deflateInit = deflateInit;
    exports.deflateInit2 = deflateInit2;
    exports.deflateReset = deflateReset;
    exports.deflateResetKeep = deflateResetKeep;
    exports.deflateSetHeader = deflateSetHeader;
    exports.deflate = deflate;
    exports.deflateEnd = deflateEnd;
    exports.deflateSetDictionary = deflateSetDictionary;
    exports.deflateInfo = "pako deflate (from Nodeca project)";
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/pako/lib/utils/strings.js
var require_strings = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/pako/lib/utils/strings.js"(exports) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var utils = require_common();
    var STR_APPLY_OK = true;
    var STR_APPLY_UIA_OK = true;
    try {
      String.fromCharCode.apply(null, [0]);
    } catch (__) {
      STR_APPLY_OK = false;
    }
    try {
      String.fromCharCode.apply(null, new Uint8Array(1));
    } catch (__) {
      STR_APPLY_UIA_OK = false;
    }
    var _utf8len = new utils.Buf8(256);
    for (q2 = 0; q2 < 256; q2++) {
      _utf8len[q2] = q2 >= 252 ? 6 : q2 >= 248 ? 5 : q2 >= 240 ? 4 : q2 >= 224 ? 3 : q2 >= 192 ? 2 : 1;
    }
    var q2;
    _utf8len[254] = _utf8len[254] = 1;
    exports.string2buf = function(str) {
      var buf, c2, c22, m_pos, i2, str_len = str.length, buf_len = 0;
      for (m_pos = 0; m_pos < str_len; m_pos++) {
        c2 = str.charCodeAt(m_pos);
        if ((c2 & 64512) === 55296 && m_pos + 1 < str_len) {
          c22 = str.charCodeAt(m_pos + 1);
          if ((c22 & 64512) === 56320) {
            c2 = 65536 + (c2 - 55296 << 10) + (c22 - 56320);
            m_pos++;
          }
        }
        buf_len += c2 < 128 ? 1 : c2 < 2048 ? 2 : c2 < 65536 ? 3 : 4;
      }
      buf = new utils.Buf8(buf_len);
      for (i2 = 0, m_pos = 0; i2 < buf_len; m_pos++) {
        c2 = str.charCodeAt(m_pos);
        if ((c2 & 64512) === 55296 && m_pos + 1 < str_len) {
          c22 = str.charCodeAt(m_pos + 1);
          if ((c22 & 64512) === 56320) {
            c2 = 65536 + (c2 - 55296 << 10) + (c22 - 56320);
            m_pos++;
          }
        }
        if (c2 < 128) {
          buf[i2++] = c2;
        } else if (c2 < 2048) {
          buf[i2++] = 192 | c2 >>> 6;
          buf[i2++] = 128 | c2 & 63;
        } else if (c2 < 65536) {
          buf[i2++] = 224 | c2 >>> 12;
          buf[i2++] = 128 | c2 >>> 6 & 63;
          buf[i2++] = 128 | c2 & 63;
        } else {
          buf[i2++] = 240 | c2 >>> 18;
          buf[i2++] = 128 | c2 >>> 12 & 63;
          buf[i2++] = 128 | c2 >>> 6 & 63;
          buf[i2++] = 128 | c2 & 63;
        }
      }
      return buf;
    };
    function buf2binstring(buf, len) {
      if (len < 65534) {
        if (buf.subarray && STR_APPLY_UIA_OK || !buf.subarray && STR_APPLY_OK) {
          return String.fromCharCode.apply(null, utils.shrinkBuf(buf, len));
        }
      }
      var result = "";
      for (var i2 = 0; i2 < len; i2++) {
        result += String.fromCharCode(buf[i2]);
      }
      return result;
    }
    exports.buf2binstring = function(buf) {
      return buf2binstring(buf, buf.length);
    };
    exports.binstring2buf = function(str) {
      var buf = new utils.Buf8(str.length);
      for (var i2 = 0, len = buf.length; i2 < len; i2++) {
        buf[i2] = str.charCodeAt(i2);
      }
      return buf;
    };
    exports.buf2string = function(buf, max) {
      var i2, out, c2, c_len;
      var len = max || buf.length;
      var utf16buf = new Array(len * 2);
      for (out = 0, i2 = 0; i2 < len; ) {
        c2 = buf[i2++];
        if (c2 < 128) {
          utf16buf[out++] = c2;
          continue;
        }
        c_len = _utf8len[c2];
        if (c_len > 4) {
          utf16buf[out++] = 65533;
          i2 += c_len - 1;
          continue;
        }
        c2 &= c_len === 2 ? 31 : c_len === 3 ? 15 : 7;
        while (c_len > 1 && i2 < len) {
          c2 = c2 << 6 | buf[i2++] & 63;
          c_len--;
        }
        if (c_len > 1) {
          utf16buf[out++] = 65533;
          continue;
        }
        if (c2 < 65536) {
          utf16buf[out++] = c2;
        } else {
          c2 -= 65536;
          utf16buf[out++] = 55296 | c2 >> 10 & 1023;
          utf16buf[out++] = 56320 | c2 & 1023;
        }
      }
      return buf2binstring(utf16buf, out);
    };
    exports.utf8border = function(buf, max) {
      var pos;
      max = max || buf.length;
      if (max > buf.length) {
        max = buf.length;
      }
      pos = max - 1;
      while (pos >= 0 && (buf[pos] & 192) === 128) {
        pos--;
      }
      if (pos < 0) {
        return max;
      }
      if (pos === 0) {
        return max;
      }
      return pos + _utf8len[buf[pos]] > max ? pos : max;
    };
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/pako/lib/zlib/zstream.js
var require_zstream = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/pako/lib/zlib/zstream.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    function ZStream() {
      this.input = null;
      this.next_in = 0;
      this.avail_in = 0;
      this.total_in = 0;
      this.output = null;
      this.next_out = 0;
      this.avail_out = 0;
      this.total_out = 0;
      this.msg = "";
      this.state = null;
      this.data_type = 2;
      this.adler = 0;
    }
    module.exports = ZStream;
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/pako/lib/deflate.js
var require_deflate2 = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/pako/lib/deflate.js"(exports) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var zlib_deflate = require_deflate();
    var utils = require_common();
    var strings = require_strings();
    var msg = require_messages();
    var ZStream = require_zstream();
    var toString = Object.prototype.toString;
    var Z_NO_FLUSH = 0;
    var Z_FINISH = 4;
    var Z_OK = 0;
    var Z_STREAM_END = 1;
    var Z_SYNC_FLUSH = 2;
    var Z_DEFAULT_COMPRESSION = -1;
    var Z_DEFAULT_STRATEGY = 0;
    var Z_DEFLATED = 8;
    function Deflate(options) {
      if (!(this instanceof Deflate)) return new Deflate(options);
      this.options = utils.assign({
        level: Z_DEFAULT_COMPRESSION,
        method: Z_DEFLATED,
        chunkSize: 16384,
        windowBits: 15,
        memLevel: 8,
        strategy: Z_DEFAULT_STRATEGY,
        to: ""
      }, options || {});
      var opt = this.options;
      if (opt.raw && opt.windowBits > 0) {
        opt.windowBits = -opt.windowBits;
      } else if (opt.gzip && opt.windowBits > 0 && opt.windowBits < 16) {
        opt.windowBits += 16;
      }
      this.err = 0;
      this.msg = "";
      this.ended = false;
      this.chunks = [];
      this.strm = new ZStream();
      this.strm.avail_out = 0;
      var status = zlib_deflate.deflateInit2(
        this.strm,
        opt.level,
        opt.method,
        opt.windowBits,
        opt.memLevel,
        opt.strategy
      );
      if (status !== Z_OK) {
        throw new Error(msg[status]);
      }
      if (opt.header) {
        zlib_deflate.deflateSetHeader(this.strm, opt.header);
      }
      if (opt.dictionary) {
        var dict;
        if (typeof opt.dictionary === "string") {
          dict = strings.string2buf(opt.dictionary);
        } else if (toString.call(opt.dictionary) === "[object ArrayBuffer]") {
          dict = new Uint8Array(opt.dictionary);
        } else {
          dict = opt.dictionary;
        }
        status = zlib_deflate.deflateSetDictionary(this.strm, dict);
        if (status !== Z_OK) {
          throw new Error(msg[status]);
        }
        this._dict_set = true;
      }
    }
    Deflate.prototype.push = function(data, mode) {
      var strm = this.strm;
      var chunkSize = this.options.chunkSize;
      var status, _mode;
      if (this.ended) {
        return false;
      }
      _mode = mode === ~~mode ? mode : mode === true ? Z_FINISH : Z_NO_FLUSH;
      if (typeof data === "string") {
        strm.input = strings.string2buf(data);
      } else if (toString.call(data) === "[object ArrayBuffer]") {
        strm.input = new Uint8Array(data);
      } else {
        strm.input = data;
      }
      strm.next_in = 0;
      strm.avail_in = strm.input.length;
      do {
        if (strm.avail_out === 0) {
          strm.output = new utils.Buf8(chunkSize);
          strm.next_out = 0;
          strm.avail_out = chunkSize;
        }
        status = zlib_deflate.deflate(strm, _mode);
        if (status !== Z_STREAM_END && status !== Z_OK) {
          this.onEnd(status);
          this.ended = true;
          return false;
        }
        if (strm.avail_out === 0 || strm.avail_in === 0 && (_mode === Z_FINISH || _mode === Z_SYNC_FLUSH)) {
          if (this.options.to === "string") {
            this.onData(strings.buf2binstring(utils.shrinkBuf(strm.output, strm.next_out)));
          } else {
            this.onData(utils.shrinkBuf(strm.output, strm.next_out));
          }
        }
      } while ((strm.avail_in > 0 || strm.avail_out === 0) && status !== Z_STREAM_END);
      if (_mode === Z_FINISH) {
        status = zlib_deflate.deflateEnd(this.strm);
        this.onEnd(status);
        this.ended = true;
        return status === Z_OK;
      }
      if (_mode === Z_SYNC_FLUSH) {
        this.onEnd(Z_OK);
        strm.avail_out = 0;
        return true;
      }
      return true;
    };
    Deflate.prototype.onData = function(chunk) {
      this.chunks.push(chunk);
    };
    Deflate.prototype.onEnd = function(status) {
      if (status === Z_OK) {
        if (this.options.to === "string") {
          this.result = this.chunks.join("");
        } else {
          this.result = utils.flattenChunks(this.chunks);
        }
      }
      this.chunks = [];
      this.err = status;
      this.msg = this.strm.msg;
    };
    function deflate(input, options) {
      var deflator = new Deflate(options);
      deflator.push(input, true);
      if (deflator.err) {
        throw deflator.msg || msg[deflator.err];
      }
      return deflator.result;
    }
    function deflateRaw(input, options) {
      options = options || {};
      options.raw = true;
      return deflate(input, options);
    }
    function gzip(input, options) {
      options = options || {};
      options.gzip = true;
      return deflate(input, options);
    }
    exports.Deflate = Deflate;
    exports.deflate = deflate;
    exports.deflateRaw = deflateRaw;
    exports.gzip = gzip;
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/pako/lib/zlib/inffast.js
var require_inffast = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/pako/lib/zlib/inffast.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var BAD = 30;
    var TYPE = 12;
    module.exports = function inflate_fast(strm, start) {
      var state;
      var _in;
      var last;
      var _out;
      var beg;
      var end;
      var dmax;
      var wsize;
      var whave;
      var wnext;
      var s_window;
      var hold;
      var bits;
      var lcode;
      var dcode;
      var lmask;
      var dmask;
      var here;
      var op;
      var len;
      var dist;
      var from;
      var from_source;
      var input, output;
      state = strm.state;
      _in = strm.next_in;
      input = strm.input;
      last = _in + (strm.avail_in - 5);
      _out = strm.next_out;
      output = strm.output;
      beg = _out - (start - strm.avail_out);
      end = _out + (strm.avail_out - 257);
      dmax = state.dmax;
      wsize = state.wsize;
      whave = state.whave;
      wnext = state.wnext;
      s_window = state.window;
      hold = state.hold;
      bits = state.bits;
      lcode = state.lencode;
      dcode = state.distcode;
      lmask = (1 << state.lenbits) - 1;
      dmask = (1 << state.distbits) - 1;
      top:
        do {
          if (bits < 15) {
            hold += input[_in++] << bits;
            bits += 8;
            hold += input[_in++] << bits;
            bits += 8;
          }
          here = lcode[hold & lmask];
          dolen:
            for (; ; ) {
              op = here >>> 24;
              hold >>>= op;
              bits -= op;
              op = here >>> 16 & 255;
              if (op === 0) {
                output[_out++] = here & 65535;
              } else if (op & 16) {
                len = here & 65535;
                op &= 15;
                if (op) {
                  if (bits < op) {
                    hold += input[_in++] << bits;
                    bits += 8;
                  }
                  len += hold & (1 << op) - 1;
                  hold >>>= op;
                  bits -= op;
                }
                if (bits < 15) {
                  hold += input[_in++] << bits;
                  bits += 8;
                  hold += input[_in++] << bits;
                  bits += 8;
                }
                here = dcode[hold & dmask];
                dodist:
                  for (; ; ) {
                    op = here >>> 24;
                    hold >>>= op;
                    bits -= op;
                    op = here >>> 16 & 255;
                    if (op & 16) {
                      dist = here & 65535;
                      op &= 15;
                      if (bits < op) {
                        hold += input[_in++] << bits;
                        bits += 8;
                        if (bits < op) {
                          hold += input[_in++] << bits;
                          bits += 8;
                        }
                      }
                      dist += hold & (1 << op) - 1;
                      if (dist > dmax) {
                        strm.msg = "invalid distance too far back";
                        state.mode = BAD;
                        break top;
                      }
                      hold >>>= op;
                      bits -= op;
                      op = _out - beg;
                      if (dist > op) {
                        op = dist - op;
                        if (op > whave) {
                          if (state.sane) {
                            strm.msg = "invalid distance too far back";
                            state.mode = BAD;
                            break top;
                          }
                        }
                        from = 0;
                        from_source = s_window;
                        if (wnext === 0) {
                          from += wsize - op;
                          if (op < len) {
                            len -= op;
                            do {
                              output[_out++] = s_window[from++];
                            } while (--op);
                            from = _out - dist;
                            from_source = output;
                          }
                        } else if (wnext < op) {
                          from += wsize + wnext - op;
                          op -= wnext;
                          if (op < len) {
                            len -= op;
                            do {
                              output[_out++] = s_window[from++];
                            } while (--op);
                            from = 0;
                            if (wnext < len) {
                              op = wnext;
                              len -= op;
                              do {
                                output[_out++] = s_window[from++];
                              } while (--op);
                              from = _out - dist;
                              from_source = output;
                            }
                          }
                        } else {
                          from += wnext - op;
                          if (op < len) {
                            len -= op;
                            do {
                              output[_out++] = s_window[from++];
                            } while (--op);
                            from = _out - dist;
                            from_source = output;
                          }
                        }
                        while (len > 2) {
                          output[_out++] = from_source[from++];
                          output[_out++] = from_source[from++];
                          output[_out++] = from_source[from++];
                          len -= 3;
                        }
                        if (len) {
                          output[_out++] = from_source[from++];
                          if (len > 1) {
                            output[_out++] = from_source[from++];
                          }
                        }
                      } else {
                        from = _out - dist;
                        do {
                          output[_out++] = output[from++];
                          output[_out++] = output[from++];
                          output[_out++] = output[from++];
                          len -= 3;
                        } while (len > 2);
                        if (len) {
                          output[_out++] = output[from++];
                          if (len > 1) {
                            output[_out++] = output[from++];
                          }
                        }
                      }
                    } else if ((op & 64) === 0) {
                      here = dcode[(here & 65535) + (hold & (1 << op) - 1)];
                      continue dodist;
                    } else {
                      strm.msg = "invalid distance code";
                      state.mode = BAD;
                      break top;
                    }
                    break;
                  }
              } else if ((op & 64) === 0) {
                here = lcode[(here & 65535) + (hold & (1 << op) - 1)];
                continue dolen;
              } else if (op & 32) {
                state.mode = TYPE;
                break top;
              } else {
                strm.msg = "invalid literal/length code";
                state.mode = BAD;
                break top;
              }
              break;
            }
        } while (_in < last && _out < end);
      len = bits >> 3;
      _in -= len;
      bits -= len << 3;
      hold &= (1 << bits) - 1;
      strm.next_in = _in;
      strm.next_out = _out;
      strm.avail_in = _in < last ? 5 + (last - _in) : 5 - (_in - last);
      strm.avail_out = _out < end ? 257 + (end - _out) : 257 - (_out - end);
      state.hold = hold;
      state.bits = bits;
      return;
    };
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/pako/lib/zlib/inftrees.js
var require_inftrees = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/pako/lib/zlib/inftrees.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var utils = require_common();
    var MAXBITS = 15;
    var ENOUGH_LENS = 852;
    var ENOUGH_DISTS = 592;
    var CODES = 0;
    var LENS = 1;
    var DISTS = 2;
    var lbase = [
      /* Length codes 257..285 base */
      3,
      4,
      5,
      6,
      7,
      8,
      9,
      10,
      11,
      13,
      15,
      17,
      19,
      23,
      27,
      31,
      35,
      43,
      51,
      59,
      67,
      83,
      99,
      115,
      131,
      163,
      195,
      227,
      258,
      0,
      0
    ];
    var lext = [
      /* Length codes 257..285 extra */
      16,
      16,
      16,
      16,
      16,
      16,
      16,
      16,
      17,
      17,
      17,
      17,
      18,
      18,
      18,
      18,
      19,
      19,
      19,
      19,
      20,
      20,
      20,
      20,
      21,
      21,
      21,
      21,
      16,
      72,
      78
    ];
    var dbase = [
      /* Distance codes 0..29 base */
      1,
      2,
      3,
      4,
      5,
      7,
      9,
      13,
      17,
      25,
      33,
      49,
      65,
      97,
      129,
      193,
      257,
      385,
      513,
      769,
      1025,
      1537,
      2049,
      3073,
      4097,
      6145,
      8193,
      12289,
      16385,
      24577,
      0,
      0
    ];
    var dext = [
      /* Distance codes 0..29 extra */
      16,
      16,
      16,
      16,
      17,
      17,
      18,
      18,
      19,
      19,
      20,
      20,
      21,
      21,
      22,
      22,
      23,
      23,
      24,
      24,
      25,
      25,
      26,
      26,
      27,
      27,
      28,
      28,
      29,
      29,
      64,
      64
    ];
    module.exports = function inflate_table(type, lens, lens_index, codes, table, table_index, work, opts) {
      var bits = opts.bits;
      var len = 0;
      var sym = 0;
      var min = 0, max = 0;
      var root = 0;
      var curr = 0;
      var drop = 0;
      var left = 0;
      var used = 0;
      var huff = 0;
      var incr;
      var fill;
      var low;
      var mask;
      var next;
      var base = null;
      var base_index = 0;
      var end;
      var count = new utils.Buf16(MAXBITS + 1);
      var offs = new utils.Buf16(MAXBITS + 1);
      var extra = null;
      var extra_index = 0;
      var here_bits, here_op, here_val;
      for (len = 0; len <= MAXBITS; len++) {
        count[len] = 0;
      }
      for (sym = 0; sym < codes; sym++) {
        count[lens[lens_index + sym]]++;
      }
      root = bits;
      for (max = MAXBITS; max >= 1; max--) {
        if (count[max] !== 0) {
          break;
        }
      }
      if (root > max) {
        root = max;
      }
      if (max === 0) {
        table[table_index++] = 1 << 24 | 64 << 16 | 0;
        table[table_index++] = 1 << 24 | 64 << 16 | 0;
        opts.bits = 1;
        return 0;
      }
      for (min = 1; min < max; min++) {
        if (count[min] !== 0) {
          break;
        }
      }
      if (root < min) {
        root = min;
      }
      left = 1;
      for (len = 1; len <= MAXBITS; len++) {
        left <<= 1;
        left -= count[len];
        if (left < 0) {
          return -1;
        }
      }
      if (left > 0 && (type === CODES || max !== 1)) {
        return -1;
      }
      offs[1] = 0;
      for (len = 1; len < MAXBITS; len++) {
        offs[len + 1] = offs[len] + count[len];
      }
      for (sym = 0; sym < codes; sym++) {
        if (lens[lens_index + sym] !== 0) {
          work[offs[lens[lens_index + sym]]++] = sym;
        }
      }
      if (type === CODES) {
        base = extra = work;
        end = 19;
      } else if (type === LENS) {
        base = lbase;
        base_index -= 257;
        extra = lext;
        extra_index -= 257;
        end = 256;
      } else {
        base = dbase;
        extra = dext;
        end = -1;
      }
      huff = 0;
      sym = 0;
      len = min;
      next = table_index;
      curr = root;
      drop = 0;
      low = -1;
      used = 1 << root;
      mask = used - 1;
      if (type === LENS && used > ENOUGH_LENS || type === DISTS && used > ENOUGH_DISTS) {
        return 1;
      }
      for (; ; ) {
        here_bits = len - drop;
        if (work[sym] < end) {
          here_op = 0;
          here_val = work[sym];
        } else if (work[sym] > end) {
          here_op = extra[extra_index + work[sym]];
          here_val = base[base_index + work[sym]];
        } else {
          here_op = 32 + 64;
          here_val = 0;
        }
        incr = 1 << len - drop;
        fill = 1 << curr;
        min = fill;
        do {
          fill -= incr;
          table[next + (huff >> drop) + fill] = here_bits << 24 | here_op << 16 | here_val | 0;
        } while (fill !== 0);
        incr = 1 << len - 1;
        while (huff & incr) {
          incr >>= 1;
        }
        if (incr !== 0) {
          huff &= incr - 1;
          huff += incr;
        } else {
          huff = 0;
        }
        sym++;
        if (--count[len] === 0) {
          if (len === max) {
            break;
          }
          len = lens[lens_index + work[sym]];
        }
        if (len > root && (huff & mask) !== low) {
          if (drop === 0) {
            drop = root;
          }
          next += min;
          curr = len - drop;
          left = 1 << curr;
          while (curr + drop < max) {
            left -= count[curr + drop];
            if (left <= 0) {
              break;
            }
            curr++;
            left <<= 1;
          }
          used += 1 << curr;
          if (type === LENS && used > ENOUGH_LENS || type === DISTS && used > ENOUGH_DISTS) {
            return 1;
          }
          low = huff & mask;
          table[low] = root << 24 | curr << 16 | next - table_index | 0;
        }
      }
      if (huff !== 0) {
        table[next + huff] = len - drop << 24 | 64 << 16 | 0;
      }
      opts.bits = root;
      return 0;
    };
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/pako/lib/zlib/inflate.js
var require_inflate = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/pako/lib/zlib/inflate.js"(exports) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var utils = require_common();
    var adler32 = require_adler32();
    var crc32 = require_crc322();
    var inflate_fast = require_inffast();
    var inflate_table = require_inftrees();
    var CODES = 0;
    var LENS = 1;
    var DISTS = 2;
    var Z_FINISH = 4;
    var Z_BLOCK = 5;
    var Z_TREES = 6;
    var Z_OK = 0;
    var Z_STREAM_END = 1;
    var Z_NEED_DICT = 2;
    var Z_STREAM_ERROR = -2;
    var Z_DATA_ERROR = -3;
    var Z_MEM_ERROR = -4;
    var Z_BUF_ERROR = -5;
    var Z_DEFLATED = 8;
    var HEAD = 1;
    var FLAGS = 2;
    var TIME = 3;
    var OS = 4;
    var EXLEN = 5;
    var EXTRA = 6;
    var NAME = 7;
    var COMMENT = 8;
    var HCRC = 9;
    var DICTID = 10;
    var DICT = 11;
    var TYPE = 12;
    var TYPEDO = 13;
    var STORED = 14;
    var COPY_ = 15;
    var COPY = 16;
    var TABLE = 17;
    var LENLENS = 18;
    var CODELENS = 19;
    var LEN_ = 20;
    var LEN = 21;
    var LENEXT = 22;
    var DIST = 23;
    var DISTEXT = 24;
    var MATCH = 25;
    var LIT = 26;
    var CHECK = 27;
    var LENGTH = 28;
    var DONE = 29;
    var BAD = 30;
    var MEM = 31;
    var SYNC = 32;
    var ENOUGH_LENS = 852;
    var ENOUGH_DISTS = 592;
    var MAX_WBITS = 15;
    var DEF_WBITS = MAX_WBITS;
    function zswap32(q2) {
      return (q2 >>> 24 & 255) + (q2 >>> 8 & 65280) + ((q2 & 65280) << 8) + ((q2 & 255) << 24);
    }
    function InflateState() {
      this.mode = 0;
      this.last = false;
      this.wrap = 0;
      this.havedict = false;
      this.flags = 0;
      this.dmax = 0;
      this.check = 0;
      this.total = 0;
      this.head = null;
      this.wbits = 0;
      this.wsize = 0;
      this.whave = 0;
      this.wnext = 0;
      this.window = null;
      this.hold = 0;
      this.bits = 0;
      this.length = 0;
      this.offset = 0;
      this.extra = 0;
      this.lencode = null;
      this.distcode = null;
      this.lenbits = 0;
      this.distbits = 0;
      this.ncode = 0;
      this.nlen = 0;
      this.ndist = 0;
      this.have = 0;
      this.next = null;
      this.lens = new utils.Buf16(320);
      this.work = new utils.Buf16(288);
      this.lendyn = null;
      this.distdyn = null;
      this.sane = 0;
      this.back = 0;
      this.was = 0;
    }
    function inflateResetKeep(strm) {
      var state;
      if (!strm || !strm.state) {
        return Z_STREAM_ERROR;
      }
      state = strm.state;
      strm.total_in = strm.total_out = state.total = 0;
      strm.msg = "";
      if (state.wrap) {
        strm.adler = state.wrap & 1;
      }
      state.mode = HEAD;
      state.last = 0;
      state.havedict = 0;
      state.dmax = 32768;
      state.head = null;
      state.hold = 0;
      state.bits = 0;
      state.lencode = state.lendyn = new utils.Buf32(ENOUGH_LENS);
      state.distcode = state.distdyn = new utils.Buf32(ENOUGH_DISTS);
      state.sane = 1;
      state.back = -1;
      return Z_OK;
    }
    function inflateReset(strm) {
      var state;
      if (!strm || !strm.state) {
        return Z_STREAM_ERROR;
      }
      state = strm.state;
      state.wsize = 0;
      state.whave = 0;
      state.wnext = 0;
      return inflateResetKeep(strm);
    }
    function inflateReset2(strm, windowBits) {
      var wrap;
      var state;
      if (!strm || !strm.state) {
        return Z_STREAM_ERROR;
      }
      state = strm.state;
      if (windowBits < 0) {
        wrap = 0;
        windowBits = -windowBits;
      } else {
        wrap = (windowBits >> 4) + 1;
        if (windowBits < 48) {
          windowBits &= 15;
        }
      }
      if (windowBits && (windowBits < 8 || windowBits > 15)) {
        return Z_STREAM_ERROR;
      }
      if (state.window !== null && state.wbits !== windowBits) {
        state.window = null;
      }
      state.wrap = wrap;
      state.wbits = windowBits;
      return inflateReset(strm);
    }
    function inflateInit2(strm, windowBits) {
      var ret;
      var state;
      if (!strm) {
        return Z_STREAM_ERROR;
      }
      state = new InflateState();
      strm.state = state;
      state.window = null;
      ret = inflateReset2(strm, windowBits);
      if (ret !== Z_OK) {
        strm.state = null;
      }
      return ret;
    }
    function inflateInit(strm) {
      return inflateInit2(strm, DEF_WBITS);
    }
    var virgin = true;
    var lenfix;
    var distfix;
    function fixedtables(state) {
      if (virgin) {
        var sym;
        lenfix = new utils.Buf32(512);
        distfix = new utils.Buf32(32);
        sym = 0;
        while (sym < 144) {
          state.lens[sym++] = 8;
        }
        while (sym < 256) {
          state.lens[sym++] = 9;
        }
        while (sym < 280) {
          state.lens[sym++] = 7;
        }
        while (sym < 288) {
          state.lens[sym++] = 8;
        }
        inflate_table(LENS, state.lens, 0, 288, lenfix, 0, state.work, { bits: 9 });
        sym = 0;
        while (sym < 32) {
          state.lens[sym++] = 5;
        }
        inflate_table(DISTS, state.lens, 0, 32, distfix, 0, state.work, { bits: 5 });
        virgin = false;
      }
      state.lencode = lenfix;
      state.lenbits = 9;
      state.distcode = distfix;
      state.distbits = 5;
    }
    function updatewindow(strm, src, end, copy) {
      var dist;
      var state = strm.state;
      if (state.window === null) {
        state.wsize = 1 << state.wbits;
        state.wnext = 0;
        state.whave = 0;
        state.window = new utils.Buf8(state.wsize);
      }
      if (copy >= state.wsize) {
        utils.arraySet(state.window, src, end - state.wsize, state.wsize, 0);
        state.wnext = 0;
        state.whave = state.wsize;
      } else {
        dist = state.wsize - state.wnext;
        if (dist > copy) {
          dist = copy;
        }
        utils.arraySet(state.window, src, end - copy, dist, state.wnext);
        copy -= dist;
        if (copy) {
          utils.arraySet(state.window, src, end - copy, copy, 0);
          state.wnext = copy;
          state.whave = state.wsize;
        } else {
          state.wnext += dist;
          if (state.wnext === state.wsize) {
            state.wnext = 0;
          }
          if (state.whave < state.wsize) {
            state.whave += dist;
          }
        }
      }
      return 0;
    }
    function inflate(strm, flush) {
      var state;
      var input, output;
      var next;
      var put;
      var have, left;
      var hold;
      var bits;
      var _in, _out;
      var copy;
      var from;
      var from_source;
      var here = 0;
      var here_bits, here_op, here_val;
      var last_bits, last_op, last_val;
      var len;
      var ret;
      var hbuf = new utils.Buf8(4);
      var opts;
      var n2;
      var order = (
        /* permutation of code lengths */
        [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]
      );
      if (!strm || !strm.state || !strm.output || !strm.input && strm.avail_in !== 0) {
        return Z_STREAM_ERROR;
      }
      state = strm.state;
      if (state.mode === TYPE) {
        state.mode = TYPEDO;
      }
      put = strm.next_out;
      output = strm.output;
      left = strm.avail_out;
      next = strm.next_in;
      input = strm.input;
      have = strm.avail_in;
      hold = state.hold;
      bits = state.bits;
      _in = have;
      _out = left;
      ret = Z_OK;
      inf_leave:
        for (; ; ) {
          switch (state.mode) {
            case HEAD:
              if (state.wrap === 0) {
                state.mode = TYPEDO;
                break;
              }
              while (bits < 16) {
                if (have === 0) {
                  break inf_leave;
                }
                have--;
                hold += input[next++] << bits;
                bits += 8;
              }
              if (state.wrap & 2 && hold === 35615) {
                state.check = 0;
                hbuf[0] = hold & 255;
                hbuf[1] = hold >>> 8 & 255;
                state.check = crc32(state.check, hbuf, 2, 0);
                hold = 0;
                bits = 0;
                state.mode = FLAGS;
                break;
              }
              state.flags = 0;
              if (state.head) {
                state.head.done = false;
              }
              if (!(state.wrap & 1) || /* check if zlib header allowed */
              (((hold & 255) << 8) + (hold >> 8)) % 31) {
                strm.msg = "incorrect header check";
                state.mode = BAD;
                break;
              }
              if ((hold & 15) !== Z_DEFLATED) {
                strm.msg = "unknown compression method";
                state.mode = BAD;
                break;
              }
              hold >>>= 4;
              bits -= 4;
              len = (hold & 15) + 8;
              if (state.wbits === 0) {
                state.wbits = len;
              } else if (len > state.wbits) {
                strm.msg = "invalid window size";
                state.mode = BAD;
                break;
              }
              state.dmax = 1 << len;
              strm.adler = state.check = 1;
              state.mode = hold & 512 ? DICTID : TYPE;
              hold = 0;
              bits = 0;
              break;
            case FLAGS:
              while (bits < 16) {
                if (have === 0) {
                  break inf_leave;
                }
                have--;
                hold += input[next++] << bits;
                bits += 8;
              }
              state.flags = hold;
              if ((state.flags & 255) !== Z_DEFLATED) {
                strm.msg = "unknown compression method";
                state.mode = BAD;
                break;
              }
              if (state.flags & 57344) {
                strm.msg = "unknown header flags set";
                state.mode = BAD;
                break;
              }
              if (state.head) {
                state.head.text = hold >> 8 & 1;
              }
              if (state.flags & 512) {
                hbuf[0] = hold & 255;
                hbuf[1] = hold >>> 8 & 255;
                state.check = crc32(state.check, hbuf, 2, 0);
              }
              hold = 0;
              bits = 0;
              state.mode = TIME;
            /* falls through */
            case TIME:
              while (bits < 32) {
                if (have === 0) {
                  break inf_leave;
                }
                have--;
                hold += input[next++] << bits;
                bits += 8;
              }
              if (state.head) {
                state.head.time = hold;
              }
              if (state.flags & 512) {
                hbuf[0] = hold & 255;
                hbuf[1] = hold >>> 8 & 255;
                hbuf[2] = hold >>> 16 & 255;
                hbuf[3] = hold >>> 24 & 255;
                state.check = crc32(state.check, hbuf, 4, 0);
              }
              hold = 0;
              bits = 0;
              state.mode = OS;
            /* falls through */
            case OS:
              while (bits < 16) {
                if (have === 0) {
                  break inf_leave;
                }
                have--;
                hold += input[next++] << bits;
                bits += 8;
              }
              if (state.head) {
                state.head.xflags = hold & 255;
                state.head.os = hold >> 8;
              }
              if (state.flags & 512) {
                hbuf[0] = hold & 255;
                hbuf[1] = hold >>> 8 & 255;
                state.check = crc32(state.check, hbuf, 2, 0);
              }
              hold = 0;
              bits = 0;
              state.mode = EXLEN;
            /* falls through */
            case EXLEN:
              if (state.flags & 1024) {
                while (bits < 16) {
                  if (have === 0) {
                    break inf_leave;
                  }
                  have--;
                  hold += input[next++] << bits;
                  bits += 8;
                }
                state.length = hold;
                if (state.head) {
                  state.head.extra_len = hold;
                }
                if (state.flags & 512) {
                  hbuf[0] = hold & 255;
                  hbuf[1] = hold >>> 8 & 255;
                  state.check = crc32(state.check, hbuf, 2, 0);
                }
                hold = 0;
                bits = 0;
              } else if (state.head) {
                state.head.extra = null;
              }
              state.mode = EXTRA;
            /* falls through */
            case EXTRA:
              if (state.flags & 1024) {
                copy = state.length;
                if (copy > have) {
                  copy = have;
                }
                if (copy) {
                  if (state.head) {
                    len = state.head.extra_len - state.length;
                    if (!state.head.extra) {
                      state.head.extra = new Array(state.head.extra_len);
                    }
                    utils.arraySet(
                      state.head.extra,
                      input,
                      next,
                      // extra field is limited to 65536 bytes
                      // - no need for additional size check
                      copy,
                      /*len + copy > state.head.extra_max - len ? state.head.extra_max : copy,*/
                      len
                    );
                  }
                  if (state.flags & 512) {
                    state.check = crc32(state.check, input, copy, next);
                  }
                  have -= copy;
                  next += copy;
                  state.length -= copy;
                }
                if (state.length) {
                  break inf_leave;
                }
              }
              state.length = 0;
              state.mode = NAME;
            /* falls through */
            case NAME:
              if (state.flags & 2048) {
                if (have === 0) {
                  break inf_leave;
                }
                copy = 0;
                do {
                  len = input[next + copy++];
                  if (state.head && len && state.length < 65536) {
                    state.head.name += String.fromCharCode(len);
                  }
                } while (len && copy < have);
                if (state.flags & 512) {
                  state.check = crc32(state.check, input, copy, next);
                }
                have -= copy;
                next += copy;
                if (len) {
                  break inf_leave;
                }
              } else if (state.head) {
                state.head.name = null;
              }
              state.length = 0;
              state.mode = COMMENT;
            /* falls through */
            case COMMENT:
              if (state.flags & 4096) {
                if (have === 0) {
                  break inf_leave;
                }
                copy = 0;
                do {
                  len = input[next + copy++];
                  if (state.head && len && state.length < 65536) {
                    state.head.comment += String.fromCharCode(len);
                  }
                } while (len && copy < have);
                if (state.flags & 512) {
                  state.check = crc32(state.check, input, copy, next);
                }
                have -= copy;
                next += copy;
                if (len) {
                  break inf_leave;
                }
              } else if (state.head) {
                state.head.comment = null;
              }
              state.mode = HCRC;
            /* falls through */
            case HCRC:
              if (state.flags & 512) {
                while (bits < 16) {
                  if (have === 0) {
                    break inf_leave;
                  }
                  have--;
                  hold += input[next++] << bits;
                  bits += 8;
                }
                if (hold !== (state.check & 65535)) {
                  strm.msg = "header crc mismatch";
                  state.mode = BAD;
                  break;
                }
                hold = 0;
                bits = 0;
              }
              if (state.head) {
                state.head.hcrc = state.flags >> 9 & 1;
                state.head.done = true;
              }
              strm.adler = state.check = 0;
              state.mode = TYPE;
              break;
            case DICTID:
              while (bits < 32) {
                if (have === 0) {
                  break inf_leave;
                }
                have--;
                hold += input[next++] << bits;
                bits += 8;
              }
              strm.adler = state.check = zswap32(hold);
              hold = 0;
              bits = 0;
              state.mode = DICT;
            /* falls through */
            case DICT:
              if (state.havedict === 0) {
                strm.next_out = put;
                strm.avail_out = left;
                strm.next_in = next;
                strm.avail_in = have;
                state.hold = hold;
                state.bits = bits;
                return Z_NEED_DICT;
              }
              strm.adler = state.check = 1;
              state.mode = TYPE;
            /* falls through */
            case TYPE:
              if (flush === Z_BLOCK || flush === Z_TREES) {
                break inf_leave;
              }
            /* falls through */
            case TYPEDO:
              if (state.last) {
                hold >>>= bits & 7;
                bits -= bits & 7;
                state.mode = CHECK;
                break;
              }
              while (bits < 3) {
                if (have === 0) {
                  break inf_leave;
                }
                have--;
                hold += input[next++] << bits;
                bits += 8;
              }
              state.last = hold & 1;
              hold >>>= 1;
              bits -= 1;
              switch (hold & 3) {
                case 0:
                  state.mode = STORED;
                  break;
                case 1:
                  fixedtables(state);
                  state.mode = LEN_;
                  if (flush === Z_TREES) {
                    hold >>>= 2;
                    bits -= 2;
                    break inf_leave;
                  }
                  break;
                case 2:
                  state.mode = TABLE;
                  break;
                case 3:
                  strm.msg = "invalid block type";
                  state.mode = BAD;
              }
              hold >>>= 2;
              bits -= 2;
              break;
            case STORED:
              hold >>>= bits & 7;
              bits -= bits & 7;
              while (bits < 32) {
                if (have === 0) {
                  break inf_leave;
                }
                have--;
                hold += input[next++] << bits;
                bits += 8;
              }
              if ((hold & 65535) !== (hold >>> 16 ^ 65535)) {
                strm.msg = "invalid stored block lengths";
                state.mode = BAD;
                break;
              }
              state.length = hold & 65535;
              hold = 0;
              bits = 0;
              state.mode = COPY_;
              if (flush === Z_TREES) {
                break inf_leave;
              }
            /* falls through */
            case COPY_:
              state.mode = COPY;
            /* falls through */
            case COPY:
              copy = state.length;
              if (copy) {
                if (copy > have) {
                  copy = have;
                }
                if (copy > left) {
                  copy = left;
                }
                if (copy === 0) {
                  break inf_leave;
                }
                utils.arraySet(output, input, next, copy, put);
                have -= copy;
                next += copy;
                left -= copy;
                put += copy;
                state.length -= copy;
                break;
              }
              state.mode = TYPE;
              break;
            case TABLE:
              while (bits < 14) {
                if (have === 0) {
                  break inf_leave;
                }
                have--;
                hold += input[next++] << bits;
                bits += 8;
              }
              state.nlen = (hold & 31) + 257;
              hold >>>= 5;
              bits -= 5;
              state.ndist = (hold & 31) + 1;
              hold >>>= 5;
              bits -= 5;
              state.ncode = (hold & 15) + 4;
              hold >>>= 4;
              bits -= 4;
              if (state.nlen > 286 || state.ndist > 30) {
                strm.msg = "too many length or distance symbols";
                state.mode = BAD;
                break;
              }
              state.have = 0;
              state.mode = LENLENS;
            /* falls through */
            case LENLENS:
              while (state.have < state.ncode) {
                while (bits < 3) {
                  if (have === 0) {
                    break inf_leave;
                  }
                  have--;
                  hold += input[next++] << bits;
                  bits += 8;
                }
                state.lens[order[state.have++]] = hold & 7;
                hold >>>= 3;
                bits -= 3;
              }
              while (state.have < 19) {
                state.lens[order[state.have++]] = 0;
              }
              state.lencode = state.lendyn;
              state.lenbits = 7;
              opts = { bits: state.lenbits };
              ret = inflate_table(CODES, state.lens, 0, 19, state.lencode, 0, state.work, opts);
              state.lenbits = opts.bits;
              if (ret) {
                strm.msg = "invalid code lengths set";
                state.mode = BAD;
                break;
              }
              state.have = 0;
              state.mode = CODELENS;
            /* falls through */
            case CODELENS:
              while (state.have < state.nlen + state.ndist) {
                for (; ; ) {
                  here = state.lencode[hold & (1 << state.lenbits) - 1];
                  here_bits = here >>> 24;
                  here_op = here >>> 16 & 255;
                  here_val = here & 65535;
                  if (here_bits <= bits) {
                    break;
                  }
                  if (have === 0) {
                    break inf_leave;
                  }
                  have--;
                  hold += input[next++] << bits;
                  bits += 8;
                }
                if (here_val < 16) {
                  hold >>>= here_bits;
                  bits -= here_bits;
                  state.lens[state.have++] = here_val;
                } else {
                  if (here_val === 16) {
                    n2 = here_bits + 2;
                    while (bits < n2) {
                      if (have === 0) {
                        break inf_leave;
                      }
                      have--;
                      hold += input[next++] << bits;
                      bits += 8;
                    }
                    hold >>>= here_bits;
                    bits -= here_bits;
                    if (state.have === 0) {
                      strm.msg = "invalid bit length repeat";
                      state.mode = BAD;
                      break;
                    }
                    len = state.lens[state.have - 1];
                    copy = 3 + (hold & 3);
                    hold >>>= 2;
                    bits -= 2;
                  } else if (here_val === 17) {
                    n2 = here_bits + 3;
                    while (bits < n2) {
                      if (have === 0) {
                        break inf_leave;
                      }
                      have--;
                      hold += input[next++] << bits;
                      bits += 8;
                    }
                    hold >>>= here_bits;
                    bits -= here_bits;
                    len = 0;
                    copy = 3 + (hold & 7);
                    hold >>>= 3;
                    bits -= 3;
                  } else {
                    n2 = here_bits + 7;
                    while (bits < n2) {
                      if (have === 0) {
                        break inf_leave;
                      }
                      have--;
                      hold += input[next++] << bits;
                      bits += 8;
                    }
                    hold >>>= here_bits;
                    bits -= here_bits;
                    len = 0;
                    copy = 11 + (hold & 127);
                    hold >>>= 7;
                    bits -= 7;
                  }
                  if (state.have + copy > state.nlen + state.ndist) {
                    strm.msg = "invalid bit length repeat";
                    state.mode = BAD;
                    break;
                  }
                  while (copy--) {
                    state.lens[state.have++] = len;
                  }
                }
              }
              if (state.mode === BAD) {
                break;
              }
              if (state.lens[256] === 0) {
                strm.msg = "invalid code -- missing end-of-block";
                state.mode = BAD;
                break;
              }
              state.lenbits = 9;
              opts = { bits: state.lenbits };
              ret = inflate_table(LENS, state.lens, 0, state.nlen, state.lencode, 0, state.work, opts);
              state.lenbits = opts.bits;
              if (ret) {
                strm.msg = "invalid literal/lengths set";
                state.mode = BAD;
                break;
              }
              state.distbits = 6;
              state.distcode = state.distdyn;
              opts = { bits: state.distbits };
              ret = inflate_table(DISTS, state.lens, state.nlen, state.ndist, state.distcode, 0, state.work, opts);
              state.distbits = opts.bits;
              if (ret) {
                strm.msg = "invalid distances set";
                state.mode = BAD;
                break;
              }
              state.mode = LEN_;
              if (flush === Z_TREES) {
                break inf_leave;
              }
            /* falls through */
            case LEN_:
              state.mode = LEN;
            /* falls through */
            case LEN:
              if (have >= 6 && left >= 258) {
                strm.next_out = put;
                strm.avail_out = left;
                strm.next_in = next;
                strm.avail_in = have;
                state.hold = hold;
                state.bits = bits;
                inflate_fast(strm, _out);
                put = strm.next_out;
                output = strm.output;
                left = strm.avail_out;
                next = strm.next_in;
                input = strm.input;
                have = strm.avail_in;
                hold = state.hold;
                bits = state.bits;
                if (state.mode === TYPE) {
                  state.back = -1;
                }
                break;
              }
              state.back = 0;
              for (; ; ) {
                here = state.lencode[hold & (1 << state.lenbits) - 1];
                here_bits = here >>> 24;
                here_op = here >>> 16 & 255;
                here_val = here & 65535;
                if (here_bits <= bits) {
                  break;
                }
                if (have === 0) {
                  break inf_leave;
                }
                have--;
                hold += input[next++] << bits;
                bits += 8;
              }
              if (here_op && (here_op & 240) === 0) {
                last_bits = here_bits;
                last_op = here_op;
                last_val = here_val;
                for (; ; ) {
                  here = state.lencode[last_val + ((hold & (1 << last_bits + last_op) - 1) >> last_bits)];
                  here_bits = here >>> 24;
                  here_op = here >>> 16 & 255;
                  here_val = here & 65535;
                  if (last_bits + here_bits <= bits) {
                    break;
                  }
                  if (have === 0) {
                    break inf_leave;
                  }
                  have--;
                  hold += input[next++] << bits;
                  bits += 8;
                }
                hold >>>= last_bits;
                bits -= last_bits;
                state.back += last_bits;
              }
              hold >>>= here_bits;
              bits -= here_bits;
              state.back += here_bits;
              state.length = here_val;
              if (here_op === 0) {
                state.mode = LIT;
                break;
              }
              if (here_op & 32) {
                state.back = -1;
                state.mode = TYPE;
                break;
              }
              if (here_op & 64) {
                strm.msg = "invalid literal/length code";
                state.mode = BAD;
                break;
              }
              state.extra = here_op & 15;
              state.mode = LENEXT;
            /* falls through */
            case LENEXT:
              if (state.extra) {
                n2 = state.extra;
                while (bits < n2) {
                  if (have === 0) {
                    break inf_leave;
                  }
                  have--;
                  hold += input[next++] << bits;
                  bits += 8;
                }
                state.length += hold & (1 << state.extra) - 1;
                hold >>>= state.extra;
                bits -= state.extra;
                state.back += state.extra;
              }
              state.was = state.length;
              state.mode = DIST;
            /* falls through */
            case DIST:
              for (; ; ) {
                here = state.distcode[hold & (1 << state.distbits) - 1];
                here_bits = here >>> 24;
                here_op = here >>> 16 & 255;
                here_val = here & 65535;
                if (here_bits <= bits) {
                  break;
                }
                if (have === 0) {
                  break inf_leave;
                }
                have--;
                hold += input[next++] << bits;
                bits += 8;
              }
              if ((here_op & 240) === 0) {
                last_bits = here_bits;
                last_op = here_op;
                last_val = here_val;
                for (; ; ) {
                  here = state.distcode[last_val + ((hold & (1 << last_bits + last_op) - 1) >> last_bits)];
                  here_bits = here >>> 24;
                  here_op = here >>> 16 & 255;
                  here_val = here & 65535;
                  if (last_bits + here_bits <= bits) {
                    break;
                  }
                  if (have === 0) {
                    break inf_leave;
                  }
                  have--;
                  hold += input[next++] << bits;
                  bits += 8;
                }
                hold >>>= last_bits;
                bits -= last_bits;
                state.back += last_bits;
              }
              hold >>>= here_bits;
              bits -= here_bits;
              state.back += here_bits;
              if (here_op & 64) {
                strm.msg = "invalid distance code";
                state.mode = BAD;
                break;
              }
              state.offset = here_val;
              state.extra = here_op & 15;
              state.mode = DISTEXT;
            /* falls through */
            case DISTEXT:
              if (state.extra) {
                n2 = state.extra;
                while (bits < n2) {
                  if (have === 0) {
                    break inf_leave;
                  }
                  have--;
                  hold += input[next++] << bits;
                  bits += 8;
                }
                state.offset += hold & (1 << state.extra) - 1;
                hold >>>= state.extra;
                bits -= state.extra;
                state.back += state.extra;
              }
              if (state.offset > state.dmax) {
                strm.msg = "invalid distance too far back";
                state.mode = BAD;
                break;
              }
              state.mode = MATCH;
            /* falls through */
            case MATCH:
              if (left === 0) {
                break inf_leave;
              }
              copy = _out - left;
              if (state.offset > copy) {
                copy = state.offset - copy;
                if (copy > state.whave) {
                  if (state.sane) {
                    strm.msg = "invalid distance too far back";
                    state.mode = BAD;
                    break;
                  }
                }
                if (copy > state.wnext) {
                  copy -= state.wnext;
                  from = state.wsize - copy;
                } else {
                  from = state.wnext - copy;
                }
                if (copy > state.length) {
                  copy = state.length;
                }
                from_source = state.window;
              } else {
                from_source = output;
                from = put - state.offset;
                copy = state.length;
              }
              if (copy > left) {
                copy = left;
              }
              left -= copy;
              state.length -= copy;
              do {
                output[put++] = from_source[from++];
              } while (--copy);
              if (state.length === 0) {
                state.mode = LEN;
              }
              break;
            case LIT:
              if (left === 0) {
                break inf_leave;
              }
              output[put++] = state.length;
              left--;
              state.mode = LEN;
              break;
            case CHECK:
              if (state.wrap) {
                while (bits < 32) {
                  if (have === 0) {
                    break inf_leave;
                  }
                  have--;
                  hold |= input[next++] << bits;
                  bits += 8;
                }
                _out -= left;
                strm.total_out += _out;
                state.total += _out;
                if (_out) {
                  strm.adler = state.check = /*UPDATE(state.check, put - _out, _out);*/
                  state.flags ? crc32(state.check, output, _out, put - _out) : adler32(state.check, output, _out, put - _out);
                }
                _out = left;
                if ((state.flags ? hold : zswap32(hold)) !== state.check) {
                  strm.msg = "incorrect data check";
                  state.mode = BAD;
                  break;
                }
                hold = 0;
                bits = 0;
              }
              state.mode = LENGTH;
            /* falls through */
            case LENGTH:
              if (state.wrap && state.flags) {
                while (bits < 32) {
                  if (have === 0) {
                    break inf_leave;
                  }
                  have--;
                  hold += input[next++] << bits;
                  bits += 8;
                }
                if (hold !== (state.total & 4294967295)) {
                  strm.msg = "incorrect length check";
                  state.mode = BAD;
                  break;
                }
                hold = 0;
                bits = 0;
              }
              state.mode = DONE;
            /* falls through */
            case DONE:
              ret = Z_STREAM_END;
              break inf_leave;
            case BAD:
              ret = Z_DATA_ERROR;
              break inf_leave;
            case MEM:
              return Z_MEM_ERROR;
            case SYNC:
            /* falls through */
            default:
              return Z_STREAM_ERROR;
          }
        }
      strm.next_out = put;
      strm.avail_out = left;
      strm.next_in = next;
      strm.avail_in = have;
      state.hold = hold;
      state.bits = bits;
      if (state.wsize || _out !== strm.avail_out && state.mode < BAD && (state.mode < CHECK || flush !== Z_FINISH)) {
        if (updatewindow(strm, strm.output, strm.next_out, _out - strm.avail_out)) {
          state.mode = MEM;
          return Z_MEM_ERROR;
        }
      }
      _in -= strm.avail_in;
      _out -= strm.avail_out;
      strm.total_in += _in;
      strm.total_out += _out;
      state.total += _out;
      if (state.wrap && _out) {
        strm.adler = state.check = /*UPDATE(state.check, strm.next_out - _out, _out);*/
        state.flags ? crc32(state.check, output, _out, strm.next_out - _out) : adler32(state.check, output, _out, strm.next_out - _out);
      }
      strm.data_type = state.bits + (state.last ? 64 : 0) + (state.mode === TYPE ? 128 : 0) + (state.mode === LEN_ || state.mode === COPY_ ? 256 : 0);
      if ((_in === 0 && _out === 0 || flush === Z_FINISH) && ret === Z_OK) {
        ret = Z_BUF_ERROR;
      }
      return ret;
    }
    function inflateEnd(strm) {
      if (!strm || !strm.state) {
        return Z_STREAM_ERROR;
      }
      var state = strm.state;
      if (state.window) {
        state.window = null;
      }
      strm.state = null;
      return Z_OK;
    }
    function inflateGetHeader(strm, head) {
      var state;
      if (!strm || !strm.state) {
        return Z_STREAM_ERROR;
      }
      state = strm.state;
      if ((state.wrap & 2) === 0) {
        return Z_STREAM_ERROR;
      }
      state.head = head;
      head.done = false;
      return Z_OK;
    }
    function inflateSetDictionary(strm, dictionary) {
      var dictLength = dictionary.length;
      var state;
      var dictid;
      var ret;
      if (!strm || !strm.state) {
        return Z_STREAM_ERROR;
      }
      state = strm.state;
      if (state.wrap !== 0 && state.mode !== DICT) {
        return Z_STREAM_ERROR;
      }
      if (state.mode === DICT) {
        dictid = 1;
        dictid = adler32(dictid, dictionary, dictLength, 0);
        if (dictid !== state.check) {
          return Z_DATA_ERROR;
        }
      }
      ret = updatewindow(strm, dictionary, dictLength, dictLength);
      if (ret) {
        state.mode = MEM;
        return Z_MEM_ERROR;
      }
      state.havedict = 1;
      return Z_OK;
    }
    exports.inflateReset = inflateReset;
    exports.inflateReset2 = inflateReset2;
    exports.inflateResetKeep = inflateResetKeep;
    exports.inflateInit = inflateInit;
    exports.inflateInit2 = inflateInit2;
    exports.inflate = inflate;
    exports.inflateEnd = inflateEnd;
    exports.inflateGetHeader = inflateGetHeader;
    exports.inflateSetDictionary = inflateSetDictionary;
    exports.inflateInfo = "pako inflate (from Nodeca project)";
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/pako/lib/zlib/constants.js
var require_constants = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/pako/lib/zlib/constants.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    module.exports = {
      /* Allowed flush values; see deflate() and inflate() below for details */
      Z_NO_FLUSH: 0,
      Z_PARTIAL_FLUSH: 1,
      Z_SYNC_FLUSH: 2,
      Z_FULL_FLUSH: 3,
      Z_FINISH: 4,
      Z_BLOCK: 5,
      Z_TREES: 6,
      /* Return codes for the compression/decompression functions. Negative values
      * are errors, positive values are used for special but normal events.
      */
      Z_OK: 0,
      Z_STREAM_END: 1,
      Z_NEED_DICT: 2,
      Z_ERRNO: -1,
      Z_STREAM_ERROR: -2,
      Z_DATA_ERROR: -3,
      //Z_MEM_ERROR:     -4,
      Z_BUF_ERROR: -5,
      //Z_VERSION_ERROR: -6,
      /* compression levels */
      Z_NO_COMPRESSION: 0,
      Z_BEST_SPEED: 1,
      Z_BEST_COMPRESSION: 9,
      Z_DEFAULT_COMPRESSION: -1,
      Z_FILTERED: 1,
      Z_HUFFMAN_ONLY: 2,
      Z_RLE: 3,
      Z_FIXED: 4,
      Z_DEFAULT_STRATEGY: 0,
      /* Possible values of the data_type field (though see inflate()) */
      Z_BINARY: 0,
      Z_TEXT: 1,
      //Z_ASCII:                1, // = Z_TEXT (deprecated)
      Z_UNKNOWN: 2,
      /* The deflate compression method */
      Z_DEFLATED: 8
      //Z_NULL:                 null // Use -1 or null inline, depending on var type
    };
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/pako/lib/zlib/gzheader.js
var require_gzheader = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/pako/lib/zlib/gzheader.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    function GZheader() {
      this.text = 0;
      this.time = 0;
      this.xflags = 0;
      this.os = 0;
      this.extra = null;
      this.extra_len = 0;
      this.name = "";
      this.comment = "";
      this.hcrc = 0;
      this.done = false;
    }
    module.exports = GZheader;
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/pako/lib/inflate.js
var require_inflate2 = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/pako/lib/inflate.js"(exports) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var zlib_inflate = require_inflate();
    var utils = require_common();
    var strings = require_strings();
    var c2 = require_constants();
    var msg = require_messages();
    var ZStream = require_zstream();
    var GZheader = require_gzheader();
    var toString = Object.prototype.toString;
    function Inflate(options) {
      if (!(this instanceof Inflate)) return new Inflate(options);
      this.options = utils.assign({
        chunkSize: 16384,
        windowBits: 0,
        to: ""
      }, options || {});
      var opt = this.options;
      if (opt.raw && opt.windowBits >= 0 && opt.windowBits < 16) {
        opt.windowBits = -opt.windowBits;
        if (opt.windowBits === 0) {
          opt.windowBits = -15;
        }
      }
      if (opt.windowBits >= 0 && opt.windowBits < 16 && !(options && options.windowBits)) {
        opt.windowBits += 32;
      }
      if (opt.windowBits > 15 && opt.windowBits < 48) {
        if ((opt.windowBits & 15) === 0) {
          opt.windowBits |= 15;
        }
      }
      this.err = 0;
      this.msg = "";
      this.ended = false;
      this.chunks = [];
      this.strm = new ZStream();
      this.strm.avail_out = 0;
      var status = zlib_inflate.inflateInit2(
        this.strm,
        opt.windowBits
      );
      if (status !== c2.Z_OK) {
        throw new Error(msg[status]);
      }
      this.header = new GZheader();
      zlib_inflate.inflateGetHeader(this.strm, this.header);
      if (opt.dictionary) {
        if (typeof opt.dictionary === "string") {
          opt.dictionary = strings.string2buf(opt.dictionary);
        } else if (toString.call(opt.dictionary) === "[object ArrayBuffer]") {
          opt.dictionary = new Uint8Array(opt.dictionary);
        }
        if (opt.raw) {
          status = zlib_inflate.inflateSetDictionary(this.strm, opt.dictionary);
          if (status !== c2.Z_OK) {
            throw new Error(msg[status]);
          }
        }
      }
    }
    Inflate.prototype.push = function(data, mode) {
      var strm = this.strm;
      var chunkSize = this.options.chunkSize;
      var dictionary = this.options.dictionary;
      var status, _mode;
      var next_out_utf8, tail, utf8str;
      var allowBufError = false;
      if (this.ended) {
        return false;
      }
      _mode = mode === ~~mode ? mode : mode === true ? c2.Z_FINISH : c2.Z_NO_FLUSH;
      if (typeof data === "string") {
        strm.input = strings.binstring2buf(data);
      } else if (toString.call(data) === "[object ArrayBuffer]") {
        strm.input = new Uint8Array(data);
      } else {
        strm.input = data;
      }
      strm.next_in = 0;
      strm.avail_in = strm.input.length;
      do {
        if (strm.avail_out === 0) {
          strm.output = new utils.Buf8(chunkSize);
          strm.next_out = 0;
          strm.avail_out = chunkSize;
        }
        status = zlib_inflate.inflate(strm, c2.Z_NO_FLUSH);
        if (status === c2.Z_NEED_DICT && dictionary) {
          status = zlib_inflate.inflateSetDictionary(this.strm, dictionary);
        }
        if (status === c2.Z_BUF_ERROR && allowBufError === true) {
          status = c2.Z_OK;
          allowBufError = false;
        }
        if (status !== c2.Z_STREAM_END && status !== c2.Z_OK) {
          this.onEnd(status);
          this.ended = true;
          return false;
        }
        if (strm.next_out) {
          if (strm.avail_out === 0 || status === c2.Z_STREAM_END || strm.avail_in === 0 && (_mode === c2.Z_FINISH || _mode === c2.Z_SYNC_FLUSH)) {
            if (this.options.to === "string") {
              next_out_utf8 = strings.utf8border(strm.output, strm.next_out);
              tail = strm.next_out - next_out_utf8;
              utf8str = strings.buf2string(strm.output, next_out_utf8);
              strm.next_out = tail;
              strm.avail_out = chunkSize - tail;
              if (tail) {
                utils.arraySet(strm.output, strm.output, next_out_utf8, tail, 0);
              }
              this.onData(utf8str);
            } else {
              this.onData(utils.shrinkBuf(strm.output, strm.next_out));
            }
          }
        }
        if (strm.avail_in === 0 && strm.avail_out === 0) {
          allowBufError = true;
        }
      } while ((strm.avail_in > 0 || strm.avail_out === 0) && status !== c2.Z_STREAM_END);
      if (status === c2.Z_STREAM_END) {
        _mode = c2.Z_FINISH;
      }
      if (_mode === c2.Z_FINISH) {
        status = zlib_inflate.inflateEnd(this.strm);
        this.onEnd(status);
        this.ended = true;
        return status === c2.Z_OK;
      }
      if (_mode === c2.Z_SYNC_FLUSH) {
        this.onEnd(c2.Z_OK);
        strm.avail_out = 0;
        return true;
      }
      return true;
    };
    Inflate.prototype.onData = function(chunk) {
      this.chunks.push(chunk);
    };
    Inflate.prototype.onEnd = function(status) {
      if (status === c2.Z_OK) {
        if (this.options.to === "string") {
          this.result = this.chunks.join("");
        } else {
          this.result = utils.flattenChunks(this.chunks);
        }
      }
      this.chunks = [];
      this.err = status;
      this.msg = this.strm.msg;
    };
    function inflate(input, options) {
      var inflator = new Inflate(options);
      inflator.push(input, true);
      if (inflator.err) {
        throw inflator.msg || msg[inflator.err];
      }
      return inflator.result;
    }
    function inflateRaw(input, options) {
      options = options || {};
      options.raw = true;
      return inflate(input, options);
    }
    exports.Inflate = Inflate;
    exports.inflate = inflate;
    exports.inflateRaw = inflateRaw;
    exports.ungzip = inflate;
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/pako/index.js
var require_pako = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/pako/index.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var assign = require_common().assign;
    var deflate = require_deflate2();
    var inflate = require_inflate2();
    var constants = require_constants();
    var pako = {};
    assign(pako, deflate, inflate, constants);
    module.exports = pako;
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/flate.js
var require_flate = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/flate.js"(exports) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var USE_TYPEDARRAY = typeof Uint8Array !== "undefined" && typeof Uint16Array !== "undefined" && typeof Uint32Array !== "undefined";
    var pako = require_pako();
    var utils = require_utils();
    var GenericWorker = require_GenericWorker();
    var ARRAY_TYPE = USE_TYPEDARRAY ? "uint8array" : "array";
    exports.magic = "\b\0";
    function FlateWorker(action, options) {
      GenericWorker.call(this, "FlateWorker/" + action);
      this._pako = null;
      this._pakoAction = action;
      this._pakoOptions = options;
      this.meta = {};
    }
    utils.inherits(FlateWorker, GenericWorker);
    FlateWorker.prototype.processChunk = function(chunk) {
      this.meta = chunk.meta;
      if (this._pako === null) {
        this._createPako();
      }
      this._pako.push(utils.transformTo(ARRAY_TYPE, chunk.data), false);
    };
    FlateWorker.prototype.flush = function() {
      GenericWorker.prototype.flush.call(this);
      if (this._pako === null) {
        this._createPako();
      }
      this._pako.push([], true);
    };
    FlateWorker.prototype.cleanUp = function() {
      GenericWorker.prototype.cleanUp.call(this);
      this._pako = null;
    };
    FlateWorker.prototype._createPako = function() {
      this._pako = new pako[this._pakoAction]({
        raw: true,
        level: this._pakoOptions.level || -1
        // default compression
      });
      var self2 = this;
      this._pako.onData = function(data) {
        self2.push({
          data,
          meta: self2.meta
        });
      };
    };
    exports.compressWorker = function(compressionOptions) {
      return new FlateWorker("Deflate", compressionOptions);
    };
    exports.uncompressWorker = function() {
      return new FlateWorker("Inflate", {});
    };
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/compressions.js
var require_compressions = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/compressions.js"(exports) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var GenericWorker = require_GenericWorker();
    exports.STORE = {
      magic: "\0\0",
      compressWorker: function() {
        return new GenericWorker("STORE compression");
      },
      uncompressWorker: function() {
        return new GenericWorker("STORE decompression");
      }
    };
    exports.DEFLATE = require_flate();
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/signature.js
var require_signature = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/signature.js"(exports) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    exports.LOCAL_FILE_HEADER = "PK";
    exports.CENTRAL_FILE_HEADER = "PK";
    exports.CENTRAL_DIRECTORY_END = "PK";
    exports.ZIP64_CENTRAL_DIRECTORY_LOCATOR = "PK\x07";
    exports.ZIP64_CENTRAL_DIRECTORY_END = "PK";
    exports.DATA_DESCRIPTOR = "PK\x07\b";
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/generate/ZipFileWorker.js
var require_ZipFileWorker = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/generate/ZipFileWorker.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var utils = require_utils();
    var GenericWorker = require_GenericWorker();
    var utf8 = require_utf8();
    var crc32 = require_crc32();
    var signature = require_signature();
    var decToHex = function(dec, bytes) {
      var hex = "", i2;
      for (i2 = 0; i2 < bytes; i2++) {
        hex += String.fromCharCode(dec & 255);
        dec = dec >>> 8;
      }
      return hex;
    };
    var generateUnixExternalFileAttr = function(unixPermissions, isDir) {
      var result = unixPermissions;
      if (!unixPermissions) {
        result = isDir ? 16893 : 33204;
      }
      return (result & 65535) << 16;
    };
    var generateDosExternalFileAttr = function(dosPermissions) {
      return (dosPermissions || 0) & 63;
    };
    var generateZipParts = function(streamInfo, streamedContent, streamingEnded, offset, platform, encodeFileName) {
      var file = streamInfo["file"], compression = streamInfo["compression"], useCustomEncoding = encodeFileName !== utf8.utf8encode, encodedFileName = utils.transformTo("string", encodeFileName(file.name)), utfEncodedFileName = utils.transformTo("string", utf8.utf8encode(file.name)), comment = file.comment, encodedComment = utils.transformTo("string", encodeFileName(comment)), utfEncodedComment = utils.transformTo("string", utf8.utf8encode(comment)), useUTF8ForFileName = utfEncodedFileName.length !== file.name.length, useUTF8ForComment = utfEncodedComment.length !== comment.length, dosTime, dosDate, extraFields = "", unicodePathExtraField = "", unicodeCommentExtraField = "", dir = file.dir, date = file.date;
      var dataInfo = {
        crc32: 0,
        compressedSize: 0,
        uncompressedSize: 0
      };
      if (!streamedContent || streamingEnded) {
        dataInfo.crc32 = streamInfo["crc32"];
        dataInfo.compressedSize = streamInfo["compressedSize"];
        dataInfo.uncompressedSize = streamInfo["uncompressedSize"];
      }
      var bitflag = 0;
      if (streamedContent) {
        bitflag |= 8;
      }
      if (!useCustomEncoding && (useUTF8ForFileName || useUTF8ForComment)) {
        bitflag |= 2048;
      }
      var extFileAttr = 0;
      var versionMadeBy = 0;
      if (dir) {
        extFileAttr |= 16;
      }
      if (platform === "UNIX") {
        versionMadeBy = 798;
        extFileAttr |= generateUnixExternalFileAttr(file.unixPermissions, dir);
      } else {
        versionMadeBy = 20;
        extFileAttr |= generateDosExternalFileAttr(file.dosPermissions, dir);
      }
      dosTime = date.getUTCHours();
      dosTime = dosTime << 6;
      dosTime = dosTime | date.getUTCMinutes();
      dosTime = dosTime << 5;
      dosTime = dosTime | date.getUTCSeconds() / 2;
      dosDate = date.getUTCFullYear() - 1980;
      dosDate = dosDate << 4;
      dosDate = dosDate | date.getUTCMonth() + 1;
      dosDate = dosDate << 5;
      dosDate = dosDate | date.getUTCDate();
      if (useUTF8ForFileName) {
        unicodePathExtraField = // Version
        decToHex(1, 1) + // NameCRC32
        decToHex(crc32(encodedFileName), 4) + // UnicodeName
        utfEncodedFileName;
        extraFields += // Info-ZIP Unicode Path Extra Field
        "up" + // size
        decToHex(unicodePathExtraField.length, 2) + // content
        unicodePathExtraField;
      }
      if (useUTF8ForComment) {
        unicodeCommentExtraField = // Version
        decToHex(1, 1) + // CommentCRC32
        decToHex(crc32(encodedComment), 4) + // UnicodeName
        utfEncodedComment;
        extraFields += // Info-ZIP Unicode Path Extra Field
        "uc" + // size
        decToHex(unicodeCommentExtraField.length, 2) + // content
        unicodeCommentExtraField;
      }
      var header = "";
      header += "\n\0";
      header += decToHex(bitflag, 2);
      header += compression.magic;
      header += decToHex(dosTime, 2);
      header += decToHex(dosDate, 2);
      header += decToHex(dataInfo.crc32, 4);
      header += decToHex(dataInfo.compressedSize, 4);
      header += decToHex(dataInfo.uncompressedSize, 4);
      header += decToHex(encodedFileName.length, 2);
      header += decToHex(extraFields.length, 2);
      var fileRecord = signature.LOCAL_FILE_HEADER + header + encodedFileName + extraFields;
      var dirRecord = signature.CENTRAL_FILE_HEADER + // version made by (00: DOS)
      decToHex(versionMadeBy, 2) + // file header (common to file and central directory)
      header + // file comment length
      decToHex(encodedComment.length, 2) + // disk number start
      "\0\0\0\0" + // external file attributes
      decToHex(extFileAttr, 4) + // relative offset of local header
      decToHex(offset, 4) + // file name
      encodedFileName + // extra field
      extraFields + // file comment
      encodedComment;
      return {
        fileRecord,
        dirRecord
      };
    };
    var generateCentralDirectoryEnd = function(entriesCount, centralDirLength, localDirLength, comment, encodeFileName) {
      var dirEnd = "";
      var encodedComment = utils.transformTo("string", encodeFileName(comment));
      dirEnd = signature.CENTRAL_DIRECTORY_END + // number of this disk
      "\0\0\0\0" + // total number of entries in the central directory on this disk
      decToHex(entriesCount, 2) + // total number of entries in the central directory
      decToHex(entriesCount, 2) + // size of the central directory   4 bytes
      decToHex(centralDirLength, 4) + // offset of start of central directory with respect to the starting disk number
      decToHex(localDirLength, 4) + // .ZIP file comment length
      decToHex(encodedComment.length, 2) + // .ZIP file comment
      encodedComment;
      return dirEnd;
    };
    var generateDataDescriptors = function(streamInfo) {
      var descriptor = "";
      descriptor = signature.DATA_DESCRIPTOR + // crc-32                          4 bytes
      decToHex(streamInfo["crc32"], 4) + // compressed size                 4 bytes
      decToHex(streamInfo["compressedSize"], 4) + // uncompressed size               4 bytes
      decToHex(streamInfo["uncompressedSize"], 4);
      return descriptor;
    };
    function ZipFileWorker(streamFiles, comment, platform, encodeFileName) {
      GenericWorker.call(this, "ZipFileWorker");
      this.bytesWritten = 0;
      this.zipComment = comment;
      this.zipPlatform = platform;
      this.encodeFileName = encodeFileName;
      this.streamFiles = streamFiles;
      this.accumulate = false;
      this.contentBuffer = [];
      this.dirRecords = [];
      this.currentSourceOffset = 0;
      this.entriesCount = 0;
      this.currentFile = null;
      this._sources = [];
    }
    utils.inherits(ZipFileWorker, GenericWorker);
    ZipFileWorker.prototype.push = function(chunk) {
      var currentFilePercent = chunk.meta.percent || 0;
      var entriesCount = this.entriesCount;
      var remainingFiles = this._sources.length;
      if (this.accumulate) {
        this.contentBuffer.push(chunk);
      } else {
        this.bytesWritten += chunk.data.length;
        GenericWorker.prototype.push.call(this, {
          data: chunk.data,
          meta: {
            currentFile: this.currentFile,
            percent: entriesCount ? (currentFilePercent + 100 * (entriesCount - remainingFiles - 1)) / entriesCount : 100
          }
        });
      }
    };
    ZipFileWorker.prototype.openedSource = function(streamInfo) {
      this.currentSourceOffset = this.bytesWritten;
      this.currentFile = streamInfo["file"].name;
      var streamedContent = this.streamFiles && !streamInfo["file"].dir;
      if (streamedContent) {
        var record = generateZipParts(streamInfo, streamedContent, false, this.currentSourceOffset, this.zipPlatform, this.encodeFileName);
        this.push({
          data: record.fileRecord,
          meta: { percent: 0 }
        });
      } else {
        this.accumulate = true;
      }
    };
    ZipFileWorker.prototype.closedSource = function(streamInfo) {
      this.accumulate = false;
      var streamedContent = this.streamFiles && !streamInfo["file"].dir;
      var record = generateZipParts(streamInfo, streamedContent, true, this.currentSourceOffset, this.zipPlatform, this.encodeFileName);
      this.dirRecords.push(record.dirRecord);
      if (streamedContent) {
        this.push({
          data: generateDataDescriptors(streamInfo),
          meta: { percent: 100 }
        });
      } else {
        this.push({
          data: record.fileRecord,
          meta: { percent: 0 }
        });
        while (this.contentBuffer.length) {
          this.push(this.contentBuffer.shift());
        }
      }
      this.currentFile = null;
    };
    ZipFileWorker.prototype.flush = function() {
      var localDirLength = this.bytesWritten;
      for (var i2 = 0; i2 < this.dirRecords.length; i2++) {
        this.push({
          data: this.dirRecords[i2],
          meta: { percent: 100 }
        });
      }
      var centralDirLength = this.bytesWritten - localDirLength;
      var dirEnd = generateCentralDirectoryEnd(this.dirRecords.length, centralDirLength, localDirLength, this.zipComment, this.encodeFileName);
      this.push({
        data: dirEnd,
        meta: { percent: 100 }
      });
    };
    ZipFileWorker.prototype.prepareNextSource = function() {
      this.previous = this._sources.shift();
      this.openedSource(this.previous.streamInfo);
      if (this.isPaused) {
        this.previous.pause();
      } else {
        this.previous.resume();
      }
    };
    ZipFileWorker.prototype.registerPrevious = function(previous) {
      this._sources.push(previous);
      var self2 = this;
      previous.on("data", function(chunk) {
        self2.processChunk(chunk);
      });
      previous.on("end", function() {
        self2.closedSource(self2.previous.streamInfo);
        if (self2._sources.length) {
          self2.prepareNextSource();
        } else {
          self2.end();
        }
      });
      previous.on("error", function(e2) {
        self2.error(e2);
      });
      return this;
    };
    ZipFileWorker.prototype.resume = function() {
      if (!GenericWorker.prototype.resume.call(this)) {
        return false;
      }
      if (!this.previous && this._sources.length) {
        this.prepareNextSource();
        return true;
      }
      if (!this.previous && !this._sources.length && !this.generatedError) {
        this.end();
        return true;
      }
    };
    ZipFileWorker.prototype.error = function(e2) {
      var sources = this._sources;
      if (!GenericWorker.prototype.error.call(this, e2)) {
        return false;
      }
      for (var i2 = 0; i2 < sources.length; i2++) {
        try {
          sources[i2].error(e2);
        } catch (e3) {
        }
      }
      return true;
    };
    ZipFileWorker.prototype.lock = function() {
      GenericWorker.prototype.lock.call(this);
      var sources = this._sources;
      for (var i2 = 0; i2 < sources.length; i2++) {
        sources[i2].lock();
      }
    };
    module.exports = ZipFileWorker;
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/generate/index.js
var require_generate = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/generate/index.js"(exports) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var compressions = require_compressions();
    var ZipFileWorker = require_ZipFileWorker();
    var getCompression = function(fileCompression, zipCompression) {
      var compressionName = fileCompression || zipCompression;
      var compression = compressions[compressionName];
      if (!compression) {
        throw new Error(compressionName + " is not a valid compression method !");
      }
      return compression;
    };
    exports.generateWorker = function(zip, options, comment) {
      var zipFileWorker = new ZipFileWorker(options.streamFiles, comment, options.platform, options.encodeFileName);
      var entriesCount = 0;
      try {
        zip.forEach(function(relativePath, file) {
          entriesCount++;
          var compression = getCompression(file.options.compression, options.compression);
          var compressionOptions = file.options.compressionOptions || options.compressionOptions || {};
          var dir = file.dir, date = file.date;
          file._compressWorker(compression, compressionOptions).withStreamInfo("file", {
            name: relativePath,
            dir,
            date,
            comment: file.comment || "",
            unixPermissions: file.unixPermissions,
            dosPermissions: file.dosPermissions
          }).pipe(zipFileWorker);
        });
        zipFileWorker.entriesCount = entriesCount;
      } catch (e2) {
        zipFileWorker.error(e2);
      }
      return zipFileWorker;
    };
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/nodejs/NodejsStreamInputAdapter.js
var require_NodejsStreamInputAdapter = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/nodejs/NodejsStreamInputAdapter.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var utils = require_utils();
    var GenericWorker = require_GenericWorker();
    function NodejsStreamInputAdapter(filename, stream) {
      GenericWorker.call(this, "Nodejs stream input adapter for " + filename);
      this._upstreamEnded = false;
      this._bindStream(stream);
    }
    utils.inherits(NodejsStreamInputAdapter, GenericWorker);
    NodejsStreamInputAdapter.prototype._bindStream = function(stream) {
      var self2 = this;
      this._stream = stream;
      stream.pause();
      stream.on("data", function(chunk) {
        self2.push({
          data: chunk,
          meta: {
            percent: 0
          }
        });
      }).on("error", function(e2) {
        if (self2.isPaused) {
          this.generatedError = e2;
        } else {
          self2.error(e2);
        }
      }).on("end", function() {
        if (self2.isPaused) {
          self2._upstreamEnded = true;
        } else {
          self2.end();
        }
      });
    };
    NodejsStreamInputAdapter.prototype.pause = function() {
      if (!GenericWorker.prototype.pause.call(this)) {
        return false;
      }
      this._stream.pause();
      return true;
    };
    NodejsStreamInputAdapter.prototype.resume = function() {
      if (!GenericWorker.prototype.resume.call(this)) {
        return false;
      }
      if (this._upstreamEnded) {
        this.end();
      } else {
        this._stream.resume();
      }
      return true;
    };
    module.exports = NodejsStreamInputAdapter;
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/object.js
var require_object = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/object.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var utf8 = require_utf8();
    var utils = require_utils();
    var GenericWorker = require_GenericWorker();
    var StreamHelper = require_StreamHelper();
    var defaults2 = require_defaults();
    var CompressedObject = require_compressedObject();
    var ZipObject = require_zipObject();
    var generate = require_generate();
    var nodejsUtils = require_nodejsUtils();
    var NodejsStreamInputAdapter = require_NodejsStreamInputAdapter();
    var fileAdd = function(name, data, originalOptions) {
      var dataType = utils.getTypeOf(data), parent;
      var o2 = utils.extend(originalOptions || {}, defaults2);
      o2.date = o2.date || /* @__PURE__ */ new Date();
      if (o2.compression !== null) {
        o2.compression = o2.compression.toUpperCase();
      }
      if (typeof o2.unixPermissions === "string") {
        o2.unixPermissions = parseInt(o2.unixPermissions, 8);
      }
      if (o2.unixPermissions && o2.unixPermissions & 16384) {
        o2.dir = true;
      }
      if (o2.dosPermissions && o2.dosPermissions & 16) {
        o2.dir = true;
      }
      if (o2.dir) {
        name = forceTrailingSlash(name);
      }
      if (o2.createFolders && (parent = parentFolder(name))) {
        folderAdd.call(this, parent, true);
      }
      var isUnicodeString = dataType === "string" && o2.binary === false && o2.base64 === false;
      if (!originalOptions || typeof originalOptions.binary === "undefined") {
        o2.binary = !isUnicodeString;
      }
      var isCompressedEmpty = data instanceof CompressedObject && data.uncompressedSize === 0;
      if (isCompressedEmpty || o2.dir || !data || data.length === 0) {
        o2.base64 = false;
        o2.binary = true;
        data = "";
        o2.compression = "STORE";
        dataType = "string";
      }
      var zipObjectContent = null;
      if (data instanceof CompressedObject || data instanceof GenericWorker) {
        zipObjectContent = data;
      } else if (nodejsUtils.isNode && nodejsUtils.isStream(data)) {
        zipObjectContent = new NodejsStreamInputAdapter(name, data);
      } else {
        zipObjectContent = utils.prepareContent(name, data, o2.binary, o2.optimizedBinaryString, o2.base64);
      }
      var object = new ZipObject(name, zipObjectContent, o2);
      this.files[name] = object;
    };
    var parentFolder = function(path) {
      if (path.slice(-1) === "/") {
        path = path.substring(0, path.length - 1);
      }
      var lastSlash = path.lastIndexOf("/");
      return lastSlash > 0 ? path.substring(0, lastSlash) : "";
    };
    var forceTrailingSlash = function(path) {
      if (path.slice(-1) !== "/") {
        path += "/";
      }
      return path;
    };
    var folderAdd = function(name, createFolders) {
      createFolders = typeof createFolders !== "undefined" ? createFolders : defaults2.createFolders;
      name = forceTrailingSlash(name);
      if (!this.files[name]) {
        fileAdd.call(this, name, null, {
          dir: true,
          createFolders
        });
      }
      return this.files[name];
    };
    function isRegExp(object) {
      return Object.prototype.toString.call(object) === "[object RegExp]";
    }
    var out = {
      /**
       * @see loadAsync
       */
      load: function() {
        throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.");
      },
      /**
       * Call a callback function for each entry at this folder level.
       * @param {Function} cb the callback function:
       * function (relativePath, file) {...}
       * It takes 2 arguments : the relative path and the file.
       */
      forEach: function(cb) {
        var filename, relativePath, file;
        for (filename in this.files) {
          file = this.files[filename];
          relativePath = filename.slice(this.root.length, filename.length);
          if (relativePath && filename.slice(0, this.root.length) === this.root) {
            cb(relativePath, file);
          }
        }
      },
      /**
       * Filter nested files/folders with the specified function.
       * @param {Function} search the predicate to use :
       * function (relativePath, file) {...}
       * It takes 2 arguments : the relative path and the file.
       * @return {Array} An array of matching elements.
       */
      filter: function(search) {
        var result = [];
        this.forEach(function(relativePath, entry) {
          if (search(relativePath, entry)) {
            result.push(entry);
          }
        });
        return result;
      },
      /**
       * Add a file to the zip file, or search a file.
       * @param   {string|RegExp} name The name of the file to add (if data is defined),
       * the name of the file to find (if no data) or a regex to match files.
       * @param   {String|ArrayBuffer|Uint8Array|Buffer} data  The file data, either raw or base64 encoded
       * @param   {Object} o     File options
       * @return  {JSZip|Object|Array} this JSZip object (when adding a file),
       * a file (when searching by string) or an array of files (when searching by regex).
       */
      file: function(name, data, o2) {
        if (arguments.length === 1) {
          if (isRegExp(name)) {
            var regexp = name;
            return this.filter(function(relativePath, file) {
              return !file.dir && regexp.test(relativePath);
            });
          } else {
            var obj = this.files[this.root + name];
            if (obj && !obj.dir) {
              return obj;
            } else {
              return null;
            }
          }
        } else {
          name = this.root + name;
          fileAdd.call(this, name, data, o2);
        }
        return this;
      },
      /**
       * Add a directory to the zip file, or search.
       * @param   {String|RegExp} arg The name of the directory to add, or a regex to search folders.
       * @return  {JSZip} an object with the new directory as the root, or an array containing matching folders.
       */
      folder: function(arg) {
        if (!arg) {
          return this;
        }
        if (isRegExp(arg)) {
          return this.filter(function(relativePath, file) {
            return file.dir && arg.test(relativePath);
          });
        }
        var name = this.root + arg;
        var newFolder = folderAdd.call(this, name);
        var ret = this.clone();
        ret.root = newFolder.name;
        return ret;
      },
      /**
       * Delete a file, or a directory and all sub-files, from the zip
       * @param {string} name the name of the file to delete
       * @return {JSZip} this JSZip object
       */
      remove: function(name) {
        name = this.root + name;
        var file = this.files[name];
        if (!file) {
          if (name.slice(-1) !== "/") {
            name += "/";
          }
          file = this.files[name];
        }
        if (file && !file.dir) {
          delete this.files[name];
        } else {
          var kids = this.filter(function(relativePath, file2) {
            return file2.name.slice(0, name.length) === name;
          });
          for (var i2 = 0; i2 < kids.length; i2++) {
            delete this.files[kids[i2].name];
          }
        }
        return this;
      },
      /**
       * @deprecated This method has been removed in JSZip 3.0, please check the upgrade guide.
       */
      generate: function() {
        throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.");
      },
      /**
       * Generate the complete zip file as an internal stream.
       * @param {Object} options the options to generate the zip file :
       * - compression, "STORE" by default.
       * - type, "base64" by default. Values are : string, base64, uint8array, arraybuffer, blob.
       * @return {StreamHelper} the streamed zip file.
       */
      generateInternalStream: function(options) {
        var worker, opts = {};
        try {
          opts = utils.extend(options || {}, {
            streamFiles: false,
            compression: "STORE",
            compressionOptions: null,
            type: "",
            platform: "DOS",
            comment: null,
            mimeType: "application/zip",
            encodeFileName: utf8.utf8encode
          });
          opts.type = opts.type.toLowerCase();
          opts.compression = opts.compression.toUpperCase();
          if (opts.type === "binarystring") {
            opts.type = "string";
          }
          if (!opts.type) {
            throw new Error("No output type specified.");
          }
          utils.checkSupport(opts.type);
          if (opts.platform === "darwin" || opts.platform === "freebsd" || opts.platform === "linux" || opts.platform === "sunos") {
            opts.platform = "UNIX";
          }
          if (opts.platform === "win32") {
            opts.platform = "DOS";
          }
          var comment = opts.comment || this.comment || "";
          worker = generate.generateWorker(this, opts, comment);
        } catch (e2) {
          worker = new GenericWorker("error");
          worker.error(e2);
        }
        return new StreamHelper(worker, opts.type || "string", opts.mimeType);
      },
      /**
       * Generate the complete zip file asynchronously.
       * @see generateInternalStream
       */
      generateAsync: function(options, onUpdate) {
        return this.generateInternalStream(options).accumulate(onUpdate);
      },
      /**
       * Generate the complete zip file asynchronously.
       * @see generateInternalStream
       */
      generateNodeStream: function(options, onUpdate) {
        options = options || {};
        if (!options.type) {
          options.type = "nodebuffer";
        }
        return this.generateInternalStream(options).toNodejsStream(onUpdate);
      }
    };
    module.exports = out;
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/reader/DataReader.js
var require_DataReader = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/reader/DataReader.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var utils = require_utils();
    function DataReader(data) {
      this.data = data;
      this.length = data.length;
      this.index = 0;
      this.zero = 0;
    }
    DataReader.prototype = {
      /**
       * Check that the offset will not go too far.
       * @param {string} offset the additional offset to check.
       * @throws {Error} an Error if the offset is out of bounds.
       */
      checkOffset: function(offset) {
        this.checkIndex(this.index + offset);
      },
      /**
       * Check that the specified index will not be too far.
       * @param {string} newIndex the index to check.
       * @throws {Error} an Error if the index is out of bounds.
       */
      checkIndex: function(newIndex) {
        if (this.length < this.zero + newIndex || newIndex < 0) {
          throw new Error("End of data reached (data length = " + this.length + ", asked index = " + newIndex + "). Corrupted zip ?");
        }
      },
      /**
       * Change the index.
       * @param {number} newIndex The new index.
       * @throws {Error} if the new index is out of the data.
       */
      setIndex: function(newIndex) {
        this.checkIndex(newIndex);
        this.index = newIndex;
      },
      /**
       * Skip the next n bytes.
       * @param {number} n the number of bytes to skip.
       * @throws {Error} if the new index is out of the data.
       */
      skip: function(n2) {
        this.setIndex(this.index + n2);
      },
      /**
       * Get the byte at the specified index.
       * @param {number} i the index to use.
       * @return {number} a byte.
       */
      byteAt: function() {
      },
      /**
       * Get the next number with a given byte size.
       * @param {number} size the number of bytes to read.
       * @return {number} the corresponding number.
       */
      readInt: function(size) {
        var result = 0, i2;
        this.checkOffset(size);
        for (i2 = this.index + size - 1; i2 >= this.index; i2--) {
          result = (result << 8) + this.byteAt(i2);
        }
        this.index += size;
        return result;
      },
      /**
       * Get the next string with a given byte size.
       * @param {number} size the number of bytes to read.
       * @return {string} the corresponding string.
       */
      readString: function(size) {
        return utils.transformTo("string", this.readData(size));
      },
      /**
       * Get raw data without conversion, <size> bytes.
       * @param {number} size the number of bytes to read.
       * @return {Object} the raw data, implementation specific.
       */
      readData: function() {
      },
      /**
       * Find the last occurrence of a zip signature (4 bytes).
       * @param {string} sig the signature to find.
       * @return {number} the index of the last occurrence, -1 if not found.
       */
      lastIndexOfSignature: function() {
      },
      /**
       * Read the signature (4 bytes) at the current position and compare it with sig.
       * @param {string} sig the expected signature
       * @return {boolean} true if the signature matches, false otherwise.
       */
      readAndCheckSignature: function() {
      },
      /**
       * Get the next date.
       * @return {Date} the date.
       */
      readDate: function() {
        var dostime = this.readInt(4);
        return new Date(Date.UTC(
          (dostime >> 25 & 127) + 1980,
          // year
          (dostime >> 21 & 15) - 1,
          // month
          dostime >> 16 & 31,
          // day
          dostime >> 11 & 31,
          // hour
          dostime >> 5 & 63,
          // minute
          (dostime & 31) << 1
        ));
      }
    };
    module.exports = DataReader;
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/reader/ArrayReader.js
var require_ArrayReader = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/reader/ArrayReader.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var DataReader = require_DataReader();
    var utils = require_utils();
    function ArrayReader(data) {
      DataReader.call(this, data);
      for (var i2 = 0; i2 < this.data.length; i2++) {
        data[i2] = data[i2] & 255;
      }
    }
    utils.inherits(ArrayReader, DataReader);
    ArrayReader.prototype.byteAt = function(i2) {
      return this.data[this.zero + i2];
    };
    ArrayReader.prototype.lastIndexOfSignature = function(sig) {
      var sig0 = sig.charCodeAt(0), sig1 = sig.charCodeAt(1), sig2 = sig.charCodeAt(2), sig3 = sig.charCodeAt(3);
      for (var i2 = this.length - 4; i2 >= 0; --i2) {
        if (this.data[i2] === sig0 && this.data[i2 + 1] === sig1 && this.data[i2 + 2] === sig2 && this.data[i2 + 3] === sig3) {
          return i2 - this.zero;
        }
      }
      return -1;
    };
    ArrayReader.prototype.readAndCheckSignature = function(sig) {
      var sig0 = sig.charCodeAt(0), sig1 = sig.charCodeAt(1), sig2 = sig.charCodeAt(2), sig3 = sig.charCodeAt(3), data = this.readData(4);
      return sig0 === data[0] && sig1 === data[1] && sig2 === data[2] && sig3 === data[3];
    };
    ArrayReader.prototype.readData = function(size) {
      this.checkOffset(size);
      if (size === 0) {
        return [];
      }
      var result = this.data.slice(this.zero + this.index, this.zero + this.index + size);
      this.index += size;
      return result;
    };
    module.exports = ArrayReader;
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/reader/StringReader.js
var require_StringReader = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/reader/StringReader.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var DataReader = require_DataReader();
    var utils = require_utils();
    function StringReader(data) {
      DataReader.call(this, data);
    }
    utils.inherits(StringReader, DataReader);
    StringReader.prototype.byteAt = function(i2) {
      return this.data.charCodeAt(this.zero + i2);
    };
    StringReader.prototype.lastIndexOfSignature = function(sig) {
      return this.data.lastIndexOf(sig) - this.zero;
    };
    StringReader.prototype.readAndCheckSignature = function(sig) {
      var data = this.readData(4);
      return sig === data;
    };
    StringReader.prototype.readData = function(size) {
      this.checkOffset(size);
      var result = this.data.slice(this.zero + this.index, this.zero + this.index + size);
      this.index += size;
      return result;
    };
    module.exports = StringReader;
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/reader/Uint8ArrayReader.js
var require_Uint8ArrayReader = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/reader/Uint8ArrayReader.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var ArrayReader = require_ArrayReader();
    var utils = require_utils();
    function Uint8ArrayReader(data) {
      ArrayReader.call(this, data);
    }
    utils.inherits(Uint8ArrayReader, ArrayReader);
    Uint8ArrayReader.prototype.readData = function(size) {
      this.checkOffset(size);
      if (size === 0) {
        return new Uint8Array(0);
      }
      var result = this.data.subarray(this.zero + this.index, this.zero + this.index + size);
      this.index += size;
      return result;
    };
    module.exports = Uint8ArrayReader;
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/reader/NodeBufferReader.js
var require_NodeBufferReader = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/reader/NodeBufferReader.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var Uint8ArrayReader = require_Uint8ArrayReader();
    var utils = require_utils();
    function NodeBufferReader(data) {
      Uint8ArrayReader.call(this, data);
    }
    utils.inherits(NodeBufferReader, Uint8ArrayReader);
    NodeBufferReader.prototype.readData = function(size) {
      this.checkOffset(size);
      var result = this.data.slice(this.zero + this.index, this.zero + this.index + size);
      this.index += size;
      return result;
    };
    module.exports = NodeBufferReader;
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/reader/readerFor.js
var require_readerFor = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/reader/readerFor.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var utils = require_utils();
    var support = require_support();
    var ArrayReader = require_ArrayReader();
    var StringReader = require_StringReader();
    var NodeBufferReader = require_NodeBufferReader();
    var Uint8ArrayReader = require_Uint8ArrayReader();
    module.exports = function(data) {
      var type = utils.getTypeOf(data);
      utils.checkSupport(type);
      if (type === "string" && !support.uint8array) {
        return new StringReader(data);
      }
      if (type === "nodebuffer") {
        return new NodeBufferReader(data);
      }
      if (support.uint8array) {
        return new Uint8ArrayReader(utils.transformTo("uint8array", data));
      }
      return new ArrayReader(utils.transformTo("array", data));
    };
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/zipEntry.js
var require_zipEntry = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/zipEntry.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var readerFor = require_readerFor();
    var utils = require_utils();
    var CompressedObject = require_compressedObject();
    var crc32fn = require_crc32();
    var utf8 = require_utf8();
    var compressions = require_compressions();
    var support = require_support();
    var MADE_BY_DOS = 0;
    var MADE_BY_UNIX = 3;
    var findCompression = function(compressionMethod) {
      for (var method in compressions) {
        if (!Object.prototype.hasOwnProperty.call(compressions, method)) {
          continue;
        }
        if (compressions[method].magic === compressionMethod) {
          return compressions[method];
        }
      }
      return null;
    };
    function ZipEntry(options, loadOptions) {
      this.options = options;
      this.loadOptions = loadOptions;
    }
    ZipEntry.prototype = {
      /**
       * say if the file is encrypted.
       * @return {boolean} true if the file is encrypted, false otherwise.
       */
      isEncrypted: function() {
        return (this.bitFlag & 1) === 1;
      },
      /**
       * say if the file has utf-8 filename/comment.
       * @return {boolean} true if the filename/comment is in utf-8, false otherwise.
       */
      useUTF8: function() {
        return (this.bitFlag & 2048) === 2048;
      },
      /**
       * Read the local part of a zip file and add the info in this object.
       * @param {DataReader} reader the reader to use.
       */
      readLocalPart: function(reader) {
        var compression, localExtraFieldsLength;
        reader.skip(22);
        this.fileNameLength = reader.readInt(2);
        localExtraFieldsLength = reader.readInt(2);
        this.fileName = reader.readData(this.fileNameLength);
        reader.skip(localExtraFieldsLength);
        if (this.compressedSize === -1 || this.uncompressedSize === -1) {
          throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");
        }
        compression = findCompression(this.compressionMethod);
        if (compression === null) {
          throw new Error("Corrupted zip : compression " + utils.pretty(this.compressionMethod) + " unknown (inner file : " + utils.transformTo("string", this.fileName) + ")");
        }
        this.decompressed = new CompressedObject(this.compressedSize, this.uncompressedSize, this.crc32, compression, reader.readData(this.compressedSize));
      },
      /**
       * Read the central part of a zip file and add the info in this object.
       * @param {DataReader} reader the reader to use.
       */
      readCentralPart: function(reader) {
        this.versionMadeBy = reader.readInt(2);
        reader.skip(2);
        this.bitFlag = reader.readInt(2);
        this.compressionMethod = reader.readString(2);
        this.date = reader.readDate();
        this.crc32 = reader.readInt(4);
        this.compressedSize = reader.readInt(4);
        this.uncompressedSize = reader.readInt(4);
        var fileNameLength = reader.readInt(2);
        this.extraFieldsLength = reader.readInt(2);
        this.fileCommentLength = reader.readInt(2);
        this.diskNumberStart = reader.readInt(2);
        this.internalFileAttributes = reader.readInt(2);
        this.externalFileAttributes = reader.readInt(4);
        this.localHeaderOffset = reader.readInt(4);
        if (this.isEncrypted()) {
          throw new Error("Encrypted zip are not supported");
        }
        reader.skip(fileNameLength);
        this.readExtraFields(reader);
        this.parseZIP64ExtraField(reader);
        this.fileComment = reader.readData(this.fileCommentLength);
      },
      /**
       * Parse the external file attributes and get the unix/dos permissions.
       */
      processAttributes: function() {
        this.unixPermissions = null;
        this.dosPermissions = null;
        var madeBy = this.versionMadeBy >> 8;
        this.dir = this.externalFileAttributes & 16 ? true : false;
        if (madeBy === MADE_BY_DOS) {
          this.dosPermissions = this.externalFileAttributes & 63;
        }
        if (madeBy === MADE_BY_UNIX) {
          this.unixPermissions = this.externalFileAttributes >> 16 & 65535;
        }
        if (!this.dir && this.fileNameStr.slice(-1) === "/") {
          this.dir = true;
        }
      },
      /**
       * Parse the ZIP64 extra field and merge the info in the current ZipEntry.
       * @param {DataReader} reader the reader to use.
       */
      parseZIP64ExtraField: function() {
        if (!this.extraFields[1]) {
          return;
        }
        var extraReader = readerFor(this.extraFields[1].value);
        if (this.uncompressedSize === utils.MAX_VALUE_32BITS) {
          this.uncompressedSize = extraReader.readInt(8);
        }
        if (this.compressedSize === utils.MAX_VALUE_32BITS) {
          this.compressedSize = extraReader.readInt(8);
        }
        if (this.localHeaderOffset === utils.MAX_VALUE_32BITS) {
          this.localHeaderOffset = extraReader.readInt(8);
        }
        if (this.diskNumberStart === utils.MAX_VALUE_32BITS) {
          this.diskNumberStart = extraReader.readInt(4);
        }
      },
      /**
       * Read the central part of a zip file and add the info in this object.
       * @param {DataReader} reader the reader to use.
       */
      readExtraFields: function(reader) {
        var end = reader.index + this.extraFieldsLength, extraFieldId, extraFieldLength, extraFieldValue;
        if (!this.extraFields) {
          this.extraFields = {};
        }
        while (reader.index + 4 < end) {
          extraFieldId = reader.readInt(2);
          extraFieldLength = reader.readInt(2);
          extraFieldValue = reader.readData(extraFieldLength);
          this.extraFields[extraFieldId] = {
            id: extraFieldId,
            length: extraFieldLength,
            value: extraFieldValue
          };
        }
        reader.setIndex(end);
      },
      /**
       * Apply an UTF8 transformation if needed.
       */
      handleUTF8: function() {
        var decodeParamType = support.uint8array ? "uint8array" : "array";
        if (this.useUTF8()) {
          this.fileNameStr = utf8.utf8decode(this.fileName);
          this.fileCommentStr = utf8.utf8decode(this.fileComment);
        } else {
          var upath = this.findExtraFieldUnicodePath();
          if (upath !== null) {
            this.fileNameStr = upath;
          } else {
            var fileNameByteArray = utils.transformTo(decodeParamType, this.fileName);
            this.fileNameStr = this.loadOptions.decodeFileName(fileNameByteArray);
          }
          var ucomment = this.findExtraFieldUnicodeComment();
          if (ucomment !== null) {
            this.fileCommentStr = ucomment;
          } else {
            var commentByteArray = utils.transformTo(decodeParamType, this.fileComment);
            this.fileCommentStr = this.loadOptions.decodeFileName(commentByteArray);
          }
        }
      },
      /**
       * Find the unicode path declared in the extra field, if any.
       * @return {String} the unicode path, null otherwise.
       */
      findExtraFieldUnicodePath: function() {
        var upathField = this.extraFields[28789];
        if (upathField) {
          var extraReader = readerFor(upathField.value);
          if (extraReader.readInt(1) !== 1) {
            return null;
          }
          if (crc32fn(this.fileName) !== extraReader.readInt(4)) {
            return null;
          }
          return utf8.utf8decode(extraReader.readData(upathField.length - 5));
        }
        return null;
      },
      /**
       * Find the unicode comment declared in the extra field, if any.
       * @return {String} the unicode comment, null otherwise.
       */
      findExtraFieldUnicodeComment: function() {
        var ucommentField = this.extraFields[25461];
        if (ucommentField) {
          var extraReader = readerFor(ucommentField.value);
          if (extraReader.readInt(1) !== 1) {
            return null;
          }
          if (crc32fn(this.fileComment) !== extraReader.readInt(4)) {
            return null;
          }
          return utf8.utf8decode(extraReader.readData(ucommentField.length - 5));
        }
        return null;
      }
    };
    module.exports = ZipEntry;
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/zipEntries.js
var require_zipEntries = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/zipEntries.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var readerFor = require_readerFor();
    var utils = require_utils();
    var sig = require_signature();
    var ZipEntry = require_zipEntry();
    var support = require_support();
    function ZipEntries(loadOptions) {
      this.files = [];
      this.loadOptions = loadOptions;
    }
    ZipEntries.prototype = {
      /**
       * Check that the reader is on the specified signature.
       * @param {string} expectedSignature the expected signature.
       * @throws {Error} if it is an other signature.
       */
      checkSignature: function(expectedSignature) {
        if (!this.reader.readAndCheckSignature(expectedSignature)) {
          this.reader.index -= 4;
          var signature = this.reader.readString(4);
          throw new Error("Corrupted zip or bug: unexpected signature (" + utils.pretty(signature) + ", expected " + utils.pretty(expectedSignature) + ")");
        }
      },
      /**
       * Check if the given signature is at the given index.
       * @param {number} askedIndex the index to check.
       * @param {string} expectedSignature the signature to expect.
       * @return {boolean} true if the signature is here, false otherwise.
       */
      isSignature: function(askedIndex, expectedSignature) {
        var currentIndex = this.reader.index;
        this.reader.setIndex(askedIndex);
        var signature = this.reader.readString(4);
        var result = signature === expectedSignature;
        this.reader.setIndex(currentIndex);
        return result;
      },
      /**
       * Read the end of the central directory.
       */
      readBlockEndOfCentral: function() {
        this.diskNumber = this.reader.readInt(2);
        this.diskWithCentralDirStart = this.reader.readInt(2);
        this.centralDirRecordsOnThisDisk = this.reader.readInt(2);
        this.centralDirRecords = this.reader.readInt(2);
        this.centralDirSize = this.reader.readInt(4);
        this.centralDirOffset = this.reader.readInt(4);
        this.zipCommentLength = this.reader.readInt(2);
        var zipComment = this.reader.readData(this.zipCommentLength);
        var decodeParamType = support.uint8array ? "uint8array" : "array";
        var decodeContent = utils.transformTo(decodeParamType, zipComment);
        this.zipComment = this.loadOptions.decodeFileName(decodeContent);
      },
      /**
       * Read the end of the Zip 64 central directory.
       * Not merged with the method readEndOfCentral :
       * The end of central can coexist with its Zip64 brother,
       * I don't want to read the wrong number of bytes !
       */
      readBlockZip64EndOfCentral: function() {
        this.zip64EndOfCentralSize = this.reader.readInt(8);
        this.reader.skip(4);
        this.diskNumber = this.reader.readInt(4);
        this.diskWithCentralDirStart = this.reader.readInt(4);
        this.centralDirRecordsOnThisDisk = this.reader.readInt(8);
        this.centralDirRecords = this.reader.readInt(8);
        this.centralDirSize = this.reader.readInt(8);
        this.centralDirOffset = this.reader.readInt(8);
        this.zip64ExtensibleData = {};
        var extraDataSize = this.zip64EndOfCentralSize - 44, index = 0, extraFieldId, extraFieldLength, extraFieldValue;
        while (index < extraDataSize) {
          extraFieldId = this.reader.readInt(2);
          extraFieldLength = this.reader.readInt(4);
          extraFieldValue = this.reader.readData(extraFieldLength);
          this.zip64ExtensibleData[extraFieldId] = {
            id: extraFieldId,
            length: extraFieldLength,
            value: extraFieldValue
          };
        }
      },
      /**
       * Read the end of the Zip 64 central directory locator.
       */
      readBlockZip64EndOfCentralLocator: function() {
        this.diskWithZip64CentralDirStart = this.reader.readInt(4);
        this.relativeOffsetEndOfZip64CentralDir = this.reader.readInt(8);
        this.disksCount = this.reader.readInt(4);
        if (this.disksCount > 1) {
          throw new Error("Multi-volumes zip are not supported");
        }
      },
      /**
       * Read the local files, based on the offset read in the central part.
       */
      readLocalFiles: function() {
        var i2, file;
        for (i2 = 0; i2 < this.files.length; i2++) {
          file = this.files[i2];
          this.reader.setIndex(file.localHeaderOffset);
          this.checkSignature(sig.LOCAL_FILE_HEADER);
          file.readLocalPart(this.reader);
          file.handleUTF8();
          file.processAttributes();
        }
      },
      /**
       * Read the central directory.
       */
      readCentralDir: function() {
        var file;
        this.reader.setIndex(this.centralDirOffset);
        while (this.reader.readAndCheckSignature(sig.CENTRAL_FILE_HEADER)) {
          file = new ZipEntry({
            zip64: this.zip64
          }, this.loadOptions);
          file.readCentralPart(this.reader);
          this.files.push(file);
        }
        if (this.centralDirRecords !== this.files.length) {
          if (this.centralDirRecords !== 0 && this.files.length === 0) {
            throw new Error("Corrupted zip or bug: expected " + this.centralDirRecords + " records in central dir, got " + this.files.length);
          } else {
          }
        }
      },
      /**
       * Read the end of central directory.
       */
      readEndOfCentral: function() {
        var offset = this.reader.lastIndexOfSignature(sig.CENTRAL_DIRECTORY_END);
        if (offset < 0) {
          var isGarbage = !this.isSignature(0, sig.LOCAL_FILE_HEADER);
          if (isGarbage) {
            throw new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");
          } else {
            throw new Error("Corrupted zip: can't find end of central directory");
          }
        }
        this.reader.setIndex(offset);
        var endOfCentralDirOffset = offset;
        this.checkSignature(sig.CENTRAL_DIRECTORY_END);
        this.readBlockEndOfCentral();
        if (this.diskNumber === utils.MAX_VALUE_16BITS || this.diskWithCentralDirStart === utils.MAX_VALUE_16BITS || this.centralDirRecordsOnThisDisk === utils.MAX_VALUE_16BITS || this.centralDirRecords === utils.MAX_VALUE_16BITS || this.centralDirSize === utils.MAX_VALUE_32BITS || this.centralDirOffset === utils.MAX_VALUE_32BITS) {
          this.zip64 = true;
          offset = this.reader.lastIndexOfSignature(sig.ZIP64_CENTRAL_DIRECTORY_LOCATOR);
          if (offset < 0) {
            throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");
          }
          this.reader.setIndex(offset);
          this.checkSignature(sig.ZIP64_CENTRAL_DIRECTORY_LOCATOR);
          this.readBlockZip64EndOfCentralLocator();
          if (!this.isSignature(this.relativeOffsetEndOfZip64CentralDir, sig.ZIP64_CENTRAL_DIRECTORY_END)) {
            this.relativeOffsetEndOfZip64CentralDir = this.reader.lastIndexOfSignature(sig.ZIP64_CENTRAL_DIRECTORY_END);
            if (this.relativeOffsetEndOfZip64CentralDir < 0) {
              throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");
            }
          }
          this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir);
          this.checkSignature(sig.ZIP64_CENTRAL_DIRECTORY_END);
          this.readBlockZip64EndOfCentral();
        }
        var expectedEndOfCentralDirOffset = this.centralDirOffset + this.centralDirSize;
        if (this.zip64) {
          expectedEndOfCentralDirOffset += 20;
          expectedEndOfCentralDirOffset += 12 + this.zip64EndOfCentralSize;
        }
        var extraBytes = endOfCentralDirOffset - expectedEndOfCentralDirOffset;
        if (extraBytes > 0) {
          if (this.isSignature(endOfCentralDirOffset, sig.CENTRAL_FILE_HEADER)) {
          } else {
            this.reader.zero = extraBytes;
          }
        } else if (extraBytes < 0) {
          throw new Error("Corrupted zip: missing " + Math.abs(extraBytes) + " bytes.");
        }
      },
      prepareReader: function(data) {
        this.reader = readerFor(data);
      },
      /**
       * Read a zip file and create ZipEntries.
       * @param {String|ArrayBuffer|Uint8Array|Buffer} data the binary string representing a zip file.
       */
      load: function(data) {
        this.prepareReader(data);
        this.readEndOfCentral();
        this.readCentralDir();
        this.readLocalFiles();
      }
    };
    module.exports = ZipEntries;
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/load.js
var require_load = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/load.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    var utils = require_utils();
    var external = require_external();
    var utf8 = require_utf8();
    var ZipEntries = require_zipEntries();
    var Crc32Probe = require_Crc32Probe();
    var nodejsUtils = require_nodejsUtils();
    function checkEntryCRC32(zipEntry) {
      return new external.Promise(function(resolve, reject) {
        var worker = zipEntry.decompressed.getContentWorker().pipe(new Crc32Probe());
        worker.on("error", function(e2) {
          reject(e2);
        }).on("end", function() {
          if (worker.streamInfo.crc32 !== zipEntry.decompressed.crc32) {
            reject(new Error("Corrupted zip : CRC32 mismatch"));
          } else {
            resolve();
          }
        }).resume();
      });
    }
    module.exports = function(data, options) {
      var zip = this;
      options = utils.extend(options || {}, {
        base64: false,
        checkCRC32: false,
        optimizedBinaryString: false,
        createFolders: false,
        decodeFileName: utf8.utf8decode
      });
      if (nodejsUtils.isNode && nodejsUtils.isStream(data)) {
        return external.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file."));
      }
      return utils.prepareContent("the loaded zip file", data, true, options.optimizedBinaryString, options.base64).then(function(data2) {
        var zipEntries = new ZipEntries(options);
        zipEntries.load(data2);
        return zipEntries;
      }).then(function checkCRC32(zipEntries) {
        var promises = [external.Promise.resolve(zipEntries)];
        var files = zipEntries.files;
        if (options.checkCRC32) {
          for (var i2 = 0; i2 < files.length; i2++) {
            promises.push(checkEntryCRC32(files[i2]));
          }
        }
        return external.Promise.all(promises);
      }).then(function addFiles(results) {
        var zipEntries = results.shift();
        var files = zipEntries.files;
        for (var i2 = 0; i2 < files.length; i2++) {
          var input = files[i2];
          var unsafeName = input.fileNameStr;
          var safeName = utils.resolve(input.fileNameStr);
          zip.file(safeName, input.decompressed, {
            binary: true,
            optimizedBinaryString: true,
            date: input.date,
            dir: input.dir,
            comment: input.fileCommentStr.length ? input.fileCommentStr : null,
            unixPermissions: input.unixPermissions,
            dosPermissions: input.dosPermissions,
            createFolders: options.createFolders
          });
          if (!input.dir) {
            zip.file(safeName).unsafeOriginalName = unsafeName;
          }
        }
        if (zipEntries.zipComment.length) {
          zip.comment = zipEntries.zipComment;
        }
        return zip;
      });
    };
  }
});

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/index.js
var require_lib3 = __commonJS({
  "../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/jszip/lib/index.js"(exports, module) {
    "use strict";
    init_define_COCO_TOOL_CONFIG();
    function JSZip3() {
      if (!(this instanceof JSZip3)) {
        return new JSZip3();
      }
      if (arguments.length) {
        throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");
      }
      this.files = /* @__PURE__ */ Object.create(null);
      this.comment = null;
      this.root = "";
      this.clone = function() {
        var newObj = new JSZip3();
        for (var i2 in this) {
          if (typeof this[i2] !== "function") {
            newObj[i2] = this[i2];
          }
        }
        return newObj;
      };
    }
    JSZip3.prototype = require_object();
    JSZip3.prototype.loadAsync = require_load();
    JSZip3.support = require_support();
    JSZip3.defaults = require_defaults();
    JSZip3.version = "3.10.2";
    JSZip3.loadAsync = function(content, options) {
      return new JSZip3().loadAsync(content, options);
    };
    JSZip3.external = require_external();
    module.exports = JSZip3;
  }
});

// coco-dsh/packages/workbuddy/local-skills/src/copybook.mjs
init_define_COCO_TOOL_CONFIG();

// coco-engine/packages/application-tools/src/runners/excel-script.ts
init_define_COCO_TOOL_CONFIG();

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/@coco-vexel/coco-office/dist/excel.js
init_define_COCO_TOOL_CONFIG();
var import_jszip = __toESM(require_lib3(), 1);

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/slimdom/dist/slimdom.esm.js
init_define_COCO_TOOL_CONFIG();
var t = class {
  constructor(t2, n2, e2, r2) {
    this.source = null, this.observer = t2, this.node = n2, this.options = e2, this.source = r2 || null, r2 && t2.t.push(this);
  }
  collectInterestedObservers(t2, n2, e2, r2, o2) {
    if (this.node !== n2 && !this.options.subtree) return;
    if ("attributes" === t2 && !this.options.attributes) return;
    if ("characterData" === t2 && !this.options.characterData) return;
    if ("childList" === t2 && !this.options.childList) return;
    let i2 = r2.indexOf(this.observer);
    i2 < 0 && (i2 = r2.length, r2.push(this.observer), o2.push(void 0)), ("attributes" === t2 && this.options.attributeOldValue || "characterData" === t2 && this.options.characterDataOldValue) && (o2[i2] = e2.oldValue);
  }
};
var n = class {
  constructor(t2) {
    this.o = [], this.i = t2;
  }
  register(n2, e2) {
    const r2 = this.o;
    let o2 = false;
    r2.forEach(((t2) => {
      t2.observer === n2 && (o2 = true, (function(t3) {
        for (let n3 = t3.observer.t.length - 1; n3 >= 0; --n3) {
          const e3 = t3.observer.t[n3];
          if (e3.source !== t3) return;
          e3.node.o.removeTransientRegisteredObserver(e3), t3.observer.t.splice(n3, 1);
        }
      })(t2), t2.options = e2);
    })), o2 || (this.o.push(new t(n2, this.i, e2)), n2.u.push(this.i));
  }
  removeTransientRegisteredObserver(t2) {
    this.o.splice(this.o.indexOf(t2), 1);
  }
  removeForObserver(t2) {
    let n2 = 0;
    for (let e2 = 0, r2 = this.o.length; e2 < r2; ++e2) {
      const r3 = this.o[e2];
      r3.observer !== t2 && (e2 !== n2 && (this.o[n2] = r3), ++n2);
    }
    this.o.length = n2;
  }
  collectInterestedObservers(t2, n2, e2, r2, o2) {
    this.o.forEach(((i2) => {
      i2.collectInterestedObservers(t2, n2, e2, r2, o2);
    }));
  }
  appendTransientRegisteredObservers(t2) {
    this.o.forEach(((n2) => {
      n2.options.subtree && t2.o.registerTransient(n2);
    }));
  }
  registerTransient(n2) {
    this.o.push(new t(n2.observer, this.i, n2.options, n2));
  }
};
function e(t2, n2, ...e2) {
  "function" != typeof queueMicrotask ? Promise.resolve().then((() => t2.apply(n2, e2))) : queueMicrotask((() => t2.apply(n2, e2)));
}
var r = class {
  constructor() {
    this.l = /* @__PURE__ */ new Set(), this.h = false;
  }
  appendRecord(t2, n2) {
    t2.m.push(n2), this.l.add(t2);
  }
  queueMutationObserverMicrotask() {
    this.h || (this.h = true, e((() => {
      this.p();
    }), this));
  }
  p() {
    this.h = false;
    const t2 = Array.from(this.l);
    this.l.clear(), t2.forEach(((t3) => {
      e(((t4) => {
        const n2 = t4.takeRecords();
        var e2;
        (e2 = t4).t.forEach(((t5) => {
          t5.node.o.removeTransientRegisteredObserver(t5);
        })), e2.t.length = 0, n2.length > 0 && t4.g(n2, t4);
      }), this, t3);
    }));
  }
};
var o = class {
  constructor(t2) {
    this.v = t2;
  }
  deref() {
    return this.v;
  }
};
var i = new class {
  constructor() {
    this.l = new r(), this.N = [], this.S = /* @__PURE__ */ new WeakSet();
  }
  forEachRange(t2) {
    let n2 = this.N.length;
    for (let e2 = n2 - 1; e2 >= 0; --e2) {
      const r2 = this.N[e2].deref(), o2 = null == r2, i2 = !o2 && !this.S.has(r2);
      o2 || i2 ? (this.N[e2] = this.N[n2 - 1], this.N.pop(), n2 -= 1) : t2(r2);
    }
  }
  addRange(t2) {
    const n2 = (e2 = t2, "function" == typeof WeakRef ? new WeakRef(e2) : new o(e2));
    var e2;
    this.N.push(n2), this.S.add(t2);
  }
  removeRange(t2) {
    this.S.delete(t2);
  }
}();
function s(t2) {
  return i;
}
function u(t2, ...n2) {
  return n2.some(((n3) => t2.nodeType === n3));
}
function l(t2) {
  return 2 === t2.nodeType;
}
function c(t2) {
  return 3 === t2.nodeType || 4 === t2.nodeType || 8 === t2.nodeType || 7 === t2.nodeType;
}
function a(t2) {
  return 3 === t2.nodeType || 4 === t2.nodeType;
}
function h(t2) {
  return 1 === t2.nodeType;
}
function f(t2) {
  return 10 === t2.nodeType;
}
function d(t2) {
  switch (t2.nodeType) {
    case 3:
    case 7:
    case 8:
      return t2.data.length;
    default:
      return t2.childNodes.length;
  }
}
function m(t2) {
  let n2 = t2, e2 = [];
  for (; n2; ) e2.unshift(n2), n2 = n2.parentNode;
  return e2;
}
function p(t2) {
  return u(t2, 9) ? t2 : t2.ownerDocument;
}
function g(t2) {
  return t2.parentNode.childNodes.indexOf(t2);
}
function w(t2) {
  for (; t2.parentNode; ) t2 = t2.parentNode;
  return t2;
}
function y(t2, n2) {
  n2(t2);
  for (let e2 = t2.firstChild; e2; e2 = e2.nextSibling) y(e2, n2);
}
function v(t2, n2) {
  const e2 = [];
  return y(n2, ((r2) => {
    if (r2 === n2 || 1 !== r2.nodeType) return;
    const o2 = r2;
    "*" !== t2 && o2.nodeName !== t2 || e2.push(o2);
  })), e2;
}
function b(t2, n2, e2) {
  "" === t2 && (t2 = null);
  const r2 = [];
  return y(e2, ((o2) => {
    if (o2 === e2 || 1 !== o2.nodeType) return;
    const i2 = o2;
    "*" !== t2 && i2.namespaceURI !== t2 || "*" !== n2 && i2.localName !== n2 || r2.push(i2);
  })), r2;
}
function x(t2, n2, e2) {
  e2 || (e2 = p(t2));
  let r2 = t2.T(e2);
  if (n2) for (let n3 = t2.firstChild; n3; n3 = n3.nextSibling) r2.appendChild(x(n3, true, e2));
  return r2;
}
function N(t2, n2) {
  if (t2.length < n2) throw new TypeError(`Function should be called with at least ${n2} arguments`);
}
var S = { IndexSizeError: 1, HierarchyRequestError: 3, WrongDocumentError: 4, InvalidCharacterError: 5, NotFoundError: 8, NotSupportedError: 9, InUseAttributeError: 10, InvalidStateError: 11, NamespaceError: 14, InvalidNodeTypeError: 24 };
var E = class extends Error {
  constructor(t2 = "", n2 = "Error") {
    super(t2), this.message = t2, this.name = n2, this.code = S[n2] || 0, this.stack = new Error(t2).stack;
  }
};
function T(t2, n2) {
  return new E(`${t2}: ${n2}`, t2);
}
function C(t2) {
  throw T("HierarchyRequestError", t2);
}
function D(t2) {
  throw T("IndexSizeError", t2);
}
function $(t2) {
  throw T("InvalidCharacterError", t2);
}
function A(t2) {
  throw T("InvalidNodeTypeError", t2);
}
function I(t2) {
  throw T("InvalidStateError", t2);
}
function k(t2) {
  throw T("NamespaceError", t2);
}
function M(t2) {
  throw T("NotFoundError", t2);
}
function R(t2) {
  throw T("NotSupportedError", t2);
}
function P(t2) {
  throw T("WrongDocumentError", t2);
}
var L = class {
  constructor(t2, n2) {
    this.addedNodes = [], this.removedNodes = [], this.previousSibling = null, this.nextSibling = null, this.attributeName = null, this.attributeNamespace = null, this.oldValue = null, this.type = t2, this.target = n2;
  }
};
function z(t2, n2, e2) {
  const r2 = [], o2 = [];
  for (let i3 = n2; i3; i3 = i3.parentNode) i3.o.collectInterestedObservers(t2, n2, e2, r2, o2);
  const i2 = s();
  r2.forEach(((r3, s2) => {
    const u2 = o2[s2], l2 = new L(t2, n2);
    void 0 !== e2.name && void 0 !== e2.namespace && (l2.attributeName = e2.name, l2.attributeNamespace = e2.namespace), void 0 !== u2 && (l2.oldValue = u2), void 0 !== e2.addedNodes && (l2.addedNodes = e2.addedNodes), void 0 !== e2.removedNodes && (l2.removedNodes = e2.removedNodes), void 0 !== e2.previousSibling && (l2.previousSibling = e2.previousSibling), void 0 !== e2.nextSibling && (l2.nextSibling = e2.nextSibling), i2.l.appendRecord(r3, l2);
  })), i2.l.queueMutationObserverMicrotask();
}
function O(t2) {
  const n2 = [];
  for (let e2 = t2.firstElementChild; e2; e2 = e2.nextElementSibling) n2.push(e2);
  return n2;
}
function V(t2) {
  for (let n2 = t2.previousSibling; n2; n2 = n2.previousSibling) if (h(n2)) return n2;
  return null;
}
function F(t2) {
  for (let n2 = t2.nextSibling; n2; n2 = n2.nextSibling) if (h(n2)) return n2;
  return null;
}
function U(t2, n2) {
  const e2 = t2.previousSibling, r2 = t2.nextSibling, o2 = u(t2, 1), i2 = o2 ? t2.previousElementSibling : null, s2 = o2 ? t2.nextElementSibling : null;
  if (t2.parentNode = null, t2.previousSibling = null, t2.nextSibling = null, e2 ? e2.nextSibling = r2 : n2.firstChild = r2, r2 ? r2.previousSibling = e2 : n2.lastChild = e2, n2.childNodes.splice(n2.childNodes.indexOf(t2), 1), o2) {
    const e3 = (function(t3) {
      return u(t3, 1, 9, 11) ? t3 : null;
    })(n2);
    e3 && (e3.firstElementChild === t2 && (e3.firstElementChild = s2), e3.lastElementChild === t2 && (e3.lastElementChild = i2), e3.childElementCount -= 1);
  }
  if (u(n2, 9)) {
    const e3 = n2;
    u(t2, 1) ? e3.documentElement = null : u(t2, 10) && (e3.doctype = null);
  }
}
function _(t2, n2, e2) {
  if (u(n2, 9, 11, 1) || C("parent must be a Document, DocumentFragment or Element node"), t2.contains(n2) && C("node must not be an inclusive ancestor of parent"), e2 && e2.parentNode !== n2 && M("child is not a child of parent"), u(t2, 11, 10, 1, 3, 4, 7, 8) || C("node must be a DocumentFragment, DocumentType, Element, Text, ProcessingInstruction or Comment node"), u(t2, 3) && u(n2, 9) && C("can not insert a Text node under a Document"), u(t2, 10) && !u(n2, 9) && C("can only insert a DocumentType node under a Document"), u(n2, 9)) {
    const r2 = n2;
    switch (t2.nodeType) {
      case 11:
        const n3 = t2;
        n3.firstElementChild !== n3.lastElementChild && C("can not insert more than one element under a Document"), Array.from(n3.childNodes).some(((t3) => u(t3, 3))) && C("can not insert a Text node under a Document"), n3.firstElementChild && (r2.documentElement || e2 && u(e2, 10) || e2 && r2.doctype && g(e2) < g(r2.doctype)) && C("Document should contain at most one doctype, followed by at most one element");
        break;
      case 1:
        (r2.documentElement || e2 && u(e2, 10) || e2 && r2.doctype && g(e2) < g(r2.doctype)) && C("Document should contain at most one doctype, followed by at most one element");
        break;
      case 10:
        (r2.doctype || e2 && r2.documentElement && g(r2.documentElement) < g(e2) || !e2 && r2.documentElement) && C("Document should contain at most one doctype, followed by at most one element");
    }
  }
}
function q(t2, n2, e2) {
  _(t2, n2, e2);
  let r2 = e2;
  return r2 === t2 && (r2 = t2.nextSibling), j(t2, p(n2)), B(t2, n2, r2), t2;
}
function B(t2, n2, e2, r2 = false) {
  const o2 = (function(t3) {
    return 11 === t3.nodeType;
  })(t2), i2 = o2 ? Array.from(t2.childNodes) : [t2], u2 = i2.length;
  if (0 === u2) return;
  if (o2 && (i2.forEach(((t3) => H(t3, true))), z("childList", t2, { removedNodes: i2 })), null !== e2) {
    const t3 = g(e2);
    s().forEachRange(((e3) => {
      e3.startContainer === n2 && e3.startOffset > t3 && (e3.startOffset += u2), e3.endContainer === n2 && e3.endOffset > t3 && (e3.endOffset += u2);
    }));
  }
  let l2 = null === e2 ? n2.lastChild : e2.previousSibling;
  i2.forEach(((t3) => {
    !(function(t4, n3, e3) {
      t4.parentNode = n3;
      const r3 = null === e3 ? n3.lastChild : e3.previousSibling, o3 = null === e3 ? null : e3;
      if (t4.previousSibling = r3, t4.nextSibling = o3, r3 ? r3.nextSibling = t4 : n3.firstChild = t4, o3 ? (o3.previousSibling = t4, n3.childNodes.splice(n3.childNodes.indexOf(o3), 0, t4)) : (n3.lastChild = t4, n3.childNodes.push(t4)), h(t4)) {
        const e4 = n3;
        let i3 = null;
        for (let t5 = r3; t5; t5 = t5.previousSibling) {
          if (h(t5)) {
            i3 = t5;
            break;
          }
          const n4 = t5;
          if (!f(n4)) {
            i3 = n4.previousElementSibling;
            break;
          }
        }
        let s2 = null;
        for (let t5 = o3; t5; t5 = t5.nextSibling) {
          if (h(t5)) {
            s2 = t5;
            break;
          }
          s2 = t5.nextElementSibling;
          break;
        }
        i3 || (e4.firstElementChild = t4), s2 || (e4.lastElementChild = t4), e4.childElementCount += 1;
      }
      (function(t5) {
        return 9 === t5.nodeType;
      })(n3) && (h(t4) ? n3.documentElement = t4 : f(t4) && (n3.doctype = t4));
    })(t3, n2, e2);
  })), r2 || z("childList", n2, { addedNodes: i2, nextSibling: e2, previousSibling: l2 });
}
function W(t2, n2) {
  return q(t2, n2, null);
}
function X(t2, n2, e2) {
  if (u(e2, 9, 11, 1) || C("Can not replace under a non-parent node"), n2.contains(e2) && C("Can not insert a node under its own descendant"), t2.parentNode !== e2 && M("child is not a child of parent"), u(n2, 11, 10, 1, 3, 4, 7, 8) || C("Can not insert a node that isn't a DocumentFragment, DocumentType, Element, Text, ProcessingInstruction or Comment"), u(n2, 3) && u(e2, 9) && C("can not insert a Text node under a Document"), u(n2, 10) && !u(e2, 9) && C("can only insert a DocumentType node under a Document"), u(e2, 9)) {
    const r3 = e2;
    switch (n2.nodeType) {
      case 11:
        const e3 = n2;
        e3.firstElementChild !== e3.lastElementChild && C("can not insert more than one element under a Document"), Array.from(e3.childNodes).some(((t3) => u(t3, 3))) && C("can not insert a Text node under a Document"), e3.firstElementChild && (r3.documentElement && r3.documentElement !== t2 || t2 && r3.doctype && g(t2) < g(r3.doctype)) && C("Document should contain at most one doctype, followed by at most one element");
        break;
      case 1:
        (r3.documentElement && r3.documentElement !== t2 || r3.doctype && g(t2) < g(r3.doctype)) && C("Document should contain at most one doctype, followed by at most one element");
        break;
      case 10:
        (r3.doctype && r3.doctype !== t2 || r3.documentElement && g(r3.documentElement) < g(t2)) && C("Document should contain at most one doctype, followed by at most one element");
    }
  }
  let r2 = t2.nextSibling;
  r2 === n2 && (r2 = n2.nextSibling);
  const o2 = t2.previousSibling;
  j(n2, p(e2));
  let i2 = [];
  null !== t2.parentNode && (i2.push(t2), H(t2, true));
  const s2 = u(n2, 11) ? Array.from(n2.childNodes) : [n2];
  return B(n2, e2, r2, true), z("childList", e2, { addedNodes: s2, removedNodes: i2, nextSibling: r2, previousSibling: o2 }), t2;
}
function Y(t2, n2) {
  null !== t2 && j(t2, p(n2));
  const e2 = Array.from(n2.childNodes);
  let r2 = [];
  null !== t2 && (u(t2, 11) ? t2.childNodes.forEach(((t3) => {
    r2.push(t3);
  })) : r2.push(t2)), e2.forEach(((t3) => {
    H(t3, true);
  })), null !== t2 && B(t2, n2, null, true), (r2.length > 0 || e2.length > 0) && z("childList", n2, { addedNodes: r2, removedNodes: e2 });
}
function H(t2, n2 = false) {
  const e2 = t2.parentNode, r2 = g(t2);
  s().forEachRange(((n3) => {
    t2.contains(n3.startContainer) && (n3.startContainer = e2, n3.startOffset = r2), t2.contains(n3.endContainer) && (n3.endContainer = e2, n3.endOffset = r2), n3.startContainer === e2 && n3.startOffset > r2 && (n3.startOffset -= 1), n3.endContainer === e2 && n3.endOffset > r2 && (n3.endOffset -= 1);
  }));
  const o2 = t2.previousSibling, i2 = t2.nextSibling;
  U(t2, e2);
  for (let n3 = e2; n3; n3 = n3.parentNode) n3.o.appendTransientRegisteredObservers(t2);
  n2 || z("childList", e2, { removedNodes: [t2], nextSibling: i2, previousSibling: o2 });
}
function j(t2, n2) {
  const e2 = p(t2);
  t2.parentNode && H(t2), n2 !== e2 && y(t2, ((t3) => {
    if (t3.ownerDocument = n2, u(t3, 1)) for (const e3 of t3.attributes) e3.ownerDocument = n2;
  }));
}
function Q(t2) {
  const n2 = [];
  return y(t2, ((t3) => {
    u(t3, 3, 4) && n2.push(t3.data);
  })), n2.join("");
}
function K(t2, n2) {
  let e2 = null;
  if ("" !== n2) {
    e2 = new (s()).Text(n2);
  }
  Y(e2, t2);
}
function G(t2, n2) {
  const e2 = t2.map(((t3) => t3 instanceof Node ? t3 : n2.createTextNode(String(t3))));
  if (1 === e2.length) return e2[0];
  {
    const t3 = n2.createDocumentFragment();
    return e2.forEach(((n3) => {
      t3.appendChild(n3);
    })), t3;
  }
}
function J(t2, n2) {
  q(G(n2, p(t2)), t2, t2.firstChild);
}
function Z(t2, n2) {
  W(G(n2, p(t2)), t2);
}
function tt(t2, n2) {
  const e2 = G(n2, p(t2));
  _(e2, t2, null), Y(e2, t2);
}
function nt(t2, n2) {
  const e2 = t2.parentNode;
  if (null === e2) return;
  let r2 = t2.previousSibling;
  for (; null !== r2 && n2.indexOf(r2) >= 0; ) r2 = r2.previousSibling;
  q(G(n2, p(t2)), e2, null === r2 ? e2.firstChild : r2.nextSibling);
}
function et(t2, n2) {
  const e2 = t2.parentNode;
  if (null === e2) return;
  let r2 = t2.nextSibling;
  for (; null !== r2 && n2.indexOf(r2) >= 0; ) r2 = r2.nextSibling;
  q(G(n2, p(t2)), e2, r2);
}
function rt(t2, n2) {
  const e2 = t2.parentNode;
  if (null === e2) return;
  let r2 = t2.nextSibling;
  for (; null !== r2 && n2.indexOf(r2) >= 0; ) r2 = r2.nextSibling;
  const o2 = G(n2, p(t2));
  t2.parentNode === e2 ? X(t2, o2, e2) : q(o2, e2, r2);
}
function ot(t2) {
  null !== t2.parentNode && H(t2);
}
function it(t2, n2) {
  const e2 = n2.startContainer;
  u(e2, 7) && C("Can not insert into a processing instruction"), u(e2, 8) && C("Can not insert into a comment"), a(e2) && null === e2.parentNode && C("Can not insert into a text node without a parent");
  let r2 = null;
  r2 = a(e2) ? e2 : e2.childNodes[n2.startOffset] || null;
  const o2 = null === r2 ? e2 : r2.parentNode;
  _(t2, o2, r2), a(e2) && (r2 = e2.splitText(n2.startOffset)), t2 === r2 && (r2 = r2.nextSibling), null !== t2.parentNode && H(t2);
  let i2 = null === r2 ? d(o2) : g(r2);
  u(t2, 11) ? i2 += d(t2) : i2 += 1, q(t2, o2, r2), n2.collapsed && n2.setEnd(o2, i2);
}
function st(t2) {
  return t2 >>> 0;
}
function ut(t2) {
  return null === t2 ? "" : String(t2);
}
function lt(t2) {
  return null == t2 ? "" : String(t2);
}
function ct(t2, n2) {
  return (function(t3, n3) {
    if (!(t3 instanceof n3)) throw new TypeError(`Value should be an instance of ${n3.name}`);
  })(t2, n2), t2;
}
function at(t2, n2) {
  return null == t2 ? null : ct(t2, n2);
}
function ht(t2) {
  return void 0 === t2 ? null : t2;
}
var ft = /* @__PURE__ */ new WeakMap();
function dt(t2) {
  let n2 = ft.get(t2);
  return void 0 === n2 && (n2 = Math.random(), ft.set(t2, n2)), n2;
}
var Node = class _Node {
  constructor() {
    this.ownerDocument = null, this.parentNode = null, this.childNodes = [], this.firstChild = null, this.lastChild = null, this.previousSibling = null, this.nextSibling = null, this.o = new n(this);
  }
  get parentElement() {
    return this.parentNode && u(this.parentNode, 1) ? this.parentNode : null;
  }
  hasChildNodes() {
    return !!this.childNodes.length;
  }
  normalize() {
    let t2 = this.firstChild, n2 = 0;
    for (p(this); t2; ) {
      let e2 = t2.nextSibling;
      if (!u(t2, 3)) {
        t2.normalize(), t2 = e2;
        continue;
      }
      const r2 = t2;
      let o2 = r2.length;
      if (0 === o2) {
        H(t2), --n2, t2 = e2;
        continue;
      }
      let i2 = "";
      const l2 = [];
      for (let t3 = r2.nextSibling; t3 && u(t3, 3); t3 = t3.nextSibling) i2 += t3.data, l2.push(t3);
      i2 && r2.replaceData(o2, 0, i2);
      const c2 = s();
      for (let t3 = 0, e3 = l2.length; t3 < e3; ++t3) {
        const e4 = l2[t3], i3 = n2 + t3 + 1;
        c2.forEachRange(((t4) => {
          t4.startContainer === e4 && (t4.startOffset += o2, t4.startContainer = r2), t4.endContainer === e4 && (t4.endOffset += o2, t4.endContainer = r2), t4.startContainer === this && t4.startOffset === i3 && (t4.startContainer = r2, t4.startOffset = o2), t4.endContainer === this && t4.endOffset === i3 && (t4.endContainer = r2, t4.endOffset = o2);
        })), o2 += e4.length;
      }
      for (; l2.length; ) H(l2.shift());
      t2 = t2.nextSibling, ++n2;
    }
  }
  cloneNode(t2 = false) {
    return x(this, t2);
  }
  compareDocumentPosition(t2) {
    if (N(arguments, 1), this === (t2 = ct(t2, _Node))) return 0;
    let n2 = t2, e2 = this, r2 = null, o2 = null;
    if (l(n2) && (r2 = n2, n2 = r2.ownerElement), l(e2) && (o2 = e2, e2 = o2.ownerElement, null !== r2 && null !== n2 && e2 === n2)) for (const t3 of e2.attributes) {
      if (t3 === r2) return _Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC | _Node.DOCUMENT_POSITION_PRECEDING;
      if (t3 === o2) return _Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC | _Node.DOCUMENT_POSITION_FOLLOWING;
    }
    if (null === n2 || null === e2) return _Node.DOCUMENT_POSITION_DISCONNECTED | _Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC | (dt(n2 || r2) > dt(e2 || o2) ? _Node.DOCUMENT_POSITION_FOLLOWING : _Node.DOCUMENT_POSITION_PRECEDING);
    const i2 = m(n2), s2 = m(e2);
    if (i2[0] !== s2[0]) return _Node.DOCUMENT_POSITION_DISCONNECTED | _Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC | (dt(i2[0]) > dt(s2[0]) ? _Node.DOCUMENT_POSITION_FOLLOWING : _Node.DOCUMENT_POSITION_PRECEDING);
    let u2 = 0;
    for (; u2 < i2.length && u2 < s2.length && i2[u2] === s2[u2]; ) ++u2;
    const c2 = n2 !== e2 && u2 === i2.length, a2 = n2 !== e2 && u2 === s2.length;
    return c2 && null === r2 || n2 === e2 && null !== o2 ? _Node.DOCUMENT_POSITION_CONTAINS | _Node.DOCUMENT_POSITION_PRECEDING : a2 && null === o2 || n2 === e2 && null !== r2 ? _Node.DOCUMENT_POSITION_CONTAINED_BY | _Node.DOCUMENT_POSITION_FOLLOWING : c2 || g(i2[u2]) < g(s2[u2]) ? _Node.DOCUMENT_POSITION_PRECEDING : _Node.DOCUMENT_POSITION_FOLLOWING;
  }
  contains(t2) {
    for (N(arguments, 1), t2 = at(t2, _Node); t2 && t2 != this; ) t2 = t2.parentNode;
    return t2 === this;
  }
  isDefaultNamespace(t2) {
    N(arguments, 1), "" === (t2 = ht(t2)) && (t2 = null);
    return this.lookupNamespaceURI(null) === t2;
  }
  insertBefore(t2, n2) {
    return N(arguments, 2), q(t2 = ct(t2, _Node), this, n2 = at(n2, _Node));
  }
  appendChild(t2) {
    return N(arguments, 1), W(t2 = ct(t2, _Node), this);
  }
  replaceChild(t2, n2) {
    return N(arguments, 2), t2 = ct(t2, _Node), X(n2 = ct(n2, _Node), t2, this);
  }
  removeChild(t2) {
    return N(arguments, 1), (function(t3, n2) {
      return t3.parentNode !== n2 && M("child is not a child of parent"), H(t3), t3;
    })(t2 = ct(t2, _Node), this);
  }
};
function mt(t2, n2, e2, r2) {
  z("attributes", n2, { name: t2.localName, namespace: t2.namespaceURI, oldValue: e2 });
}
function pt(t2, n2) {
  mt(t2, t2.ownerElement, t2.value), t2.C = n2;
}
function gt(t2, n2, e2 = false) {
  e2 || mt(t2, n2, null, t2.value), n2.attributes.push(t2), t2.ownerElement = n2;
}
function wt(t2) {
  const n2 = t2.ownerElement;
  mt(t2, n2, t2.value), n2.attributes.splice(n2.attributes.indexOf(t2), 1), t2.ownerElement = null;
}
Node.ELEMENT_NODE = 1, Node.ATTRIBUTE_NODE = 2, Node.TEXT_NODE = 3, Node.CDATA_SECTION_NODE = 4, Node.ENTITY_REFERENCE_NODE = 5, Node.ENTITY_NODE = 6, Node.PROCESSING_INSTRUCTION_NODE = 7, Node.COMMENT_NODE = 8, Node.DOCUMENT_NODE = 9, Node.DOCUMENT_TYPE_NODE = 10, Node.DOCUMENT_FRAGMENT_NODE = 11, Node.NOTATION_NODE = 12, Node.DOCUMENT_POSITION_DISCONNECTED = 1, Node.DOCUMENT_POSITION_PRECEDING = 2, Node.DOCUMENT_POSITION_FOLLOWING = 4, Node.DOCUMENT_POSITION_CONTAINS = 8, Node.DOCUMENT_POSITION_CONTAINED_BY = 16, Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC = 32, Node.prototype.ELEMENT_NODE = 1, Node.prototype.ATTRIBUTE_NODE = 2, Node.prototype.TEXT_NODE = 3, Node.prototype.CDATA_SECTION_NODE = 4, Node.prototype.ENTITY_REFERENCE_NODE = 5, Node.prototype.ENTITY_NODE = 6, Node.prototype.PROCESSING_INSTRUCTION_NODE = 7, Node.prototype.COMMENT_NODE = 8, Node.prototype.DOCUMENT_NODE = 9, Node.prototype.DOCUMENT_TYPE_NODE = 10, Node.prototype.DOCUMENT_FRAGMENT_NODE = 11, Node.prototype.NOTATION_NODE = 12;
var Attr = class extends Node {
  get nodeType() {
    return 2;
  }
  get nodeName() {
    return this.name;
  }
  get nodeValue() {
    return this.C;
  }
  set nodeValue(t2) {
    yt(this, t2 = lt(t2));
  }
  get textContent() {
    return this.C;
  }
  set textContent(t2) {
    yt(this, t2 = lt(t2));
  }
  lookupPrefix(t2) {
    return N(arguments, 1), null !== this.ownerElement ? this.ownerElement.lookupPrefix(t2) : null;
  }
  lookupNamespaceURI(t2) {
    return N(arguments, 1), null === this.ownerElement ? null : this.ownerElement.lookupNamespaceURI(t2);
  }
  get value() {
    return this.C;
  }
  set value(t2) {
    yt(this, t2);
  }
  constructor(t2, n2, e2, r2, o2) {
    super(), this.namespaceURI = t2, this.prefix = n2, this.localName = e2, this.name = null === n2 ? e2 : `${n2}:${e2}`, this.C = r2, this.ownerElement = o2, this.ownerDocument = o2 ? o2.ownerDocument : s().document;
  }
  T(t2) {
    const n2 = new (s()).Attr(this.namespaceURI, this.prefix, this.localName, this.value, null);
    return n2.ownerDocument = t2, n2;
  }
};
function yt(t2, n2) {
  n2 = String(n2);
  null === t2.ownerElement ? t2.C = n2 : pt(t2, n2);
}
var CharacterData = class extends Node {
  get nodeValue() {
    return this.D;
  }
  set nodeValue(t2) {
    t2 = lt(t2), vt(this, 0, this.length, t2);
  }
  get textContent() {
    return this.D;
  }
  set textContent(t2) {
    t2 = lt(t2), vt(this, 0, this.length, t2);
  }
  lookupPrefix(t2) {
    N(arguments, 1);
    const n2 = this.parentElement;
    return null !== n2 ? n2.lookupPrefix(t2) : null;
  }
  lookupNamespaceURI(t2) {
    N(arguments, 1);
    const n2 = this.parentElement;
    return null === n2 ? null : n2.lookupNamespaceURI(t2);
  }
  before(...t2) {
    nt(this, t2);
  }
  after(...t2) {
    et(this, t2);
  }
  replaceWith(...t2) {
    rt(this, t2);
  }
  remove() {
    ot(this);
  }
  get previousElementSibling() {
    return V(this);
  }
  get nextElementSibling() {
    return F(this);
  }
  get data() {
    return this.D;
  }
  set data(t2) {
    t2 = ut(t2), vt(this, 0, this.length, t2);
  }
  get length() {
    return this.data.length;
  }
  constructor(t2) {
    super(), this.D = String(t2);
  }
  substringData(t2, n2) {
    return N(arguments, 2), bt(this, t2, n2);
  }
  appendData(t2) {
    N(arguments, 1), vt(this, this.length, 0, t2);
  }
  insertData(t2, n2) {
    N(arguments, 1), vt(this, t2, 0, n2);
  }
  deleteData(t2, n2) {
    N(arguments, 2), vt(this, t2, n2, "");
  }
  replaceData(t2, n2, e2) {
    N(arguments, 3), vt(this, t2, n2, e2);
  }
};
function vt(t2, n2, e2, r2) {
  n2 = st(n2), e2 = st(e2);
  const o2 = t2.length;
  n2 > o2 && D("can not replace data past the node's length"), n2 + e2 > o2 && (e2 = o2 - n2), z("characterData", t2, { oldValue: t2.data });
  const i2 = t2.data, u2 = i2.substring(0, n2) + r2 + i2.substring(n2 + e2);
  t2.D = u2;
  s().forEachRange(((o3) => {
    o3.startContainer === t2 && o3.startOffset > n2 && o3.startOffset <= n2 + e2 && (o3.startOffset = n2), o3.endContainer === t2 && o3.endOffset > n2 && o3.endOffset <= n2 + e2 && (o3.endOffset = n2), o3.startContainer === t2 && o3.startOffset > n2 + e2 && (o3.startOffset = o3.startOffset + r2.length - e2), o3.endContainer === t2 && o3.endOffset > n2 + e2 && (o3.endOffset = o3.endOffset + r2.length - e2);
  }));
}
function bt(t2, n2, e2) {
  n2 = st(n2), e2 = st(e2);
  const r2 = t2.length;
  return n2 > r2 && D("can not substring data past the node's length"), n2 + e2 > r2 ? t2.data.substring(n2) : t2.data.substring(n2, n2 + e2);
}
var Text = class extends CharacterData {
  get nodeType() {
    return 3;
  }
  get nodeName() {
    return "#text";
  }
  constructor(t2 = "") {
    super(t2);
    const n2 = s();
    this.ownerDocument = n2.document;
  }
  splitText(t2) {
    return N(arguments, 1), (function(t3, n2) {
      const e2 = t3.length;
      n2 > e2 && D("can not split past the node's length");
      const r2 = e2 - n2, o2 = bt(t3, n2, r2), i2 = new (s()).Text(o2);
      i2.ownerDocument = t3.ownerDocument;
      const u2 = t3.parentNode;
      if (null !== u2) {
        B(i2, u2, t3.nextSibling);
        const e3 = g(t3) + 1;
        s().forEachRange(((r3) => {
          r3.startContainer === t3 && r3.startOffset > n2 && (r3.startContainer = i2, r3.startOffset -= n2), r3.endContainer === t3 && r3.endOffset > n2 && (r3.endContainer = i2, r3.endOffset -= n2), r3.startContainer === u2 && r3.startOffset === e3 && (r3.startOffset += 1), r3.endContainer === u2 && r3.endOffset === e3 && (r3.endOffset += 1);
        }));
      }
      return vt(t3, n2, r2, ""), i2;
    })(this, t2 = st(t2));
  }
  T(t2) {
    const n2 = new (s()).Text(this.data);
    return n2.ownerDocument = t2, n2;
  }
  get wholeText() {
    const t2 = [this.data];
    let n2 = this.previousSibling;
    for (; null !== n2 && u(n2, 3, 4); ) {
      const e3 = n2.data;
      t2.unshift(e3), n2 = n2.previousSibling;
    }
    let e2 = this.nextSibling;
    for (; null !== e2 && u(e2, 3, 4); ) {
      const n3 = e2.data;
      t2.push(n3), e2 = e2.nextSibling;
    }
    return t2.join("");
  }
};
var CDATASection = class extends Text {
  get nodeType() {
    return 4;
  }
  get nodeName() {
    return "#cdata-section";
  }
  constructor(t2) {
    super(t2);
  }
  T(t2) {
    const n2 = new (s()).CDATASection(this.data);
    return n2.ownerDocument = t2, n2;
  }
};
var xt = class extends CharacterData {
  get nodeType() {
    return 8;
  }
  get nodeName() {
    return "#comment";
  }
  constructor(t2 = "") {
    super(t2);
    const n2 = s();
    this.ownerDocument = n2.document;
  }
  T(t2) {
    const n2 = new (s()).Comment(this.data);
    return n2.ownerDocument = t2, n2;
  }
};
var DocumentType = class extends Node {
  get nodeType() {
    return 10;
  }
  get nodeName() {
    return this.name;
  }
  get nodeValue() {
    return null;
  }
  set nodeValue(t2) {
  }
  get textContent() {
    return null;
  }
  set textContent(t2) {
  }
  lookupPrefix(t2) {
    return N(arguments, 1), null;
  }
  lookupNamespaceURI(t2) {
    return N(arguments, 1), null;
  }
  before(...t2) {
    nt(this, t2);
  }
  after(...t2) {
    et(this, t2);
  }
  replaceWith(...t2) {
    rt(this, t2);
  }
  remove() {
    ot(this);
  }
  constructor(t2, n2 = "", e2 = "") {
    super(), this.name = t2, this.publicId = n2, this.systemId = e2;
  }
  T(t2) {
    const n2 = new (s()).DocumentType(this.name, this.publicId, this.systemId);
    return n2.ownerDocument = t2, n2;
  }
};
function Nt(t2, n2, e2, r2, o2) {
  return new Attr(t2, n2, e2, r2, o2);
}
function St(t2, n2, e2, r2 = null) {
  return uo(t2, n2, e2, r2);
}
var Tt = "http://www.w3.org/1999/xhtml";
var Ct = "http://www.w3.org/XML/1998/namespace";
var Dt = "http://www.w3.org/2000/xmlns/";
function $t(t2) {
  (function(t3) {
    const n2 = t3.split(":");
    return !(n2.length > 2) && n2.every(((t4) => _r(t4)));
  })(t2) || $("The qualified name is not a valid QName");
}
function At(t2, n2) {
  "" === t2 && (t2 = null), $t(n2);
  let e2 = null, r2 = n2;
  const o2 = n2.indexOf(":");
  return o2 >= 0 && (e2 = n2.substring(0, o2), r2 = n2.substring(o2 + 1)), null !== e2 && null === t2 && k("Qualified name with prefix can not have a null namespace"), "xml" === e2 && t2 !== Ct && k("xml prefix can only be used for the XML namespace"), "xmlns" !== n2 && "xmlns" !== e2 || t2 === Dt || k("xmlns prefix or qualifiedName must use the XMLNS namespace"), t2 === Dt && "xmlns" !== n2 && "xmlns" !== e2 && k("xmlns prefix or qualifiedName must be used for the XMLNS namespace"), { namespace: t2, prefix: e2, localName: r2 };
}
function It(t2, n2) {
  if (t2.namespaceURI === n2 && null !== t2.prefix) return t2.prefix;
  const e2 = Array.from(t2.attributes).find(((t3) => "xmlns" === t3.prefix && t3.value === n2));
  return e2 ? e2.localName : null !== t2.parentElement ? It(t2.parentElement, n2) : null;
}
var kt = class {
  constructor(t2, n2, e2) {
    this.$ = null, this.A = 0, this.I = t2, this.k = t2, this.M = n2, this.R = e2;
  }
  enter(t2, n2) {
    var e2;
    const r2 = null !== (e2 = this.$) && void 0 !== e2 ? e2 : t2;
    if (this.k += n2, this.k > this.M) {
      this.k / this.I > this.R && Vr("too much entity expansion", r2);
    }
    this.$ = r2, this.A += 1;
  }
  exit() {
    this.A -= 1, 0 === this.A && (this.$ = null);
  }
};
function Mt(t2, n2) {
  return { success: true, offset: t2, value: n2 };
}
function Rt(t2) {
  return Mt(t2, void 0);
}
function Pt(t2, n2, e2 = false) {
  return { success: false, offset: t2, expected: n2, fatal: e2 };
}
function Lt(t2) {
  return (n2, e2) => {
    const r2 = e2 + t2.length;
    return n2.slice(e2, r2) === t2 ? Mt(r2, t2) : Pt(e2, [t2]);
  };
}
function zt(t2, n2) {
  return (e2, r2) => {
    const o2 = e2.codePointAt(r2);
    return void 0 !== o2 && t2(o2) ? Rt(r2 + (function(t3) {
      return t3 > 65535 ? 2 : 1;
    })(o2)) : Pt(r2, n2);
  };
}
function Ot(t2, n2) {
  return (e2, r2) => {
    const o2 = r2;
    for (; ; ) {
      const n3 = e2.codePointAt(r2);
      if (void 0 === n3) break;
      if (!t2(n3)) break;
      r2 += n3 > 65535 ? 2 : 1;
    }
    return void 0 !== n2 && r2 === o2 ? Pt(r2, n2) : Rt(r2);
  };
}
function Vt(t2, n2, e2) {
  return zt(((e3) => t2 <= e3 && e3 <= n2), e2 || [`${String.fromCodePoint(t2)}-${String.fromCodePoint(n2)}`]);
}
function Ft(t2, n2) {
  return (e2, r2) => {
    const o2 = t2(e2, r2);
    return o2.success ? Mt(o2.offset, n2(o2.value)) : o2;
  };
}
function Ut(t2) {
  return Ft(t2, (() => {
  }));
}
function _t(t2, n2, e2, r2) {
  return (o2, i2) => {
    const s2 = t2(o2, i2);
    return s2.success ? n2(s2.value) ? s2 : Pt(i2, e2, r2) : s2;
  };
}
function qt(t2, n2) {
  return (e2, r2) => {
    let o2 = null;
    for (const i2 of t2) {
      const t3 = i2(e2, r2);
      if (t3.success) return t3;
      if (null === o2 || t3.offset > o2.offset ? o2 = t3 : t3.offset === o2.offset && void 0 === n2 && (o2.expected = o2.expected.concat(t3.expected)), t3.fatal) return t3;
    }
    return n2 = n2 || (null == o2 ? void 0 : o2.expected) || [], o2 && (o2.expected = n2), o2 || Pt(r2, n2);
  };
}
function Bt(t2) {
  return (n2, e2) => {
    const r2 = t2(n2, e2);
    return r2.success || r2.fatal ? r2 : Mt(e2, null);
  };
}
function Wt(t2) {
  return (n2, e2) => {
    let r2 = [], o2 = e2;
    for (; ; ) {
      const e3 = t2(n2, o2);
      if (!e3.success) {
        if (e3.fatal) return e3;
        break;
      }
      if (r2.push(e3.value), e3.offset === o2) break;
      o2 = e3.offset;
    }
    return Mt(o2, r2);
  };
}
function Xt(t2) {
  return (n2, e2) => {
    let r2 = e2;
    for (; ; ) {
      const e3 = t2(n2, r2);
      if (!e3.success) {
        if (e3.fatal) return e3;
        break;
      }
      if (e3.offset === r2) break;
      r2 = e3.offset;
    }
    return Rt(r2);
  };
}
function Yt(t2, n2, e2) {
  return (r2, o2) => {
    const i2 = t2(r2, o2);
    if (!i2.success) return i2;
    const s2 = n2(r2, i2.offset);
    return s2.success ? Mt(s2.offset, e2(i2.value, s2.value)) : s2;
  };
}
function Ht(...t2) {
  return (n2, e2) => {
    const r2 = [];
    for (const o2 of t2) {
      const t3 = o2(n2, e2);
      if (!t3.success) return t3;
      e2 = t3.offset, r2.push(t3.value);
    }
    return Mt(e2, r2);
  };
}
function jt(...t2) {
  return (n2, e2) => {
    for (const r2 of t2) {
      const t3 = r2(n2, e2);
      if (!t3.success) return t3;
      e2 = t3.offset;
    }
    return Rt(e2);
  };
}
function Qt(t2, n2) {
  return t2;
}
function Kt(t2, n2) {
  return n2;
}
function Gt(t2) {
  return Yt(t2, Xt(t2), Kt);
}
function Jt(t2, n2) {
  return Yt(t2, n2, Kt);
}
function Zt(t2, n2) {
  return Yt(t2, n2, Qt);
}
function tn(t2, n2, e2, r2 = false) {
  return Jt(t2, r2 ? un(Zt(n2, e2)) : Zt(n2, e2));
}
function nn(t2) {
  return (n2, e2) => {
    const r2 = t2(n2, e2);
    return r2.success ? Mt(r2.offset, n2.slice(e2, r2.offset)) : r2;
  };
}
function en(t2) {
  return (n2, e2) => {
    const r2 = t2(n2, e2);
    return r2.success ? Mt(e2, r2.value) : r2;
  };
}
function rn(t2, n2) {
  return (e2, r2) => t2(e2, r2).success ? Pt(r2, n2) : Rt(r2);
}
function on(t2, n2, e2) {
  return Jt(rn(n2, e2), t2);
}
function sn(t2, n2, e2 = 0, r2 = []) {
  return (o2, i2) => {
    const s2 = o2.codePointAt(i2 + e2);
    if (void 0 === s2) return Pt(i2, r2);
    const u2 = t2[s2];
    return void 0 === u2 ? void 0 === n2 ? Pt(i2, r2) : n2(o2, i2) : u2(o2, i2);
  };
}
function un(t2) {
  return (n2, e2) => {
    const r2 = t2(n2, e2);
    return r2.success ? r2 : Pt(r2.offset, r2.expected, true);
  };
}
var ln = (t2, n2) => t2.length === n2 ? Rt(n2) : Pt(n2, ["end of input"]);
function cn(t2) {
  return Yt(t2, ln, Qt);
}
var an = class {
  constructor(t2, n2) {
    this.P = 0, this.L = 0, this.O = t2, this.V = n2;
  }
  next() {
    if (this.P >= this.V.length) return { done: true, value: ln(this.O, this.L) };
    const { parser: t2, type: n2 } = this.V[this.P], e2 = t2(this.O, this.L);
    return e2.success ? (this.L = e2.offset, 1 !== n2 && (this.P += 1), void 0 === e2.value ? this.next() : { done: false, value: e2.value }) : 0 === n2 || e2.fatal ? { done: true, value: e2 } : (this.P += 1, this.next());
  }
};
function hn(t2) {
  return (n2, e2) => {
    const r2 = e2, o2 = t2(n2, e2);
    return o2.success ? Mt(o2.offset, Object.assign({ input: n2, start: r2, end: o2.offset }, o2.value)) : o2;
  };
}
var fn = Lt("_");
var dn = Lt("-");
var mn = Lt(".");
var pn = Lt('"');
var gn = Lt("'");
var wn = Lt("<");
var yn = Lt(">");
var vn = Lt("&");
var bn = Lt("=");
var xn = Lt("[");
var Nn = Lt("]");
var Sn = Lt(";");
var En = Lt("%");
var Tn = Lt("(");
var Cn = Lt(")");
var Dn = Lt("+");
var $n = Lt(",");
var An = Lt("?");
var In = Lt("*");
var kn = Lt("|");
var Mn = Lt("]]>");
var Rn = Lt("<!--");
var Pn = Lt("-->");
var Ln = Lt("<?");
var zn = Lt("?>");
var On = Lt("1.");
var Vn = Lt("version");
var Fn = Lt("encoding");
var Un = Lt("standalone");
var _n = Lt("yes");
var qn = Lt("no");
var Bn = Lt("<?xml");
var Wn = Lt("<!DOCTYPE");
var Xn = Lt("SYSTEM");
var Yn = Lt("PUBLIC");
var Hn = Lt("</");
var jn = Lt("/>");
var Qn = Lt("&#");
var Kn = Lt("&#x");
var Gn = Lt("<!ELEMENT");
var Jn = Lt("EMPTY");
var Zn = Lt("ANY");
var te = Lt("#PCDATA");
var ne = Lt("<!ATTLIST");
var ee = Lt("NOTATION");
var re = Lt("#REQUIRED");
var oe = Lt("#IMPLIED");
var ie = Lt("#FIXED");
var se = Lt("<!ENTITY");
var ue = Lt("NDATA");
var le = Lt("<!NOTATION");
var ce = Vt(65, 90);
var ae = Vt(97, 122);
var he = Vt(48, 57);
var fe = qt([he, Vt(65, 70), Vt(97, 102)], ["hexadecimal digit"]);
function de(t2) {
  return 9 === t2 || 10 === t2 || 13 === t2 || 32 <= t2 && t2 <= 55295 || 57344 <= t2 && t2 <= 65533 || 65536 <= t2 && t2 <= 1114111;
}
var me = cn(Ot(de));
function pe(t2) {
  return 32 === t2 || 9 === t2 || 13 === t2 || 10 === t2;
}
var ge = Ot(pe, ["whitespace"]);
var we = cn(Ot(pe));
function ye(t2) {
  return 58 === t2 || 65 <= t2 && t2 <= 90 || 95 === t2 || 97 <= t2 && t2 <= 122 || 192 <= t2 && t2 <= 214 || 216 <= t2 && t2 <= 246 || 248 <= t2 && t2 <= 767 || 880 <= t2 && t2 <= 893 || 895 <= t2 && t2 <= 8191 || 8204 <= t2 && t2 <= 8205 || 8304 <= t2 && t2 <= 8591 || 11264 <= t2 && t2 <= 12271 || 12289 <= t2 && t2 <= 55295 || 63744 <= t2 && t2 <= 64975 || 65008 <= t2 && t2 <= 65533 || 65536 <= t2 && t2 <= 983039;
}
var ve = zt(ye, ["valid name start character"]);
function be(t2) {
  return ye(t2) || 45 === t2 || 46 === t2 || 48 <= t2 && t2 <= 57 || 183 === t2 || 768 <= t2 && t2 <= 879 || 8255 <= t2 && t2 <= 8256;
}
var xe = nn(Jt(ve, Ot(be)));
var Ne = cn(xe);
var Se = _t(xe, ((t2) => !t2.includes(":")), ["name must not contain colon"], true);
var Ee = nn(Ot(be, ["valid name character"]));
var Te = hn(Ft(_t(qt([Ft(tn(Kn, nn(Gt(fe)), Sn, true), ((t2) => parseInt(t2, 16))), Ft(tn(Qn, nn(Gt(he)), Sn, true), ((t2) => parseInt(t2, 10)))]), ((t2) => de(t2)), ["character reference must reference a valid character"], true), ((t2) => ({ type: 0, cp: t2 }))));
var Ce = qt([hn(Ft(tn(vn, Se, un(Sn)), ((t2) => ({ type: 1, name: t2 })))), Te]);
var De = hn(Ft(tn(En, Se, Sn), ((t2) => ({ type: 2, name: t2 }))));
var $e = qt([tn(pn, Wt(qt([nn(Ot(((t2) => 37 !== t2 && 38 !== t2 && t2 !== Ae && de(t2)), [])), De, Ce])), pn, true), tn(gn, Wt(qt([nn(Ot(((t2) => 37 !== t2 && 38 !== t2 && t2 !== Ie && de(t2)), [])), De, Ce])), gn, true)]);
var Ae = 34;
var Ie = 39;
var ke = sn({ [Ae]: tn(pn, Wt(sn({ 38: Ce }, nn(Ot(((t2) => t2 !== Oe && 38 !== t2 && t2 !== Ae && de(t2)), [])))), pn, true), [Ie]: tn(gn, Wt(sn({ 38: Ce }, nn(Ot(((t2) => t2 !== Oe && 38 !== t2 && t2 !== Ie && de(t2)), [])))), gn, true) }, void 0, 0, ["quoted attribute value"]);
var Me = cn(Wt(qt([nn(Ot(((t2) => t2 !== Oe && 38 !== t2 && de(t2)), [])), Ce])));
var Re = _t(qt([tn(pn, nn(Ot(((t2) => t2 !== Ae && de(t2)))), pn), tn(gn, nn(Ot(((t2) => t2 !== Ie && de(t2)))), gn)]), ((t2) => !t2.includes("#")), ["system identifier must not contain a fragment identifier"], true);
function Pe(t2) {
  return 32 === t2 || 13 === t2 || 10 === t2 || 97 <= t2 && t2 <= 122 || 65 <= t2 && t2 <= 90 || 48 <= t2 && t2 <= 57 || 33 <= t2 && t2 <= 47 && 34 !== t2 && 38 !== t2 || 58 <= t2 && t2 <= 64 && 60 !== t2 && 62 !== t2 || 95 === t2;
}
var Le = cn(Ot(Pe));
var ze = qt([tn(pn, nn(Ot(((t2) => t2 !== Ae && Pe(t2)))), pn, true), tn(gn, nn(Ot(((t2) => t2 !== Ie && Pe(t2)))), gn, true)]);
var Oe = 60;
var Ve = nn(Gt(qt([Ot(((t2) => t2 !== Oe && 38 !== t2 && 93 !== t2 && de(t2)), []), on(Ut(Nn), Mn, [])], ["character data"])));
var Comment = Ft(tn(Rn, nn(Xt(qt([Ot(((t2) => 45 !== t2 && de(t2)), []), Zt(Ut(dn), rn(dn, ["comment content may not contain --"]))]))), Pn, true), ((t2) => ({ type: 3, data: t2 })));
var Fe = _t(Se, ((t2) => "xml" !== t2.toLowerCase()), ['processing instruction target must not be "xml"'], true);
var Ue = tn(Ln, Yt(Fe, Bt(Jt(ge, nn(Xt(qt([Ot(((t2) => 63 !== t2 && de(t2)), []), Zt(Ut(An), rn(yn, ["PI data"]))]))))), ((t2, n2) => ({ type: 4, target: t2, data: n2 }))), zn, true);
var _e = Lt("<![CDATA[");
var qe = nn(Xt(qt([Ot(((t2) => 93 !== t2 && de(t2)), []), on(Ut(Nn), Mn, ["CData"])])));
var Be = hn(Ft(tn(_e, qe, Mn, true), ((t2) => ({ type: 5, data: t2 }))));
var We = tn(Bt(ge), bn, Bt(ge));
var Xe = nn(Jt(On, Gt(he)));
var Ye = Jt(ge, Jt(Vn, Jt(We, qt([tn(pn, Xe, pn, true), tn(gn, Xe, gn, true)]))));
var He = nn(Jt(qt([ce, ae]), Xt(qt([ce, ae, he, Ut(mn), Ut(fn), Ut(dn)]))));
var je = Jt(ge, Jt(Fn, Jt(We, qt([tn(pn, He, pn, true), tn(gn, He, gn, true)]))));
var Qe = qt([Ft(_n, (() => true)), Ft(qn, (() => false))]);
var Ke = Jt(ge, Jt(Un, un(Jt(We, qt([tn(pn, Qe, pn, true), tn(gn, Qe, gn, true)])))));
var Ge = tn(Zt(Bn, en(ge)), Zt(Yt(Ye, Yt(Bt(je), Bt(Ke), ((t2, n2) => [t2, n2])), ((t2, [n2, e2]) => ({ type: 6, version: t2, encoding: n2, standalone: e2 }))), Bt(ge)), zn, true);
var Je = hn(Ft(xe, ((t2) => ({ name: t2 }))));
var Ze = Yt(Je, Jt(un(We), un(ke)), ((t2, n2) => ({ name: t2, value: n2 })));
var tr = Ft(Ht(wn, Je, un(Zt(Wt(Jt(ge, Ze)), Bt(ge))), un(sn({ 47: Ft(jn, (() => true)) }, Ft(yn, (() => false)), 0, [">", "/>"]))), (([t2, n2, e2, r2]) => ({ type: r2 ? 9 : 7, name: n2, attributes: e2 })));
var nr = hn(Ft(tn(Hn, Zt(xe, Bt(ge)), yn, true), ((t2) => ({ type: 8, name: t2 }))));
var er = qt([An, In, Dn]);
var rr = Zt(qt([Ut(xe), function(t2, n2) {
  return or(t2, n2);
}, function(t2, n2) {
  return ir(t2, n2);
}]), Ut(Bt(er)));
var or = jt(Tn, Bt(ge), rr, Gt(Ht(Bt(ge), kn, Bt(ge), un(rr))), Bt(ge), Cn);
var ir = jt(Tn, Bt(ge), rr, Xt(Ht(Bt(ge), $n, Bt(ge), un(rr))), Bt(ge), Cn);
var sr = Zt(qt([or, ir]), Bt(er));
var ur = jt(Tn, Bt(ge), te, qt([jt(Xt(jt(Bt(ge), kn, Bt(ge), xe)), Bt(ge), Cn, In), Ut(Zt(Bt(ge), Cn))]));
var lr = Zt(Gn, un(jt(ge, xe, ge, qt([Ut(Jn), Ut(Zn), Ut(ur), Ut(sr)]), Bt(ge), yn)));
var cr = Lt("CDATA");
var ar = qt([Lt("IDREFS"), Lt("IDREF"), Lt("ID"), Lt("ENTITY"), Lt("ENTITIES"), Lt("NMTOKENS"), Lt("NMTOKEN")]);
var hr = qt([Zt(ee, un(jt(ge, Tn, Bt(ge), Se, Xt(jt(Bt(ge), kn, Bt(ge), Se)), Bt(ge), Cn))), Zt(Tn, un(jt(Bt(ge), Ee, Xt(jt(Bt(ge), kn, Bt(ge), Ee)), Bt(ge), Cn)))]);
var fr = qt([Ft(cr, (() => true)), Ft(ar, (() => false)), Ft(hr, (() => false))]);
var dr = qt([Ft(re, (() => ({ type: 0 }))), Ft(oe, (() => ({ type: 1 }))), Yt(Ft(Bt(Zt(ie, ge)), ((t2) => null !== t2)), ke, ((t2, n2) => ({ type: 2, fixed: t2, value: n2 })))]);
var mr = Yt(Jt(ge, Je), un(Yt(Jt(ge, fr), Jt(ge, dr), ((t2, n2) => ({ isCData: t2, def: n2 })))), ((t2, { isCData: n2, def: e2 }) => ({ name: t2, isCData: n2, def: e2 })));
var pr = tn(Zt(ne, ge), Yt(xe, un(Wt(mr)), ((t2, n2) => ({ type: 0, name: t2, attdefs: n2 }))), Jt(Bt(ge), yn), true);
var gr = qt([Ft(Jt(Xn, un(Jt(ge, Re))), ((t2) => ({ publicId: null, systemId: t2 }))), Jt(Yn, Yt(un(Jt(ge, ze)), Jt(ge, Re), ((t2, n2) => ({ publicId: t2, systemId: n2 }))))]);
var wr = qt([$e, Yt(gr, Bt(Jt(tn(ge, ue, ge), Se)), ((t2, n2) => ({ ids: t2, ndata: n2 })))]);
var yr = tn(se, Yt(Jt(ge, Se), un(Jt(ge, wr)), ((t2, n2) => ({ type: 1, name: t2, value: n2 }))), Jt(Bt(ge), yn));
var vr = qt([$e, Ut(gr)]);
var br = tn(Zt(se, Jt(ge, En)), Yt(Jt(ge, Se), un(Jt(ge, vr)), ((t2, n2) => n2 ? { type: 2, name: t2, value: n2 } : void 0)), Jt(Bt(ge), yn), true);
var xr = Jt(en(se), un(qt([yr, br])));
var Nr = tn(Zt(Bn, en(ge)), Zt(Yt(Bt(Ye), je, ((t2, n2) => ({ type: 6, version: t2, encoding: n2, standalone: null }))), Bt(ge)), zn, true);
var Sr = Ft(Zt(Zt(Yn, ge), un(ze)), ((t2) => ({ publicId: t2, systemId: null })));
var Er = tn(le, Yt(tn(ge, Se, ge), qt([Ut(gr), Ut(Sr)]), (() => {
})), Jt(Bt(ge), yn), true);
var Tr = qt([Ut(lr), pr, xr, Ut(Er), Ut(Ue), Ut(Comment)]);
var Cr = qt([Ut(De), Ut(ge)]);
var Dr = (function(t2) {
  return Ft(t2, ((t3) => t3.filter(((t4) => void 0 !== t4))));
})(Wt(qt([Tr, Cr])));
var $r = Jt(Wn, un(Ft(Ht(ge, xe, Bt(Jt(ge, gr)), Bt(ge), Bt(Zt(tn(xn, Dr, Nn, true), Bt(ge))), yn), (([t2, n2, e2, r2, o2, i2]) => ({ type: 10, name: n2, ids: e2, intSubset: o2 })))));
var Ar = { parser: sn({ [Oe]: sn({ 47: nr, 33: qt([Comment, Be]), 63: Ue }, tr, 1), 38: Ce }, Ve), type: 1 };
function Ir(t2) {
  return new an(t2, [Ar]);
}
var kr = qt([Comment, Ue, ge]);
var Mr = [...[{ parser: Ge, type: 2 }, { parser: kr, type: 1 }, { parser: $r, type: 2 }, { parser: kr, type: 1 }], ...[{ parser: tr, type: 0 }, Ar]];
function Rr(t2) {
  return new an(t2, Mr);
}
function zr(t2) {
  return Array.from(t2, ((t3) => Ur(t3) ? t3 : "[invalid character]")).join("");
}
function Or(t2, n2, e2) {
  const r2 = Array.from(t2);
  if (r2.length < e2) return t2;
  switch (n2) {
    case 0:
      return "\u2026" + r2.slice(-e2).join("");
    case 1:
      return r2.slice(0, e2).join("") + "\u2026";
  }
  const o2 = 0 | Math.min(r2.length / 2, e2 / 2);
  return r2.slice(0, o2).join("") + "\u2026" + r2.slice(-o2).join("");
}
function Vr(t2, n2) {
  const { line: e2, char: r2 } = (function(t3, n3) {
    let e3 = 1, r3 = 1, o2 = 0;
    for (; o2 < n3; ) {
      const n4 = t3.codePointAt(o2);
      r3++, o2 += n4 > 65535 ? 2 : 1, 10 === n4 && (e3++, r3 = 1);
    }
    return { line: e3, char: r3 };
  })(n2.input, n2.start);
  throw new Error(`${t2}
${`At line ${e2}, character ${r2}:`}

${(function(t3, n3, e3) {
    const r3 = Or(zr(t3.substring(n3, e3)), 2, 30), o2 = t3.lastIndexOf("\n", n3), i2 = Or(zr(t3.substring(o2 + 1, n3)), 0, 55 - r3.length), s2 = t3.indexOf("\n", e3), u2 = Or(zr(s2 > 0 ? t3.substring(e3, s2) : t3.substring(e3)), 1, 80 - r3.length - i2.length), l2 = Array.from(i2, ((t4) => qr(t4) ? t4 : " ")).join("");
    return `${i2}${r3}${u2}
${l2}${"^".repeat(Math.max(Array.from(r3).length, 1))}`;
  })(n2.input, n2.start, n2.end)}`);
}
function Fr(t2, n2, e2, r2) {
  const o2 = Array.from(new Set(e2), ((t3) => t3.includes('"') ? `'${t3}'` : `"${t3}"`)), i2 = n2.codePointAt(r2), s2 = i2 ? String.fromCodePoint(i2) : "";
  Vr(`Parsing ${t2} failed, expected ${o2.length > 1 ? "one of " + o2.join(", ") : o2[0]}`, { input: n2, start: r2, end: r2 + Math.max(s2.length, 1) });
}
function Ur(t2) {
  return me(t2, 0).success;
}
function _r(t2) {
  return Ne(t2, 0).success;
}
function qr(t2) {
  return we(t2, 0).success;
}
function Br(t2) {
  const n2 = [];
  for (const e2 of t2) if ("string" != typeof e2) switch (e2.type) {
    case 0:
      n2.push(String.fromCodePoint(e2.cp));
      break;
    case 1:
      n2.push(`&${e2.name};`);
      break;
    case 2:
      Vr(`reference to parameter entity "${e2.name}" must not occur in an entity declaration in the internal subset`, e2);
  }
  else n2.push(e2);
  return n2.join("");
}
var Wr = class {
  constructor(t2) {
    if (this.F = /* @__PURE__ */ new Map(), this.U = /* @__PURE__ */ new Map(), this._ = /* @__PURE__ */ new Set(), this.q = /* @__PURE__ */ new Set(), t2.intSubset) for (const n2 of t2.intSubset) switch (n2.type) {
      case 0: {
        for (const t4 of n2.attdefs) if (2 === t4.def.type) for (const n3 of t4.def.value) "string" != typeof n3 && 1 === n3.type && (this.U.has(n3.name) || this._.has(n3.name) || this.q.has(n3.name) || Vr(`default value of attribute "${t4.name.name}" contains reference to undefined entity "${n3.name}"`, n3), this._.has(n3.name) && Vr(`default value of attribute "${t4.name.name}" must not contain reference to external entity "${n3.name}"`, n3));
        let t3 = this.F.get(n2.name);
        void 0 === t3 && (t3 = /* @__PURE__ */ new Map(), this.F.set(n2.name, t3));
        for (const e2 of n2.attdefs) t3.has(e2.name.name) || t3.set(e2.name.name, e2);
        break;
      }
      case 2:
        if (Array.isArray(n2.value)) for (const t3 of n2.value) "string" != typeof t3 && 2 === t3.type && Vr(`reference to parameter entity "${t3.name}" must not occur in an entity declaration in the internal subset`, t3);
        break;
      case 1:
        if (this.U.has(n2.name) || this._.has(n2.name)) continue;
        Array.isArray(n2.value) ? this.U.set(n2.name, Br(n2.value)) : null === n2.value.ndata ? this._.add(n2.name) : this.q.add(n2.name);
    }
  }
  getAttlist(t2) {
    return this.F.get(t2.name);
  }
  getEntityReplacementText(t2, n2) {
    const e2 = this.U.get(t2.name);
    if (void 0 === e2 && (this.q.has(t2.name) && Vr(`reference to binary entity "${t2.name}" is not allowed`, t2), this._.has(t2.name))) {
      if (n2) return "";
      Vr(`reference to external entity "${t2.name}" is not allowed in attribute value`, t2);
    }
    return e2;
  }
};
var Xr = /* @__PURE__ */ new Map([["lt", "&#60;"], ["gt", ">"], ["amp", "&#38;"], ["apos", "'"], ["quot", '"']]);
function Yr(t2, n2, e2, r2, o2) {
  for (const i2 of n2) {
    if ("string" == typeof i2) {
      t2.push(i2.replace(/[\r\n\t]/g, " "));
      continue;
    }
    if (0 === i2.type) {
      t2.push(String.fromCodePoint(i2.cp));
      continue;
    }
    null !== r2 && r2.includes(i2.name) && Vr(`reference to entity "${i2.name}" must not be recursive`, i2);
    let n3 = Xr.get(i2.name);
    void 0 === n3 && null !== e2 && (n3 = e2.getEntityReplacementText(i2, false)), void 0 === n3 && Vr(`reference to unknown entity "${i2.name}" in attribute value`, i2), o2.enter(i2, n3.length);
    const s2 = Me(n3, 0);
    s2.success || Fr(`replacement text for entity "${i2.name}"`, n3, s2.expected, s2.offset), Yr(t2, s2.value, e2, r2 ? [i2.name, ...r2] : [i2.name], o2), o2.exit();
  }
}
function Hr(t2, n2, e2, r2) {
  const o2 = [];
  return Yr(o2, t2, e2, null, r2), n2 && !n2.isCData ? o2.join("").replace(/[ ]+/g, " ").replace(/^[ ]+|[ ]+$/g, "") : o2.join("");
}
function jr(t2, n2) {
  const e2 = t2.name, r2 = n2.get(e2);
  if (void 0 !== r2) return r2;
  let o2 = null, i2 = e2;
  const s2 = e2.indexOf(":");
  s2 >= 0 && (o2 = e2.substring(0, s2), i2 = e2.substring(s2 + 1)), ("" === o2 || "" === i2 || i2.includes(":")) && Vr(`the name "${e2}" is not a valid qualified name`, t2);
  const u2 = { prefix: o2, localName: i2 };
  return n2.set(e2, u2), u2;
}
var Qr = class _Qr {
  constructor(t2, n2 = null) {
    var e2;
    this.B = /* @__PURE__ */ new Map(), this.W = null, this.X = t2, this.W = null !== (e2 = null != n2 ? n2 : null == t2 ? void 0 : t2.W) && void 0 !== e2 ? e2 : null;
  }
  getForElement(t2, n2) {
    "xmlns" === t2 && Vr('element names must not have the prefix "xmlns"', n2);
    for (let n3 = this; null !== n3; n3 = n3.X) {
      const e2 = n3.B.get(t2);
      if (void 0 !== e2) return e2;
    }
    if (null !== t2 && this.W) {
      const n3 = this.W(t2);
      if (void 0 !== n3) return n3;
    }
    Vr(`use of undeclared element prefix "${t2}"`, n2);
  }
  getForAttribute(t2, n2, e2) {
    if (null === t2) return "xmlns" === n2 ? Dt : null;
    for (let n3 = this; null !== n3; n3 = n3.X) {
      const e3 = n3.B.get(t2);
      if (void 0 !== e3) return e3;
    }
    if (this.W) {
      const n3 = this.W(t2);
      if (void 0 !== n3) return n3;
    }
    Vr(`use of undeclared attribute prefix ${t2}`, e2);
  }
  static fromAttrs(t2, n2, e2, r2, o2, i2) {
    let s2 = t2, u2 = false;
    const l2 = (n3, e3, r3) => {
      null !== n3 || e3 !== Ct && e3 !== Dt || Vr(`the namespace "${e3}" must not be used as the default namespace`, r3), e3 === Dt && Vr(`the namespace "${Dt}" must not be bound to a prefix`, r3), e3 === Ct && "xml" !== n3 && Vr(`the namespace "${Ct}" must be bound only to the prefix "xml"`, r3), e3 !== Ct && "xml" === n3 && Vr(`the xml namespace prefix must not be bound to any namespace other than "${Ct}"`, r3), null !== n3 && null === e3 && Vr(`the prefix "${n3}" must not be undeclared`, r3), u2 || (s2 = new _Qr(t2), u2 = true), s2.B.set(n3, e3);
    }, c2 = (t3, n3) => {
      const { prefix: c3, localName: a2 } = jr(t3, o2), h2 = null == e2 ? void 0 : e2.get(t3.name);
      if (null !== c3 || "xmlns" !== a2 || u2 && s2.B.has(null)) {
        if (!("xmlns" !== c3 || u2 && s2.B.has(a2))) {
          "xmlns" === a2 && Vr('the "xmlns" namespace prefix must not be declared', t3);
          const e3 = Hr(n3, h2, r2, i2) || null;
          l2(a2, e3, t3);
        }
      } else {
        const e3 = Hr(n3, h2, r2, i2) || null;
        l2(null, e3, t3);
      }
    };
    for (const t3 of n2.attributes) c2(t3.name, t3.value);
    if (e2) for (const t3 of e2.values()) {
      const n3 = t3.def;
      2 === n3.type && c2(t3.name, n3.value);
    }
    return s2;
  }
  static default(t2) {
    const n2 = new _Qr(null, t2);
    return n2.B.set(null, null), n2.B.set("xml", Ct), n2.B.set("xmlns", Dt), n2;
  }
};
var Kr = Qr.default(null);
function Gr(t2, n2) {
  B(n2, t2, null, true);
}
function Jr(t2, n2, e2, r2, { entityExpansionMaxAmplification: o2 = 100, entityExpansionThreshold: i2 = 4194304, treatCDataAsText: s2 = false }) {
  var u2, l2;
  const c2 = p(r2);
  let a2 = { parent: null, root: r2, namespaces: e2, entityRoot: true }, f2 = null;
  const d2 = /* @__PURE__ */ new Map();
  let m2 = [];
  function g2() {
    if (m2.length > 0) {
      const t3 = m2.join("");
      if (a2.root === c2) {
        if (!qr(t3)) throw new Error("document must not contain text outside of elements");
      } else Gr(a2.root, c2.createTextNode(m2.join("")));
      m2.length = 0;
    }
  }
  t2 = (function(t3) {
    return t3.replace(/\r\n?/g, "\n");
  })(t2 = t2.replace(/^\ufeff/, ""));
  const w2 = new kt(t2.length, i2, o2);
  let y2 = { parent: null, entity: null, iterator: n2(t2) };
  for (; y2; ) {
    let n3 = y2.iterator.next();
    for (; !n3.done; n3 = y2.iterator.next()) {
      const t3 = n3.value;
      if ("string" != typeof t3) {
        switch (t3.type) {
          case 0:
            a2.root === c2 && null !== c2.documentElement && Vr("character reference must not appear after the document element", t3), m2.push(String.fromCodePoint(t3.cp));
            continue;
          case 1: {
            a2.root === c2 && null !== c2.documentElement && Vr(`reference to entity "${t3.name}" must not appear after the document element`, t3);
            for (let n5 = y2; n5; n5 = n5.parent) n5.entity === t3.name && Vr(`reference to entity "${t3.name}" must not be recursive`, t3);
            let n4 = Xr.get(t3.name);
            void 0 === n4 && null !== f2 && (n4 = f2.getEntityReplacementText(t3, true)), void 0 === n4 && Vr(`reference to unknown entity "${t3.name}" in content`, t3), w2.enter(t3, n4.length), a2 = { parent: a2, root: a2.root, namespaces: a2.namespaces, entityRoot: true }, y2 = { parent: y2, entity: t3.name, iterator: Ir(n4) };
            continue;
          }
          case 5:
            if (s2) {
              m2.push(t3.data);
              continue;
            }
        }
        switch (g2(), t3.type) {
          case 5:
            a2.root === c2 && null !== c2.documentElement && Vr("CData section must not appear after the document element", t3), Gr(a2.root, c2.createCDATASection(t3.data));
            continue;
          case 3:
            Gr(a2.root, c2.createComment(t3.data));
            continue;
          case 10:
            f2 = new Wr(t3), Gr(a2.root, c2.implementation.createDocumentType(t3.name, (null === (u2 = t3.ids) || void 0 === u2 ? void 0 : u2.publicId) || "", (null === (l2 = t3.ids) || void 0 === l2 ? void 0 : l2.systemId) || ""));
            continue;
          case 4:
            Gr(a2.root, c2.createProcessingInstruction(t3.target, t3.data || ""));
            continue;
          case 7:
          case 9: {
            a2.root === c2 && null !== c2.documentElement && Vr(`document must contain a single root element, but found "${c2.documentElement.nodeName}" and "${t3.name.name}"`, t3.name);
            const n4 = f2 ? f2.getAttlist(t3.name) : void 0, e3 = Qr.fromAttrs(a2.namespaces, t3, n4, f2, d2, w2), { prefix: r3, localName: o3 } = jr(t3.name, d2), i3 = e3.getForElement(r3, t3.name), s3 = St(c2, o3, i3, r3);
            for (const r4 of t3.attributes) {
              const { prefix: o4, localName: i4 } = jr(r4.name, d2), u3 = e3.getForAttribute(o4, i4, r4.name), l3 = null == n4 ? void 0 : n4.get(r4.name.name);
              s3.hasAttributeNS(u3, i4) && Vr(`attribute "${r4.name.name}" must not appear multiple times on element "${t3.name.name}"`, r4.name);
              gt(Nt(u3, o4, i4, Hr(r4.value, l3, f2, w2), s3), s3, true);
            }
            if (n4) for (const t4 of n4.values()) {
              const n5 = t4.def;
              if (2 !== n5.type) continue;
              const { prefix: r4, localName: o4 } = jr(t4.name, d2), i4 = e3.getForAttribute(r4, o4, t4.name);
              if (s3.hasAttributeNS(i4, o4)) continue;
              gt(Nt(i4, r4, o4, Hr(n5.value, t4, f2, w2), s3), s3, true);
            }
            Gr(a2.root, s3), 7 === t3.type && (a2 = { parent: a2, root: s3, namespaces: e3, entityRoot: false, event: t3 });
            continue;
          }
          case 8:
            h(a2.root) && a2.root.nodeName === t3.name || Vr(`non-well-formed element: found end tag "${t3.name}" but expected ${h(a2.root) ? `"${a2.root.nodeName}"` : "no such tag"}`, t3), a2 = a2.parent;
            continue;
        }
      } else m2.push(t3);
    }
    n3.value.success || Fr(y2.entity ? `replacement text for entity ${y2.entity}` : r2 === c2 ? "document" : "fragment", t2, n3.value.expected, n3.value.offset), a2.entityRoot || Vr(`${y2.entity ? `replacement text for entity "${y2.entity}"` : r2 === c2 ? "document" : "fragment"} is not well-formed - element "${a2.root.nodeName}" is missing a closing tag`, a2.event.name), y2 = y2.parent, y2 && (w2.exit(), a2 = a2.parent);
  }
  g2();
}
function to(t2, n2 = {}) {
  const e2 = new Document();
  return Jr(t2, Rr, Kr, e2, n2), e2;
}
var no = class _no {
  constructor(t2) {
    this.Y = /* @__PURE__ */ new Map(), this.H = /* @__PURE__ */ new Map(), this.X = t2;
  }
  static new() {
    const t2 = new _no(null);
    return t2.add(null, null), t2.add("xml", Ct), t2.add("xmlns", Dt), t2;
  }
  add(t2, n2) {
    const e2 = this.H.get(n2);
    void 0 === e2 ? this.H.set(n2, [t2]) : e2.push(t2), this.Y.set(t2, n2);
  }
  recordNamespaceInformation(t2) {
    const n2 = new _no(this);
    for (const e2 of t2.attributes) {
      if (e2.namespaceURI !== Dt) continue;
      const t3 = "" === e2.value ? null : e2.value, r2 = null === e2.prefix ? null : e2.localName;
      n2.add(r2, t3);
    }
    return n2;
  }
  j(t2) {
    return this.Y.get(t2);
  }
  K(t2) {
    var n2;
    return null === (n2 = this.X) || void 0 === n2 ? void 0 : n2.prefixToNamespace(t2);
  }
  prefixToNamespace(t2) {
    const n2 = this.j(t2);
    return void 0 !== n2 ? n2 : this.K(t2);
  }
  shouldSerializeDeclaration(t2, n2) {
    return this.prefixToNamespace(t2) === n2 && this.K(t2) !== n2;
  }
  G(t2, n2) {
    let e2 = this;
    for (; e2; ) {
      const r2 = e2.H.get(t2);
      if (void 0 !== r2) for (let e3 = r2.length - 1; e3 >= 0; --e3) {
        const o2 = r2[e3];
        if ((n2 || null !== o2) && this.prefixToNamespace(o2) === t2) return o2;
      }
      e2 = e2.X;
    }
  }
  getPreferredPrefix(t2, n2) {
    var e2;
    if (t2.namespaceURI === Ct) return "xml";
    const r2 = l(t2);
    if (t2.namespaceURI === Dt) return r2 && null === t2.prefix ? null : "xmlns";
    if (r2 && null === t2.namespaceURI) return null;
    if (!r2) {
      let n3 = null !== (e2 = this.K(null)) && void 0 !== e2 ? e2 : null;
      if (t2.namespaceURI === n3) return null;
    }
    if ((!r2 || null !== t2.prefix) && this.prefixToNamespace(t2.prefix) === t2.namespaceURI) return t2.prefix;
    const o2 = this.G(t2.namespaceURI, !r2);
    if (void 0 !== o2) return o2;
    if (r2) {
      const e3 = this.j(t2.prefix);
      if (!(null !== t2.prefix && (void 0 === e3 || e3 === t2.namespaceURI))) for (; ; ) {
        const t3 = `ns${n2.value}`;
        if (n2.value += 1, void 0 === this.j(t3)) return t3;
      }
    }
    return t2.prefix;
  }
};
var eo = ["area", "base", "basefont", "bgsound", "br", "col", "embed", "frame", "hr", "img", "input", "keygen", "link", "menuitem", "meta", "param", "source", "track", "wbr"];
function ro(t2, n2, e2 = false) {
  const r2 = e2 ? [t2] : t2.childNodes, o2 = [];
  for (const t3 of r2) oo(t3, n2, o2);
  return o2.join("");
}
function oo(t2, n2, e2) {
  const r2 = no.new(), o2 = { value: 1 };
  try {
    io(t2, r2, o2, n2, e2);
  } catch (t3) {
    return I(t3.message);
  }
}
function io(t2, n2, e2, r2, o2) {
  switch (t2.nodeType) {
    case 1:
      return void (function(t3, n3, e3, r3, o3) {
        const i2 = t3;
        if (r3 && (i2.localName.indexOf(":") >= 0 || !_r(i2.localName))) throw new Error(`Can not serialize an element because the localName "${i2.localName}" is not allowed.`);
        o3.push("<");
        let s2 = "", u2 = false;
        const l2 = n3.recordNamespaceInformation(i2);
        if ("xmlns" === i2.prefix && r3) throw new Error('Can not serialize an element with prefix "xmlns" because it will not legally round-trip in a conforming XML parser.');
        const c2 = l2.getPreferredPrefix(i2, e3);
        null !== c2 && (s2 += `${c2}:`);
        s2 += i2.localName, o3.push(s2), l2.prefixToNamespace(c2) !== i2.namespaceURI && (l2.add(c2, i2.namespaceURI), null === c2 ? o3.push(' xmlns="') : o3.push(" xmlns:", c2, '="'), o3.push(so(i2.namespaceURI, r3), '"'));
        (function(t4, n4, e4, r4, o4) {
          const i3 = [];
          for (const s3 of t4.attributes) {
            let t5 = n4.getPreferredPrefix(s3, e4);
            if (s3.namespaceURI === Dt) {
              const t6 = "" === s3.value ? null : s3.value;
              if (r4 && t6 === Dt) throw new Error("The serialization of this attribute would produce invalid XML because the XMLNS namespace is reserved and cannot be applied as an element's namespace via XML parsing.");
              if (t6 === Ct || t6 === Dt) continue;
              const e5 = null === s3.prefix ? null : s3.localName;
              if (r4 && null !== s3.prefix && "" === s3.value) throw new Error("Namespace prefix declarations cannot be used to undeclare a namespace. Use a default namespace declaration instead.");
              if (!n4.shouldSerializeDeclaration(e5, t6)) continue;
            }
            if (r4 && i3.find(((t6) => t6.localName === s3.localName && t6.namespaceURI === s3.namespaceURI))) throw new Error(`Can not serialize a duplicate attribute for namespaceURI "${s3.namespaceURI}", localName "${s3.localName}".`);
            if (i3.push({ namespaceURI: s3.namespaceURI, localName: s3.localName }), r4 && (s3.localName.indexOf(":") >= 0 || !_r(s3.localName) || "xmlns" === s3.localName && null === s3.namespaceURI)) throw new Error(`Can not serialize an attribute because the localName "${s3.localName}" is not allowed.`);
            null !== t5 && n4.prefixToNamespace(t5) !== s3.namespaceURI && (o4.push(" xmlns:", t5, '="', so(s3.namespaceURI, r4), '"'), n4.add(t5, s3.namespaceURI)), o4.push(" "), null !== t5 && o4.push(t5, ":"), o4.push(s3.localName, '="', so(s3.value, r4), '"');
          }
        })(i2, l2, e3, r3, o3), i2.namespaceURI === Tt && !i2.hasChildNodes() && eo.indexOf(i2.localName) >= 0 && (o3.push(" /"), u2 = true);
        i2.namespaceURI === Tt || i2.hasChildNodes() || (o3.push("/"), u2 = true);
        if (o3.push(">"), u2) return;
        for (const n4 of t3.childNodes) io(n4, l2, e3, r3, o3);
        o3.push("</", s2, ">");
      })(t2, n2, e2, r2, o2);
    case 9:
      return void (function(t3, n3, e3, r3, o3) {
        const i2 = t3;
        if (r3 && null === i2.documentElement) throw new Error("Can not serialize a document with no documentElement.");
        for (const t4 of i2.childNodes) io(t4, n3, e3, r3, o3);
      })(t2, n2, e2, r2, o2);
    case 8:
      return void (function(t3, n3, e3) {
        const r3 = t3;
        if (n3 && (!Ur(r3.data) || r3.data.indexOf("--") >= 0 || r3.data.endsWith("-"))) throw new Error("Can not serialize a comment because it contains invalid characters.");
        e3.push("<!--", r3.data, "-->");
      })(t2, r2, o2);
    case 4:
      return void (function(t3, n3, e3) {
        const r3 = t3;
        e3.push("<![CDATA[", r3.data, "]]>");
      })(t2, 0, o2);
    case 3:
      return void (function(t3, n3, e3) {
        const r3 = t3;
        if (n3 && !Ur(r3.data)) throw new Error("Can not serialize a text node because it contains invalid characters.");
        let o3 = r3.data;
        o3 = o3.replace(/&/g, "&amp;"), o3 = o3.replace(/</g, "&lt;"), o3 = o3.replace(/>/g, "&gt;"), e3.push(o3);
      })(t2, r2, o2);
    case 11:
      return void (function(t3, n3, e3, r3, o3) {
        for (const i2 of t3.childNodes) io(i2, n3, e3, r3, o3);
      })(t2, n2, e2, r2, o2);
    case 10:
      return void (function(t3, n3, e3) {
        const r3 = t3;
        if (n3 && (o3 = r3.publicId, !Le(o3, 0).success)) throw new Error("Can not serialize a document type because the publicId contains invalid characters.");
        var o3;
        if (n3 && (!Ur(r3.systemId) || r3.systemId.indexOf('"') >= 0 && r3.systemId.indexOf("'") >= 0)) throw new Error("Can not serialize a document type because the systemId contains invalid characters.");
        e3.push("<!DOCTYPE"), e3.push(" "), e3.push(r3.name), "" !== r3.publicId && e3.push(' PUBLIC "', r3.publicId, '"');
        "" !== r3.systemId && "" === r3.publicId && e3.push(" SYSTEM");
        "" !== r3.systemId && e3.push(' "', r3.systemId, '"');
        e3.push(">");
      })(t2, r2, o2);
    case 7:
      return void (function(t3, n3, e3) {
        const r3 = t3;
        if (n3) {
          if (r3.target.indexOf(":") >= 0) throw new Error(`Can not serialize a processing instruction because the target "${r3.target}" may not contain ":".`);
          if ("xml" === r3.target.toLowerCase()) throw new Error('Can not serialize a processing instruction because "xml" may not be used as target.');
        }
        if (n3 && (!Ur(r3.data) || r3.data.indexOf("?>") >= 0)) throw new Error("Can not serialize a processing instruction because the data contains invalid characters.");
        e3.push("<?", r3.target, " ", r3.data, "?>");
      })(t2, r2, o2);
    case 2:
      return;
    default:
      throw new TypeError("Only Nodes and Attr objects can be serialized by this algorithm.");
  }
}
function so(t2, n2) {
  if (n2 && null !== t2 && !Ur(t2)) throw new Error("Can not serialize an attribute value because it contains invalid characters.");
  return null === t2 ? "" : t2.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\t/g, "&#9;").replace(/\n/g, "&#10;").replace(/\r/g, "&#13;");
}
var Element = class extends Node {
  get nodeType() {
    return 1;
  }
  get nodeName() {
    return this.tagName;
  }
  get nodeValue() {
    return null;
  }
  set nodeValue(t2) {
  }
  get textContent() {
    return Q(this);
  }
  set textContent(t2) {
    K(this, t2 = lt(t2));
  }
  lookupPrefix(t2) {
    return N(arguments, 1), null === (t2 = ht(t2)) || "" === t2 ? null : It(this, t2);
  }
  lookupNamespaceURI(t2) {
    if (N(arguments, 1), "" === (t2 = ht(t2)) && (t2 = null), null !== this.namespaceURI && this.prefix === t2) return this.namespaceURI;
    let n2 = null;
    if (null !== t2) {
      const e3 = this.getAttributeNodeNS(Dt, t2);
      e3 && "xmlns" === e3.prefix && (n2 = e3.value);
    } else {
      const t3 = this.getAttributeNodeNS(Dt, "xmlns");
      t3 && null === t3.prefix && (n2 = t3.value);
    }
    if (null !== n2) return "" !== n2 ? n2 : null;
    const e2 = this.parentElement;
    return null === e2 ? null : e2.lookupNamespaceURI(t2);
  }
  before(...t2) {
    nt(this, t2);
  }
  after(...t2) {
    et(this, t2);
  }
  replaceWith(...t2) {
    rt(this, t2);
  }
  remove() {
    ot(this);
  }
  get children() {
    return O(this);
  }
  prepend(...t2) {
    J(this, t2);
  }
  append(...t2) {
    Z(this, t2);
  }
  replaceChildren(...t2) {
    tt(this, t2);
  }
  get previousElementSibling() {
    return V(this);
  }
  get nextElementSibling() {
    return F(this);
  }
  constructor(t2, n2, e2) {
    super(), this.firstElementChild = null, this.lastElementChild = null, this.childElementCount = 0, this.attributes = [], this.namespaceURI = t2, this.prefix = n2, this.localName = e2, this.tagName = null === n2 ? e2 : `${n2}:${e2}`;
  }
  hasAttributes() {
    return this.attributes.length > 0;
  }
  getAttribute(t2) {
    N(arguments, 1);
    const n2 = lo(t2 = String(t2), this);
    return null === n2 ? null : n2.value;
  }
  getAttributeNS(t2, n2) {
    N(arguments, 2);
    const e2 = co(t2 = ht(t2), n2 = String(n2), this);
    return null === e2 ? null : e2.value;
  }
  setAttribute(t2, n2) {
    N(arguments, 2), t2 = String(t2), n2 = String(n2), _r(t2) || $("The qualified name does not match the Name production");
    const e2 = lo(t2, this);
    if (null === e2) {
      const e3 = new (s()).Attr(null, null, t2, n2, this);
      return e3.ownerDocument = this.ownerDocument, void gt(e3, this);
    }
    pt(e2, n2);
  }
  setAttributeNS(t2, n2, e2) {
    N(arguments, 3), t2 = ht(t2), n2 = String(n2), e2 = String(e2);
    const { namespace: r2, prefix: o2, localName: i2 } = At(t2, n2);
    !(function(t3, n3, e3, r3, o3) {
      const i3 = co(o3, n3, t3);
      if (null === i3) {
        const i4 = new (s()).Attr(o3, r3, n3, e3, t3);
        return i4.ownerDocument = t3.ownerDocument, void gt(i4, t3);
      }
      pt(i3, e3);
    })(this, i2, e2, o2, r2);
  }
  removeAttribute(t2) {
    N(arguments, 1), ho(t2 = String(t2), this);
  }
  removeAttributeNS(t2, n2) {
    N(arguments, 2), (function(t3, n3, e2) {
      const r2 = co(t3, n3, e2);
      null !== r2 && wt(r2);
    })(t2 = ht(t2), n2 = String(n2), this);
  }
  toggleAttribute(t2, n2) {
    _r(t2) || $("The qualified name does not match the Name production");
    if (null === lo(t2, this)) {
      if (void 0 === n2 || true === n2) {
        const n3 = new (s()).Attr(null, null, t2, "", this);
        return n3.ownerDocument = this.ownerDocument, gt(n3, this), true;
      }
      return false;
    }
    return void 0 !== n2 && false !== n2 || (ho(t2, this), false);
  }
  hasAttribute(t2) {
    return N(arguments, 1), null !== lo(t2 = String(t2), this);
  }
  hasAttributeNS(t2, n2) {
    return N(arguments, 2), null !== co(t2 = ht(t2), n2 = String(n2), this);
  }
  getAttributeNode(t2) {
    return N(arguments, 1), lo(t2 = String(t2), this);
  }
  getAttributeNodeNS(t2, n2) {
    return N(arguments, 2), co(t2 = ht(t2), n2 = String(n2), this);
  }
  setAttributeNode(t2) {
    return N(arguments, 1), ao(t2 = ct(t2, Attr), this);
  }
  setAttributeNodeNS(t2) {
    return N(arguments, 1), ao(t2 = ct(t2, Attr), this);
  }
  removeAttributeNode(t2) {
    return N(arguments, 1), t2 = ct(t2, Attr), this.attributes.indexOf(t2) < 0 && M("the specified attribute does not exist"), wt(t2), t2;
  }
  getElementsByTagName(t2) {
    return N(arguments, 1), v(t2 = String(t2), this);
  }
  getElementsByTagNameNS(t2, n2) {
    return N(arguments, 2), b(t2 = ht(t2), n2 = String(n2), this);
  }
  T(t2) {
    const n2 = uo(t2, this.localName, this.namespaceURI, this.prefix);
    for (const e2 of this.attributes) {
      const r2 = e2.T(t2);
      n2.setAttributeNode(r2);
    }
    return n2;
  }
  get innerHTML() {
    return ro(this, true);
  }
  get outerHTML() {
    return ro(this, true, true);
  }
};
function uo(t2, n2, e2, r2 = null) {
  let o2 = null;
  return o2 = new (s()).Element(e2, r2, n2), o2.ownerDocument = t2, o2;
}
function lo(t2, n2) {
  return n2.attributes.find(((n3) => n3.name === t2)) || null;
}
function co(t2, n2, e2) {
  return "" === t2 && (t2 = null), e2.attributes.find(((e3) => e3.namespaceURI === t2 && e3.localName === n2)) || null;
}
function ao(t2, n2) {
  null !== t2.ownerElement && t2.ownerElement !== n2 && (function(t3) {
    throw T("InUseAttributeError", t3);
  })("attribute is in use by another element");
  const e2 = co(t2.namespaceURI, t2.localName, n2);
  return e2 === t2 ? t2 : (null !== e2 ? (function(t3, n3) {
    const e3 = t3.ownerElement;
    mt(t3, e3, t3.value, n3.value), e3.attributes.splice(e3.attributes.indexOf(t3), 1, n3), n3.ownerElement = e3, t3.ownerElement = null;
  })(e2, t2) : gt(t2, n2), e2);
}
function ho(t2, n2) {
  const e2 = lo(t2, n2);
  return null !== e2 && wt(e2), e2;
}
function fo(t2, n2, e2) {
  const { namespace: r2, prefix: o2, localName: i2 } = At(n2, e2);
  return uo(t2, i2, r2, o2);
}
var DOMImplementation = class {
  constructor(t2) {
    this.J = t2;
  }
  createDocumentType(t2, n2, e2) {
    N(arguments, 3), t2 = String(t2), n2 = String(n2), e2 = String(e2), $t(t2);
    const r2 = new (s(this.J)).DocumentType(t2, n2, e2);
    return r2.ownerDocument = this.J, r2;
  }
  createDocument(t2, n2, e2 = null) {
    N(arguments, 2), t2 = ht(t2), n2 = ut(n2), e2 = at(e2, DocumentType);
    const r2 = new (s(this.J)).XMLDocument();
    let o2 = null;
    return "" !== n2 && (o2 = fo(r2, t2, n2)), e2 && r2.appendChild(e2), o2 && r2.appendChild(o2), r2;
  }
  createHTMLDocument(t2) {
    t2 = ht(t2);
    const n2 = s(this.J), e2 = new n2.Document(), r2 = new n2.DocumentType("html");
    r2.ownerDocument = e2, e2.appendChild(r2);
    const o2 = uo(e2, "html", Tt);
    e2.appendChild(o2);
    const i2 = uo(e2, "head", Tt);
    if (o2.appendChild(i2), null !== t2) {
      const n3 = uo(e2, "title", Tt);
      i2.appendChild(n3), n3.appendChild(e2.createTextNode(t2));
    }
    return o2.appendChild(uo(e2, "body", Tt)), e2;
  }
};
var Document = class extends Node {
  get nodeType() {
    return 9;
  }
  get nodeName() {
    return "#document";
  }
  get nodeValue() {
    return null;
  }
  set nodeValue(t2) {
  }
  get textContent() {
    return null;
  }
  set textContent(t2) {
  }
  lookupPrefix(t2) {
    return N(arguments, 1), null !== this.documentElement ? this.documentElement.lookupPrefix(t2) : null;
  }
  lookupNamespaceURI(t2) {
    return N(arguments, 1), null === this.documentElement ? null : this.documentElement.lookupNamespaceURI(t2);
  }
  get children() {
    return O(this);
  }
  prepend(...t2) {
    J(this, t2);
  }
  append(...t2) {
    Z(this, t2);
  }
  replaceChildren(...t2) {
    tt(this, t2);
  }
  constructor() {
    super(), this.firstElementChild = null, this.lastElementChild = null, this.childElementCount = 0, this.implementation = new DOMImplementation(this), this.doctype = null, this.documentElement = null;
  }
  getElementsByTagName(t2) {
    return N(arguments, 1), v(t2 = String(t2), this);
  }
  getElementsByTagNameNS(t2, n2) {
    return N(arguments, 2), b(t2 = ht(t2), n2 = String(n2), this);
  }
  createElement(t2) {
    N(arguments, 1), _r(t2 = String(t2)) || $("The local name is not a valid Name");
    return uo(this, t2, null, null);
  }
  createElementNS(t2, n2) {
    return N(arguments, 2), fo(this, t2 = ht(t2), n2 = String(n2));
  }
  createDocumentFragment() {
    const t2 = new (s()).DocumentFragment();
    return t2.ownerDocument = this, t2;
  }
  createTextNode(t2) {
    N(arguments, 1), t2 = String(t2);
    const n2 = new (s()).Text(t2);
    return n2.ownerDocument = this, n2;
  }
  createCDATASection(t2) {
    N(arguments, 1), (t2 = String(t2)).indexOf("]]>") >= 0 && $('Data must not contain the string "]]>"');
    const n2 = new (s()).CDATASection(t2);
    return n2.ownerDocument = this, n2;
  }
  createComment(t2) {
    N(arguments, 1), t2 = String(t2);
    const n2 = new (s()).Comment(t2);
    return n2.ownerDocument = this, n2;
  }
  createProcessingInstruction(t2, n2) {
    N(arguments, 2), t2 = String(t2), n2 = String(n2), _r(t2) || $("The target is not a valid Name"), n2.indexOf("?>") >= 0 && $('Data must not contain the string "?>"');
    const e2 = new (s()).ProcessingInstruction(t2, n2);
    return e2.ownerDocument = this, e2;
  }
  importNode(t2, n2 = false) {
    return N(arguments, 1), u(t2 = ct(t2, Node), 9) && R("importing a Document node is not supported"), x(t2, n2, this);
  }
  adoptNode(t2) {
    return N(arguments, 1), u(t2 = ct(t2, Node), 9) && R("adopting a Document node is not supported"), j(t2, this), t2;
  }
  createAttribute(t2) {
    N(arguments, 1), _r(t2 = String(t2)) || $("The local name is not a valid Name");
    const n2 = new (s()).Attr(null, null, t2, "", null);
    return n2.ownerDocument = this, n2;
  }
  createAttributeNS(t2, n2) {
    N(arguments, 2), t2 = ht(t2), n2 = String(n2);
    const { namespace: e2, prefix: r2, localName: o2 } = At(t2, n2), i2 = new (s()).Attr(e2, r2, o2, "", null);
    return i2.ownerDocument = this, i2;
  }
  createRange() {
    const t2 = new (s()).Range();
    return t2.startContainer = this, t2.startOffset = 0, t2.endContainer = this, t2.endOffset = 0, t2;
  }
  T(t2) {
    return new (s()).Document();
  }
};
var DocumentFragment = class extends Node {
  get nodeType() {
    return 11;
  }
  get nodeName() {
    return "#document-fragment";
  }
  get nodeValue() {
    return null;
  }
  set nodeValue(t2) {
  }
  get textContent() {
    return Q(this);
  }
  set textContent(t2) {
    K(this, t2 = lt(t2));
  }
  lookupPrefix(t2) {
    return N(arguments, 1), null;
  }
  lookupNamespaceURI(t2) {
    return N(arguments, 1), null;
  }
  get children() {
    return O(this);
  }
  prepend(...t2) {
    J(this, t2);
  }
  append(...t2) {
    Z(this, t2);
  }
  replaceChildren(...t2) {
    tt(this, t2);
  }
  constructor() {
    super(), this.firstElementChild = null, this.lastElementChild = null, this.childElementCount = 0;
    const t2 = s();
    this.ownerDocument = t2.document;
  }
  T(t2) {
    const n2 = new (s()).DocumentFragment();
    return n2.ownerDocument = t2, n2;
  }
};
var ProcessingInstruction = class extends CharacterData {
  get nodeType() {
    return 7;
  }
  get nodeName() {
    return this.target;
  }
  constructor(t2, n2) {
    super(n2), this.target = t2;
  }
  T(t2) {
    const n2 = new (s()).ProcessingInstruction(this.target, this.data);
    return n2.ownerDocument = t2, n2;
  }
};
function po(t2, n2) {
  if (t2.collapsed) return;
  const e2 = m(t2.startContainer), r2 = m(t2.endContainer);
  let o2 = 0;
  for (; o2 < e2.length && o2 < r2.length && e2[o2] === r2[o2]; ) ++o2;
  const i2 = t2.endContainer.childNodes[t2.endOffset] || null;
  for (let o3 = t2.startContainer.childNodes[t2.startOffset] || null; o3 && o3 !== i2 && o3 !== r2[e2.length]; o3 = o3.nextSibling) n2(o3);
  for (let t3 = e2.length - 1; t3 >= o2; --t3) for (let o3 = e2[t3].nextSibling; o3 && o3 !== i2 && o3 !== r2[t3]; o3 = o3.nextSibling) n2(o3);
  for (let t3 = o2; t3 < r2.length; ++t3) for (let e3 = r2[t3].firstChild; e3 && e3 !== i2 && e3 !== r2[t3 + 1]; e3 = e3.nextSibling) n2(e3);
}
function go(t2, n2) {
  const e2 = p(t2.startContainer), r2 = e2.createDocumentFragment();
  if (t2.collapsed) return r2;
  const o2 = t2.startContainer, i2 = t2.startOffset, s2 = t2.endContainer, l2 = t2.endOffset;
  if (o2 === s2 && c(o2)) {
    const t3 = o2.cloneNode();
    return t3.data = o2.substringData(i2, l2 - i2), W(t3, r2), n2 || o2.replaceData(i2, l2 - i2, ""), r2;
  }
  const a2 = m(t2.startContainer), h2 = m(t2.endContainer);
  let f2 = 0;
  for (; f2 < a2.length && f2 < h2.length && a2[f2] === h2[f2]; ) ++f2;
  const w2 = f2 === a2.length, y2 = f2 === h2.length;
  let v2 = null;
  w2 || (v2 = a2[f2]);
  let b2 = null;
  y2 || (b2 = h2[f2]);
  const x2 = [], N2 = v2 ? v2.nextSibling : o2.childNodes[i2], S2 = b2 || s2.childNodes[l2] || null;
  for (var E2 = N2; E2 && E2 !== S2; E2 = E2.nextSibling) u(E2, 10) && C(n2 ? "Can not clone a doctype using cloneContents" : "Can not extract a doctype using extractContents"), x2.push(E2);
  let T2, D2;
  if (w2 || n2) T2 = o2, D2 = i2;
  else {
    const t3 = a2[f2];
    T2 = t3.parentNode, D2 = 1 + g(t3);
  }
  if (null !== v2 && c(v2)) {
    const t3 = v2.cloneNode();
    t3.data = v2.substringData(i2, v2.length - i2), W(t3, r2), n2 || v2.replaceData(i2, v2.length - i2, "");
  } else if (null !== v2) {
    const t3 = v2.cloneNode();
    W(t3, r2);
    const s3 = e2.createRange();
    s3.setStart(o2, i2), s3.setEnd(v2, d(v2));
    const u2 = go(s3, n2);
    s3.detach(), W(u2, t3);
  }
  if (x2.forEach(((t3) => {
    if (n2) {
      W(t3.cloneNode(true), r2);
    } else W(t3, r2);
  })), b2 && c(b2)) {
    const t3 = b2.cloneNode();
    t3.data = b2.substringData(0, l2), W(t3, r2), n2 || b2.replaceData(0, l2, "");
  } else if (null !== b2) {
    const t3 = b2.cloneNode();
    W(t3, r2);
    const o3 = e2.createRange();
    o3.setStart(b2, 0), o3.setEnd(s2, l2);
    const i3 = go(o3, n2);
    o3.detach(), W(i3, t3);
  }
  return n2 || (t2.setStart(T2, D2), t2.collapse(true)), r2;
}
var Range = class _Range {
  get collapsed() {
    return (t2 = this).startContainer === t2.endContainer && t2.startOffset === t2.endOffset;
    var t2;
  }
  constructor() {
    const t2 = s();
    this.startContainer = t2.document, this.startOffset = 0, this.endContainer = t2.document, this.endOffset = 0, t2.addRange(this);
  }
  get commonAncestorContainer() {
    const t2 = m(this.startContainer), n2 = m(this.endContainer);
    let e2 = t2[0], r2 = 0;
    for (; r2 < t2.length && r2 < n2.length && t2[r2] === n2[r2]; ) e2 = t2[r2], ++r2;
    return e2;
  }
  setStart(t2, n2) {
    N(arguments, 2), t2 = ct(t2, Node), n2 = st(n2), u(t2, 10) && A("Can not set a range under a doctype node"), n2 > d(t2) && D("Can not set a range past the end of the node");
    bo(this) === w(t2) && vo(t2, n2, this.endContainer, this.endOffset) !== yo || (this.endContainer = t2, this.endOffset = n2), this.startContainer = t2, this.startOffset = n2;
  }
  setEnd(t2, n2) {
    N(arguments, 2), t2 = ct(t2, Node), n2 = st(n2), u(t2, 10) && A("Can not set a range under a doctype node"), n2 > d(t2) && D("Can not set a range past the end of the node");
    bo(this) === w(t2) && vo(t2, n2, this.startContainer, this.startOffset) !== wo || (this.startContainer = t2, this.startOffset = n2), this.endContainer = t2, this.endOffset = n2;
  }
  setStartBefore(t2) {
    N(arguments, 1);
    const n2 = (t2 = ct(t2, Node)).parentNode;
    if (null === n2) return A("Can not set range before node without a parent");
    this.setStart(n2, g(t2));
  }
  setStartAfter(t2) {
    N(arguments, 1);
    const n2 = (t2 = ct(t2, Node)).parentNode;
    if (null === n2) return A("Can not set range before node without a parent");
    this.setStart(n2, g(t2) + 1);
  }
  setEndBefore(t2) {
    N(arguments, 1);
    const n2 = (t2 = ct(t2, Node)).parentNode;
    if (null === n2) return A("Can not set range before node without a parent");
    this.setEnd(n2, g(t2));
  }
  setEndAfter(t2) {
    N(arguments, 1);
    const n2 = (t2 = ct(t2, Node)).parentNode;
    if (null === n2) return A("Can not set range before node without a parent");
    this.setEnd(n2, g(t2) + 1);
  }
  collapse(t2 = false) {
    t2 ? (this.endContainer = this.startContainer, this.endOffset = this.startOffset) : (this.startContainer = this.endContainer, this.startOffset = this.endOffset);
  }
  selectNode(t2) {
    N(arguments, 1);
    let n2 = (t2 = ct(t2, Node)).parentNode;
    if (null === n2) return A("Can not select node with null parent");
    const e2 = g(t2);
    this.startContainer = n2, this.startOffset = e2, this.endContainer = n2, this.endOffset = e2 + 1;
  }
  selectNodeContents(t2) {
    N(arguments, 1), u(t2 = ct(t2, Node), 10) && A("Can not place range inside a doctype node");
    const n2 = d(t2);
    this.startContainer = t2, this.startOffset = 0, this.endContainer = t2, this.endOffset = n2;
  }
  compareBoundaryPoints(t2, n2) {
    switch (N(arguments, 2), n2 = ct(n2, _Range), t2 !== _Range.START_TO_START && t2 !== _Range.START_TO_END && t2 !== _Range.END_TO_END && t2 !== _Range.END_TO_START && R("Unsupported comparison type"), bo(this) !== bo(n2) && P("Can not compare positions of ranges in different trees"), t2) {
      case _Range.START_TO_START:
        return vo(this.startContainer, this.startOffset, n2.startContainer, n2.startOffset);
      case _Range.START_TO_END:
        return vo(this.endContainer, this.endOffset, n2.startContainer, n2.startOffset);
      case _Range.END_TO_END:
        return vo(this.endContainer, this.endOffset, n2.endContainer, n2.endOffset);
      default:
        return vo(this.startContainer, this.startOffset, n2.endContainer, n2.endOffset);
    }
  }
  deleteContents() {
    if (this.collapsed) return;
    const t2 = this.startContainer, n2 = this.startOffset, e2 = this.endContainer, r2 = this.endOffset;
    if (t2 === e2 && c(t2)) return void t2.replaceData(n2, r2 - n2, "");
    const o2 = [];
    let i2, s2;
    if (po(this, ((t3) => {
      o2.push(t3);
    })), t2.contains(e2)) i2 = t2, s2 = n2;
    else {
      let n3 = t2;
      for (; null !== n3.parentNode && !n3.parentNode.contains(e2); ) n3 = n3.parentNode;
      i2 = n3.parentNode, s2 = 1 + g(n3);
    }
    c(t2) && t2.replaceData(n2, t2.length - n2, ""), o2.forEach(((t3) => {
      H(t3);
    })), c(e2) && e2.replaceData(0, r2, ""), this.setStart(i2, s2), this.collapse(true);
  }
  extractContents() {
    return go(this, false);
  }
  cloneContents() {
    return go(this, true);
  }
  insertNode(t2) {
    N(arguments, 1), it(t2 = ct(t2, Node), this);
  }
  surroundContents(t2) {
    N(arguments, 1), t2 = ct(t2, Node);
    (a(this.startContainer) ? this.startContainer.parentNode : this.startContainer) !== (a(this.endContainer) ? this.endContainer.parentNode : this.endContainer) && I("Can not use surroundContents on a range that has partially selected a non-Text node"), u(t2, 9, 10, 11) && A("Can not use Document, DocumentType, or DocumentFragment as a parent node in surroundContents");
    const n2 = go(this, false);
    t2.firstChild && Y(null, t2), it(t2, this), W(n2, t2), this.selectNode(t2);
  }
  cloneRange() {
    const t2 = new (s()).Range();
    return t2.startContainer = this.startContainer, t2.startOffset = this.startOffset, t2.endContainer = this.endContainer, t2.endOffset = this.endOffset, t2;
  }
  detach() {
    s().removeRange(this);
  }
  isPointInRange(t2, n2) {
    return N(arguments, 2), t2 = ct(t2, Node), n2 = st(n2), w(t2) === bo(this) && (u(t2, 10) && A("Point can not be under a doctype"), n2 > d(t2) && D("Offset should not be past the end of node"), vo(t2, n2, this.startContainer, this.startOffset) !== wo && vo(t2, n2, this.endContainer, this.endOffset) !== yo);
  }
  comparePoint(t2, n2) {
    return N(arguments, 2), t2 = ct(t2, Node), n2 = st(n2), w(t2) !== bo(this) && P("Can not compare point to range in different trees"), u(t2, 10) && A("Point can not be under a doctype"), n2 > d(t2) && D("Offset should not be past the end of node"), vo(t2, n2, this.startContainer, this.startOffset) === wo ? -1 : vo(t2, n2, this.endContainer, this.endOffset) === yo ? 1 : 0;
  }
  intersectsNode(t2) {
    if (N(arguments, 1), w(t2 = ct(t2, Node)) !== bo(this)) return false;
    const n2 = t2.parentNode;
    if (null === n2) return true;
    const e2 = g(t2);
    return vo(n2, e2, this.endContainer, this.endOffset) === wo && vo(n2, e2 + 1, this.startContainer, this.startOffset) === yo;
  }
  toString() {
    let t2 = [];
    const n2 = this.startContainer;
    if (a(n2)) {
      if (this.startContainer === this.endContainer) return n2.substringData(this.startOffset, this.endOffset - this.startOffset);
      t2.push(n2.substringData(this.startOffset, n2.length - this.startOffset));
    }
    po(this, ((n3) => {
      y(n3, ((n4) => {
        a(n4) && t2.push(n4.data);
      }));
    }));
    const e2 = this.endContainer;
    return a(e2) && t2.push(e2.substringData(0, this.endOffset)), t2.join("");
  }
};
Range.START_TO_START = 0, Range.START_TO_END = 1, Range.END_TO_END = 2, Range.END_TO_START = 3;
var wo = -1;
var yo = 1;
function vo(t2, n2, e2, r2) {
  if (t2 !== e2) {
    const o2 = m(t2), i2 = m(e2);
    for (; o2[0] && i2[0] && o2[0] === i2[0]; ) o2.shift(), i2.shift();
    o2.length && (n2 = g(o2[0]) + 0.5), i2.length && (r2 = g(i2[0]) + 0.5);
  }
  return n2 === r2 ? 0 : n2 < r2 ? wo : yo;
}
function bo(t2) {
  return w(t2.startContainer);
}
var XMLDocument = class extends Document {
  T(t2) {
    return new (s()).XMLDocument();
  }
};
function xo(t2) {
  const n2 = [];
  return oo(t2 = ct(t2, Node), true, n2), n2.join("");
}
var No = new Document();
i.document = No, i.Attr = Attr, i.CDATASection = CDATASection, i.Comment = xt, i.Document = Document, i.DocumentFragment = DocumentFragment, i.DocumentType = DocumentType, i.DOMImplementation = DOMImplementation, i.Element = Element, i.ProcessingInstruction = ProcessingInstruction, i.Range = Range, i.Text = Text, i.XMLDocument = XMLDocument;

// ../../../../private/var/folders/zz/kt313rb55md8rrvyvvvrg15r0000gn/T/coco-skill-build-hCL2vS/node_modules/@coco-vexel/coco-office/dist/excel.js
var __defProp2 = Object.defineProperty;
var __defProps = Object.defineProperties;
var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __hasOwnProp2 = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key2, value) => key2 in obj ? __defProp2(obj, key2, { enumerable: true, configurable: true, writable: true, value }) : obj[key2] = value;
var __spreadValues = (a2, b2) => {
  for (var prop in b2 || (b2 = {}))
    if (__hasOwnProp2.call(b2, prop))
      __defNormalProp(a2, prop, b2[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b2)) {
      if (__propIsEnum.call(b2, prop))
        __defNormalProp(a2, prop, b2[prop]);
    }
  return a2;
};
var __spreadProps = (a2, b2) => __defProps(a2, __getOwnPropDescs(b2));
var __name = (target, value) => __defProp2(target, "name", { value, configurable: true });
var __objRest = (source, exclude) => {
  var target = {};
  for (var prop in source)
    if (__hasOwnProp2.call(source, prop) && exclude.indexOf(prop) < 0)
      target[prop] = source[prop];
  if (source != null && __getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(source)) {
      if (exclude.indexOf(prop) < 0 && __propIsEnum.call(source, prop))
        target[prop] = source[prop];
    }
  return target;
};
var __publicField = (obj, key2, value) => __defNormalProp(obj, typeof key2 !== "symbol" ? key2 + "" : key2, value);
function assertPath(path) {
  if (typeof path !== "string" || path.length === 0) {
    throw new Error(`invalid part path: must be non-empty string, got: ${JSON.stringify(path)}`);
  }
  if (path.startsWith("/")) {
    throw new Error(`invalid part path: must not start with '/', got: ${path}`);
  }
}
__name(assertPath, "assertPath");
function assertContentType(contentType) {
  if (typeof contentType !== "string" || contentType.length === 0) {
    throw new Error(`invalid contentType: must be non-empty string`);
  }
}
__name(assertContentType, "assertContentType");
function createXmlPart(spec) {
  assertPath(spec.path);
  assertContentType(spec.contentType);
  if (!spec.xmlDom) {
    throw new Error(`createXmlPart: xmlDom required for ${spec.path}`);
  }
  return {
    path: spec.path,
    contentType: spec.contentType,
    xmlDom: spec.xmlDom,
    _originalBytes: spec.originalBytes,
    _dirty: spec.originalBytes === void 0
  };
}
__name(createXmlPart, "createXmlPart");
function createBinaryPart(spec) {
  var _a;
  assertPath(spec.path);
  assertContentType(spec.contentType);
  if (!spec.bytes) {
    throw new Error(`createBinaryPart: bytes required for ${spec.path}`);
  }
  return {
    path: spec.path,
    contentType: spec.contentType,
    bytes: spec.bytes,
    _originalBytes: (_a = spec.originalBytes) != null ? _a : spec.bytes,
    _dirty: false
  };
}
__name(createBinaryPart, "createBinaryPart");
function markDirty(part) {
  part._dirty = true;
}
__name(markDirty, "markDirty");
function isXmlPart(part) {
  return part.xmlDom !== void 0;
}
__name(isXmlPart, "isXmlPart");
function createPackage() {
  return { parts: /* @__PURE__ */ new Map() };
}
__name(createPackage, "createPackage");
function setPart(pkg, part) {
  pkg.parts.set(part.path, part);
}
__name(setPart, "setPart");
function getPart(pkg, path) {
  return pkg.parts.get(path);
}
__name(getPart, "getPart");
function deletePart(pkg, path) {
  return pkg.parts.delete(path);
}
__name(deletePart, "deletePart");
var CONTENT_TYPES_PATH = "[Content_Types].xml";
var CONTENT_TYPES_NS = "http://schemas.openxmlformats.org/package/2006/content-types";
var CONTENT_TYPES_CTYPE = "application/vnd.openxmlformats-package.content-types+xml";
function xmlAttr(v2) {
  return v2.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
__name(xmlAttr, "xmlAttr");
function ensureContentTypes(pkg) {
  if (getPart(pkg, CONTENT_TYPES_PATH)) return false;
  const overrides = [];
  for (const part of pkg.parts.values()) {
    if (part.path === CONTENT_TYPES_PATH) continue;
    overrides.push(
      `  <Override PartName="/${xmlAttr(part.path)}" ContentType="${xmlAttr(part.contentType)}"/>`
    );
  }
  const xml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="${CONTENT_TYPES_NS}">
` + overrides.join("\n") + (overrides.length > 0 ? "\n" : "") + `</Types>`;
  setPart(
    pkg,
    createXmlPart({
      path: CONTENT_TYPES_PATH,
      contentType: CONTENT_TYPES_CTYPE,
      xmlDom: to(xml),
      originalBytes: new TextEncoder().encode(xml)
    })
  );
  return true;
}
__name(ensureContentTypes, "ensureContentTypes");
var CONTENT_TYPES_PATH2 = "[Content_Types].xml";
var CONTENT_TYPES_NS2 = "http://schemas.openxmlformats.org/package/2006/content-types";
var CONTENT_TYPES_CTYPE2 = "application/vnd.openxmlformats-package.content-types+xml";
function isXmlContentType(ct2) {
  const normalized = ct2.toLowerCase();
  if (normalized.startsWith("image/") || normalized.startsWith("audio/") || normalized.startsWith("video/") || normalized === "application/octet-stream" || normalized === "application/vnd.openxmlformats-officedocument.oleobject" || normalized.startsWith("application/vnd.ms-office.")) {
    return false;
  }
  return normalized.endsWith("+xml") || normalized === "application/xml" || normalized === "text/xml";
}
__name(isXmlContentType, "isXmlContentType");
function parseContentTypes(xml) {
  const doc = to(xml);
  const defaults2 = /* @__PURE__ */ new Map();
  const overrides = /* @__PURE__ */ new Map();
  const defaultEls = doc.getElementsByTagNameNS(CONTENT_TYPES_NS2, "Default");
  for (let i2 = 0; i2 < defaultEls.length; i2++) {
    const el = defaultEls[i2];
    if (!el) continue;
    const ext = el.getAttribute("Extension");
    const ct2 = el.getAttribute("ContentType");
    if (ext && ct2) defaults2.set(ext.toLowerCase(), ct2);
  }
  const overrideEls = doc.getElementsByTagNameNS(CONTENT_TYPES_NS2, "Override");
  for (let i2 = 0; i2 < overrideEls.length; i2++) {
    const el = overrideEls[i2];
    if (!el) continue;
    const partName = el.getAttribute("PartName");
    const ct2 = el.getAttribute("ContentType");
    if (partName && ct2) {
      overrides.set(partName.replace(/^\//, ""), ct2);
    }
  }
  return {
    resolve(partName) {
      const override = overrides.get(partName);
      if (override) return override;
      const dot = partName.lastIndexOf(".");
      if (dot === -1) return void 0;
      return defaults2.get(partName.slice(dot + 1).toLowerCase());
    }
  };
}
__name(parseContentTypes, "parseContentTypes");
async function fromZip(buf) {
  const bytes = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
  const zip = await import_jszip.default.loadAsync(bytes);
  const pkg = createPackage();
  const ctFile = zip.file(CONTENT_TYPES_PATH2);
  if (!ctFile) {
    throw new Error(`fromZip: missing ${CONTENT_TYPES_PATH2}; not a valid OOXML package`);
  }
  const ctXml = await ctFile.async("string");
  const resolver = parseContentTypes(ctXml);
  const ctBytes = await ctFile.async("uint8array");
  setPart(
    pkg,
    createXmlPart({
      path: CONTENT_TYPES_PATH2,
      contentType: CONTENT_TYPES_CTYPE2,
      xmlDom: to(ctXml),
      originalBytes: ctBytes
    })
  );
  const entryPaths = [];
  zip.forEach((relativePath, entry) => {
    if (entry.dir) return;
    if (relativePath === CONTENT_TYPES_PATH2) return;
    entryPaths.push(relativePath);
  });
  for (const path of entryPaths) {
    const entry = zip.file(path);
    if (!entry) continue;
    const contentType = resolver.resolve(path);
    if (!contentType) {
      throw new Error(
        `fromZip: no ContentType for part '${path}' (not in Default by extension, not in Override by partName)`
      );
    }
    const entryBytes = await entry.async("uint8array");
    if (isXmlContentType(contentType)) {
      const xmlText2 = await entry.async("string");
      const xmlDom = to(xmlText2);
      setPart(pkg, createXmlPart({ path, contentType, xmlDom, originalBytes: entryBytes }));
    } else {
      setPart(pkg, createBinaryPart({ path, contentType, bytes: entryBytes }));
    }
  }
  return pkg;
}
__name(fromZip, "fromZip");
async function toZip(pkg) {
  ensureContentTypes(pkg);
  const zip = new import_jszip.default();
  for (const part of pkg.parts.values()) {
    const bytes = partToBytes(part);
    zip.file(part.path, bytes, { createFolders: false });
  }
  return await zip.generateAsync({
    type: "uint8array",
    compression: "DEFLATE",
    compressionOptions: { level: 6 }
  });
}
__name(toZip, "toZip");
function partToBytes(part) {
  if (!part._dirty && part._originalBytes) {
    return part._originalBytes;
  }
  if (isXmlPart(part)) {
    if (!part.xmlDom) {
      throw new Error(`toZip: XML part '${part.path}' missing xmlDom`);
    }
    const text = xo(part.xmlDom);
    return new TextEncoder().encode(text);
  }
  if (part.bytes) return part.bytes;
  if (part._originalBytes) return part._originalBytes;
  throw new Error(`toZip: binary part '${part.path}' has no bytes`);
}
__name(partToBytes, "partToBytes");
var SS_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
var REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships";
var OFFICE_REL_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
var EXCEL_MAX_ROW = 1048576;
var EXCEL_MAX_COLUMN = 16384;
function columnNameToIndex(columnName) {
  let value = 0;
  for (const ch of columnName.toUpperCase()) {
    const code = ch.charCodeAt(0);
    if (code < 65 || code > 90) continue;
    value = value * 26 + (code - 64);
  }
  if (value <= 0) {
    throw new Error(`ExcelWorkbook: invalid column name ${columnName}`);
  }
  return value;
}
__name(columnNameToIndex, "columnNameToIndex");
function columnIndexToName(column) {
  if (!Number.isInteger(column) || column < 1) {
    throw new Error(`ExcelWorkbook: invalid column index ${column}`);
  }
  let value = column;
  let name = "";
  while (value > 0) {
    const rem = (value - 1) % 26;
    name = String.fromCharCode(65 + rem) + name;
    value = Math.floor((value - 1) / 26);
  }
  return name;
}
__name(columnIndexToName, "columnIndexToName");
function parseCellAddress(address) {
  const qualified = splitSheetQualifiedAddress(address);
  const normalized = qualified.address.replace(/\$/g, "").trim();
  const match = /^([A-Za-z]+)(\d+)$/.exec(normalized);
  if (!match) {
    throw new Error(`ExcelWorkbook: invalid cell address ${address}`);
  }
  const column = columnNameToIndex(match[1]);
  const row = Number(match[2]);
  if (!Number.isInteger(row) || row < 1) {
    throw new Error(`ExcelWorkbook: invalid cell address ${address}`);
  }
  return {
    address: `${columnIndexToName(column)}${row}`,
    column,
    row
  };
}
__name(parseCellAddress, "parseCellAddress");
function formatCellAddress(row, column) {
  if (!Number.isInteger(row) || row < 1) {
    throw new Error(`ExcelWorkbook: invalid row index ${row}`);
  }
  return `${columnIndexToName(column)}${row}`;
}
__name(formatCellAddress, "formatCellAddress");
function parseRangeAddress(address) {
  const qualified = splitSheetQualifiedAddress(address);
  const parts = qualified.address.split(":");
  if (parts.length > 2) {
    throw new Error(`ExcelWorkbook: invalid range address ${address}`);
  }
  const [startRaw, endRaw] = parts;
  if (!startRaw) {
    throw new Error(`ExcelWorkbook: invalid range address ${address}`);
  }
  const wholeColumn = parseWholeColumnRange(parts, address);
  if (wholeColumn) {
    return __spreadProps(__spreadValues({}, wholeColumn), { sheetName: qualified.sheetName });
  }
  const wholeRow = parseWholeRowRange(parts, address);
  if (wholeRow) {
    return __spreadProps(__spreadValues({}, wholeRow), { sheetName: qualified.sheetName });
  }
  const start = parseCellAddress(startRaw);
  const end = endRaw ? parseCellAddress(endRaw) : start;
  const startRow = Math.min(start.row, end.row);
  const endRow = Math.max(start.row, end.row);
  const startColumn = Math.min(start.column, end.column);
  const endColumn = Math.max(start.column, end.column);
  const first = formatCellAddress(startRow, startColumn);
  const last = formatCellAddress(endRow, endColumn);
  return {
    address: first === last ? first : `${first}:${last}`,
    sheetName: qualified.sheetName,
    startRow,
    startColumn,
    rowCount: endRow - startRow + 1,
    columnCount: endColumn - startColumn + 1
  };
}
__name(parseRangeAddress, "parseRangeAddress");
function parseWholeColumnRange(parts, originalAddress) {
  if (parts.length !== 2) return null;
  const [startRaw, endRaw] = parts;
  const startColumn = parseColumnReference(startRaw);
  const endColumn = endRaw ? parseColumnReference(endRaw) : startColumn;
  if (startColumn === null && endColumn === null) return null;
  if (startColumn === null || endColumn === null) {
    throw new Error(`ExcelWorkbook: invalid range address ${originalAddress}`);
  }
  const firstColumn = Math.min(startColumn, endColumn);
  const lastColumn = Math.max(startColumn, endColumn);
  return {
    address: formatRangeAddress(
      1,
      firstColumn,
      EXCEL_MAX_ROW,
      lastColumn - firstColumn + 1
    ),
    startRow: 1,
    startColumn: firstColumn,
    rowCount: EXCEL_MAX_ROW,
    columnCount: lastColumn - firstColumn + 1
  };
}
__name(parseWholeColumnRange, "parseWholeColumnRange");
function parseWholeRowRange(parts, originalAddress) {
  if (parts.length !== 2) return null;
  const [startRaw, endRaw] = parts;
  const startRow = parseRowReference(startRaw);
  const endRow = endRaw ? parseRowReference(endRaw) : startRow;
  if (startRow === null && endRow === null) return null;
  if (startRow === null || endRow === null) {
    throw new Error(`ExcelWorkbook: invalid range address ${originalAddress}`);
  }
  const firstRow = Math.min(startRow, endRow);
  const lastRow = Math.max(startRow, endRow);
  return {
    address: formatRangeAddress(
      firstRow,
      1,
      lastRow - firstRow + 1,
      EXCEL_MAX_COLUMN
    ),
    startRow: firstRow,
    startColumn: 1,
    rowCount: lastRow - firstRow + 1,
    columnCount: EXCEL_MAX_COLUMN
  };
}
__name(parseWholeRowRange, "parseWholeRowRange");
function parseColumnReference(value) {
  const normalized = value == null ? void 0 : value.replace(/\$/g, "").trim();
  if (!normalized || !/^[A-Za-z]+$/.test(normalized)) return null;
  return columnNameToIndex(normalized);
}
__name(parseColumnReference, "parseColumnReference");
function parseRowReference(value) {
  const normalized = value == null ? void 0 : value.replace(/\$/g, "").trim();
  if (!normalized || !/^\d+$/.test(normalized)) return null;
  const row = Number(normalized);
  if (!Number.isInteger(row) || row < 1) {
    throw new Error(`ExcelWorkbook: invalid row reference ${value}`);
  }
  return row;
}
__name(parseRowReference, "parseRowReference");
function splitSheetQualifiedAddress(input) {
  const trimmed = input.trim();
  if (!trimmed) {
    throw new Error(`ExcelWorkbook: invalid address ${input}`);
  }
  let inQuote = false;
  for (let i2 = 0; i2 < trimmed.length; i2++) {
    const ch = trimmed[i2];
    if (ch === "'") {
      if (inQuote && trimmed[i2 + 1] === "'") {
        i2 += 1;
      } else {
        inQuote = !inQuote;
      }
      continue;
    }
    if (ch === "!" && !inQuote) {
      const rawSheet = trimmed.slice(0, i2).trim();
      const address = trimmed.slice(i2 + 1).trim();
      if (!rawSheet || !address) {
        throw new Error(`ExcelWorkbook: invalid sheet-qualified address ${input}`);
      }
      return { sheetName: unquoteSheetName(rawSheet), address };
    }
  }
  return { address: trimmed };
}
__name(splitSheetQualifiedAddress, "splitSheetQualifiedAddress");
function formatRangeAddress(startRow, startColumn, rowCount, columnCount) {
  if (!Number.isInteger(rowCount) || rowCount < 1) {
    throw new Error(`ExcelWorkbook: invalid row count ${rowCount}`);
  }
  if (!Number.isInteger(columnCount) || columnCount < 1) {
    throw new Error(`ExcelWorkbook: invalid column count ${columnCount}`);
  }
  const first = formatCellAddress(startRow, startColumn);
  const last = formatCellAddress(startRow + rowCount - 1, startColumn + columnCount - 1);
  return first === last ? first : `${first}:${last}`;
}
__name(formatRangeAddress, "formatRangeAddress");
function unquoteSheetName(raw) {
  if (!raw.startsWith("'")) return raw;
  if (!raw.endsWith("'") || raw.length < 2) {
    throw new Error(`ExcelWorkbook: invalid quoted sheet name ${raw}`);
  }
  return raw.slice(1, -1).replace(/''/g, "'");
}
__name(unquoteSheetName, "unquoteSheetName");
var RGB_PATTERN = /^#[0-9A-Fa-f]{6}$/;
function normalizeExcelColor(color, context = "Excel color") {
  if (color === void 0) return void 0;
  if (!color || typeof color !== "object" || !RGB_PATTERN.test(color.rgb)) {
    throw new Error(`${context}: color must use { rgb: "#RRGGBB" }`);
  }
  if (Object.keys(color).some((key2) => key2 !== "rgb")) {
    throw new Error(`${context}: only the rgb field is supported`);
  }
  return { rgb: color.rgb.toUpperCase() };
}
__name(normalizeExcelColor, "normalizeExcelColor");
function ooxmlArgbToExcelColor(value) {
  if (!value) return void 0;
  const normalized = value.trim().replace(/^#/, "");
  if (/^[0-9A-Fa-f]{8}$/.test(normalized)) {
    return { rgb: `#${normalized.slice(2).toUpperCase()}` };
  }
  if (/^[0-9A-Fa-f]{6}$/.test(normalized)) {
    return { rgb: `#${normalized.toUpperCase()}` };
  }
  return void 0;
}
__name(ooxmlArgbToExcelColor, "ooxmlArgbToExcelColor");
function excelColorToOoxmlArgb(color, context = "Excel color") {
  const normalized = normalizeExcelColor(color, context);
  return `FF${normalized.rgb.slice(1)}`;
}
__name(excelColorToOoxmlArgb, "excelColorToOoxmlArgb");
function applyExcelTint(color, tint) {
  if (tint === void 0 || tint === 0 || !Number.isFinite(tint)) return color;
  const ratio = Math.max(-1, Math.min(1, tint));
  const channels = [1, 3, 5].map(
    (offset) => Number.parseInt(color.rgb.slice(offset, offset + 2), 16)
  );
  const adjusted = channels.map(
    (channel) => Math.round(ratio < 0 ? channel * (1 + ratio) : channel + (255 - channel) * ratio)
  );
  return {
    rgb: `#${adjusted.map((channel) => channel.toString(16).padStart(2, "0")).join("").toUpperCase()}`
  };
}
__name(applyExcelTint, "applyExcelTint");
var DRAWING_NS = "http://schemas.openxmlformats.org/drawingml/2006/main";
var THEME_COLOR_ORDER = [
  "lt1",
  "dk1",
  "lt2",
  "dk2",
  "accent1",
  "accent2",
  "accent3",
  "accent4",
  "accent5",
  "accent6",
  "hlink",
  "folHlink"
];
var INDEXED_COLORS = [
  "000000",
  "FFFFFF",
  "FF0000",
  "00FF00",
  "0000FF",
  "FFFF00",
  "FF00FF",
  "00FFFF",
  "000000",
  "FFFFFF",
  "FF0000",
  "00FF00",
  "0000FF",
  "FFFF00",
  "FF00FF",
  "00FFFF",
  "800000",
  "008000",
  "000080",
  "808000",
  "800080",
  "008080",
  "C0C0C0",
  "808080",
  "9999FF",
  "993366",
  "FFFFCC",
  "CCFFFF",
  "660066",
  "FF8080",
  "0066CC",
  "CCCCFF",
  "000080",
  "FF00FF",
  "FFFF00",
  "00FFFF",
  "800080",
  "800000",
  "008080",
  "0000FF",
  "00CCFF",
  "CCFFFF",
  "CCFFCC",
  "FFFF99",
  "99CCFF",
  "FF99CC",
  "CC99FF",
  "FFCC99",
  "3366FF",
  "33CCCC",
  "99CC00",
  "FFCC00",
  "FF9900",
  "FF6600",
  "666699",
  "969696",
  "003366",
  "339966",
  "003300",
  "333300",
  "993300",
  "993366",
  "333399",
  "333333"
];
function firstChildNs(parent, ns, localName) {
  var _a;
  return (_a = parent.getElementsByTagNameNS(ns, localName)[0]) != null ? _a : null;
}
__name(firstChildNs, "firstChildNs");
function childElementsNs(parent, ns, localName) {
  const elements = parent.getElementsByTagNameNS(ns, localName);
  return Array.from(elements).filter((el) => el.parentElement === parent);
}
__name(childElementsNs, "childElementsNs");
function parseOptionalNumber(raw) {
  if (raw === null || raw === "") return void 0;
  const value = Number(raw);
  return Number.isFinite(value) ? value : void 0;
}
__name(parseOptionalNumber, "parseOptionalNumber");
function parseBooleanAttr(raw) {
  if (raw === null) return void 0;
  return raw === "1" || raw === "true";
}
__name(parseBooleanAttr, "parseBooleanAttr");
function setIfDefined(target, key2, value) {
  if (value !== void 0) target[key2] = value;
}
__name(setIfDefined, "setIfDefined");
function parseColor(el, themeColors) {
  var _a, _b;
  if (!el) return void 0;
  let color = ooxmlArgbToExcelColor((_a = el.getAttribute("rgb")) != null ? _a : void 0);
  const theme = parseOptionalNumber(el.getAttribute("theme"));
  if (!color && theme !== void 0) color = themeColors.get(theme);
  const indexed = parseOptionalNumber(el.getAttribute("indexed"));
  if (!color && indexed !== void 0) {
    const rgb = (_b = INDEXED_COLORS[indexed]) != null ? _b : indexed === 64 ? "000000" : indexed === 65 ? "FFFFFF" : void 0;
    if (rgb) color = { rgb: `#${rgb}` };
  }
  if (!color && parseBooleanAttr(el.getAttribute("auto"))) color = { rgb: "#000000" };
  return color ? applyExcelTint(color, parseOptionalNumber(el.getAttribute("tint"))) : void 0;
}
__name(parseColor, "parseColor");
function parseThemeColors(pkg) {
  var _a;
  const themeColors = /* @__PURE__ */ new Map();
  const themeDom = (_a = getPart(pkg, "xl/theme/theme1.xml")) == null ? void 0 : _a.xmlDom;
  if (!themeDom) return themeColors;
  const scheme = themeDom.getElementsByTagNameNS(DRAWING_NS, "clrScheme")[0];
  if (!scheme) return themeColors;
  THEME_COLOR_ORDER.forEach((name, index) => {
    var _a2, _b;
    const slot = Array.from(scheme.getElementsByTagNameNS(DRAWING_NS, name)).find(
      (element) => element.parentElement === scheme
    );
    const source = slot == null ? void 0 : slot.firstElementChild;
    const raw = (_b = (_a2 = source == null ? void 0 : source.getAttribute("lastClr")) != null ? _a2 : source == null ? void 0 : source.getAttribute("val")) != null ? _b : void 0;
    const color = ooxmlArgbToExcelColor(raw);
    if (color) themeColors.set(index, color);
  });
  return themeColors;
}
__name(parseThemeColors, "parseThemeColors");
function themeColorByName(themeColors, name) {
  return themeColors.get(THEME_COLOR_ORDER.findIndex((item) => item === name));
}
__name(themeColorByName, "themeColorByName");
function parseValNumber(parent, name) {
  var _a, _b;
  return parseOptionalNumber((_b = (_a = firstChildNs(parent, SS_NS, name)) == null ? void 0 : _a.getAttribute("val")) != null ? _b : null);
}
__name(parseValNumber, "parseValNumber");
function parseValString(parent, name) {
  var _a, _b;
  return (_b = (_a = firstChildNs(parent, SS_NS, name)) == null ? void 0 : _a.getAttribute("val")) != null ? _b : void 0;
}
__name(parseValString, "parseValString");
function emptyStyles() {
  return {
    numberFormats: [],
    fonts: [],
    fills: [],
    borders: [],
    cellFormats: []
  };
}
__name(emptyStyles, "emptyStyles");
function parseNumberFormats(stylesDom) {
  const list = [];
  const byId = /* @__PURE__ */ new Map();
  const numFmtEls = stylesDom.getElementsByTagNameNS(SS_NS, "numFmt");
  for (let i2 = 0; i2 < numFmtEls.length; i2++) {
    const el = numFmtEls[i2];
    if (!el) continue;
    const id = parseOptionalNumber(el.getAttribute("numFmtId"));
    const code = el.getAttribute("formatCode");
    if (id === void 0 || code === null) continue;
    list.push({ id, code });
    byId.set(id, code);
  }
  return { list, byId };
}
__name(parseNumberFormats, "parseNumberFormats");
function parseFonts(stylesDom, themeColors) {
  const fontsEl = stylesDom.getElementsByTagNameNS(SS_NS, "fonts")[0];
  if (!fontsEl) return [];
  return childElementsNs(fontsEl, SS_NS, "font").map((element) => parseFontProperties(element, themeColors));
}
__name(parseFonts, "parseFonts");
function parseFontProperties(element, themeColors, nameTag = "name") {
  const font = {};
  setIfDefined(font, "name", parseValString(element, nameTag));
  setIfDefined(font, "size", parseValNumber(element, "sz"));
  setIfDefined(font, "family", parseValNumber(element, "family"));
  setIfDefined(font, "charset", parseValNumber(element, "charset"));
  setIfDefined(font, "scheme", parseValString(element, "scheme"));
  for (const [tag, key2] of [["b", "bold"], ["i", "italic"], ["u", "underline"]]) {
    const property = firstChildNs(element, SS_NS, tag);
    if (property) {
      const value = property.getAttribute("val");
      font[key2] = value !== "0" && value !== "false" && value !== "none";
    }
  }
  setIfDefined(font, "color", parseColor(firstChildNs(element, SS_NS, "color"), themeColors));
  return font;
}
__name(parseFontProperties, "parseFontProperties");
function parseFills(stylesDom, themeColors) {
  const fillsEl = stylesDom.getElementsByTagNameNS(SS_NS, "fills")[0];
  if (!fillsEl) return [];
  return childElementsNs(fillsEl, SS_NS, "fill").map((fillEl) => {
    var _a;
    const pattern = firstChildNs(fillEl, SS_NS, "patternFill");
    const fill = {};
    if (!pattern) return fill;
    setIfDefined(fill, "patternType", (_a = pattern.getAttribute("patternType")) != null ? _a : void 0);
    setIfDefined(
      fill,
      "foregroundColor",
      parseColor(firstChildNs(pattern, SS_NS, "fgColor"), themeColors)
    );
    setIfDefined(
      fill,
      "backgroundColor",
      parseColor(firstChildNs(pattern, SS_NS, "bgColor"), themeColors)
    );
    return fill;
  });
}
__name(parseFills, "parseFills");
function parseBorderSide(borderEl, name, themeColors) {
  var _a;
  const sideEl = firstChildNs(borderEl, SS_NS, name);
  if (!sideEl) return void 0;
  const side = {};
  setIfDefined(side, "style", (_a = sideEl.getAttribute("style")) != null ? _a : void 0);
  setIfDefined(side, "color", parseColor(firstChildNs(sideEl, SS_NS, "color"), themeColors));
  return Object.keys(side).length ? side : void 0;
}
__name(parseBorderSide, "parseBorderSide");
function parseBorders(stylesDom, themeColors) {
  const bordersEl = stylesDom.getElementsByTagNameNS(SS_NS, "borders")[0];
  if (!bordersEl) return [];
  return childElementsNs(bordersEl, SS_NS, "border").map((borderEl) => {
    const border = {};
    setIfDefined(border, "left", parseBorderSide(borderEl, "left", themeColors));
    setIfDefined(border, "right", parseBorderSide(borderEl, "right", themeColors));
    setIfDefined(border, "top", parseBorderSide(borderEl, "top", themeColors));
    setIfDefined(border, "bottom", parseBorderSide(borderEl, "bottom", themeColors));
    setIfDefined(border, "diagonal", parseBorderSide(borderEl, "diagonal", themeColors));
    return border;
  });
}
__name(parseBorders, "parseBorders");
function parseAlignment(xfEl) {
  var _a, _b;
  const alignmentEl = firstChildNs(xfEl, SS_NS, "alignment");
  if (!alignmentEl) return void 0;
  const alignment = {};
  setIfDefined(alignment, "horizontal", (_a = alignmentEl.getAttribute("horizontal")) != null ? _a : void 0);
  setIfDefined(alignment, "vertical", (_b = alignmentEl.getAttribute("vertical")) != null ? _b : void 0);
  setIfDefined(
    alignment,
    "textRotation",
    parseOptionalNumber(alignmentEl.getAttribute("textRotation"))
  );
  setIfDefined(alignment, "wrapText", parseBooleanAttr(alignmentEl.getAttribute("wrapText")));
  setIfDefined(alignment, "shrinkToFit", parseBooleanAttr(alignmentEl.getAttribute("shrinkToFit")));
  setIfDefined(alignment, "indent", parseOptionalNumber(alignmentEl.getAttribute("indent")));
  return Object.keys(alignment).length ? alignment : void 0;
}
__name(parseAlignment, "parseAlignment");
function parseCellFormats(stylesDom, numberFormatsById) {
  const cellXfsEl = stylesDom.getElementsByTagNameNS(SS_NS, "cellXfs")[0];
  if (!cellXfsEl) return [];
  return childElementsNs(cellXfsEl, SS_NS, "xf").map((xfEl) => {
    var _a;
    const numberFormatId = parseOptionalNumber(xfEl.getAttribute("numFmtId"));
    const format = {};
    setIfDefined(format, "numberFormatId", numberFormatId);
    setIfDefined(
      format,
      "numberFormatCode",
      numberFormatId === void 0 ? void 0 : (_a = numberFormatsById.get(numberFormatId)) != null ? _a : builtInNumberFormatCode(numberFormatId)
    );
    setIfDefined(format, "fontId", parseOptionalNumber(xfEl.getAttribute("fontId")));
    setIfDefined(format, "fillId", parseOptionalNumber(xfEl.getAttribute("fillId")));
    setIfDefined(format, "borderId", parseOptionalNumber(xfEl.getAttribute("borderId")));
    setIfDefined(format, "xfId", parseOptionalNumber(xfEl.getAttribute("xfId")));
    setIfDefined(
      format,
      "applyNumberFormat",
      parseBooleanAttr(xfEl.getAttribute("applyNumberFormat"))
    );
    setIfDefined(format, "applyFont", parseBooleanAttr(xfEl.getAttribute("applyFont")));
    setIfDefined(format, "applyFill", parseBooleanAttr(xfEl.getAttribute("applyFill")));
    setIfDefined(format, "applyBorder", parseBooleanAttr(xfEl.getAttribute("applyBorder")));
    setIfDefined(format, "applyAlignment", parseBooleanAttr(xfEl.getAttribute("applyAlignment")));
    setIfDefined(format, "alignment", parseAlignment(xfEl));
    return format;
  });
}
__name(parseCellFormats, "parseCellFormats");
function builtInNumberFormatCode(id) {
  const builtIns = {
    0: "General",
    1: "0",
    2: "0.00",
    3: "#,##0",
    4: "#,##0.00",
    9: "0%",
    10: "0.00%",
    14: "mm-dd-yy",
    15: "d-mmm-yy",
    16: "d-mmm",
    17: "mmm-yy",
    18: "h:mm AM/PM",
    19: "h:mm:ss AM/PM",
    20: "h:mm",
    21: "h:mm:ss",
    22: "m/d/yy h:mm",
    45: "mm:ss",
    46: "[h]:mm:ss",
    47: "mmss.0"
  };
  return builtIns[id];
}
__name(builtInNumberFormatCode, "builtInNumberFormatCode");
function parseStyles(pkg, themeColors = parseThemeColors(pkg)) {
  const part = getPart(pkg, "xl/styles.xml");
  if (!(part == null ? void 0 : part.xmlDom)) return emptyStyles();
  const numberFormats = parseNumberFormats(part.xmlDom);
  return {
    numberFormats: numberFormats.list,
    fonts: parseFonts(part.xmlDom, themeColors),
    fills: parseFills(part.xmlDom, themeColors),
    borders: parseBorders(part.xmlDom, themeColors),
    cellFormats: parseCellFormats(part.xmlDom, numberFormats.byId)
  };
}
__name(parseStyles, "parseStyles");
function readExcelStringContent(element, themeColors) {
  var _a, _b, _c;
  const runs = [];
  let rich = false;
  for (const child of Array.from(element.children)) {
    if (child.namespaceURI !== SS_NS) continue;
    if (child.localName === "t") {
      runs.push({ text: (_a = child.textContent) != null ? _a : "" });
    } else if (child.localName === "r") {
      const text2 = (_c = (_b = child.getElementsByTagNameNS(SS_NS, "t")[0]) == null ? void 0 : _b.textContent) != null ? _c : "";
      const properties = child.getElementsByTagNameNS(SS_NS, "rPr")[0];
      runs.push(properties ? { text: text2, font: parseFontProperties(properties, themeColors, "rFont") } : { text: text2 });
      rich = true;
    }
  }
  const text = runs.map((run) => run.text).join("");
  return rich ? { text, richText: runs } : { text };
}
__name(readExcelStringContent, "readExcelStringContent");
function cloneExcelRichText(runs) {
  return runs.map((run) => {
    if (!run.font) return { text: run.text };
    const font = __spreadValues({}, run.font);
    if (font.color) font.color = __spreadValues({}, font.color);
    return { text: run.text, font };
  });
}
__name(cloneExcelRichText, "cloneExcelRichText");
function cloneExcelCell(cell) {
  return cell.richText ? __spreadProps(__spreadValues({}, cell), { richText: cloneExcelRichText(cell.richText) }) : __spreadValues({}, cell);
}
__name(cloneExcelCell, "cloneExcelCell");
function excelCellRichText(cell) {
  const runs = cell.richText;
  return cell.kind === "string" && (runs == null ? void 0 : runs.length) && runs.map((run) => run.text).join("") === cell.value ? runs : void 0;
}
__name(excelCellRichText, "excelCellRichText");
function serializeExcelRichText(runs) {
  const doc = new Document();
  const inline = createExcelRichTextElement(doc, runs);
  return xo(inline);
}
__name(serializeExcelRichText, "serializeExcelRichText");
function createExcelRichTextElement(document, runs) {
  const inline = document.createElementNS(SS_NS, "is");
  for (const { text, font } of runs) {
    const run = document.createElementNS(SS_NS, "r");
    if (font) {
      const properties = document.createElementNS(SS_NS, "rPr");
      for (const [name, value2] of [
        ["rFont", font.name],
        ["charset", font.charset],
        ["family", font.family],
        ["b", font.bold],
        ["i", font.italic],
        ["u", font.underline],
        ["sz", font.size],
        ["scheme", font.scheme]
      ]) {
        if (value2 === void 0) continue;
        const child = document.createElementNS(SS_NS, name);
        if (value2 !== true) child.setAttribute("val", value2 === false ? name === "u" ? "none" : "0" : String(value2));
        properties.appendChild(child);
      }
      if (font.color) {
        const color = document.createElementNS(SS_NS, "color");
        color.setAttribute("rgb", excelColorToOoxmlArgb(font.color));
        properties.appendChild(color);
      }
      run.appendChild(properties);
    }
    const value = document.createElementNS(SS_NS, "t");
    if (/^\s|\s$/.test(text)) {
      value.setAttributeNS("http://www.w3.org/XML/1998/namespace", "xml:space", "preserve");
    }
    value.textContent = text;
    run.appendChild(value);
    inline.appendChild(run);
  }
  return inline;
}
__name(createExcelRichTextElement, "createExcelRichTextElement");
function requireXmlPart(pkg, path) {
  const part = getPart(pkg, path);
  if (!(part == null ? void 0 : part.xmlDom)) {
    throw new Error(`ExcelWorkbook: missing XML part ${path}`);
  }
  return part;
}
__name(requireXmlPart, "requireXmlPart");
function optionalXmlPart(pkg, path) {
  const part = getPart(pkg, path);
  return (part == null ? void 0 : part.xmlDom) ? part : void 0;
}
__name(optionalXmlPart, "optionalXmlPart");
function textOf(el) {
  var _a;
  if (!el) return "";
  return (_a = el.textContent) != null ? _a : "";
}
__name(textOf, "textOf");
function firstChildNs2(parent, ns, localName) {
  var _a;
  return (_a = parent.getElementsByTagNameNS(ns, localName)[0]) != null ? _a : null;
}
__name(firstChildNs2, "firstChildNs");
function childElementsNs2(parent, ns, localName) {
  const elements = parent.getElementsByTagNameNS(ns, localName);
  return Array.from(elements).filter((el) => el.parentElement === parent);
}
__name(childElementsNs2, "childElementsNs");
function parseRelationships(part) {
  const rels = /* @__PURE__ */ new Map();
  if (!(part == null ? void 0 : part.xmlDom)) return rels;
  const relEls = part.xmlDom.getElementsByTagNameNS(REL_NS, "Relationship");
  for (let i2 = 0; i2 < relEls.length; i2++) {
    const rel = relEls[i2];
    if (!rel) continue;
    const id = rel.getAttribute("Id");
    const type = rel.getAttribute("Type");
    const target = rel.getAttribute("Target");
    if (!id || !type || !target) continue;
    const model = { id, type, target };
    const targetMode = rel.getAttribute("TargetMode");
    if (targetMode) model.targetMode = targetMode;
    rels.set(id, model);
  }
  return rels;
}
__name(parseRelationships, "parseRelationships");
function dirname(path) {
  const index = path.lastIndexOf("/");
  return index === -1 ? "" : path.slice(0, index);
}
__name(dirname, "dirname");
function normalizePath(path) {
  const parts = [];
  for (const part of path.split("/")) {
    if (!part || part === ".") continue;
    if (part === "..") {
      parts.pop();
      continue;
    }
    parts.push(part);
  }
  return parts.join("/");
}
__name(normalizePath, "normalizePath");
function resolveRelationshipTarget(sourcePartPath, target) {
  if (target.startsWith("/")) return normalizePath(target.slice(1));
  return normalizePath(`${dirname(sourcePartPath)}/${target}`);
}
__name(resolveRelationshipTarget, "resolveRelationshipTarget");
function parseWorkbookSheets(pkg) {
  const workbook = requireXmlPart(pkg, "xl/workbook.xml");
  const rels = parseRelationships(optionalXmlPart(pkg, "xl/_rels/workbook.xml.rels"));
  const sheetsEl = firstChildNs2(workbook.xmlDom.documentElement, SS_NS, "sheets");
  if (!sheetsEl) return [];
  return childElementsNs2(sheetsEl, SS_NS, "sheet").map((sheetEl, index) => {
    var _a, _b, _c, _d;
    const relationshipId = (_a = sheetEl.getAttributeNS(OFFICE_REL_NS, "id")) != null ? _a : void 0;
    const rel = relationshipId ? rels.get(relationshipId) : void 0;
    const path = rel ? resolveRelationshipTarget("xl/workbook.xml", rel.target) : void 0;
    const name = (_b = sheetEl.getAttribute("name")) != null ? _b : `Sheet${index + 1}`;
    const id = (_c = sheetEl.getAttribute("sheetId")) != null ? _c : String(index + 1);
    const visibility = (_d = sheetEl.getAttribute("state")) != null ? _d : void 0;
    return { id, name, visibility, relationshipId, path };
  });
}
__name(parseWorkbookSheets, "parseWorkbookSheets");
function parseWorkbookDate1904(pkg) {
  const workbook = requireXmlPart(pkg, "xl/workbook.xml");
  const workbookPr = firstChildNs2(workbook.xmlDom.documentElement, SS_NS, "workbookPr");
  const value = workbookPr == null ? void 0 : workbookPr.getAttribute("date1904");
  return value === "1" || value === "true";
}
__name(parseWorkbookDate1904, "parseWorkbookDate1904");
function parseDefinedNames(pkg) {
  const workbookPart = requireXmlPart(pkg, "xl/workbook.xml");
  const definedNameEls = workbookPart.xmlDom.getElementsByTagNameNS(SS_NS, "definedName");
  const result = [];
  for (let i2 = 0; i2 < definedNameEls.length; i2++) {
    const el = definedNameEls[i2];
    if (!el) continue;
    const name = el.getAttribute("name");
    if (!name) continue;
    const model = {
      name,
      text: textOf(el)
    };
    const localSheetId = el.getAttribute("localSheetId");
    if (localSheetId !== null && localSheetId !== "") {
      const value = Number(localSheetId);
      if (Number.isFinite(value)) model.localSheetId = value;
    }
    result.push(model);
  }
  return result;
}
__name(parseDefinedNames, "parseDefinedNames");
function parseSharedStrings(pkg, themeColors) {
  const part = optionalXmlPart(pkg, "xl/sharedStrings.xml");
  if (!(part == null ? void 0 : part.xmlDom)) return [];
  const strings = [];
  const siEls = part.xmlDom.getElementsByTagNameNS(SS_NS, "si");
  for (let i2 = 0; i2 < siEls.length; i2++) {
    const si = siEls[i2];
    if (!si) continue;
    strings.push(readExcelStringContent(si, themeColors));
  }
  return strings;
}
__name(parseSharedStrings, "parseSharedStrings");
function optionalXmlPart2(pkg, path) {
  const part = getPart(pkg, path);
  return (part == null ? void 0 : part.xmlDom) ? part : void 0;
}
__name(optionalXmlPart2, "optionalXmlPart");
function textOf2(el) {
  var _a;
  if (!el) return "";
  return (_a = el.textContent) != null ? _a : "";
}
__name(textOf2, "textOf");
function firstChildNs3(parent, ns, localName) {
  var _a;
  return (_a = parent.getElementsByTagNameNS(ns, localName)[0]) != null ? _a : null;
}
__name(firstChildNs3, "firstChildNs");
function childElementsNs3(parent, ns, localName) {
  const result = [];
  for (let i2 = 0; i2 < parent.childNodes.length; i2++) {
    const child = parent.childNodes[i2];
    if ((child == null ? void 0 : child.nodeType) !== 1) continue;
    const el = child;
    if (el.namespaceURI === ns && el.localName === localName) {
      result.push(el);
    }
  }
  return result;
}
__name(childElementsNs3, "childElementsNs");
function parseRelationships2(part) {
  var _a;
  const result = /* @__PURE__ */ new Map();
  if (!(part == null ? void 0 : part.xmlDom)) return result;
  const rels = part.xmlDom.getElementsByTagNameNS(REL_NS, "Relationship");
  for (let i2 = 0; i2 < rels.length; i2++) {
    const rel = rels[i2];
    if (!rel) continue;
    const id = rel.getAttribute("Id");
    const type = rel.getAttribute("Type");
    const target = rel.getAttribute("Target");
    if (!id || !type || !target) continue;
    result.set(id, {
      id,
      type,
      target,
      targetMode: (_a = rel.getAttribute("TargetMode")) != null ? _a : void 0
    });
  }
  return result;
}
__name(parseRelationships2, "parseRelationships");
function dirname2(path) {
  const idx = path.lastIndexOf("/");
  return idx === -1 ? "" : path.slice(0, idx);
}
__name(dirname2, "dirname");
function normalizePath2(path) {
  const parts = [];
  for (const part of path.split("/")) {
    if (!part || part === ".") continue;
    if (part === "..") parts.pop();
    else parts.push(part);
  }
  return parts.join("/");
}
__name(normalizePath2, "normalizePath");
function resolveRelationshipTarget2(sourcePartPath, target) {
  if (target.startsWith("/")) return normalizePath2(target.slice(1));
  const base = dirname2(sourcePartPath);
  return normalizePath2(base ? `${base}/${target}` : target);
}
__name(resolveRelationshipTarget2, "resolveRelationshipTarget");
function parseNumber(raw) {
  if (raw === void 0 || raw === "") return null;
  const value = Number(raw);
  return Number.isFinite(value) ? value : null;
}
__name(parseNumber, "parseNumber");
function parseOptionalNumber2(raw) {
  if (raw === null || raw === "") return void 0;
  const value = Number(raw);
  return Number.isFinite(value) ? value : void 0;
}
__name(parseOptionalNumber2, "parseOptionalNumber");
function parseBooleanAttr2(raw) {
  if (raw === null) return void 0;
  return raw === "1" || raw === "true";
}
__name(parseBooleanAttr2, "parseBooleanAttr");
var EXCEL_1900_EPOCH_OFFSET_DAYS = 25569;
var EXCEL_1904_EPOCH_OFFSET_DAYS = 24107;
var MILLISECONDS_PER_DAY = 864e5;
function parseIsoDateSerial(raw, date1904) {
  var _a, _b, _c, _d;
  if (!raw) return null;
  const match = /^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2})(?::(\d{2})(?:\.(\d{1,9}))?)?(?:Z|[+-]\d{2}:\d{2})?)?$/.exec(
    raw
  );
  if (!match) return null;
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  const hour = Number((_a = match[4]) != null ? _a : 0);
  const minute = Number((_b = match[5]) != null ? _b : 0);
  const second = Number((_c = match[6]) != null ? _c : 0);
  const millisecond = Number(((_d = match[7]) != null ? _d : "").padEnd(3, "0").slice(0, 3));
  if (month < 1 || month > 12 || hour > 23 || minute > 59 || second > 59) return null;
  const timestamp = Date.UTC(year, month - 1, day, hour, minute, second, millisecond);
  const date = new Date(timestamp);
  if (date.getUTCFullYear() !== year || date.getUTCMonth() !== month - 1 || date.getUTCDate() !== day || date.getUTCHours() !== hour || date.getUTCMinutes() !== minute || date.getUTCSeconds() !== second || date.getUTCMilliseconds() !== millisecond) return null;
  if (date1904) return timestamp / MILLISECONDS_PER_DAY + EXCEL_1904_EPOCH_OFFSET_DAYS;
  let serial = timestamp / MILLISECONDS_PER_DAY + EXCEL_1900_EPOCH_OFFSET_DAYS;
  if (serial < 61) serial -= 1;
  return serial;
}
__name(parseIsoDateSerial, "parseIsoDateSerial");
function setIfDefined2(target, key2, value) {
  if (value !== void 0) target[key2] = value;
}
__name(setIfDefined2, "setIfDefined");
function parseCell(cell, sharedStrings, date1904, themeColors) {
  var _a, _b, _c, _d;
  const address = cell.getAttribute("r");
  if (!address) return null;
  const { row, column } = parseCellAddress(address);
  const dataType = (_a = cell.getAttribute("t")) != null ? _a : void 0;
  const styleIdRaw = cell.getAttribute("s");
  const formula = textOf2(firstChildNs3(cell, SS_NS, "f")) || void 0;
  const rawValue = textOf2(firstChildNs3(cell, SS_NS, "v")) || void 0;
  let kind = formula ? "formula" : "blank";
  let value = null;
  let sharedStringIndex;
  let richText;
  if (dataType === "s") {
    sharedStringIndex = rawValue === void 0 ? void 0 : Number(rawValue);
    const shared = sharedStringIndex === void 0 ? void 0 : sharedStrings[sharedStringIndex];
    value = (_b = shared == null ? void 0 : shared.text) != null ? _b : null;
    if ((shared == null ? void 0 : shared.richText) && !formula) richText = cloneExcelRichText(shared.richText);
    kind = formula ? "formula" : "string";
  } else if (dataType === "inlineStr") {
    const inline = firstChildNs3(cell, SS_NS, "is");
    const content = inline ? readExcelStringContent(inline, themeColors) : void 0;
    value = (_c = content == null ? void 0 : content.text) != null ? _c : "";
    if (!formula) richText = content == null ? void 0 : content.richText;
    kind = formula ? "formula" : "string";
  } else if (dataType === "b") {
    value = rawValue === "1";
    kind = formula ? "formula" : "boolean";
  } else if (dataType === "str") {
    value = rawValue != null ? rawValue : "";
    kind = formula ? "formula" : "string";
  } else if (dataType === "e") {
    value = rawValue != null ? rawValue : null;
    kind = "error";
  } else if (dataType === "d") {
    const serial = parseIsoDateSerial(rawValue, date1904);
    value = (_d = serial != null ? serial : rawValue) != null ? _d : null;
    kind = formula ? "formula" : serial === null ? "string" : "number";
  } else if (rawValue !== void 0) {
    value = parseNumber(rawValue);
    kind = formula ? "formula" : "number";
  }
  const model = {
    address,
    row,
    column,
    kind,
    value,
    rawValue,
    formula,
    dataType,
    styleId: styleIdRaw === null ? void 0 : Number(styleIdRaw),
    sharedStringIndex
  };
  setIfDefined2(model, "richText", richText);
  return model;
}
__name(parseCell, "parseCell");
function parseColumns(sheetDom) {
  const colEls = sheetDom.getElementsByTagNameNS(SS_NS, "col");
  const columns = [];
  for (let i2 = 0; i2 < colEls.length; i2++) {
    const col = colEls[i2];
    if (!col) continue;
    const min = parseOptionalNumber2(col.getAttribute("min"));
    const max = parseOptionalNumber2(col.getAttribute("max"));
    if (min === void 0 || max === void 0) continue;
    const column = { min, max };
    setIfDefined2(column, "width", parseOptionalNumber2(col.getAttribute("width")));
    setIfDefined2(column, "hidden", parseBooleanAttr2(col.getAttribute("hidden")));
    setIfDefined2(column, "styleId", parseOptionalNumber2(col.getAttribute("style")));
    setIfDefined2(column, "customWidth", parseBooleanAttr2(col.getAttribute("customWidth")));
    columns.push(column);
  }
  return columns;
}
__name(parseColumns, "parseColumns");
function parseRows(sheetDom) {
  const rowEls = sheetDom.getElementsByTagNameNS(SS_NS, "row");
  const rows = [];
  for (let i2 = 0; i2 < rowEls.length; i2++) {
    const row = rowEls[i2];
    if (!row) continue;
    const index = parseOptionalNumber2(row.getAttribute("r"));
    if (index === void 0) continue;
    const rowModel = { index };
    setIfDefined2(rowModel, "height", parseOptionalNumber2(row.getAttribute("ht")));
    setIfDefined2(rowModel, "hidden", parseBooleanAttr2(row.getAttribute("hidden")));
    setIfDefined2(rowModel, "styleId", parseOptionalNumber2(row.getAttribute("s")));
    setIfDefined2(rowModel, "customHeight", parseBooleanAttr2(row.getAttribute("customHeight")));
    rows.push(rowModel);
  }
  return rows;
}
__name(parseRows, "parseRows");
function parseMergedRanges(sheetDom) {
  var _a;
  const mergeCellEls = sheetDom.getElementsByTagNameNS(SS_NS, "mergeCell");
  const mergedRanges = [];
  for (let i2 = 0; i2 < mergeCellEls.length; i2++) {
    const ref = (_a = mergeCellEls[i2]) == null ? void 0 : _a.getAttribute("ref");
    if (ref) mergedRanges.push({ address: ref });
  }
  return mergedRanges;
}
__name(parseMergedRanges, "parseMergedRanges");
function sheetRelationshipPartPath(sheetPath) {
  return `${dirname2(sheetPath)}/_rels/${sheetPath.slice(sheetPath.lastIndexOf("/") + 1)}.rels`;
}
__name(sheetRelationshipPartPath, "sheetRelationshipPartPath");
function parseHyperlinks(pkg, sheetPath, sheetDom) {
  var _a, _b, _c, _d;
  const rels = parseRelationships2(optionalXmlPart2(pkg, sheetRelationshipPartPath(sheetPath)));
  const hyperlinkEls = sheetDom.getElementsByTagNameNS(SS_NS, "hyperlink");
  const hyperlinks = [];
  for (let i2 = 0; i2 < hyperlinkEls.length; i2++) {
    const hyperlink = hyperlinkEls[i2];
    if (!hyperlink) continue;
    const ref = hyperlink.getAttribute("ref");
    if (!ref) continue;
    const relationshipId = (_a = hyperlink.getAttributeNS(OFFICE_REL_NS, "id")) != null ? _a : void 0;
    const rel = relationshipId ? rels.get(relationshipId) : void 0;
    const model = { ref };
    setIfDefined2(model, "relationshipId", relationshipId);
    setIfDefined2(
      model,
      "target",
      rel ? rel.targetMode === "External" ? rel.target : resolveRelationshipTarget2(sheetPath, rel.target) : void 0
    );
    setIfDefined2(model, "targetMode", rel == null ? void 0 : rel.targetMode);
    setIfDefined2(model, "location", (_b = hyperlink.getAttribute("location")) != null ? _b : void 0);
    setIfDefined2(model, "display", (_c = hyperlink.getAttribute("display")) != null ? _c : void 0);
    setIfDefined2(model, "tooltip", (_d = hyperlink.getAttribute("tooltip")) != null ? _d : void 0);
    hyperlinks.push(model);
  }
  return hyperlinks;
}
__name(parseHyperlinks, "parseHyperlinks");
function parseTableColumns(tableDom) {
  var _a, _b;
  const tableColumnEls = tableDom.getElementsByTagNameNS(SS_NS, "tableColumn");
  const columns = [];
  for (let i2 = 0; i2 < tableColumnEls.length; i2++) {
    const el = tableColumnEls[i2];
    if (!el) continue;
    const id = parseOptionalNumber2(el.getAttribute("id"));
    const name = el.getAttribute("name");
    if (id === void 0 || name === null) continue;
    const column = { id, name };
    setIfDefined2(column, "totalsRowLabel", (_a = el.getAttribute("totalsRowLabel")) != null ? _a : void 0);
    setIfDefined2(column, "totalsRowFunction", (_b = el.getAttribute("totalsRowFunction")) != null ? _b : void 0);
    columns.push(column);
  }
  return columns;
}
__name(parseTableColumns, "parseTableColumns");
function parseTableStyle(tableDom) {
  var _a;
  const styleEl = tableDom.getElementsByTagNameNS(SS_NS, "tableStyleInfo")[0];
  if (!styleEl) return void 0;
  const style = {};
  setIfDefined2(style, "name", (_a = styleEl.getAttribute("name")) != null ? _a : void 0);
  setIfDefined2(style, "showFirstColumn", parseBooleanAttr2(styleEl.getAttribute("showFirstColumn")));
  setIfDefined2(style, "showLastColumn", parseBooleanAttr2(styleEl.getAttribute("showLastColumn")));
  setIfDefined2(style, "showRowStripes", parseBooleanAttr2(styleEl.getAttribute("showRowStripes")));
  setIfDefined2(style, "showColumnStripes", parseBooleanAttr2(styleEl.getAttribute("showColumnStripes")));
  return Object.keys(style).length ? style : void 0;
}
__name(parseTableStyle, "parseTableStyle");
function parseTableAutoFilter(tableDom) {
  var _a;
  const tableEl = tableDom.getElementsByTagNameNS(SS_NS, "table")[0];
  const autoFilterEl = tableEl ? firstChildNs3(tableEl, SS_NS, "autoFilter") : null;
  if (!autoFilterEl) return void 0;
  const model = {
    ref: (_a = autoFilterEl.getAttribute("ref")) != null ? _a : void 0,
    filterColumns: parseFilterColumns(autoFilterEl)
  };
  setIfDefined2(model, "sortState", parseSortState(autoFilterEl));
  if (!model.filterColumns.length && !model.sortState) return void 0;
  return model;
}
__name(parseTableAutoFilter, "parseTableAutoFilter");
function parseFilterColumns(autoFilterEl) {
  return childElementsNs3(autoFilterEl, SS_NS, "filterColumn").flatMap((filterColumnEl) => {
    const colId = parseOptionalNumber2(filterColumnEl.getAttribute("colId"));
    if (colId === void 0) return [];
    const filterColumn = { colId };
    setIfDefined2(filterColumn, "hiddenButton", parseBooleanAttr2(filterColumnEl.getAttribute("hiddenButton")));
    setIfDefined2(filterColumn, "showButton", parseBooleanAttr2(filterColumnEl.getAttribute("showButton")));
    const filtersEl = firstChildNs3(filterColumnEl, SS_NS, "filters");
    const filters = filtersEl ? childElementsNs3(filtersEl, SS_NS, "filter").map((filterEl) => {
      var _a;
      return (_a = filterEl.getAttribute("val")) != null ? _a : void 0;
    }).filter((value) => value !== void 0) : [];
    if (filters.length) filterColumn.filters = filters;
    return [filterColumn];
  });
}
__name(parseFilterColumns, "parseFilterColumns");
function parseSortState(autoFilterEl) {
  var _a, _b;
  const sortStateEl = firstChildNs3(autoFilterEl, SS_NS, "sortState");
  if (!sortStateEl) return void 0;
  const state = { conditions: [] };
  setIfDefined2(state, "ref", (_a = sortStateEl.getAttribute("ref")) != null ? _a : void 0);
  setIfDefined2(state, "caseSensitive", parseBooleanAttr2(sortStateEl.getAttribute("caseSensitive")));
  setIfDefined2(state, "sortMethod", (_b = sortStateEl.getAttribute("sortMethod")) != null ? _b : void 0);
  state.conditions = childElementsNs3(sortStateEl, SS_NS, "sortCondition").map((conditionEl) => {
    var _a2, _b2;
    const condition = {};
    setIfDefined2(condition, "ref", (_a2 = conditionEl.getAttribute("ref")) != null ? _a2 : void 0);
    setIfDefined2(condition, "descending", parseBooleanAttr2(conditionEl.getAttribute("descending")));
    setIfDefined2(condition, "sortBy", (_b2 = conditionEl.getAttribute("sortBy")) != null ? _b2 : void 0);
    return condition;
  });
  return state;
}
__name(parseSortState, "parseSortState");
function parseTablePart(pkg, relationshipId, path) {
  var _a, _b, _c, _d;
  const part = optionalXmlPart2(pkg, path);
  if (!(part == null ? void 0 : part.xmlDom)) {
    return { relationshipId, path, columns: [] };
  }
  const tableEl = part.xmlDom.getElementsByTagNameNS(SS_NS, "table")[0];
  if (!tableEl) {
    return { relationshipId, path, columns: [] };
  }
  const table = {
    relationshipId,
    path,
    columns: parseTableColumns(part.xmlDom)
  };
  setIfDefined2(table, "id", parseOptionalNumber2(tableEl.getAttribute("id")));
  setIfDefined2(table, "name", (_a = tableEl.getAttribute("name")) != null ? _a : void 0);
  setIfDefined2(table, "displayName", (_b = tableEl.getAttribute("displayName")) != null ? _b : void 0);
  setIfDefined2(table, "ref", (_c = tableEl.getAttribute("ref")) != null ? _c : void 0);
  setIfDefined2(table, "headerRowCount", parseOptionalNumber2(tableEl.getAttribute("headerRowCount")));
  setIfDefined2(table, "totalsRowCount", parseOptionalNumber2(tableEl.getAttribute("totalsRowCount")));
  setIfDefined2(table, "totalsRowShown", parseBooleanAttr2(tableEl.getAttribute("totalsRowShown")));
  const autoFilterEl = firstChildNs3(tableEl, SS_NS, "autoFilter");
  const autoFilter = parseTableAutoFilter(part.xmlDom);
  setIfDefined2(table, "autoFilterRef", (_d = autoFilterEl == null ? void 0 : autoFilterEl.getAttribute("ref")) != null ? _d : void 0);
  setIfDefined2(table, "autoFilter", autoFilter);
  setIfDefined2(table, "style", parseTableStyle(part.xmlDom));
  return table;
}
__name(parseTablePart, "parseTablePart");
function parseTables(pkg, sheetPath, sheetDom) {
  var _a, _b;
  const rels = parseRelationships2(optionalXmlPart2(pkg, sheetRelationshipPartPath(sheetPath)));
  const tablePartEls = sheetDom.getElementsByTagNameNS(SS_NS, "tablePart");
  const tables = [];
  for (let i2 = 0; i2 < tablePartEls.length; i2++) {
    const relationshipId = (_b = (_a = tablePartEls[i2]) == null ? void 0 : _a.getAttributeNS(OFFICE_REL_NS, "id")) != null ? _b : void 0;
    if (!relationshipId) continue;
    const rel = rels.get(relationshipId);
    if (!rel) {
      tables.push({ relationshipId, columns: [] });
      continue;
    }
    tables.push(parseTablePart(pkg, relationshipId, resolveRelationshipTarget2(sheetPath, rel.target)));
  }
  return tables;
}
__name(parseTables, "parseTables");
function parseDataValidations(sheetDom) {
  var _a, _b, _c, _d, _e2, _f, _g, _h;
  const validationEls = sheetDom.getElementsByTagNameNS(SS_NS, "dataValidation");
  const validations = [];
  for (let i2 = 0; i2 < validationEls.length; i2++) {
    const el = validationEls[i2];
    if (!el) continue;
    const validation = {};
    setIfDefined2(validation, "sqref", (_a = el.getAttribute("sqref")) != null ? _a : void 0);
    setIfDefined2(validation, "type", (_b = el.getAttribute("type")) != null ? _b : void 0);
    setIfDefined2(validation, "operator", (_c = el.getAttribute("operator")) != null ? _c : void 0);
    setIfDefined2(validation, "allowBlank", parseBooleanAttr2(el.getAttribute("allowBlank")));
    setIfDefined2(validation, "showDropDown", parseBooleanAttr2(el.getAttribute("showDropDown")));
    setIfDefined2(validation, "showInputMessage", parseBooleanAttr2(el.getAttribute("showInputMessage")));
    setIfDefined2(validation, "showErrorMessage", parseBooleanAttr2(el.getAttribute("showErrorMessage")));
    setIfDefined2(validation, "errorStyle", (_d = el.getAttribute("errorStyle")) != null ? _d : void 0);
    setIfDefined2(validation, "errorTitle", (_e2 = el.getAttribute("errorTitle")) != null ? _e2 : void 0);
    setIfDefined2(validation, "error", (_f = el.getAttribute("error")) != null ? _f : void 0);
    setIfDefined2(validation, "promptTitle", (_g = el.getAttribute("promptTitle")) != null ? _g : void 0);
    setIfDefined2(validation, "prompt", (_h = el.getAttribute("prompt")) != null ? _h : void 0);
    setIfDefined2(validation, "formula1", textOf2(firstChildNs3(el, SS_NS, "formula1")) || void 0);
    setIfDefined2(validation, "formula2", textOf2(firstChildNs3(el, SS_NS, "formula2")) || void 0);
    validations.push(validation);
  }
  return validations;
}
__name(parseDataValidations, "parseDataValidations");
function parseConditionalFormatRule(ruleEl) {
  var _a, _b, _c, _d;
  const rule = { formulas: [] };
  setIfDefined2(rule, "type", (_a = ruleEl.getAttribute("type")) != null ? _a : void 0);
  setIfDefined2(rule, "priority", parseOptionalNumber2(ruleEl.getAttribute("priority")));
  setIfDefined2(rule, "operator", (_b = ruleEl.getAttribute("operator")) != null ? _b : void 0);
  setIfDefined2(rule, "dxfId", parseOptionalNumber2(ruleEl.getAttribute("dxfId")));
  setIfDefined2(rule, "stopIfTrue", parseBooleanAttr2(ruleEl.getAttribute("stopIfTrue")));
  setIfDefined2(rule, "aboveAverage", parseBooleanAttr2(ruleEl.getAttribute("aboveAverage")));
  setIfDefined2(rule, "percent", parseBooleanAttr2(ruleEl.getAttribute("percent")));
  setIfDefined2(rule, "bottom", parseBooleanAttr2(ruleEl.getAttribute("bottom")));
  setIfDefined2(rule, "rank", parseOptionalNumber2(ruleEl.getAttribute("rank")));
  setIfDefined2(rule, "text", (_c = ruleEl.getAttribute("text")) != null ? _c : void 0);
  setIfDefined2(rule, "timePeriod", (_d = ruleEl.getAttribute("timePeriod")) != null ? _d : void 0);
  const formulaEls = childElementsNs3(ruleEl, SS_NS, "formula");
  rule.formulas = formulaEls.map((formula) => textOf2(formula));
  return rule;
}
__name(parseConditionalFormatRule, "parseConditionalFormatRule");
function parseConditionalFormats(sheetDom) {
  var _a;
  const conditionalFormattingEls = sheetDom.getElementsByTagNameNS(SS_NS, "conditionalFormatting");
  const conditionalFormats = [];
  for (let i2 = 0; i2 < conditionalFormattingEls.length; i2++) {
    const el = conditionalFormattingEls[i2];
    if (!el) continue;
    const format = {
      rules: childElementsNs3(el, SS_NS, "cfRule").map((rule) => parseConditionalFormatRule(rule))
    };
    setIfDefined2(format, "sqref", (_a = el.getAttribute("sqref")) != null ? _a : void 0);
    conditionalFormats.push(format);
  }
  return conditionalFormats;
}
__name(parseConditionalFormats, "parseConditionalFormats");
function relationshipTargetsByType(pkg, sheetPath, typeSuffix) {
  const rels = parseRelationships2(optionalXmlPart2(pkg, sheetRelationshipPartPath(sheetPath)));
  const targets = [];
  for (const rel of rels.values()) {
    if (rel.type.endsWith(typeSuffix)) {
      targets.push({ id: rel.id, path: resolveRelationshipTarget2(sheetPath, rel.target) });
    }
  }
  return targets;
}
__name(relationshipTargetsByType, "relationshipTargetsByType");
function parseComments(pkg, sheetPath) {
  const targets = relationshipTargetsByType(pkg, sheetPath, "/comments");
  const comments = [];
  for (const target of targets) {
    const part = optionalXmlPart2(pkg, target.path);
    if (!(part == null ? void 0 : part.xmlDom)) continue;
    const authors = Array.from(part.xmlDom.getElementsByTagNameNS(SS_NS, "author")).map((author) => textOf2(author));
    const commentEls = part.xmlDom.getElementsByTagNameNS(SS_NS, "comment");
    for (let i2 = 0; i2 < commentEls.length; i2++) {
      const el = commentEls[i2];
      if (!el) continue;
      const ref = el.getAttribute("ref");
      if (!ref) continue;
      const authorId = parseOptionalNumber2(el.getAttribute("authorId"));
      const comment = {
        ref,
        text: textOf2(firstChildNs3(el, SS_NS, "text"))
      };
      setIfDefined2(comment, "authorId", authorId);
      setIfDefined2(comment, "author", authorId === void 0 ? void 0 : authors[authorId]);
      setIfDefined2(comment, "shapeId", parseOptionalNumber2(el.getAttribute("shapeId")));
      comments.push(comment);
    }
  }
  return comments;
}
__name(parseComments, "parseComments");
function parseThreadedComments(pkg, sheetPath) {
  var _a, _b, _c, _d;
  const targets = relationshipTargetsByType(pkg, sheetPath, "/threadedComment");
  const comments = [];
  for (const target of targets) {
    const part = optionalXmlPart2(pkg, target.path);
    if (!(part == null ? void 0 : part.xmlDom)) continue;
    const commentEls = part.xmlDom.getElementsByTagNameNS("*", "threadedComment");
    for (let i2 = 0; i2 < commentEls.length; i2++) {
      const el = commentEls[i2];
      if (!el) continue;
      const ref = el.getAttribute("ref");
      if (!ref) continue;
      const comment = {
        ref,
        text: textOf2(firstChildNs3(el, (_a = el.namespaceURI) != null ? _a : "", "text")) || textOf2(el.getElementsByTagNameNS("*", "text")[0])
      };
      setIfDefined2(comment, "id", (_b = el.getAttribute("id")) != null ? _b : void 0);
      setIfDefined2(comment, "personId", (_c = el.getAttribute("personId")) != null ? _c : void 0);
      setIfDefined2(comment, "dateTime", (_d = el.getAttribute("dT")) != null ? _d : void 0);
      comments.push(comment);
    }
  }
  return comments;
}
__name(parseThreadedComments, "parseThreadedComments");
function firstDescendantLocal(parent, localName) {
  var _a;
  return (_a = parent.getElementsByTagNameNS("*", localName)[0]) != null ? _a : null;
}
__name(firstDescendantLocal, "firstDescendantLocal");
function descendantsLocal(parent, localName) {
  return Array.from(parent.getElementsByTagNameNS("*", localName));
}
__name(descendantsLocal, "descendantsLocal");
function parseDrawingMarker(parent, localName) {
  var _a, _b, _c, _d, _e2, _f, _g, _h;
  const markerEl = firstDescendantLocal(parent, localName);
  if (!markerEl) return void 0;
  const marker2 = {};
  setIfDefined2(marker2, "column", parseOptionalNumber2((_b = (_a = firstDescendantLocal(markerEl, "col")) == null ? void 0 : _a.textContent) != null ? _b : null));
  setIfDefined2(marker2, "columnOffset", parseOptionalNumber2((_d = (_c = firstDescendantLocal(markerEl, "colOff")) == null ? void 0 : _c.textContent) != null ? _d : null));
  setIfDefined2(marker2, "row", parseOptionalNumber2((_f = (_e2 = firstDescendantLocal(markerEl, "row")) == null ? void 0 : _e2.textContent) != null ? _f : null));
  setIfDefined2(marker2, "rowOffset", parseOptionalNumber2((_h = (_g = firstDescendantLocal(markerEl, "rowOff")) == null ? void 0 : _g.textContent) != null ? _h : null));
  return Object.keys(marker2).length ? marker2 : void 0;
}
__name(parseDrawingMarker, "parseDrawingMarker");
function drawingObjectName(parent) {
  var _a, _b;
  return (_b = (_a = firstDescendantLocal(parent, "cNvPr")) == null ? void 0 : _a.getAttribute("name")) != null ? _b : void 0;
}
__name(drawingObjectName, "drawingObjectName");
function drawingColor(element, themeColors) {
  var _a, _b;
  const source = element == null ? void 0 : element.firstElementChild;
  const value = source == null ? void 0 : source.getAttribute("val");
  if (!source || !value) return void 0;
  const color = source.localName === "schemeClr" ? themeColorByName(themeColors, value) : source.localName === "srgbClr" ? ooxmlArgbToExcelColor(value) : void 0;
  const lumMod = parseOptionalNumber2((_b = (_a = firstDescendantLocal(source, "lumMod")) == null ? void 0 : _a.getAttribute("val")) != null ? _b : null);
  return color && applyExcelTint(color, lumMod === void 0 ? void 0 : lumMod / 1e5 - 1).rgb;
}
__name(drawingColor, "drawingColor");
function directDrawingChild(element, name) {
  return element ? Array.from(element.children).find((child) => child.localName === name) : void 0;
}
__name(directDrawingChild, "directDrawingChild");
function parseDrawingObject(anchorEl, rels, drawingPath, themeColors) {
  var _a, _b, _c, _d, _e2, _f, _g, _h, _i;
  const name = drawingObjectName(anchorEl);
  const hidden = parseBooleanAttr2((_b = (_a = firstDescendantLocal(anchorEl, "cNvPr")) == null ? void 0 : _a.getAttribute("hidden")) != null ? _b : null);
  const chartEl = firstDescendantLocal(anchorEl, "chart");
  if (chartEl) {
    const relationshipId = (_c = chartEl.getAttributeNS(OFFICE_REL_NS, "id")) != null ? _c : void 0;
    const rel = relationshipId ? rels.get(relationshipId) : void 0;
    return {
      kind: "chart",
      name,
      relationshipId,
      targetPath: rel ? resolveRelationshipTarget2(drawingPath, rel.target) : void 0,
      targetMode: rel == null ? void 0 : rel.targetMode
    };
  }
  const blipEl = firstDescendantLocal(anchorEl, "blip");
  if (blipEl) {
    const relationshipId = (_e2 = (_d = blipEl.getAttributeNS(OFFICE_REL_NS, "embed")) != null ? _d : blipEl.getAttributeNS(OFFICE_REL_NS, "link")) != null ? _e2 : void 0;
    const rel = relationshipId ? rels.get(relationshipId) : void 0;
    const object = {
      kind: "image",
      name,
      relationshipId,
      targetPath: rel ? resolveRelationshipTarget2(drawingPath, rel.target) : void 0,
      targetMode: rel == null ? void 0 : rel.targetMode
    };
    if (hidden) object.hidden = true;
    return object;
  }
  const shape = firstDescendantLocal(anchorEl, "sp");
  if (shape) {
    const object = { kind: "shape", name };
    if (hidden) object.hidden = true;
    if (shape.parentNode !== anchorEl) return object;
    const properties = directDrawingChild(shape, "spPr");
    const preset = (_f = directDrawingChild(properties, "prstGeom")) == null ? void 0 : _f.getAttribute("prst");
    if (!preset) return object;
    object.presetGeometry = preset;
    const style = directDrawingChild(shape, "style");
    const line = directDrawingChild(properties, "ln");
    setIfDefined2(object, "fillColor", directDrawingChild(properties, "noFill") ? "none" : drawingColor((_g = directDrawingChild(properties, "solidFill")) != null ? _g : directDrawingChild(style, "fillRef"), themeColors));
    setIfDefined2(object, "lineColor", directDrawingChild(line, "noFill") ? "none" : drawingColor((_h = directDrawingChild(line, "solidFill")) != null ? _h : directDrawingChild(style, "lnRef"), themeColors));
    setIfDefined2(object, "lineWidth", parseOptionalNumber2((_i = line == null ? void 0 : line.getAttribute("w")) != null ? _i : null));
    return object;
  }
  if (firstDescendantLocal(anchorEl, "graphicFrame")) {
    return { kind: "graphicFrame", name: drawingObjectName(anchorEl) };
  }
  return void 0;
}
__name(parseDrawingObject, "parseDrawingObject");
function parseDrawingAnchors(drawingDom, rels, drawingPath, themeColors) {
  var _a, _b, _c, _d, _e2, _f, _g, _h;
  const anchors = [];
  const specs = [
    ["twoCellAnchor", "twoCell"],
    ["oneCellAnchor", "oneCell"],
    ["absoluteAnchor", "absolute"]
  ];
  for (const [localName, kind] of specs) {
    for (const anchorEl of descendantsLocal(drawingDom, localName)) {
      const anchor = { kind };
      setIfDefined2(anchor, "from", parseDrawingMarker(anchorEl, "from"));
      setIfDefined2(anchor, "to", parseDrawingMarker(anchorEl, "to"));
      const position = directDrawingChild(anchorEl, "pos");
      const extent = directDrawingChild(anchorEl, "ext");
      setIfDefined2(anchor, "x", parseOptionalNumber2((_a = position == null ? void 0 : position.getAttribute("x")) != null ? _a : null));
      setIfDefined2(anchor, "y", parseOptionalNumber2((_b = position == null ? void 0 : position.getAttribute("y")) != null ? _b : null));
      setIfDefined2(anchor, "width", parseOptionalNumber2((_c = extent == null ? void 0 : extent.getAttribute("cx")) != null ? _c : null));
      setIfDefined2(anchor, "height", parseOptionalNumber2((_d = extent == null ? void 0 : extent.getAttribute("cy")) != null ? _d : null));
      const object = parseDrawingObject(anchorEl, rels, drawingPath, themeColors);
      setIfDefined2(anchor, "object", object);
      if ((object == null ? void 0 : object.kind) === "image" || (object == null ? void 0 : object.kind) === "shape") {
        const drawing = directDrawingChild(anchorEl, object.kind === "image" ? "pic" : "sp");
        const transform = directDrawingChild(directDrawingChild(drawing, "spPr"), "xfrm");
        if (transform) {
          const offset = directDrawingChild(transform, "off");
          const size = directDrawingChild(transform, "ext");
          anchor.transform = {
            x: parseOptionalNumber2((_e2 = offset == null ? void 0 : offset.getAttribute("x")) != null ? _e2 : null),
            y: parseOptionalNumber2((_f = offset == null ? void 0 : offset.getAttribute("y")) != null ? _f : null),
            width: parseOptionalNumber2((_g = size == null ? void 0 : size.getAttribute("cx")) != null ? _g : null),
            height: parseOptionalNumber2((_h = size == null ? void 0 : size.getAttribute("cy")) != null ? _h : null)
          };
        }
      }
      anchors.push(anchor);
    }
  }
  return anchors;
}
__name(parseDrawingAnchors, "parseDrawingAnchors");
function drawingRelationshipPartPath(drawingPath) {
  return `${dirname2(drawingPath)}/_rels/${drawingPath.slice(drawingPath.lastIndexOf("/") + 1)}.rels`;
}
__name(drawingRelationshipPartPath, "drawingRelationshipPartPath");
function chartTitle(chartDom) {
  const titleEl = descendantsLocal(chartDom, "title")[0];
  if (!titleEl) return void 0;
  const text = descendantsLocal(titleEl, "t").map((el) => textOf2(el)).join("");
  return text || void 0;
}
__name(chartTitle, "chartTitle");
function parseChartPart(pkg, relationshipId, drawingPath, path) {
  const part = optionalXmlPart2(pkg, path);
  const chart = { relationshipId, drawingPath, path, formulaRefs: [] };
  if (!(part == null ? void 0 : part.xmlDom)) return chart;
  setIfDefined2(chart, "title", chartTitle(part.xmlDom));
  chart.formulaRefs = descendantsLocal(part.xmlDom, "f").map((el) => textOf2(el)).filter(Boolean);
  return chart;
}
__name(parseChartPart, "parseChartPart");
function parseDrawings(pkg, sheetPath, sheetDom, themeColors) {
  var _a, _b, _c;
  const sheetRels = parseRelationships2(optionalXmlPart2(pkg, sheetRelationshipPartPath(sheetPath)));
  const drawings = [];
  const charts = [];
  const images = [];
  for (const drawingEl of descendantsLocal(sheetDom, "drawing")) {
    const relationshipId = (_a = drawingEl.getAttributeNS(OFFICE_REL_NS, "id")) != null ? _a : void 0;
    if (!relationshipId) continue;
    const sheetRel = sheetRels.get(relationshipId);
    const drawingPath = sheetRel ? resolveRelationshipTarget2(sheetPath, sheetRel.target) : void 0;
    if (!drawingPath) {
      drawings.push({ relationshipId, anchors: [] });
      continue;
    }
    const drawingPart = optionalXmlPart2(pkg, drawingPath);
    const drawingRels = parseRelationships2(optionalXmlPart2(pkg, drawingRelationshipPartPath(drawingPath)));
    const anchors = (drawingPart == null ? void 0 : drawingPart.xmlDom) ? parseDrawingAnchors(drawingPart.xmlDom, drawingRels, drawingPath, themeColors) : [];
    drawings.push({ relationshipId, path: drawingPath, anchors });
    for (const anchor of anchors) {
      if (((_b = anchor.object) == null ? void 0 : _b.kind) === "chart" && anchor.object.targetPath) {
        charts.push(parseChartPart(pkg, anchor.object.relationshipId, drawingPath, anchor.object.targetPath));
      } else if (((_c = anchor.object) == null ? void 0 : _c.kind) === "image" && anchor.object.targetPath) {
        images.push({
          relationshipId: anchor.object.relationshipId,
          drawingPath,
          path: anchor.object.targetPath,
          targetMode: anchor.object.targetMode,
          name: anchor.object.name
        });
      }
    }
  }
  return { drawings, charts, images };
}
__name(parseDrawings, "parseDrawings");
function readExcelEmbeddedObjectPreviews(pkg, sheetPath) {
  var _a, _b, _c;
  const sheet = (_a = optionalXmlPart2(pkg, sheetPath)) == null ? void 0 : _a.xmlDom;
  if (!sheet) return [];
  const rels = parseRelationships2(optionalXmlPart2(pkg, sheetRelationshipPartPath(sheetPath)));
  const previews = [];
  const seen = /* @__PURE__ */ new Set();
  for (const item of descendantsLocal(sheet, "oleObject")) {
    const properties = directDrawingChild(item, "objectPr");
    const anchor = directDrawingChild(properties, "anchor");
    const from = anchor && parseDrawingMarker(anchor, "from");
    const to2 = anchor && parseDrawingMarker(anchor, "to");
    if (!from || !to2) continue;
    const shapeId = item.getAttribute("shapeId");
    if (shapeId && seen.has(shapeId)) continue;
    if (shapeId) seen.add(shapeId);
    const payload = rels.get((_b = item.getAttributeNS(OFFICE_REL_NS, "id")) != null ? _b : "");
    const preview = rels.get((_c = properties == null ? void 0 : properties.getAttributeNS(OFFICE_REL_NS, "id")) != null ? _c : "");
    previews.push({
      kind: "twoCell",
      from,
      to: to2,
      object: {
        kind: "image",
        name: (payload == null ? void 0 : payload.targetMode) !== "External" ? payload == null ? void 0 : payload.target.split("/").pop() : void 0,
        targetPath: preview && preview.targetMode !== "External" && preview.type.endsWith("/image") ? resolveRelationshipTarget2(sheetPath, preview.target) : void 0
      }
    });
  }
  return previews;
}
__name(readExcelEmbeddedObjectPreviews, "readExcelEmbeddedObjectPreviews");
function parsePane(sheetViewEl) {
  var _a, _b, _c;
  const paneEl = firstChildNs3(sheetViewEl, SS_NS, "pane");
  if (!paneEl) return void 0;
  const pane = {};
  setIfDefined2(pane, "xSplit", parseOptionalNumber2(paneEl.getAttribute("xSplit")));
  setIfDefined2(pane, "ySplit", parseOptionalNumber2(paneEl.getAttribute("ySplit")));
  setIfDefined2(pane, "topLeftCell", (_a = paneEl.getAttribute("topLeftCell")) != null ? _a : void 0);
  setIfDefined2(pane, "activePane", (_b = paneEl.getAttribute("activePane")) != null ? _b : void 0);
  setIfDefined2(pane, "state", (_c = paneEl.getAttribute("state")) != null ? _c : void 0);
  return Object.keys(pane).length ? pane : void 0;
}
__name(parsePane, "parsePane");
function parseSelections(sheetViewEl) {
  return childElementsNs3(sheetViewEl, SS_NS, "selection").map((selectionEl) => {
    var _a, _b, _c;
    const selection = {};
    setIfDefined2(selection, "pane", (_a = selectionEl.getAttribute("pane")) != null ? _a : void 0);
    setIfDefined2(selection, "activeCell", (_b = selectionEl.getAttribute("activeCell")) != null ? _b : void 0);
    setIfDefined2(selection, "activeCellId", parseOptionalNumber2(selectionEl.getAttribute("activeCellId")));
    setIfDefined2(selection, "sqref", (_c = selectionEl.getAttribute("sqref")) != null ? _c : void 0);
    return selection;
  });
}
__name(parseSelections, "parseSelections");
function parseSheetViews(sheetDom) {
  var _a, _b;
  const sheetViewEls = sheetDom.getElementsByTagNameNS(SS_NS, "sheetView");
  const views = [];
  for (let i2 = 0; i2 < sheetViewEls.length; i2++) {
    const el = sheetViewEls[i2];
    if (!el) continue;
    const view = { selections: parseSelections(el) };
    setIfDefined2(view, "workbookViewId", parseOptionalNumber2(el.getAttribute("workbookViewId")));
    setIfDefined2(view, "view", (_a = el.getAttribute("view")) != null ? _a : void 0);
    setIfDefined2(view, "tabSelected", parseBooleanAttr2(el.getAttribute("tabSelected")));
    setIfDefined2(view, "showGridLines", parseBooleanAttr2(el.getAttribute("showGridLines")));
    setIfDefined2(view, "showRowColHeaders", parseBooleanAttr2(el.getAttribute("showRowColHeaders")));
    setIfDefined2(view, "zoomScale", parseOptionalNumber2(el.getAttribute("zoomScale")));
    setIfDefined2(view, "zoomScaleNormal", parseOptionalNumber2(el.getAttribute("zoomScaleNormal")));
    setIfDefined2(view, "topLeftCell", (_b = el.getAttribute("topLeftCell")) != null ? _b : void 0);
    setIfDefined2(view, "pane", parsePane(el));
    views.push(view);
  }
  return views;
}
__name(parseSheetViews, "parseSheetViews");
function parseSheet(pkg, ref, sharedStrings, date1904, themeColors) {
  var _a, _b;
  if (!ref.path) {
    return __spreadProps(__spreadValues({}, ref), {
      sheetViews: [],
      columns: [],
      rows: [],
      mergedRanges: [],
      hyperlinks: [],
      tables: [],
      dataValidations: [],
      conditionalFormats: [],
      comments: [],
      threadedComments: [],
      drawings: [],
      charts: [],
      images: [],
      cells: []
    });
  }
  const part = optionalXmlPart2(pkg, ref.path);
  if (!(part == null ? void 0 : part.xmlDom)) {
    return __spreadProps(__spreadValues({}, ref), {
      sheetViews: [],
      columns: [],
      rows: [],
      mergedRanges: [],
      hyperlinks: [],
      tables: [],
      dataValidations: [],
      conditionalFormats: [],
      comments: [],
      threadedComments: [],
      drawings: [],
      charts: [],
      images: [],
      cells: []
    });
  }
  const dimension = (_b = (_a = part.xmlDom.getElementsByTagNameNS(SS_NS, "dimension")[0]) == null ? void 0 : _a.getAttribute("ref")) != null ? _b : void 0;
  const cellEls = part.xmlDom.getElementsByTagNameNS(SS_NS, "c");
  const cells = [];
  for (let i2 = 0; i2 < cellEls.length; i2++) {
    const parsed = cellEls[i2] ? parseCell(cellEls[i2], sharedStrings, date1904, themeColors) : null;
    if (parsed) cells.push(parsed);
  }
  const drawingInfo = parseDrawings(pkg, ref.path, part.xmlDom, themeColors);
  return __spreadProps(__spreadValues({}, ref), {
    dimension,
    sheetViews: parseSheetViews(part.xmlDom),
    columns: parseColumns(part.xmlDom),
    rows: parseRows(part.xmlDom),
    mergedRanges: parseMergedRanges(part.xmlDom),
    hyperlinks: parseHyperlinks(pkg, ref.path, part.xmlDom),
    tables: parseTables(pkg, ref.path, part.xmlDom),
    dataValidations: parseDataValidations(part.xmlDom),
    conditionalFormats: parseConditionalFormats(part.xmlDom),
    comments: parseComments(pkg, ref.path),
    threadedComments: parseThreadedComments(pkg, ref.path),
    drawings: drawingInfo.drawings,
    charts: drawingInfo.charts,
    images: drawingInfo.images,
    cells
  });
}
__name(parseSheet, "parseSheet");
function readWorkbookModel(pkg) {
  const sheetRefs = parseWorkbookSheets(pkg);
  const date1904 = parseWorkbookDate1904(pkg);
  const themeColors = parseThemeColors(pkg);
  const sharedStrings = parseSharedStrings(pkg, themeColors);
  return {
    date1904,
    sharedStrings: sharedStrings.map((entry) => entry.text),
    definedNames: parseDefinedNames(pkg),
    styles: parseStyles(pkg, themeColors),
    sheets: sheetRefs.map((sheet) => parseSheet(pkg, sheet, sharedStrings, date1904, themeColors))
  };
}
__name(readWorkbookModel, "readWorkbookModel");
var XML_DECL = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
var CONTENT_TYPES_NS3 = "http://schemas.openxmlformats.org/package/2006/content-types";
var CONTENT_TYPES_CONTENT_TYPE = "application/xml";
var WORKBOOK_CONTENT_TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml";
var WORKSHEET_CONTENT_TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml";
var STYLES_CONTENT_TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml";
var STYLES_PART_PATH = "xl/styles.xml";
var STYLES_REL_TYPE = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles";
var TC_NS = "http://schemas.microsoft.com/office/spreadsheetml/2018/threadedcomments";
var RELS_CONTENT_TYPE = "application/vnd.openxmlformats-package.relationships+xml";
var HYPERLINK_REL_TYPE = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink";
var COMMENTS_CONTENT_TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.comments+xml";
var COMMENTS_REL_TYPE = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments";
var THREADED_COMMENTS_REL_TYPE = "http://schemas.microsoft.com/office/2017/10/relationships/threadedComment";
var TABLE_CONTENT_TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.table+xml";
var TABLE_REL_TYPE = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/table";
var WORKSHEET_REL_TYPE = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet";
var DRAWING_CONTENT_TYPE = "application/vnd.openxmlformats-officedocument.drawing+xml";
var DRAWING_REL_TYPE = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing";
var CHART_CONTENT_TYPE = "application/vnd.openxmlformats-officedocument.drawingml.chart+xml";
var CHART_REL_TYPE = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/chart";
var DRAWING_NS2 = "http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing";
var A_NS = "http://schemas.openxmlformats.org/drawingml/2006/main";
var CHART_NS = "http://schemas.openxmlformats.org/drawingml/2006/chart";
function syncWorkbookModelToPackage(pkg, model) {
  syncStylesPart(pkg, model.styles);
  syncWorkbookRelationships(pkg, model);
  syncWorkbookPart(pkg, model);
  for (const sheet of model.sheets) {
    syncWorksheetRelationships(pkg, sheet);
    syncWorksheetTableRelationships(pkg, sheet);
    syncWorksheetCommentRelationships(pkg, sheet);
    syncWorksheetThreadedCommentRelationships(pkg, sheet);
    syncWorksheetDrawingRelationships(pkg, sheet);
    syncWorksheetPart(pkg, sheet);
    syncTableParts(pkg, sheet);
    syncCommentParts(pkg, sheet);
    syncThreadedCommentParts(pkg, sheet);
    syncDrawingParts(pkg, sheet);
    syncChartParts(pkg, sheet);
  }
}
__name(syncWorkbookModelToPackage, "syncWorkbookModelToPackage");
function syncWorkbookRelationships(pkg, model) {
  var _a;
  const relsPath = "xl/_rels/workbook.xml.rels";
  const rels = parseRelationships3(getPart(pkg, relsPath));
  const usedSheetRelIds = /* @__PURE__ */ new Set();
  let changed = false;
  for (const sheet of model.sheets) {
    (_a = sheet.path) != null ? _a : sheet.path = nextIndexedPartPath(pkg, "xl/worksheets/sheet", ".xml");
    const target = relativeRelationshipTarget("xl/workbook.xml", sheet.path);
    const id = sheet.relationshipId || findReusableRelationshipId(rels, WORKSHEET_REL_TYPE, target);
    if (id) {
      sheet.relationshipId = id;
    } else {
      sheet.relationshipId = nextRelationshipId(rels);
      changed = true;
    }
    usedSheetRelIds.add(sheet.relationshipId);
    const nextRel = {
      id: sheet.relationshipId,
      type: WORKSHEET_REL_TYPE,
      target
    };
    const previous = rels.get(nextRel.id);
    if (!previous || !sameRelationship(previous, nextRel)) {
      rels.set(nextRel.id, nextRel);
      changed = true;
    }
    if (!getPart(pkg, sheet.path)) {
      setXmlPart(
        pkg,
        sheet.path,
        WORKSHEET_CONTENT_TYPE,
        `${XML_DECL}<worksheet xmlns="${SS_NS}" xmlns:r="${OFFICE_REL_NS}"/>`
      );
      setXmlPart(
        pkg,
        relationshipPartPath(sheet.path),
        RELS_CONTENT_TYPE,
        serializeRelationships(/* @__PURE__ */ new Map())
      );
      changed = true;
    }
    ensureContentTypeOverride(pkg, sheet.path, WORKSHEET_CONTENT_TYPE);
  }
  for (const rel of Array.from(rels.values())) {
    if (rel.type !== WORKSHEET_REL_TYPE || usedSheetRelIds.has(rel.id)) continue;
    const targetPath = resolveRelationshipTarget3("xl/workbook.xml", rel.target);
    rels.delete(rel.id);
    deletePart(pkg, targetPath);
    deletePart(pkg, relationshipPartPath(targetPath));
    removeContentTypeOverride(pkg, targetPath);
    changed = true;
  }
  if (!Array.from(rels.values()).some((rel) => rel.type === STYLES_REL_TYPE)) {
    const id = nextRelationshipId(rels);
    rels.set(id, {
      id,
      type: STYLES_REL_TYPE,
      target: relativeRelationshipTarget("xl/workbook.xml", STYLES_PART_PATH)
    });
    changed = true;
  }
  if (changed) writeRelationshipsPart(pkg, relsPath, rels);
}
__name(syncWorkbookRelationships, "syncWorkbookRelationships");
function syncStylesPart(pkg, styles) {
  const normalized = normalizeStyles(styles);
  styles.numberFormats = normalized.numberFormats;
  styles.fonts = normalized.fonts;
  styles.fills = normalized.fills;
  styles.borders = normalized.borders;
  styles.cellFormats = normalized.cellFormats;
  const xml = serializeStyles(styles);
  const part = getPart(pkg, STYLES_PART_PATH);
  if (part == null ? void 0 : part.xmlDom) {
    replacePartXml(part, xml);
  } else {
    setXmlPart(pkg, STYLES_PART_PATH, STYLES_CONTENT_TYPE, xml);
  }
  ensureContentTypeOverride(pkg, STYLES_PART_PATH, STYLES_CONTENT_TYPE);
}
__name(syncStylesPart, "syncStylesPart");
function createWorkbookPackageFromModel(model) {
  const pkg = createPackage();
  const standaloneModel = cloneStandaloneWorkbookModel(model);
  seedWorkbookPackage(pkg, standaloneModel);
  syncWorkbookModelToPackage(pkg, standaloneModel);
  return pkg;
}
__name(createWorkbookPackageFromModel, "createWorkbookPackageFromModel");
function cloneStandaloneWorkbookModel(model) {
  const clone2 = JSON.parse(JSON.stringify(model));
  for (const sheet of clone2.sheets) {
    sheet.threadedComments = [];
    const creatableCharts = sheet.charts.filter((chart) => chart.type);
    sheet.charts = creatableCharts;
    sheet.drawings = sheet.drawings.map((drawing) => __spreadProps(__spreadValues({}, drawing), {
      anchors: drawing.anchors.filter(
        (anchor) => {
          var _a;
          return ((_a = anchor.object) == null ? void 0 : _a.kind) === "chart" && creatableCharts.some((chart) => {
            var _a2, _b;
            return chart.path === ((_a2 = anchor.object) == null ? void 0 : _a2.targetPath) || chart.title === ((_b = anchor.object) == null ? void 0 : _b.name);
          });
        }
      )
    })).filter((drawing) => drawing.anchors.length > 0);
    sheet.images = [];
  }
  return clone2;
}
__name(cloneStandaloneWorkbookModel, "cloneStandaloneWorkbookModel");
function seedWorkbookPackage(pkg, model) {
  setXmlPart(
    pkg,
    "[Content_Types].xml",
    CONTENT_TYPES_CONTENT_TYPE,
    serializeBaseContentTypes(model)
  );
  setXmlPart(
    pkg,
    "_rels/.rels",
    RELS_CONTENT_TYPE,
    serializeRelationships(
      /* @__PURE__ */ new Map([
        [
          "rId1",
          {
            id: "rId1",
            type: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument",
            target: "xl/workbook.xml"
          }
        ]
      ])
    )
  );
  const workbookRels = /* @__PURE__ */ new Map();
  model.sheets.forEach((sheet, index) => {
    sheet.relationshipId || (sheet.relationshipId = `rId${index + 1}`);
    sheet.path || (sheet.path = `xl/worksheets/sheet${index + 1}.xml`);
    workbookRels.set(sheet.relationshipId, {
      id: sheet.relationshipId,
      type: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet",
      target: `worksheets/sheet${index + 1}.xml`
    });
    setXmlPart(
      pkg,
      sheet.path,
      WORKSHEET_CONTENT_TYPE,
      `${XML_DECL}<worksheet xmlns="${SS_NS}" xmlns:r="${OFFICE_REL_NS}"/>`
    );
    setXmlPart(
      pkg,
      relationshipPartPath(sheet.path),
      RELS_CONTENT_TYPE,
      serializeRelationships(/* @__PURE__ */ new Map())
    );
  });
  setXmlPart(
    pkg,
    "xl/workbook.xml",
    WORKBOOK_CONTENT_TYPE,
    `${XML_DECL}<workbook xmlns="${SS_NS}" xmlns:r="${OFFICE_REL_NS}"><sheets/></workbook>`
  );
  setXmlPart(
    pkg,
    "xl/_rels/workbook.xml.rels",
    RELS_CONTENT_TYPE,
    serializeRelationships(workbookRels)
  );
}
__name(seedWorkbookPackage, "seedWorkbookPackage");
function serializeBaseContentTypes(model) {
  const overrides = [
    ["/xl/workbook.xml", WORKBOOK_CONTENT_TYPE],
    ...model.sheets.map((sheet, index) => {
      var _a;
      return [
        `/${(_a = sheet.path) != null ? _a : `xl/worksheets/sheet${index + 1}.xml`}`,
        WORKSHEET_CONTENT_TYPE
      ];
    })
  ];
  return `${XML_DECL}<Types xmlns="${CONTENT_TYPES_NS3}"><Default Extension="rels" ContentType="${RELS_CONTENT_TYPE}"/><Default Extension="xml" ContentType="application/xml"/>${overrides.map(
    ([partName, contentType]) => `<Override PartName="${xmlAttr2(partName)}" ContentType="${xmlAttr2(contentType)}"/>`
  ).join("")}</Types>`;
}
__name(serializeBaseContentTypes, "serializeBaseContentTypes");
function setXmlPart(pkg, path, contentType, xml) {
  setPart(
    pkg,
    createXmlPart({
      path,
      contentType,
      xmlDom: to(xml)
    })
  );
}
__name(setXmlPart, "setXmlPart");
function syncWorksheetTableRelationships(pkg, sheet) {
  var _a, _b;
  if (!sheet.path) return;
  const relsPath = relationshipPartPath(sheet.path);
  const rels = parseRelationships3(getPart(pkg, relsPath));
  if (!sheet.tables.length && !Array.from(rels.values()).some((rel) => rel.type === TABLE_REL_TYPE))
    return;
  const usedTableRelIds = /* @__PURE__ */ new Set();
  let changed = false;
  for (const table of sheet.tables) {
    (_a = table.id) != null ? _a : table.id = nextTableId(sheet);
    (_b = table.path) != null ? _b : table.path = nextIndexedPartPath(pkg, "xl/tables/table", ".xml");
    const target = relativeRelationshipTarget(sheet.path, table.path);
    const id = table.relationshipId || findReusableRelationshipId(rels, TABLE_REL_TYPE, target);
    if (id) {
      table.relationshipId = id;
    } else {
      table.relationshipId = nextRelationshipId(rels);
      changed = true;
    }
    usedTableRelIds.add(table.relationshipId);
    const nextRel = {
      id: table.relationshipId,
      type: TABLE_REL_TYPE,
      target
    };
    const previous = rels.get(nextRel.id);
    if (!previous || !sameRelationship(previous, nextRel)) {
      rels.set(nextRel.id, nextRel);
      changed = true;
    }
  }
  for (const rel of Array.from(rels.values())) {
    if (rel.type === TABLE_REL_TYPE && !usedTableRelIds.has(rel.id)) {
      const targetPath = resolveRelationshipTarget3(sheet.path, rel.target);
      rels.delete(rel.id);
      deletePart(pkg, targetPath);
      removeContentTypeOverride(pkg, targetPath);
      changed = true;
    }
  }
  if (changed) writeRelationshipsPart(pkg, relsPath, rels);
}
__name(syncWorksheetTableRelationships, "syncWorksheetTableRelationships");
function syncWorksheetCommentRelationships(pkg, sheet) {
  if (!sheet.path) return;
  const relsPath = relationshipPartPath(sheet.path);
  const rels = parseRelationships3(getPart(pkg, relsPath));
  const commentRels = Array.from(rels.values()).filter((rel) => rel.type === COMMENTS_REL_TYPE);
  if (sheet.comments.length || !commentRels.length) return;
  for (const rel of commentRels) {
    const targetPath = resolveRelationshipTarget3(sheet.path, rel.target);
    rels.delete(rel.id);
    deletePart(pkg, targetPath);
    removeContentTypeOverride(pkg, targetPath);
  }
  writeRelationshipsPart(pkg, relsPath, rels);
}
__name(syncWorksheetCommentRelationships, "syncWorksheetCommentRelationships");
function syncWorksheetThreadedCommentRelationships(pkg, sheet) {
  if (!sheet.path) return;
  const relsPath = relationshipPartPath(sheet.path);
  const rels = parseRelationships3(getPart(pkg, relsPath));
  const commentRels = Array.from(rels.values()).filter(
    (rel) => rel.type === THREADED_COMMENTS_REL_TYPE
  );
  if (sheet.threadedComments.length || !commentRels.length) return;
  for (const rel of commentRels) {
    const targetPath = resolveRelationshipTarget3(sheet.path, rel.target);
    rels.delete(rel.id);
    deletePart(pkg, targetPath);
    removeContentTypeOverride(pkg, targetPath);
  }
  writeRelationshipsPart(pkg, relsPath, rels);
}
__name(syncWorksheetThreadedCommentRelationships, "syncWorksheetThreadedCommentRelationships");
function syncWorksheetDrawingRelationships(pkg, sheet) {
  var _a, _b, _c, _d, _e2, _f, _g, _h;
  if (!sheet.path) return;
  const needsDrawing = sheet.drawings.some((drawing2) => drawing2.anchors.length > 0) || sheet.charts.some((chart) => chart.type);
  if (!needsDrawing) return;
  const drawing = (_a = sheet.drawings[0]) != null ? _a : { anchors: [] };
  if (!sheet.drawings[0]) sheet.drawings.push(drawing);
  (_b = drawing.path) != null ? _b : drawing.path = nextIndexedPartPath(pkg, "xl/drawings/drawing", ".xml");
  const sheetRelsPath = relationshipPartPath(sheet.path);
  const sheetRels = parseRelationships3(getPart(pkg, sheetRelsPath));
  const drawingTarget = relativeRelationshipTarget(sheet.path, drawing.path);
  drawing.relationshipId || (drawing.relationshipId = findReusableRelationshipId(sheetRels, DRAWING_REL_TYPE, drawingTarget));
  drawing.relationshipId || (drawing.relationshipId = nextRelationshipId(sheetRels));
  sheetRels.set(drawing.relationshipId, {
    id: drawing.relationshipId,
    type: DRAWING_REL_TYPE,
    target: drawingTarget
  });
  writeRelationshipsPart(pkg, sheetRelsPath, sheetRels);
  ensureContentTypeOverride(pkg, drawing.path, DRAWING_CONTENT_TYPE);
  const drawingRelsPath = relationshipPartPath(drawing.path);
  const drawingRels = parseRelationships3(getPart(pkg, drawingRelsPath));
  const chartAnchors = drawing.anchors.filter((anchor) => {
    var _a2;
    return ((_a2 = anchor.object) == null ? void 0 : _a2.kind) === "chart";
  });
  const usedChartPaths = new Set(sheet.charts.map((chart) => chart.path).filter((path) => Boolean(path)));
  for (let i2 = 0; i2 < sheet.charts.length; i2++) {
    const chart = sheet.charts[i2];
    if (!(chart == null ? void 0 : chart.type)) continue;
    (_c = chart.path) != null ? _c : chart.path = nextIndexedPartPathAvoiding(pkg, "xl/charts/chart", ".xml", usedChartPaths);
    usedChartPaths.add(chart.path);
    chart.drawingPath = drawing.path;
    const chartTarget = relativeRelationshipTarget(drawing.path, chart.path);
    chart.relationshipId || (chart.relationshipId = findReusableRelationshipId(drawingRels, CHART_REL_TYPE, chartTarget));
    chart.relationshipId || (chart.relationshipId = nextRelationshipId(drawingRels));
    drawingRels.set(chart.relationshipId, {
      id: chart.relationshipId,
      type: CHART_REL_TYPE,
      target: chartTarget
    });
    const anchor = (_f = chartAnchors[i2]) != null ? _f : {
      kind: "twoCell",
      from: (_d = chart.position) == null ? void 0 : _d.from,
      to: (_e2 = chart.position) == null ? void 0 : _e2.to,
      object: { kind: "chart" }
    };
    if (!chartAnchors[i2]) drawing.anchors.push(anchor);
    (_g = anchor.object) != null ? _g : anchor.object = { kind: "chart" };
    anchor.object.kind = "chart";
    anchor.object.name = (_h = anchor.object.name) != null ? _h : chart.title;
    anchor.object.relationshipId = chart.relationshipId;
    anchor.object.targetPath = chart.path;
    if (chart.position) {
      anchor.from = __spreadValues({}, chart.position.from);
      anchor.to = __spreadValues({}, chart.position.to);
    }
  }
  writeRelationshipsPart(pkg, drawingRelsPath, drawingRels);
}
__name(syncWorksheetDrawingRelationships, "syncWorksheetDrawingRelationships");
function syncWorksheetRelationships(pkg, sheet) {
  var _a;
  if (!sheet.path) return;
  const relsPath = relationshipPartPath(sheet.path);
  const relsPart = getPart(pkg, relsPath);
  const rels = parseRelationships3(relsPart);
  const usedHyperlinkIds = /* @__PURE__ */ new Set();
  let changed = false;
  for (const hyperlink of sheet.hyperlinks) {
    if (!hyperlink.target) continue;
    const id = hyperlink.relationshipId || findReusableHyperlinkRelId(rels, hyperlink);
    if (id) {
      hyperlink.relationshipId = id;
    } else {
      hyperlink.relationshipId = nextRelationshipId(rels);
      changed = true;
    }
    usedHyperlinkIds.add(hyperlink.relationshipId);
    const nextRel = {
      id: hyperlink.relationshipId,
      type: HYPERLINK_REL_TYPE,
      target: hyperlink.target,
      targetMode: (_a = hyperlink.targetMode) != null ? _a : "External"
    };
    const previous = rels.get(nextRel.id);
    if (!previous || !sameRelationship(previous, nextRel)) {
      rels.set(nextRel.id, nextRel);
      changed = true;
    }
  }
  for (const rel of Array.from(rels.values())) {
    if (rel.type === HYPERLINK_REL_TYPE && !usedHyperlinkIds.has(rel.id)) {
      rels.delete(rel.id);
      changed = true;
    }
  }
  if (!changed && relsPart) return;
  if (!relsPart && !rels.size) return;
  writeRelationshipsPart(pkg, relsPath, rels);
}
__name(syncWorksheetRelationships, "syncWorksheetRelationships");
function writeRelationshipsPart(pkg, relsPath, rels) {
  const relsPart = getPart(pkg, relsPath);
  const xml = serializeRelationships(rels);
  if (relsPart) {
    replacePartXml(relsPart, xml);
  } else {
    setPart(
      pkg,
      createXmlPart({
        path: relsPath,
        contentType: RELS_CONTENT_TYPE,
        xmlDom: to(xml)
      })
    );
  }
}
__name(writeRelationshipsPart, "writeRelationshipsPart");
function syncWorkbookPart(pkg, model) {
  const part = getPart(pkg, "xl/workbook.xml");
  if (!(part == null ? void 0 : part.xmlDom)) return;
  const sheetsXml = model.sheets.map((sheet) => {
    const attrs = [
      `name="${xmlAttr2(sheet.name)}"`,
      `sheetId="${xmlAttr2(sheet.id)}"`,
      sheet.visibility ? `state="${xmlAttr2(sheet.visibility)}"` : "",
      sheet.relationshipId ? `r:id="${xmlAttr2(sheet.relationshipId)}"` : ""
    ].filter(Boolean);
    return `<sheet ${attrs.join(" ")}/>`;
  }).join("");
  const definedNamesXml = model.definedNames.length ? `<definedNames>${model.definedNames.map((name) => {
    const attrs = [
      `name="${xmlAttr2(name.name)}"`,
      name.localSheetId === void 0 ? "" : `localSheetId="${name.localSheetId}"`
    ].filter(Boolean);
    return `<definedName ${attrs.join(" ")}>${xmlText(name.text)}</definedName>`;
  }).join("")}</definedNames>` : "";
  const workbookPropertiesXml = model.date1904 ? '<workbookPr date1904="1"/>' : "";
  replacePartXml(
    part,
    `${XML_DECL}<workbook xmlns="${SS_NS}" xmlns:r="${OFFICE_REL_NS}">${workbookPropertiesXml}<sheets>${sheetsXml}</sheets>${definedNamesXml}</workbook>`
  );
}
__name(syncWorkbookPart, "syncWorkbookPart");
function syncWorksheetPart(pkg, sheet) {
  if (!sheet.path) return;
  const part = getPart(pkg, sheet.path);
  if (!(part == null ? void 0 : part.xmlDom)) return;
  const previous = part.xmlDom;
  replacePartXml(part, serializeWorksheet(sheet));
  preserveWorksheetPrintSettings(previous, part.xmlDom);
}
__name(syncWorksheetPart, "syncWorksheetPart");
function preserveWorksheetPrintSettings(previous, next) {
  const preserved = /* @__PURE__ */ new Set([
    "sheetPr",
    "sheetFormatPr",
    "printOptions",
    "pageMargins",
    "pageSetup",
    "headerFooter",
    "rowBreaks",
    "colBreaks"
  ]);
  const order = [
    "sheetPr",
    "dimension",
    "sheetViews",
    "sheetFormatPr",
    "cols",
    "sheetData",
    "mergeCells",
    "conditionalFormatting",
    "dataValidations",
    "hyperlinks",
    "printOptions",
    "pageMargins",
    "pageSetup",
    "headerFooter",
    "rowBreaks",
    "colBreaks",
    "drawing",
    "tableParts"
  ];
  const root = next.documentElement;
  for (const node of Array.from(previous.documentElement.childNodes)) {
    if (node.nodeType !== 1) continue;
    const element = node;
    if (element.namespaceURI !== SS_NS || !preserved.has(element.localName)) continue;
    const index = order.indexOf(element.localName);
    const before = Array.from(root.childNodes).find(
      (child) => child.nodeType === 1 && order.indexOf(child.localName) > index
    );
    root.insertBefore(next.importNode(element, true), before != null ? before : null);
  }
}
__name(preserveWorksheetPrintSettings, "preserveWorksheetPrintSettings");
function serializeWorksheet(sheet) {
  return `${XML_DECL}<worksheet xmlns="${SS_NS}" xmlns:r="${OFFICE_REL_NS}">${[
    sheet.dimension ? `<dimension ref="${xmlAttr2(sheet.dimension)}"/>` : "",
    serializeSheetViews(sheet.sheetViews),
    serializeColumns(sheet.columns),
    serializeSheetData(sheet),
    serializeMergedRanges(sheet),
    serializeConditionalFormats(sheet.conditionalFormats),
    serializeHyperlinks(sheet.hyperlinks),
    serializeDataValidations(sheet.dataValidations),
    serializeTableParts(sheet.tables),
    serializeDrawingRef(sheet.drawings)
  ].filter(Boolean).join("")}</worksheet>`;
}
__name(serializeWorksheet, "serializeWorksheet");
function serializeStyles(styles) {
  const customNumberFormats = styles.numberFormats.filter((format) => format.id >= 164);
  return `${XML_DECL}<styleSheet xmlns="${SS_NS}">${[
    customNumberFormats.length ? `<numFmts count="${customNumberFormats.length}">${customNumberFormats.map((format) => `<numFmt numFmtId="${format.id}" formatCode="${xmlAttr2(format.code)}"/>`).join("")}</numFmts>` : "",
    `<fonts count="${styles.fonts.length}">${styles.fonts.map(serializeFont).join("")}</fonts>`,
    `<fills count="${styles.fills.length}">${styles.fills.map(serializeFill).join("")}</fills>`,
    `<borders count="${styles.borders.length}">${styles.borders.map(serializeBorder).join("")}</borders>`,
    `<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>`,
    `<cellXfs count="${styles.cellFormats.length}">${styles.cellFormats.map(serializeCellFormat).join("")}</cellXfs>`,
    `<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>`
  ].filter(Boolean).join("")}</styleSheet>`;
}
__name(serializeStyles, "serializeStyles");
function serializeFont(font) {
  return `<font>${[
    font.size === void 0 ? "" : `<sz val="${font.size}"/>`,
    font.color ? serializeColor("color", font.color) : "",
    font.name === void 0 ? "" : `<name val="${xmlAttr2(font.name)}"/>`,
    font.family === void 0 ? "" : `<family val="${font.family}"/>`,
    font.charset === void 0 ? "" : `<charset val="${font.charset}"/>`,
    font.scheme === void 0 ? "" : `<scheme val="${xmlAttr2(font.scheme)}"/>`,
    font.bold ? "<b/>" : "",
    font.italic ? "<i/>" : "",
    font.underline ? "<u/>" : ""
  ].filter(Boolean).join("")}</font>`;
}
__name(serializeFont, "serializeFont");
function serializeFill(fill) {
  return `<fill><patternFill ${stringAttr("patternType", fill.patternType)}>${[
    fill.foregroundColor ? serializeColor("fgColor", fill.foregroundColor) : "",
    fill.backgroundColor ? serializeColor("bgColor", fill.backgroundColor) : ""
  ].filter(Boolean).join("")}</patternFill></fill>`;
}
__name(serializeFill, "serializeFill");
function serializeBorder(border) {
  return `<border>${["left", "right", "top", "bottom", "diagonal"].map(
    (side) => serializeBorderSide(
      side,
      border[side]
    )
  ).join("")}</border>`;
}
__name(serializeBorder, "serializeBorder");
function serializeBorderSide(name, side) {
  if (!side) return `<${name}/>`;
  return `<${name} ${stringAttr("style", side.style)}>${side.color ? serializeColor("color", side.color) : ""}</${name}>`;
}
__name(serializeBorderSide, "serializeBorderSide");
function serializeCellFormat(format) {
  var _a, _b, _c, _d, _e2;
  const attrs = [
    numberAttr("numFmtId", (_a = format.numberFormatId) != null ? _a : 0),
    numberAttr("fontId", (_b = format.fontId) != null ? _b : 0),
    numberAttr("fillId", (_c = format.fillId) != null ? _c : 0),
    numberAttr("borderId", (_d = format.borderId) != null ? _d : 0),
    numberAttr("xfId", (_e2 = format.xfId) != null ? _e2 : 0),
    booleanAttr("applyNumberFormat", format.applyNumberFormat),
    booleanAttr("applyFont", format.applyFont),
    booleanAttr("applyFill", format.applyFill),
    booleanAttr("applyBorder", format.applyBorder),
    booleanAttr("applyAlignment", format.applyAlignment)
  ].filter(Boolean);
  const alignment = format.alignment ? serializeAlignment(format.alignment) : "";
  return alignment ? `<xf ${attrs.join(" ")}>${alignment}</xf>` : `<xf ${attrs.join(" ")}/>`;
}
__name(serializeCellFormat, "serializeCellFormat");
function serializeAlignment(alignment) {
  const attrs = [
    stringAttr("horizontal", alignment.horizontal),
    stringAttr("vertical", alignment.vertical),
    numberAttr("textRotation", alignment.textRotation),
    booleanAttr("wrapText", alignment.wrapText),
    booleanAttr("shrinkToFit", alignment.shrinkToFit),
    numberAttr("indent", alignment.indent)
  ].filter(Boolean);
  return `<alignment ${attrs.join(" ")}/>`;
}
__name(serializeAlignment, "serializeAlignment");
function serializeColor(name, color) {
  return `<${name} rgb="${excelColorToOoxmlArgb(color, `Excel ${name}`)}"/>`;
}
__name(serializeColor, "serializeColor");
function normalizeStyles(styles) {
  return {
    numberFormats: styles.numberFormats,
    fonts: styles.fonts.length ? styles.fonts : [{}],
    fills: styles.fills.length ? styles.fills : [{}, { patternType: "gray125" }],
    borders: styles.borders.length ? styles.borders : [{}],
    cellFormats: styles.cellFormats.length ? styles.cellFormats : [{}]
  };
}
__name(normalizeStyles, "normalizeStyles");
function serializeSheetViews(views) {
  if (!views.length) return "";
  return `<sheetViews>${views.map((view) => {
    const attrs = [
      numberAttr("workbookViewId", view.workbookViewId),
      stringAttr("view", view.view),
      booleanAttr("tabSelected", view.tabSelected),
      booleanAttr("showGridLines", view.showGridLines),
      booleanAttr("showRowColHeaders", view.showRowColHeaders),
      numberAttr("zoomScale", view.zoomScale),
      numberAttr("zoomScaleNormal", view.zoomScaleNormal),
      stringAttr("topLeftCell", view.topLeftCell)
    ].filter(Boolean);
    const pane = view.pane ? `<pane ${[
      numberAttr("xSplit", view.pane.xSplit),
      numberAttr("ySplit", view.pane.ySplit),
      stringAttr("topLeftCell", view.pane.topLeftCell),
      stringAttr("activePane", view.pane.activePane),
      stringAttr("state", view.pane.state)
    ].filter(Boolean).join(" ")}/>` : "";
    const selections = view.selections.map(
      (selection) => `<selection ${[
        stringAttr("pane", selection.pane),
        stringAttr("activeCell", selection.activeCell),
        numberAttr("activeCellId", selection.activeCellId),
        stringAttr("sqref", selection.sqref)
      ].filter(Boolean).join(" ")}/>`
    ).join("");
    return `<sheetView ${attrs.join(" ")}>${pane}${selections}</sheetView>`;
  }).join("")}</sheetViews>`;
}
__name(serializeSheetViews, "serializeSheetViews");
function serializeColumns(columns) {
  if (!columns.length) return "";
  return `<cols>${columns.map(
    (column) => `<col ${[
      numberAttr("min", column.min),
      numberAttr("max", column.max),
      numberAttr("width", column.width),
      booleanAttr("hidden", column.hidden),
      numberAttr("style", column.styleId),
      booleanAttr("customWidth", column.customWidth)
    ].filter(Boolean).join(" ")}/>`
  ).join("")}</cols>`;
}
__name(serializeColumns, "serializeColumns");
function serializeSheetData(sheet) {
  var _a;
  const rowMap = /* @__PURE__ */ new Map();
  for (const row of sheet.rows) {
    rowMap.set(row.index, { row, cells: [] });
  }
  for (const cell of sheet.cells) {
    const entry = (_a = rowMap.get(cell.row)) != null ? _a : { cells: [] };
    entry.cells.push(cell);
    rowMap.set(cell.row, entry);
  }
  const rows = Array.from(rowMap.entries()).sort(([a2], [b2]) => a2 - b2);
  return `<sheetData>${rows.map(([index, entry]) => {
    const row = entry.row;
    const attrs = [
      numberAttr("r", index),
      numberAttr("ht", row == null ? void 0 : row.height),
      booleanAttr("hidden", row == null ? void 0 : row.hidden),
      numberAttr("s", row == null ? void 0 : row.styleId),
      booleanAttr("customHeight", row == null ? void 0 : row.customHeight)
    ].filter(Boolean);
    const cells = entry.cells.sort((a2, b2) => a2.column - b2.column).map((cell) => serializeCell(cell)).join("");
    return cells ? `<row ${attrs.join(" ")}>${cells}</row>` : `<row ${attrs.join(" ")}/>`;
  }).join("")}</sheetData>`;
}
__name(serializeSheetData, "serializeSheetData");
function serializeCell(cell) {
  var _a, _b, _c;
  const attrs = [stringAttr("r", cell.address), numberAttr("s", cell.styleId)].filter(Boolean);
  const formula = cell.formula ? `<f>${xmlText(cell.formula)}</f>` : "";
  if (cell.kind === "string") {
    attrs.push('t="inlineStr"');
    const richText = excelCellRichText(cell);
    if (richText) return `<c ${attrs.join(" ")}>${serializeExcelRichText(richText)}</c>`;
    const text = String((_a = cell.value) != null ? _a : "");
    const preserveSpace = /^\s|\s$/.test(text) ? ' xml:space="preserve"' : "";
    return `<c ${attrs.join(" ")}><is><t${preserveSpace}>${xmlText(text)}</t></is></c>`;
  }
  if (cell.kind === "boolean") {
    attrs.push('t="b"');
    return `<c ${attrs.join(" ")}>${formula}<v>${cell.value ? "1" : "0"}</v></c>`;
  }
  if (cell.kind === "error") {
    attrs.push('t="e"');
    return `<c ${attrs.join(" ")}>${formula}<v>${xmlText(String((_c = (_b = cell.value) != null ? _b : cell.rawValue) != null ? _c : ""))}</v></c>`;
  }
  if (cell.kind === "blank" && !formula) {
    return `<c ${attrs.join(" ")}/>`;
  }
  const value = cell.value === null || cell.value === void 0 ? "" : String(cell.value);
  return `<c ${attrs.join(" ")}>${formula}${value ? `<v>${xmlText(value)}</v>` : ""}</c>`;
}
__name(serializeCell, "serializeCell");
function serializeMergedRanges(sheet) {
  if (!sheet.mergedRanges.length) return "";
  return `<mergeCells count="${sheet.mergedRanges.length}">${sheet.mergedRanges.map((range) => `<mergeCell ref="${xmlAttr2(range.address)}"/>`).join("")}</mergeCells>`;
}
__name(serializeMergedRanges, "serializeMergedRanges");
function serializeConditionalFormats(formats) {
  return formats.map(
    (format) => `<conditionalFormatting ${stringAttr("sqref", format.sqref)}>${format.rules.map(
      (rule) => `<cfRule ${[
        stringAttr("type", rule.type),
        numberAttr("priority", rule.priority),
        stringAttr("operator", rule.operator),
        numberAttr("dxfId", rule.dxfId),
        booleanAttr("stopIfTrue", rule.stopIfTrue),
        booleanAttr("aboveAverage", rule.aboveAverage),
        booleanAttr("percent", rule.percent),
        booleanAttr("bottom", rule.bottom),
        numberAttr("rank", rule.rank),
        stringAttr("text", rule.text),
        stringAttr("timePeriod", rule.timePeriod)
      ].filter(Boolean).join(
        " "
      )}>${rule.formulas.map((formula) => `<formula>${xmlText(formula)}</formula>`).join("")}</cfRule>`
    ).join("")}</conditionalFormatting>`
  ).join("");
}
__name(serializeConditionalFormats, "serializeConditionalFormats");
function serializeHyperlinks(hyperlinks) {
  if (!hyperlinks.length) return "";
  return `<hyperlinks>${hyperlinks.map(
    (hyperlink) => `<hyperlink ${[
      stringAttr("ref", hyperlink.ref),
      hyperlink.relationshipId ? `r:id="${xmlAttr2(hyperlink.relationshipId)}"` : "",
      stringAttr("location", hyperlink.location),
      stringAttr("display", hyperlink.display),
      stringAttr("tooltip", hyperlink.tooltip)
    ].filter(Boolean).join(" ")}/>`
  ).join("")}</hyperlinks>`;
}
__name(serializeHyperlinks, "serializeHyperlinks");
function serializeDataValidations(validations) {
  if (!validations.length) return "";
  return `<dataValidations count="${validations.length}">${validations.map((validation) => {
    const attrs = [
      stringAttr("type", validation.type),
      stringAttr("operator", validation.operator),
      booleanAttr("allowBlank", validation.allowBlank),
      booleanAttr("showDropDown", validation.showDropDown),
      booleanAttr("showInputMessage", validation.showInputMessage),
      booleanAttr("showErrorMessage", validation.showErrorMessage),
      stringAttr("errorStyle", validation.errorStyle),
      stringAttr("sqref", validation.sqref),
      stringAttr("errorTitle", validation.errorTitle),
      stringAttr("error", validation.error),
      stringAttr("promptTitle", validation.promptTitle),
      stringAttr("prompt", validation.prompt)
    ].filter(Boolean);
    return `<dataValidation ${attrs.join(" ")}>${validation.formula1 ? `<formula1>${xmlText(validation.formula1)}</formula1>` : ""}${validation.formula2 ? `<formula2>${xmlText(validation.formula2)}</formula2>` : ""}</dataValidation>`;
  }).join("")}</dataValidations>`;
}
__name(serializeDataValidations, "serializeDataValidations");
function serializeTableParts(tables) {
  const tableIds = tables.map((table) => table.relationshipId).filter((id) => Boolean(id));
  if (!tableIds.length) return "";
  return `<tableParts count="${tableIds.length}">${tableIds.map((id) => `<tablePart r:id="${xmlAttr2(id)}"/>`).join("")}</tableParts>`;
}
__name(serializeTableParts, "serializeTableParts");
function serializeDrawingRef(drawings) {
  const drawing = drawings.find((item) => item.relationshipId);
  return (drawing == null ? void 0 : drawing.relationshipId) ? `<drawing r:id="${xmlAttr2(drawing.relationshipId)}"/>` : "";
}
__name(serializeDrawingRef, "serializeDrawingRef");
function syncTableParts(pkg, sheet) {
  for (const table of sheet.tables) {
    if (!table.path) continue;
    const part = getPart(pkg, table.path);
    const xml = serializeTable(table);
    if (part == null ? void 0 : part.xmlDom) {
      replacePartXml(part, xml);
    } else {
      setPart(
        pkg,
        createXmlPart({
          path: table.path,
          contentType: TABLE_CONTENT_TYPE,
          xmlDom: to(xml)
        })
      );
    }
    ensureContentTypeOverride(pkg, table.path, TABLE_CONTENT_TYPE);
  }
}
__name(syncTableParts, "syncTableParts");
function serializeTable(table) {
  const attrs = [
    numberAttr("id", table.id),
    stringAttr("name", table.name),
    stringAttr("displayName", table.displayName),
    stringAttr("ref", table.ref),
    numberAttr("headerRowCount", table.headerRowCount),
    numberAttr("totalsRowCount", table.totalsRowCount),
    booleanAttr("totalsRowShown", table.totalsRowShown)
  ].filter(Boolean);
  const autoFilter = serializeTableAutoFilter(table);
  const columns = `<tableColumns count="${table.columns.length}">${table.columns.map(
    (column) => `<tableColumn ${[
      numberAttr("id", column.id),
      stringAttr("name", column.name),
      stringAttr("totalsRowLabel", column.totalsRowLabel),
      stringAttr("totalsRowFunction", column.totalsRowFunction)
    ].filter(Boolean).join(" ")}/>`
  ).join("")}</tableColumns>`;
  const style = table.style ? `<tableStyleInfo ${[
    stringAttr("name", table.style.name),
    booleanAttr("showFirstColumn", table.style.showFirstColumn),
    booleanAttr("showLastColumn", table.style.showLastColumn),
    booleanAttr("showRowStripes", table.style.showRowStripes),
    booleanAttr("showColumnStripes", table.style.showColumnStripes)
  ].filter(Boolean).join(" ")}/>` : "";
  return `${XML_DECL}<table xmlns="${SS_NS}" ${attrs.join(" ")}>${autoFilter}${columns}${style}</table>`;
}
__name(serializeTable, "serializeTable");
function serializeTableAutoFilter(table) {
  var _a, _b;
  const autoFilter = (_a = table.autoFilter) != null ? _a : table.autoFilterRef ? { ref: table.autoFilterRef, filterColumns: [] } : void 0;
  if (!autoFilter) return "";
  const attrs = [stringAttr("ref", (_b = autoFilter.ref) != null ? _b : table.autoFilterRef)].filter(Boolean);
  return `<autoFilter ${attrs.join(" ")}>${[
    ...autoFilter.filterColumns.map(serializeTableFilterColumn),
    autoFilter.sortState ? serializeTableSortState(autoFilter.sortState) : ""
  ].filter(Boolean).join("")}</autoFilter>`;
}
__name(serializeTableAutoFilter, "serializeTableAutoFilter");
function serializeTableFilterColumn(column) {
  var _a;
  const attrs = [
    numberAttr("colId", column.colId),
    booleanAttr("hiddenButton", column.hiddenButton),
    booleanAttr("showButton", column.showButton)
  ].filter(Boolean);
  const filters = ((_a = column.filters) == null ? void 0 : _a.length) ? `<filters>${column.filters.map((filter) => `<filter val="${xmlAttr2(filter)}"/>`).join("")}</filters>` : "";
  return `<filterColumn ${attrs.join(" ")}>${filters}</filterColumn>`;
}
__name(serializeTableFilterColumn, "serializeTableFilterColumn");
function serializeTableSortState(sortState) {
  const attrs = [
    stringAttr("ref", sortState.ref),
    booleanAttr("caseSensitive", sortState.caseSensitive),
    stringAttr("sortMethod", sortState.sortMethod)
  ].filter(Boolean);
  return `<sortState ${attrs.join(" ")}>${sortState.conditions.map(serializeTableSortCondition).join("")}</sortState>`;
}
__name(serializeTableSortState, "serializeTableSortState");
function serializeTableSortCondition(condition) {
  const attrs = [
    stringAttr("ref", condition.ref),
    booleanAttr("descending", condition.descending),
    stringAttr("sortBy", condition.sortBy)
  ].filter(Boolean);
  return `<sortCondition ${attrs.join(" ")}/>`;
}
__name(serializeTableSortCondition, "serializeTableSortCondition");
function syncCommentParts(pkg, sheet) {
  if (!sheet.path || !sheet.comments.length) return;
  const target = ensureCommentPartTarget(pkg, sheet.path);
  const xml = serializeComments(sheet.comments);
  const part = getPart(pkg, target.path);
  if (part == null ? void 0 : part.xmlDom) {
    replacePartXml(part, xml);
  } else {
    setPart(
      pkg,
      createXmlPart({
        path: target.path,
        contentType: COMMENTS_CONTENT_TYPE,
        xmlDom: to(xml)
      })
    );
  }
  ensureContentTypeOverride(pkg, target.path, COMMENTS_CONTENT_TYPE);
}
__name(syncCommentParts, "syncCommentParts");
function ensureCommentPartTarget(pkg, sheetPath) {
  const existing = relationshipTargetsByType2(pkg, sheetPath, "/comments")[0];
  if (existing) return existing;
  const relsPath = relationshipPartPath(sheetPath);
  const rels = parseRelationships3(getPart(pkg, relsPath));
  const id = nextRelationshipId(rels);
  const path = nextIndexedPartPath(pkg, "xl/comments", ".xml");
  rels.set(id, {
    id,
    type: COMMENTS_REL_TYPE,
    target: relativeRelationshipTarget(sheetPath, path)
  });
  writeRelationshipsPart(pkg, relsPath, rels);
  return { id, path };
}
__name(ensureCommentPartTarget, "ensureCommentPartTarget");
function serializeComments(comments) {
  const authors = Array.from(new Set(comments.map((comment) => {
    var _a;
    return (_a = comment.author) != null ? _a : "";
  })));
  return `${XML_DECL}<comments xmlns="${SS_NS}"><authors>${authors.map((author) => `<author>${xmlText(author)}</author>`).join("")}</authors><commentList>${comments.map((comment) => {
    var _a, _b;
    const authorId = (_b = comment.authorId) != null ? _b : Math.max(0, authors.indexOf((_a = comment.author) != null ? _a : ""));
    return `<comment ${[
      stringAttr("ref", comment.ref),
      numberAttr("authorId", authorId),
      numberAttr("shapeId", comment.shapeId)
    ].filter(Boolean).join(" ")}><text><t>${xmlText(comment.text)}</t></text></comment>`;
  }).join("")}</commentList></comments>`;
}
__name(serializeComments, "serializeComments");
function syncThreadedCommentParts(pkg, sheet) {
  if (!sheet.path || !sheet.threadedComments.length) return;
  const target = relationshipTargetsByType2(pkg, sheet.path, "/threadedComment")[0];
  if (!target) return;
  const part = getPart(pkg, target.path);
  if (!(part == null ? void 0 : part.xmlDom)) return;
  replacePartXml(part, serializeThreadedComments(sheet.threadedComments));
}
__name(syncThreadedCommentParts, "syncThreadedCommentParts");
function serializeThreadedComments(comments) {
  return `${XML_DECL}<ThreadedComments xmlns="${TC_NS}">${comments.map(
    (comment) => `<threadedComment ${[
      stringAttr("ref", comment.ref),
      stringAttr("dT", comment.dateTime),
      stringAttr("personId", comment.personId),
      stringAttr("id", comment.id)
    ].filter(Boolean).join(" ")}><text>${xmlText(comment.text)}</text></threadedComment>`
  ).join("")}</ThreadedComments>`;
}
__name(serializeThreadedComments, "serializeThreadedComments");
function collectDrawingPositionPatches(pkg, before, after) {
  var _a, _b;
  if (before.sheets.length !== after.sheets.length) return null;
  const patches = [];
  for (let sheetIndex = 0; sheetIndex < after.sheets.length; sheetIndex++) {
    const previous = before.sheets[sheetIndex].drawings;
    const current = after.sheets[sheetIndex].drawings;
    if (previous.length !== current.length) return null;
    for (let drawingIndex = 0; drawingIndex < current.length; drawingIndex++) {
      const oldDrawing = previous[drawingIndex];
      const drawing = current[drawingIndex];
      if (JSON.stringify(oldDrawing) === JSON.stringify(drawing)) continue;
      if (!drawing.path || drawing.path !== oldDrawing.path || drawing.relationshipId !== oldDrawing.relationshipId || drawing.anchors.length !== oldDrawing.anchors.length) return null;
      const part = getPart(pkg, drawing.path);
      if (!(part == null ? void 0 : part.xmlDom)) return null;
      const elements = drawingAnchorElements(part.xmlDom);
      for (let anchorIndex = 0; anchorIndex < drawing.anchors.length; anchorIndex++) {
        const oldAnchor = oldDrawing.anchors[anchorIndex];
        const anchor = drawing.anchors[anchorIndex];
        if (JSON.stringify(oldAnchor) === JSON.stringify(anchor)) continue;
        const element = elements[anchorIndex];
        if (!element || anchor.kind !== oldAnchor.kind || ((_a = anchor.object) == null ? void 0 : _a.kind) !== "image" && ((_b = anchor.object) == null ? void 0 : _b.kind) !== "shape" || JSON.stringify(anchor.object) !== JSON.stringify(oldAnchor.object)) return null;
        patches.push({ part, element, anchor });
      }
    }
  }
  return patches;
}
__name(collectDrawingPositionPatches, "collectDrawingPositionPatches");
function patchDrawingPositions(patches) {
  for (const { part, element, anchor } of patches) {
    updateDrawingPosition(element, anchor);
    markDirty(part);
  }
}
__name(patchDrawingPositions, "patchDrawingPositions");
function drawingAnchorElements(dom) {
  return ["twoCellAnchor", "oneCellAnchor", "absoluteAnchor"].flatMap(
    (name) => Array.from(dom.getElementsByTagNameNS("*", name))
  );
}
__name(drawingAnchorElements, "drawingAnchorElements");
function syncDrawingParts(pkg, sheet) {
  var _a;
  for (const drawing of sheet.drawings) {
    if (!drawing.path) continue;
    const part = getPart(pkg, drawing.path);
    if (!(part == null ? void 0 : part.xmlDom)) {
      setXmlPart(pkg, drawing.path, DRAWING_CONTENT_TYPE, serializeDrawing(drawing));
      ensureContentTypeOverride(pkg, drawing.path, DRAWING_CONTENT_TYPE);
      continue;
    }
    const anchorEls = drawingAnchorElements(part.xmlDom);
    for (let i2 = 0; i2 < drawing.anchors.length; i2++) {
      const anchor = drawing.anchors[i2];
      const anchorEl = anchorEls[i2];
      if (!anchor || !anchorEl) continue;
      updateDrawingPosition(anchorEl, anchor);
      updateDrawingObjectName(anchorEl, (_a = anchor.object) == null ? void 0 : _a.name);
    }
    markDirty(part);
  }
}
__name(syncDrawingParts, "syncDrawingParts");
function updateDrawingPosition(element, anchor) {
  updateMarker(element, "from", anchor.from);
  updateMarker(element, "to", anchor.to);
  if (anchor.kind === "absolute") {
    const pos = element.getElementsByTagNameNS(DRAWING_NS2, "pos")[0];
    setDrawingCoordinates(pos, "x", anchor.x, "y", anchor.y);
  }
  if (anchor.kind !== "twoCell") {
    const extent = element.getElementsByTagNameNS(DRAWING_NS2, "ext")[0];
    setDrawingCoordinates(extent, "cx", anchor.width, "cy", anchor.height);
  }
  if (!anchor.transform) return;
  const transform = element.getElementsByTagNameNS(A_NS, "xfrm")[0];
  const offset = transform == null ? void 0 : transform.getElementsByTagNameNS(A_NS, "off")[0];
  const size = transform == null ? void 0 : transform.getElementsByTagNameNS(A_NS, "ext")[0];
  setDrawingCoordinates(offset, "x", anchor.transform.x, "y", anchor.transform.y);
  setDrawingCoordinates(size, "cx", anchor.transform.width, "cy", anchor.transform.height);
}
__name(updateDrawingPosition, "updateDrawingPosition");
function setDrawingCoordinates(element, horizontalName, horizontal, verticalName, vertical) {
  if (horizontal !== void 0) element == null ? void 0 : element.setAttribute(horizontalName, String(horizontal));
  if (vertical !== void 0) element == null ? void 0 : element.setAttribute(verticalName, String(vertical));
}
__name(setDrawingCoordinates, "setDrawingCoordinates");
function serializeDrawing(drawing) {
  return `${XML_DECL}<xdr:wsDr xmlns:xdr="${DRAWING_NS2}" xmlns:a="${A_NS}" xmlns:c="${CHART_NS}" xmlns:r="${OFFICE_REL_NS}">${drawing.anchors.map((anchor, index) => serializeDrawingAnchor(anchor, index + 2)).join("")}</xdr:wsDr>`;
}
__name(serializeDrawing, "serializeDrawing");
function serializeDrawingAnchor(anchor, id) {
  var _a, _b;
  const from = serializeDrawingMarker("from", anchor.from);
  const to2 = serializeDrawingMarker("to", anchor.to);
  if (((_a = anchor.object) == null ? void 0 : _a.kind) === "chart" && anchor.object.relationshipId) {
    const name = (_b = anchor.object.name) != null ? _b : `Chart ${id}`;
    return `<xdr:twoCellAnchor editAs="oneCell">${from}${to2}<xdr:graphicFrame macro=""><xdr:nvGraphicFramePr><xdr:cNvPr id="${id}" name="${xmlAttr2(name)}"/><xdr:cNvGraphicFramePr/></xdr:nvGraphicFramePr><xdr:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/></xdr:xfrm><a:graphic><a:graphicData uri="${CHART_NS}"><c:chart r:id="${xmlAttr2(anchor.object.relationshipId)}"/></a:graphicData></a:graphic></xdr:graphicFrame><xdr:clientData/></xdr:twoCellAnchor>`;
  }
  return `<xdr:twoCellAnchor editAs="oneCell">${from}${to2}<xdr:clientData/></xdr:twoCellAnchor>`;
}
__name(serializeDrawingAnchor, "serializeDrawingAnchor");
function serializeDrawingMarker(name, marker2) {
  var _a, _b, _c, _d;
  const value = marker2 != null ? marker2 : {};
  return `<xdr:${name}><xdr:col>${(_a = value.column) != null ? _a : 0}</xdr:col><xdr:colOff>${(_b = value.columnOffset) != null ? _b : 0}</xdr:colOff><xdr:row>${(_c = value.row) != null ? _c : 0}</xdr:row><xdr:rowOff>${(_d = value.rowOffset) != null ? _d : 0}</xdr:rowOff></xdr:${name}>`;
}
__name(serializeDrawingMarker, "serializeDrawingMarker");
function updateMarker(anchorEl, localName, marker2) {
  if (!marker2) return;
  const markerEl = anchorEl.getElementsByTagNameNS("*", localName)[0];
  if (!markerEl) return;
  setFirstLocalText(markerEl, "col", marker2.column);
  setFirstLocalText(markerEl, "colOff", marker2.columnOffset);
  setFirstLocalText(markerEl, "row", marker2.row);
  setFirstLocalText(markerEl, "rowOff", marker2.rowOffset);
}
__name(updateMarker, "updateMarker");
function updateDrawingObjectName(anchorEl, name) {
  if (name === void 0) return;
  const nameEl = anchorEl.getElementsByTagNameNS("*", "cNvPr")[0];
  if (nameEl) nameEl.setAttribute("name", name);
}
__name(updateDrawingObjectName, "updateDrawingObjectName");
function syncChartParts(pkg, sheet) {
  for (const chart of sheet.charts) {
    syncChartPart(pkg, chart);
  }
}
__name(syncChartParts, "syncChartParts");
function syncChartPart(pkg, chart) {
  var _a, _b;
  if (!chart.path) return;
  const part = getPart(pkg, chart.path);
  if (!(part == null ? void 0 : part.xmlDom)) {
    if (!chart.type || !chart.categoryRange || !((_a = chart.series) == null ? void 0 : _a.length)) return;
    setXmlPart(pkg, chart.path, CHART_CONTENT_TYPE, serializeChart(chart));
    ensureContentTypeOverride(pkg, chart.path, CHART_CONTENT_TYPE);
    return;
  }
  updateChartTitle(part.xmlDom, chart.title);
  const formulaEls = Array.from(part.xmlDom.getElementsByTagNameNS("*", "f"));
  for (let i2 = 0; i2 < chart.formulaRefs.length && i2 < formulaEls.length; i2++) {
    formulaEls[i2].textContent = (_b = chart.formulaRefs[i2]) != null ? _b : "";
  }
  markDirty(part);
}
__name(syncChartPart, "syncChartPart");
function serializeChart(chart) {
  const chartBody = serializeChartBody(chart);
  return `${XML_DECL}<c:chartSpace xmlns:c="${CHART_NS}" xmlns:a="${A_NS}" xmlns:r="${OFFICE_REL_NS}"><c:date1904 val="0"/><c:lang val="en-US"/><c:roundedCorners val="0"/><c:chart>${serializeChartTitle(chart.title)}<c:autoTitleDeleted val="${chart.title ? 0 : 1}"/><c:plotArea><c:layout/>${chartBody}</c:plotArea><c:legend><c:legendPos val="r"/><c:layout/></c:legend><c:plotVisOnly val="1"/></c:chart><c:printSettings><c:headerFooter/><c:pageMargins l="0.7" r="0.7" t="0.75" b="0.75" header="0.3" footer="0.3"/><c:pageSetup/></c:printSettings></c:chartSpace>`;
}
__name(serializeChart, "serializeChart");
function serializeChartTitle(title) {
  if (!title) return "";
  return `<c:title><c:tx><c:rich><a:bodyPr/><a:lstStyle/><a:p><a:r><a:t>${xmlText(title)}</a:t></a:r></a:p></c:rich></c:tx><c:layout/></c:title>`;
}
__name(serializeChartTitle, "serializeChartTitle");
function serializeChartBody(chart) {
  if (chart.type === "pie" || chart.type === "doughnut") return serializePieLikeChart(chart);
  if (chart.type === "line" || chart.type === "lineMarkers") return serializeLineChart(chart);
  return serializeBarChart(chart);
}
__name(serializeChartBody, "serializeChartBody");
function serializeBarChart(chart) {
  var _a, _b;
  const direction = ((_a = chart.type) == null ? void 0 : _a.startsWith("bar")) ? "bar" : "col";
  const grouping = ((_b = chart.type) == null ? void 0 : _b.endsWith("Stacked")) ? "stacked" : "clustered";
  return `<c:barChart><c:barDir val="${direction}"/><c:grouping val="${grouping}"/><c:varyColors val="0"/>${serializeCartesianSeries(chart)}<c:axId val="12345678"/><c:axId val="12345679"/></c:barChart>${serializeCategoryAxis()}${serializeValueAxis()}`;
}
__name(serializeBarChart, "serializeBarChart");
function serializeLineChart(chart) {
  const marker2 = chart.type === "lineMarkers" ? "1" : "0";
  return `<c:lineChart><c:grouping val="standard"/><c:varyColors val="0"/>${serializeCartesianSeries(chart, marker2)}<c:axId val="12345678"/><c:axId val="12345679"/></c:lineChart>${serializeCategoryAxis()}${serializeValueAxis()}`;
}
__name(serializeLineChart, "serializeLineChart");
function serializePieLikeChart(chart) {
  const tag = chart.type === "doughnut" ? "doughnutChart" : "pieChart";
  const hole = chart.type === "doughnut" ? '<c:holeSize val="50"/>' : "";
  return `<c:${tag}><c:varyColors val="1"/>${serializePieSeries(chart)}${hole}</c:${tag}>`;
}
__name(serializePieLikeChart, "serializePieLikeChart");
function serializeCartesianSeries(chart, marker2) {
  var _a;
  return ((_a = chart.series) != null ? _a : []).map((series, index) => {
    var _a2;
    const markerXml = marker2 === void 0 ? "" : `<c:marker><c:symbol val="${marker2 === "1" ? "auto" : "none"}"/></c:marker>`;
    return `<c:ser><c:idx val="${index}"/><c:order val="${index}"/>${serializeSeriesText(series.name)}${markerXml}<c:cat><c:strRef><c:f>${xmlText((_a2 = chart.categoryRange) != null ? _a2 : "")}</c:f></c:strRef></c:cat><c:val><c:numRef><c:f>${xmlText(series.values)}</c:f></c:numRef></c:val></c:ser>`;
  }).join("");
}
__name(serializeCartesianSeries, "serializeCartesianSeries");
function serializePieSeries(chart) {
  var _a, _b;
  const series = (_a = chart.series) == null ? void 0 : _a[0];
  if (!series) return "";
  return `<c:ser><c:idx val="0"/><c:order val="0"/>${serializeSeriesText(series.name)}<c:cat><c:strRef><c:f>${xmlText((_b = chart.categoryRange) != null ? _b : "")}</c:f></c:strRef></c:cat><c:val><c:numRef><c:f>${xmlText(series.values)}</c:f></c:numRef></c:val></c:ser>`;
}
__name(serializePieSeries, "serializePieSeries");
function serializeSeriesText(name) {
  if (!name) return "";
  if (name.includes("!") || name.includes("$")) {
    return `<c:tx><c:strRef><c:f>${xmlText(name)}</c:f></c:strRef></c:tx>`;
  }
  return `<c:tx><c:v>${xmlText(name)}</c:v></c:tx>`;
}
__name(serializeSeriesText, "serializeSeriesText");
function serializeCategoryAxis() {
  return '<c:catAx><c:axId val="12345678"/><c:scaling><c:orientation val="minMax"/></c:scaling><c:axPos val="b"/><c:tickLblPos val="nextTo"/><c:crossAx val="12345679"/><c:crosses val="autoZero"/><c:auto val="1"/><c:lblAlgn val="ctr"/><c:lblOffset val="100"/></c:catAx>';
}
__name(serializeCategoryAxis, "serializeCategoryAxis");
function serializeValueAxis() {
  return '<c:valAx><c:axId val="12345679"/><c:scaling><c:orientation val="minMax"/></c:scaling><c:axPos val="l"/><c:majorGridlines/><c:numFmt formatCode="General" sourceLinked="1"/><c:tickLblPos val="nextTo"/><c:crossAx val="12345678"/><c:crosses val="autoZero"/><c:crossBetween val="between"/></c:valAx>';
}
__name(serializeValueAxis, "serializeValueAxis");
function updateChartTitle(chartDom, title) {
  if (title === void 0) return;
  const titleEl = chartDom.getElementsByTagNameNS("*", "title")[0];
  if (!titleEl) return;
  const textEl = titleEl.getElementsByTagNameNS("*", "t")[0];
  if (textEl) textEl.textContent = title;
}
__name(updateChartTitle, "updateChartTitle");
function replacePartXml(part, xml) {
  part.xmlDom = to(xml);
  markDirty(part);
}
__name(replacePartXml, "replacePartXml");
function relationshipTargetsByType2(pkg, sourcePath, typeSuffix) {
  const rels = parseRelationships3(getPart(pkg, relationshipPartPath(sourcePath)));
  const targets = [];
  for (const rel of rels.values()) {
    if (rel.type.endsWith(typeSuffix)) {
      targets.push({ id: rel.id, path: resolveRelationshipTarget3(sourcePath, rel.target) });
    }
  }
  return targets;
}
__name(relationshipTargetsByType2, "relationshipTargetsByType");
function findReusableHyperlinkRelId(rels, hyperlink) {
  var _a, _b;
  for (const rel of rels.values()) {
    if (rel.type === HYPERLINK_REL_TYPE && rel.target === hyperlink.target && ((_a = rel.targetMode) != null ? _a : "External") === ((_b = hyperlink.targetMode) != null ? _b : "External")) {
      return rel.id;
    }
  }
  return void 0;
}
__name(findReusableHyperlinkRelId, "findReusableHyperlinkRelId");
function findReusableRelationshipId(rels, type, target, targetMode) {
  var _a;
  for (const rel of rels.values()) {
    if (rel.type === type && rel.target === target && ((_a = rel.targetMode) != null ? _a : "") === (targetMode != null ? targetMode : "")) {
      return rel.id;
    }
  }
  return void 0;
}
__name(findReusableRelationshipId, "findReusableRelationshipId");
function nextTableId(sheet) {
  let max = 0;
  for (const table of sheet.tables) {
    if (table.id && table.id > max) max = table.id;
  }
  return max + 1;
}
__name(nextTableId, "nextTableId");
function nextRelationshipId(rels) {
  let next = 1;
  while (rels.has(`rId${next}`)) next++;
  return `rId${next}`;
}
__name(nextRelationshipId, "nextRelationshipId");
function sameRelationship(left, right) {
  var _a, _b;
  return left.id === right.id && left.type === right.type && left.target === right.target && ((_a = left.targetMode) != null ? _a : "") === ((_b = right.targetMode) != null ? _b : "");
}
__name(sameRelationship, "sameRelationship");
function serializeRelationships(rels) {
  return `${XML_DECL}<Relationships xmlns="${REL_NS}">${Array.from(rels.values()).map((rel) => {
    const attrs = [
      `Id="${xmlAttr2(rel.id)}"`,
      `Type="${xmlAttr2(rel.type)}"`,
      `Target="${xmlAttr2(rel.target)}"`,
      stringAttr("TargetMode", rel.targetMode)
    ].filter(Boolean);
    return `<Relationship ${attrs.join(" ")}/>`;
  }).join("")}</Relationships>`;
}
__name(serializeRelationships, "serializeRelationships");
function nextIndexedPartPath(pkg, prefix, extension) {
  let next = 1;
  while (getPart(pkg, `${prefix}${next}${extension}`)) next++;
  return `${prefix}${next}${extension}`;
}
__name(nextIndexedPartPath, "nextIndexedPartPath");
function nextIndexedPartPathAvoiding(pkg, prefix, extension, used) {
  let next = 1;
  while (getPart(pkg, `${prefix}${next}${extension}`) || used.has(`${prefix}${next}${extension}`)) {
    next++;
  }
  return `${prefix}${next}${extension}`;
}
__name(nextIndexedPartPathAvoiding, "nextIndexedPartPathAvoiding");
function parseRelationships3(part) {
  var _a;
  const result = /* @__PURE__ */ new Map();
  if (!(part == null ? void 0 : part.xmlDom)) return result;
  const rels = part.xmlDom.getElementsByTagNameNS(REL_NS, "Relationship");
  for (let i2 = 0; i2 < rels.length; i2++) {
    const rel = rels[i2];
    if (!rel) continue;
    const id = rel.getAttribute("Id");
    const type = rel.getAttribute("Type");
    const target = rel.getAttribute("Target");
    if (!id || !type || !target) continue;
    result.set(id, {
      id,
      type,
      target,
      targetMode: (_a = rel.getAttribute("TargetMode")) != null ? _a : void 0
    });
  }
  return result;
}
__name(parseRelationships3, "parseRelationships");
function relationshipPartPath(path) {
  return `${dirname3(path)}/_rels/${path.slice(path.lastIndexOf("/") + 1)}.rels`;
}
__name(relationshipPartPath, "relationshipPartPath");
function dirname3(path) {
  const idx = path.lastIndexOf("/");
  return idx === -1 ? "" : path.slice(0, idx);
}
__name(dirname3, "dirname");
function normalizePath3(path) {
  const parts = [];
  for (const part of path.split("/")) {
    if (!part || part === ".") continue;
    if (part === "..") parts.pop();
    else parts.push(part);
  }
  return parts.join("/");
}
__name(normalizePath3, "normalizePath");
function resolveRelationshipTarget3(sourcePartPath, target) {
  if (target.startsWith("/")) return normalizePath3(target.slice(1));
  const base = dirname3(sourcePartPath);
  return normalizePath3(base ? `${base}/${target}` : target);
}
__name(resolveRelationshipTarget3, "resolveRelationshipTarget");
function relativeRelationshipTarget(sourcePartPath, targetPartPath) {
  const sourceParts = dirname3(sourcePartPath).split("/").filter(Boolean);
  const targetParts = targetPartPath.split("/").filter(Boolean);
  let common = 0;
  while (common < sourceParts.length && common < targetParts.length && sourceParts[common] === targetParts[common]) {
    common++;
  }
  const up = sourceParts.slice(common).map(() => "..");
  const down = targetParts.slice(common);
  return [...up, ...down].join("/") || targetPartPath;
}
__name(relativeRelationshipTarget, "relativeRelationshipTarget");
function ensureContentTypeOverride(pkg, path, contentType) {
  var _a;
  const part = getPart(pkg, "[Content_Types].xml");
  if (!((_a = part == null ? void 0 : part.xmlDom) == null ? void 0 : _a.documentElement)) return;
  const partName = `/${path}`;
  const overrides = part.xmlDom.getElementsByTagNameNS(CONTENT_TYPES_NS3, "Override");
  for (let i2 = 0; i2 < overrides.length; i2++) {
    const override2 = overrides[i2];
    if (!override2 || override2.getAttribute("PartName") !== partName) continue;
    if (override2.getAttribute("ContentType") !== contentType) {
      override2.setAttribute("ContentType", contentType);
      markDirty(part);
    }
    return;
  }
  const override = part.xmlDom.createElementNS(CONTENT_TYPES_NS3, "Override");
  override.setAttribute("PartName", partName);
  override.setAttribute("ContentType", contentType);
  part.xmlDom.documentElement.appendChild(override);
  markDirty(part);
}
__name(ensureContentTypeOverride, "ensureContentTypeOverride");
function removeContentTypeOverride(pkg, path) {
  var _a, _b;
  const part = getPart(pkg, "[Content_Types].xml");
  if (!((_a = part == null ? void 0 : part.xmlDom) == null ? void 0 : _a.documentElement)) return;
  const partName = `/${path}`;
  const overrides = Array.from(part.xmlDom.getElementsByTagNameNS(CONTENT_TYPES_NS3, "Override"));
  for (const override of overrides) {
    if (override.getAttribute("PartName") !== partName) continue;
    (_b = override.parentNode) == null ? void 0 : _b.removeChild(override);
    markDirty(part);
  }
}
__name(removeContentTypeOverride, "removeContentTypeOverride");
function setFirstLocalText(parent, localName, value) {
  if (value === void 0) return;
  const el = parent.getElementsByTagNameNS("*", localName)[0];
  if (el) el.textContent = String(value);
}
__name(setFirstLocalText, "setFirstLocalText");
function stringAttr(name, value) {
  return value === void 0 ? "" : `${name}="${xmlAttr2(value)}"`;
}
__name(stringAttr, "stringAttr");
function numberAttr(name, value) {
  return value === void 0 ? "" : `${name}="${value}"`;
}
__name(numberAttr, "numberAttr");
function booleanAttr(name, value) {
  return value === void 0 ? "" : `${name}="${value ? 1 : 0}"`;
}
__name(booleanAttr, "booleanAttr");
function xmlAttr2(value) {
  return value.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
__name(xmlAttr2, "xmlAttr");
function xmlText(value) {
  return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
__name(xmlText, "xmlText");
var CALC_CHAIN_REL_TYPE = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/calcChain";
var CONTENT_TYPES_NS4 = "http://schemas.openxmlformats.org/package/2006/content-types";
function collectContentOnlyCellPatches(before, after, allowDrawingPositionChanges = false) {
  if (!sameJson(before.sharedStrings, after.sharedStrings) || !sameJson(before.definedNames, after.definedNames) || !sameJson(before.styles, after.styles) || before.sheets.length !== after.sheets.length) {
    return null;
  }
  const patches = [];
  for (let index = 0; index < before.sheets.length; index += 1) {
    const previousSheet = before.sheets[index];
    const currentSheet = after.sheets[index];
    const previousMetadata = sheetWithoutCellContent(previousSheet);
    const currentMetadata = sheetWithoutCellContent(currentSheet);
    if (allowDrawingPositionChanges) currentMetadata.drawings = previousMetadata.drawings;
    if (!sameJson(previousMetadata, currentMetadata)) {
      return null;
    }
    const previousCells = new Map(previousSheet.cells.map((cell) => [cell.address, cell]));
    const currentCells = new Map(currentSheet.cells.map((cell) => [cell.address, cell]));
    const addresses = /* @__PURE__ */ new Set([...previousCells.keys(), ...currentCells.keys()]);
    const changed = [];
    for (const address of addresses) {
      const previous = previousCells.get(address);
      const current = currentCells.get(address);
      if (sameJson(previous, current)) continue;
      if (!isContentOnlyCellChange(previous, current)) return null;
      changed.push(address);
    }
    if (changed.length) {
      changed.sort(compareCellAddresses);
      patches.push({
        sheet: currentSheet,
        addresses: changed,
        dimension: preservedDimension(
          previousSheet.dimension,
          currentSheet.dimension,
          changed,
          currentCells
        )
      });
    }
  }
  return patches;
}
__name(collectContentOnlyCellPatches, "collectContentOnlyCellPatches");
function patchWorkbookCellsInPackage(pkg, patches) {
  if (patches.length === 0) return;
  assertPatchableFormulas(pkg, patches);
  invalidateCalculationChain(pkg);
  for (const patch of patches) {
    const path = patch.sheet.path;
    if (!path) throw new Error(`ExcelWorkbook: worksheet ${patch.sheet.name} has no package path`);
    const part = getPart(pkg, path);
    if (!(part == null ? void 0 : part.xmlDom)) throw new Error(`ExcelWorkbook: missing XML part ${path}`);
    const worksheet = part.xmlDom.documentElement;
    const sheetData = directChild(worksheet, "sheetData");
    if (!sheetData) throw new Error(`ExcelWorkbook: worksheet ${path} has no sheetData`);
    const currentCells = new Map(patch.sheet.cells.map((cell) => [cell.address, cell]));
    for (const address of patch.addresses) {
      patchCell(part.xmlDom, sheetData, address, currentCells.get(address));
    }
    patchDimension(part.xmlDom, worksheet, patch.dimension);
    markDirty(part);
  }
}
__name(patchWorkbookCellsInPackage, "patchWorkbookCellsInPackage");
function assertPatchableFormulas(pkg, patches) {
  var _a, _b;
  for (const patch of patches) {
    if (!patch.sheet.path) continue;
    const worksheet = (_b = (_a = getPart(pkg, patch.sheet.path)) == null ? void 0 : _a.xmlDom) == null ? void 0 : _b.documentElement;
    const sheetData = worksheet ? directChild(worksheet, "sheetData") : void 0;
    if (!sheetData) continue;
    const addresses = new Set(patch.addresses);
    for (const row of directChildren(sheetData, "row")) {
      for (const cell of directChildren(row, "c")) {
        const address = cell.getAttribute("r");
        if (!address || !addresses.has(parseCellAddress(address).address)) continue;
        const formula = directChild(cell, "f");
        const formulaType = formula == null ? void 0 : formula.getAttribute("t");
        if (formulaType === "shared" || formulaType === "array" || formulaType === "dataTable") {
          throw new Error(
            `ExcelWorkbook: fidelity-preserving cell patch does not support ${formulaType} formula cell ${patch.sheet.name}!${address}`
          );
        }
      }
    }
  }
}
__name(assertPatchableFormulas, "assertPatchableFormulas");
function invalidateCalculationChain(pkg) {
  var _a, _b, _c, _d, _e2, _f;
  const relsPart = getPart(pkg, "xl/_rels/workbook.xml.rels");
  const relationships = (_b = (_a = relsPart == null ? void 0 : relsPart.xmlDom) == null ? void 0 : _a.getElementsByTagNameNS(REL_NS, "Relationship")) != null ? _b : [];
  const removedPaths = [];
  for (const relationship of Array.from(relationships)) {
    if (relationship.getAttribute("Type") !== CALC_CHAIN_REL_TYPE) continue;
    const target = relationship.getAttribute("Target");
    if (target) removedPaths.push(resolveRelationshipTarget4("xl/workbook.xml", target));
    (_c = relationship.parentNode) == null ? void 0 : _c.removeChild(relationship);
  }
  if (!removedPaths.length) return;
  if (relsPart) markDirty(relsPart);
  for (const path of removedPaths) deletePart(pkg, path);
  const contentTypes = getPart(pkg, "[Content_Types].xml");
  if (contentTypes == null ? void 0 : contentTypes.xmlDom) {
    const overrides = contentTypes.xmlDom.getElementsByTagNameNS(CONTENT_TYPES_NS4, "Override");
    for (const override of Array.from(overrides)) {
      const path = (_d = override.getAttribute("PartName")) == null ? void 0 : _d.replace(/^\//, "");
      if (path && removedPaths.includes(path)) (_e2 = override.parentNode) == null ? void 0 : _e2.removeChild(override);
    }
    markDirty(contentTypes);
  }
  const workbookPart = getPart(pkg, "xl/workbook.xml");
  const workbook = (_f = workbookPart == null ? void 0 : workbookPart.xmlDom) == null ? void 0 : _f.documentElement;
  if (!(workbookPart == null ? void 0 : workbookPart.xmlDom) || !workbook) return;
  let calcPr = directChild(workbook, "calcPr");
  if (!calcPr) {
    calcPr = workbookPart.xmlDom.createElementNS(SS_NS, "calcPr");
    workbook.insertBefore(calcPr, firstDirectChild(workbook, "extLst"));
  }
  calcPr.setAttribute("fullCalcOnLoad", "1");
  calcPr.setAttribute("forceFullCalc", "1");
  markDirty(workbookPart);
}
__name(invalidateCalculationChain, "invalidateCalculationChain");
function resolveRelationshipTarget4(sourcePath, target) {
  if (target.startsWith("/")) return normalizePath4(target.slice(1));
  const slash = sourcePath.lastIndexOf("/");
  const directory = slash === -1 ? "" : sourcePath.slice(0, slash);
  return normalizePath4(directory ? `${directory}/${target}` : target);
}
__name(resolveRelationshipTarget4, "resolveRelationshipTarget");
function normalizePath4(path) {
  const parts = [];
  for (const part of path.split("/")) {
    if (!part || part === ".") continue;
    if (part === "..") parts.pop();
    else parts.push(part);
  }
  return parts.join("/");
}
__name(normalizePath4, "normalizePath");
function sheetWithoutCellContent(sheet) {
  const _a = sheet, { cells: _cells, dimension: _dimension } = _a, rest = __objRest(_a, ["cells", "dimension"]);
  return rest;
}
__name(sheetWithoutCellContent, "sheetWithoutCellContent");
function isContentOnlyCellChange(previous, current) {
  if (!previous) return (current == null ? void 0 : current.styleId) === void 0;
  if (!current) return true;
  return previous.address === current.address && previous.row === current.row && previous.column === current.column && previous.styleId === current.styleId;
}
__name(isContentOnlyCellChange, "isContentOnlyCellChange");
function patchCell(document, sheetData, address, model) {
  var _a;
  const parsed = parseCellAddress(address);
  let row = directChildren(sheetData, "row").find(
    (candidate) => Number(candidate.getAttribute("r")) === parsed.row
  );
  let cell = row ? directChildren(row, "c").find((candidate) => candidate.getAttribute("r") === parsed.address) : void 0;
  if (!model) {
    if (cell == null ? void 0 : cell.parentNode) cell.parentNode.removeChild(cell);
    return;
  }
  if (!row) {
    row = document.createElementNS(SS_NS, "row");
    row.setAttribute("r", String(parsed.row));
    const nextRow = directChildren(sheetData, "row").find(
      (candidate) => Number(candidate.getAttribute("r")) > parsed.row
    );
    sheetData.insertBefore(row, nextRow != null ? nextRow : null);
  }
  if (!cell) {
    cell = document.createElementNS(SS_NS, "c");
    cell.setAttribute("r", parsed.address);
    const nextCell = directChildren(row, "c").find((candidate) => {
      const ref = candidate.getAttribute("r");
      return ref ? parseCellAddress(ref).column > parsed.column : false;
    });
    row.insertBefore(cell, (_a = nextCell != null ? nextCell : firstDirectChild(row, "extLst")) != null ? _a : null);
  }
  patchCellContent(document, cell, model);
}
__name(patchCell, "patchCell");
function patchCellContent(document, cell, model) {
  var _a;
  for (const child of directChildren(cell)) {
    if (child.localName === "f" || child.localName === "v" || child.localName === "is") {
      cell.removeChild(child);
    }
  }
  cell.removeAttribute("t");
  const insertionPoint = firstDirectChild(cell, "extLst");
  if (model.kind === "string") {
    cell.setAttribute("t", "inlineStr");
    const richText = excelCellRichText(model);
    if (richText) {
      cell.insertBefore(createExcelRichTextElement(document, richText), insertionPoint != null ? insertionPoint : null);
      return;
    }
    const inline = document.createElementNS(SS_NS, "is");
    const text = document.createElementNS(SS_NS, "t");
    const value = String((_a = model.value) != null ? _a : "");
    if (/^\s|\s$/.test(value)) {
      text.setAttributeNS("http://www.w3.org/XML/1998/namespace", "xml:space", "preserve");
    }
    text.textContent = value;
    inline.appendChild(text);
    cell.insertBefore(inline, insertionPoint != null ? insertionPoint : null);
    return;
  }
  if (model.kind === "boolean") cell.setAttribute("t", "b");
  if (model.kind === "error") cell.setAttribute("t", "e");
  if (model.formula) appendTextElement(document, cell, "f", model.formula, insertionPoint);
  if (model.kind === "blank" && !model.formula) return;
  if (model.value !== null && model.value !== void 0) {
    const value = model.kind === "boolean" ? model.value ? "1" : "0" : String(model.value);
    appendTextElement(document, cell, "v", value, insertionPoint);
  }
}
__name(patchCellContent, "patchCellContent");
function appendTextElement(document, parent, name, value, before) {
  const element = document.createElementNS(SS_NS, name);
  element.textContent = value;
  parent.insertBefore(element, before);
}
__name(appendTextElement, "appendTextElement");
function patchDimension(document, worksheet, dimension) {
  const existing = directChild(worksheet, "dimension");
  if (!dimension) {
    if (existing == null ? void 0 : existing.parentNode) existing.parentNode.removeChild(existing);
    return;
  }
  if (existing) {
    existing.setAttribute("ref", dimension);
    return;
  }
  const next = ["sheetViews", "sheetFormatPr", "cols", "sheetData"].map((name) => directChild(worksheet, name)).find((element) => Boolean(element));
  const created = document.createElementNS(SS_NS, "dimension");
  created.setAttribute("ref", dimension);
  worksheet.insertBefore(created, next != null ? next : null);
}
__name(patchDimension, "patchDimension");
function directChild(parent, localName) {
  return directChildren(parent, localName)[0];
}
__name(directChild, "directChild");
function firstDirectChild(parent, localName) {
  var _a;
  return (_a = directChild(parent, localName)) != null ? _a : null;
}
__name(firstDirectChild, "firstDirectChild");
function directChildren(parent, localName) {
  const result = [];
  for (let index = 0; index < parent.childNodes.length; index += 1) {
    const child = parent.childNodes[index];
    if ((child == null ? void 0 : child.nodeType) !== 1) continue;
    const element = child;
    if (element.namespaceURI !== SS_NS) continue;
    if (localName && element.localName !== localName) continue;
    result.push(element);
  }
  return result;
}
__name(directChildren, "directChildren");
function compareCellAddresses(left, right) {
  const a2 = parseCellAddress(left);
  const b2 = parseCellAddress(right);
  return a2.row - b2.row || a2.column - b2.column;
}
__name(compareCellAddresses, "compareCellAddresses");
function preservedDimension(previous, current, changedAddresses, currentCells) {
  if (!previous) return current;
  const range = parseRangeAddress(previous);
  let minRow = range.startRow;
  let minColumn = range.startColumn;
  let maxRow = range.startRow + range.rowCount - 1;
  let maxColumn = range.startColumn + range.columnCount - 1;
  for (const address of changedAddresses) {
    if (!currentCells.has(address)) continue;
    const cell = parseCellAddress(address);
    minRow = Math.min(minRow, cell.row);
    minColumn = Math.min(minColumn, cell.column);
    maxRow = Math.max(maxRow, cell.row);
    maxColumn = Math.max(maxColumn, cell.column);
  }
  return formatRangeAddress(minRow, minColumn, maxRow - minRow + 1, maxColumn - minColumn + 1);
}
__name(preservedDimension, "preservedDimension");
function sameJson(left, right) {
  return JSON.stringify(left) === JSON.stringify(right);
}
__name(sameJson, "sameJson");
var _ExcelNamedItem = class _ExcelNamedItem2 {
  constructor(model, names) {
    __publicField(this, "model");
    __publicField(this, "names");
    this.model = model;
    this.names = names;
  }
  name() {
    return this.model.name;
  }
  text() {
    return this.model.text;
  }
  setText(text) {
    this.model.text = text;
  }
  rename(name) {
    assertValidName(name);
    if (this.names.some((item) => item !== this.model && item.name === name)) {
      throw new Error(`ExcelWorkbook: defined name already exists: ${name}`);
    }
    this.model.name = name;
  }
  localSheetId() {
    return this.model.localSheetId;
  }
  setLocalSheetId(localSheetId) {
    if (localSheetId !== void 0 && (!Number.isInteger(localSheetId) || localSheetId < 0)) {
      throw new Error(`ExcelNamedItem.setLocalSheetId: localSheetId must be a non-negative integer`);
    }
    this.model.localSheetId = localSheetId;
  }
  toModel() {
    return __spreadValues({}, this.model);
  }
};
__name(_ExcelNamedItem, "ExcelNamedItem");
var ExcelNamedItem = _ExcelNamedItem;
var _ExcelNamedItemCollection = class _ExcelNamedItemCollection2 {
  constructor(names) {
    __publicField(this, "itemsByModel");
    __publicField(this, "models");
    this.models = names;
    this.itemsByModel = names.map((name) => new ExcelNamedItem(name, names));
  }
  items() {
    return [...this.itemsByModel];
  }
  getItem(name) {
    const item = this.getItemOrNullObject(name);
    if (!item) throw new Error(`ExcelWorkbook: defined name not found: ${name}`);
    return item;
  }
  getItemOrNullObject(name) {
    var _a;
    return (_a = this.itemsByModel.find((item) => item.name() === name)) != null ? _a : null;
  }
  add(model) {
    assertValidName(model.name);
    if (this.getItemOrNullObject(model.name)) {
      throw new Error(`ExcelWorkbook: defined name already exists: ${model.name}`);
    }
    if (model.localSheetId !== void 0 && (!Number.isInteger(model.localSheetId) || model.localSheetId < 0)) {
      throw new Error(`ExcelNamedItemCollection.add: localSheetId must be a non-negative integer`);
    }
    const next = __spreadValues({}, model);
    this.models.push(next);
    const item = new ExcelNamedItem(next, this.models);
    this.itemsByModel.push(item);
    return item;
  }
  deleteItem(name) {
    const index = this.models.findIndex((item) => item.name === name);
    if (index === -1) throw new Error(`ExcelWorkbook: defined name not found: ${name}`);
    this.models.splice(index, 1);
    this.itemsByModel.splice(index, 1);
  }
};
__name(_ExcelNamedItemCollection, "ExcelNamedItemCollection");
var ExcelNamedItemCollection = _ExcelNamedItemCollection;
function assertValidName(name) {
  if (!name || !/^[A-Za-z_\\][A-Za-z0-9_.\\]*$/.test(name)) {
    throw new Error(`ExcelNamedItem: invalid defined name: ${name}`);
  }
}
__name(assertValidName, "assertValidName");
function normalizeExcelCellFormula(formula) {
  if (formula === null || formula === "") return null;
  const expression = formula.startsWith("=") ? formula.slice(1) : formula;
  if (expression.trim() === "") throw new Error("Excel cell formula: empty expression");
  return expression;
}
__name(normalizeExcelCellFormula, "normalizeExcelCellFormula");
function clearExcelCellContent(sheet, cellsByAddress, address) {
  const cell = cellsByAddress.get(address);
  if (!cell) return;
  if (cell.styleId === void 0) {
    cellsByAddress.delete(address);
    const index = sheet.cells.indexOf(cell);
    if (index !== -1) sheet.cells.splice(index, 1);
    return;
  }
  cell.kind = "blank";
  cell.value = null;
  delete cell.formula;
  clearExcelCellStringMetadata(cell);
}
__name(clearExcelCellContent, "clearExcelCellContent");
function clearExcelCellStringMetadata(cell) {
  delete cell.rawValue;
  delete cell.dataType;
  delete cell.sharedStringIndex;
  delete cell.richText;
}
__name(clearExcelCellStringMetadata, "clearExcelCellStringMetadata");
var _ExcelRange = class _ExcelRange2 {
  constructor(sheet, address, styles = createEmptyStyles(), recordMutation) {
    __publicField(this, "format");
    __publicField(this, "sheet");
    __publicField(this, "styles");
    __publicField(this, "ref");
    __publicField(this, "cellsByAddress");
    __publicField(this, "recordMutation");
    this.sheet = sheet;
    this.styles = styles;
    this.recordMutation = recordMutation;
    this.ref = parseRangeAddress(address);
    if (this.ref.sheetName && this.ref.sheetName !== sheet.name) {
      throw new Error(
        `ExcelRange: address sheet '${this.ref.sheetName}' does not match worksheet '${sheet.name}'`
      );
    }
    this.cellsByAddress = new Map(sheet.cells.map((cell) => [cell.address, cell]));
    this.format = new ExcelRangeFormat(this);
  }
  address() {
    return this.ref.address;
  }
  rowIndex() {
    return this.ref.startRow;
  }
  columnIndex() {
    return this.ref.startColumn;
  }
  rowCount() {
    return this.ref.rowCount;
  }
  columnCount() {
    return this.ref.columnCount;
  }
  values() {
    return this.matrix((cell) => cell.value);
  }
  formulas() {
    return this.matrix((cell) => {
      var _a;
      return (_a = cell.formula) != null ? _a : null;
    });
  }
  text() {
    return this.matrix((cell) => cellToText(cell));
  }
  valueTypes() {
    return this.matrix((cell) => cell.kind);
  }
  rawValues() {
    return this.matrix((cell) => {
      var _a;
      return (_a = cell.rawValue) != null ? _a : null;
    });
  }
  styleIds() {
    return this.matrix((cell) => cell.styleId);
  }
  setStyleId(styleId) {
    var _a;
    if (styleId !== void 0 && (!Number.isInteger(styleId) || styleId < 0)) {
      throw new Error(`ExcelRange.setStyleId: styleId must be a non-negative integer`);
    }
    for (let r2 = 0; r2 < this.ref.rowCount; r2++) {
      for (let c2 = 0; c2 < this.ref.columnCount; c2++) {
        const address = formatCellAddress(this.ref.startRow + r2, this.ref.startColumn + c2);
        const cell = this.ensureCell(address);
        if (styleId === void 0) delete cell.styleId;
        else cell.styleId = styleId;
      }
    }
    normalizeSheetCells(this.sheet);
    (_a = this.recordMutation) == null ? void 0 : _a.call(this, {
      kind: "unsafe",
      scope: "range",
      sheetId: this.sheet.id,
      sheetName: this.sheet.name,
      reason: "range.setStyleId is not replayable by first-phase mutation writeback"
    });
  }
  rowHeights() {
    var _a;
    const heights = [];
    for (let r2 = 0; r2 < this.ref.rowCount; r2++) {
      const rowIndex = this.ref.startRow + r2;
      heights.push((_a = this.sheet.rows.find((row) => row.index === rowIndex)) == null ? void 0 : _a.height);
    }
    return heights;
  }
  setRowHeight(height) {
    var _a;
    if (height !== void 0 && (!Number.isFinite(height) || height < 0)) {
      throw new Error(`ExcelRange.setRowHeight: height must be a non-negative number`);
    }
    for (let r2 = 0; r2 < this.ref.rowCount; r2++) {
      const row = this.ensureRow(this.ref.startRow + r2);
      if (height === void 0) {
        delete row.height;
        delete row.customHeight;
      } else {
        row.height = height;
        row.customHeight = true;
      }
    }
    (_a = this.recordMutation) == null ? void 0 : _a.call(this, {
      kind: "range.setRowHeight",
      sheetId: this.sheet.id,
      sheetName: this.sheet.name,
      address: this.ref.address,
      height
    });
  }
  columnWidths() {
    var _a;
    const widths = [];
    for (let c2 = 0; c2 < this.ref.columnCount; c2++) {
      const columnIndex = this.ref.startColumn + c2;
      widths.push(
        (_a = this.sheet.columns.find((column) => column.min <= columnIndex && column.max >= columnIndex)) == null ? void 0 : _a.width
      );
    }
    return widths;
  }
  setColumnWidth(width) {
    var _a;
    if (width !== void 0 && (!Number.isFinite(width) || width < 0)) {
      throw new Error(`ExcelRange.setColumnWidth: width must be a non-negative number`);
    }
    for (let c2 = 0; c2 < this.ref.columnCount; c2++) {
      const column = this.ensureColumn(this.ref.startColumn + c2);
      if (width === void 0) {
        delete column.width;
        delete column.customWidth;
      } else {
        column.width = width;
        column.customWidth = true;
      }
    }
    normalizeColumns(this.sheet);
    (_a = this.recordMutation) == null ? void 0 : _a.call(this, {
      kind: "range.setColumnWidth",
      sheetId: this.sheet.id,
      sheetName: this.sheet.name,
      address: this.ref.address,
      width
    });
  }
  merge() {
    var _a;
    const masterAddress = formatCellAddress(this.ref.startRow, this.ref.startColumn);
    for (let r2 = 0; r2 < this.ref.rowCount; r2++) {
      for (let c2 = 0; c2 < this.ref.columnCount; c2++) {
        const address = formatCellAddress(this.ref.startRow + r2, this.ref.startColumn + c2);
        if (address !== masterAddress) this.clearCellContent(address);
      }
    }
    normalizeSheetCells(this.sheet);
    if (!this.sheet.mergedRanges.some((range) => range.address === this.ref.address)) {
      this.sheet.mergedRanges.push({ address: this.ref.address });
    }
    (_a = this.recordMutation) == null ? void 0 : _a.call(this, {
      kind: "range.merge",
      sheetId: this.sheet.id,
      sheetName: this.sheet.name,
      address: this.ref.address
    });
  }
  unmerge() {
    var _a;
    this.sheet.mergedRanges = this.sheet.mergedRanges.filter(
      (range) => range.address !== this.ref.address
    );
    (_a = this.recordMutation) == null ? void 0 : _a.call(this, {
      kind: "range.unmerge",
      sheetId: this.sheet.id,
      sheetName: this.sheet.name,
      address: this.ref.address
    });
  }
  setValues(values) {
    var _a;
    this.assertMatrixShape(values, "ExcelRange.setValues");
    for (let r2 = 0; r2 < this.ref.rowCount; r2++) {
      for (let c2 = 0; c2 < this.ref.columnCount; c2++) {
        const address = formatCellAddress(this.ref.startRow + r2, this.ref.startColumn + c2);
        this.setCellValue(address, values[r2][c2]);
      }
    }
    normalizeSheetCells(this.sheet);
    (_a = this.recordMutation) == null ? void 0 : _a.call(this, {
      kind: "range.setValues",
      sheetId: this.sheet.id,
      sheetName: this.sheet.name,
      address: this.ref.address,
      values
    });
  }
  setFormulas(formulas) {
    var _a;
    this.assertMatrixShape(formulas, "ExcelRange.setFormulas");
    const normalized = formulas.map((row) => row.map(normalizeExcelCellFormula));
    for (let r2 = 0; r2 < this.ref.rowCount; r2++) {
      for (let c2 = 0; c2 < this.ref.columnCount; c2++) {
        const address = formatCellAddress(this.ref.startRow + r2, this.ref.startColumn + c2);
        this.setCellFormula(address, normalized[r2][c2]);
      }
    }
    normalizeSheetCells(this.sheet);
    (_a = this.recordMutation) == null ? void 0 : _a.call(this, {
      kind: "range.setFormulas",
      sheetId: this.sheet.id,
      sheetName: this.sheet.name,
      address: this.ref.address,
      formulas
    });
  }
  clear() {
    var _a;
    for (let r2 = 0; r2 < this.ref.rowCount; r2++) {
      for (let c2 = 0; c2 < this.ref.columnCount; c2++) {
        const address = formatCellAddress(this.ref.startRow + r2, this.ref.startColumn + c2);
        this.deleteCell(address);
      }
    }
    normalizeSheetCells(this.sheet);
    (_a = this.recordMutation) == null ? void 0 : _a.call(this, {
      kind: "range.clear",
      sheetId: this.sheet.id,
      sheetName: this.sheet.name,
      address: this.ref.address
    });
  }
  getCell(rowOffset, columnOffset) {
    this.assertOffset(rowOffset, columnOffset);
    const row = this.ref.startRow + rowOffset;
    const column = this.ref.startColumn + columnOffset;
    return new ExcelCell(this.sheet, formatCellAddress(row, column), this.styles, this.recordMutation);
  }
  getRow(rowOffset) {
    if (!Number.isInteger(rowOffset) || rowOffset < 0 || rowOffset >= this.ref.rowCount) {
      throw new Error(`ExcelRange.getRow: row offset out of bounds: ${rowOffset}`);
    }
    const row = this.ref.startRow + rowOffset;
    const start = formatCellAddress(row, this.ref.startColumn);
    const end = formatCellAddress(row, this.ref.startColumn + this.ref.columnCount - 1);
    return new _ExcelRange2(this.sheet, `${start}:${end}`, this.styles, this.recordMutation);
  }
  getColumn(columnOffset) {
    if (!Number.isInteger(columnOffset) || columnOffset < 0 || columnOffset >= this.ref.columnCount) {
      throw new Error(`ExcelRange.getColumn: column offset out of bounds: ${columnOffset}`);
    }
    const column = this.ref.startColumn + columnOffset;
    const start = formatCellAddress(this.ref.startRow, column);
    const end = formatCellAddress(this.ref.startRow + this.ref.rowCount - 1, column);
    return new _ExcelRange2(this.sheet, `${start}:${end}`, this.styles, this.recordMutation);
  }
  resize(rowCount, columnCount) {
    return new _ExcelRange2(
      this.sheet,
      formatRangeAddress(this.ref.startRow, this.ref.startColumn, rowCount, columnCount),
      this.styles,
      this.recordMutation
    );
  }
  offset(rowOffset, columnOffset, rowCount = this.ref.rowCount, columnCount = this.ref.columnCount) {
    if (!Number.isInteger(rowOffset) || !Number.isInteger(columnOffset)) {
      throw new Error(`ExcelRange.offset: offsets must be integers`);
    }
    return new _ExcelRange2(
      this.sheet,
      formatRangeAddress(
        this.ref.startRow + rowOffset,
        this.ref.startColumn + columnOffset,
        rowCount,
        columnCount
      ),
      this.styles,
      this.recordMutation
    );
  }
  slice(rowOffset, columnOffset, rowCount, columnCount) {
    if (!Number.isInteger(rowOffset) || !Number.isInteger(columnOffset) || !Number.isInteger(rowCount) || !Number.isInteger(columnCount) || rowOffset < 0 || columnOffset < 0 || rowCount < 1 || columnCount < 1 || rowOffset + rowCount > this.ref.rowCount || columnOffset + columnCount > this.ref.columnCount) {
      throw new Error(
        `ExcelRange.slice: range out of bounds row=${rowOffset}, column=${columnOffset}, rows=${rowCount}, columns=${columnCount}`
      );
    }
    return new _ExcelRange2(
      this.sheet,
      formatRangeAddress(
        this.ref.startRow + rowOffset,
        this.ref.startColumn + columnOffset,
        rowCount,
        columnCount
      ),
      this.styles,
      this.recordMutation
    );
  }
  toModel() {
    const cells = [];
    for (let r2 = 0; r2 < this.ref.rowCount; r2++) {
      for (let c2 = 0; c2 < this.ref.columnCount; c2++) {
        const address = formatCellAddress(this.ref.startRow + r2, this.ref.startColumn + c2);
        const cell = this.cellsByAddress.get(address);
        if (cell) cells.push(cloneExcelCell(cell));
      }
    }
    return cells;
  }
  setRichText(runs) {
    var _a;
    if (this.ref.rowCount !== 1 || this.ref.columnCount !== 1) {
      throw new Error("ExcelRange.setRichText requires a single cell");
    }
    const address = formatCellAddress(this.ref.startRow, this.ref.startColumn);
    this.setCellValue(address, runs.map((run) => run.text).join(""));
    if (runs.length > 0) this.ensureCell(address).richText = cloneExcelRichText(runs);
    (_a = this.recordMutation) == null ? void 0 : _a.call(this, {
      kind: "unsafe",
      scope: "range",
      sheetId: this.sheet.id,
      sheetName: this.sheet.name,
      reason: "Rich text requires package writeback"
    });
  }
  getResolvedFormat() {
    var _a, _b;
    const cell = this.firstCell();
    return cloneCellFormat((_b = this.styles.cellFormats[(_a = cell == null ? void 0 : cell.styleId) != null ? _a : 0]) != null ? _b : {});
  }
  updateFormat(update, options = {}) {
    var _a, _b, _c, _d;
    for (let r2 = 0; r2 < this.ref.rowCount; r2++) {
      for (let c2 = 0; c2 < this.ref.columnCount; c2++) {
        const address = formatCellAddress(this.ref.startRow + r2, this.ref.startColumn + c2);
        const cell = this.ensureCell(address);
        const current = cloneCellFormat((_b = this.styles.cellFormats[(_a = cell.styleId) != null ? _a : 0]) != null ? _b : {});
        cell.styleId = ensureCellFormat(this.styles, update(current));
      }
    }
    normalizeSheetCells(this.sheet);
    if ((_c = options.recordUnsafe) != null ? _c : true) {
      (_d = this.recordMutation) == null ? void 0 : _d.call(this, {
        kind: "unsafe",
        scope: "range",
        sheetId: this.sheet.id,
        sheetName: this.sheet.name,
        reason: "range.updateFormat is not replayable by first-phase mutation writeback"
      });
    }
  }
  recordReplayableMutation(mutation) {
    var _a;
    (_a = this.recordMutation) == null ? void 0 : _a.call(this, __spreadProps(__spreadValues({}, mutation), {
      sheetId: this.sheet.id,
      sheetName: this.sheet.name
    }));
  }
  ensureFont(font) {
    return ensureStyleItem(this.styles.fonts, font, cloneFont);
  }
  ensureFill(fill) {
    return ensureStyleItem(this.styles.fills, fill, cloneFill);
  }
  ensureBorder(border) {
    return ensureStyleItem(this.styles.borders, border, cloneBorder);
  }
  ensureNumberFormat(code) {
    const builtIn = builtInNumberFormatId(code);
    if (builtIn !== void 0) return builtIn;
    const existing = this.styles.numberFormats.find((format) => format.code === code);
    if (existing) return existing.id;
    const maxId = this.styles.numberFormats.reduce((max, format) => Math.max(max, format.id), 163);
    const next = { id: maxId + 1, code };
    this.styles.numberFormats.push(next);
    return next.id;
  }
  fontById(id) {
    var _a;
    return cloneFont((_a = this.styles.fonts[id != null ? id : 0]) != null ? _a : {});
  }
  fillById(id) {
    var _a;
    return cloneFill((_a = this.styles.fills[id != null ? id : 0]) != null ? _a : {});
  }
  borderById(id) {
    var _a;
    return cloneBorder((_a = this.styles.borders[id != null ? id : 0]) != null ? _a : {});
  }
  matrix(read) {
    var _a;
    const rows = [];
    for (let r2 = 0; r2 < this.ref.rowCount; r2++) {
      const row = [];
      for (let c2 = 0; c2 < this.ref.columnCount; c2++) {
        const address = formatCellAddress(this.ref.startRow + r2, this.ref.startColumn + c2);
        row.push(read((_a = this.cellsByAddress.get(address)) != null ? _a : blankCell(address)));
      }
      rows.push(row);
    }
    return rows;
  }
  assertOffset(rowOffset, columnOffset) {
    if (!Number.isInteger(rowOffset) || !Number.isInteger(columnOffset) || rowOffset < 0 || columnOffset < 0 || rowOffset >= this.ref.rowCount || columnOffset >= this.ref.columnCount) {
      throw new Error(
        `ExcelRange.getCell: offset out of bounds: row=${rowOffset}, column=${columnOffset}`
      );
    }
  }
  assertMatrixShape(matrix, operation) {
    if (matrix.length !== this.ref.rowCount) {
      throw new Error(
        `${operation}: expected ${this.ref.rowCount} rows, received ${matrix.length}`
      );
    }
    for (let r2 = 0; r2 < matrix.length; r2++) {
      if (!Array.isArray(matrix[r2]) || matrix[r2].length !== this.ref.columnCount) {
        throw new Error(
          `${operation}: expected row ${r2} to contain ${this.ref.columnCount} columns`
        );
      }
    }
  }
  setCellValue(address, value) {
    if (value === null) {
      this.clearCellContent(address);
      return;
    }
    const cell = this.ensureCell(address);
    cell.value = value;
    cell.kind = typeof value === "boolean" ? "boolean" : typeof value === "number" ? "number" : "string";
    delete cell.formula;
    clearExcelCellStringMetadata(cell);
  }
  setCellFormula(address, formula) {
    if (formula === null) {
      this.clearCellContent(address);
      return;
    }
    const cell = this.ensureCell(address);
    cell.kind = "formula";
    cell.formula = formula;
    cell.value = null;
    clearExcelCellStringMetadata(cell);
  }
  ensureCell(address) {
    const existing = this.cellsByAddress.get(address);
    if (existing) return existing;
    const cell = blankCell(address);
    this.sheet.cells.push(cell);
    this.cellsByAddress.set(address, cell);
    return cell;
  }
  deleteCell(address) {
    const cell = this.cellsByAddress.get(address);
    if (!cell) return;
    this.cellsByAddress.delete(address);
    const index = this.sheet.cells.indexOf(cell);
    if (index !== -1) this.sheet.cells.splice(index, 1);
  }
  clearCellContent(address) {
    clearExcelCellContent(this.sheet, this.cellsByAddress, address);
  }
  ensureRow(index) {
    let row = this.sheet.rows.find((item) => item.index === index);
    if (!row) {
      row = { index };
      this.sheet.rows.push(row);
      this.sheet.rows.sort((a2, b2) => a2.index - b2.index);
    }
    return row;
  }
  ensureColumn(index) {
    let column = this.sheet.columns.find((item) => item.min === index && item.max === index);
    if (!column) {
      column = { min: index, max: index };
      this.sheet.columns.push(column);
    }
    return column;
  }
  firstCell() {
    for (let r2 = 0; r2 < this.ref.rowCount; r2++) {
      for (let c2 = 0; c2 < this.ref.columnCount; c2++) {
        const address = formatCellAddress(this.ref.startRow + r2, this.ref.startColumn + c2);
        const cell = this.cellsByAddress.get(address);
        if (cell) return cell;
      }
    }
    return void 0;
  }
};
__name(_ExcelRange, "ExcelRange");
var ExcelRange = _ExcelRange;
var _ExcelCell = class _ExcelCell2 {
  constructor(sheet, address, styles, recordMutation) {
    __publicField(this, "range");
    this.range = new ExcelRange(sheet, address, styles, recordMutation);
  }
  address() {
    return this.range.address();
  }
  value() {
    var _a, _b;
    return (_b = (_a = this.range.values()[0]) == null ? void 0 : _a[0]) != null ? _b : null;
  }
  formula() {
    var _a, _b;
    return (_b = (_a = this.range.formulas()[0]) == null ? void 0 : _a[0]) != null ? _b : null;
  }
  text() {
    var _a, _b;
    return (_b = (_a = this.range.text()[0]) == null ? void 0 : _a[0]) != null ? _b : "";
  }
  valueType() {
    var _a, _b;
    return (_b = (_a = this.range.valueTypes()[0]) == null ? void 0 : _a[0]) != null ? _b : "blank";
  }
  rawValue() {
    var _a, _b;
    return (_b = (_a = this.range.rawValues()[0]) == null ? void 0 : _a[0]) != null ? _b : null;
  }
  styleId() {
    var _a;
    return (_a = this.range.styleIds()[0]) == null ? void 0 : _a[0];
  }
  setStyleId(styleId) {
    this.range.setStyleId(styleId);
  }
  setValue(value) {
    this.range.setValues([[value]]);
  }
  setFormula(formula) {
    this.range.setFormulas([[formula]]);
  }
  clear() {
    this.range.clear();
  }
  toRange() {
    return this.range;
  }
  toModel() {
    var _a;
    return (_a = this.range.toModel()[0]) != null ? _a : null;
  }
};
__name(_ExcelCell, "ExcelCell");
var ExcelCell = _ExcelCell;
var _ExcelRangeFormat = class _ExcelRangeFormat2 {
  constructor(range) {
    __publicField(this, "range", range);
    __publicField(this, "font");
    __publicField(this, "fill");
    __publicField(this, "border");
    __publicField(this, "alignment");
    this.font = new ExcelRangeFontFormat(range);
    this.fill = new ExcelRangeFillFormat(range);
    this.border = new ExcelRangeBorderFormat(range);
    this.alignment = new ExcelRangeAlignmentFormat(range);
  }
  numberFormatCode() {
    return this.range.getResolvedFormat().numberFormatCode;
  }
  setNumberFormatCode(code) {
    this.range.updateFormat((format) => {
      if (code === void 0) {
        delete format.numberFormatCode;
        delete format.numberFormatId;
        delete format.applyNumberFormat;
      } else {
        format.numberFormatCode = code;
        format.numberFormatId = this.range.ensureNumberFormat(code);
        format.applyNumberFormat = true;
      }
      return format;
    });
  }
};
__name(_ExcelRangeFormat, "ExcelRangeFormat");
var ExcelRangeFormat = _ExcelRangeFormat;
var _ExcelRangeFontFormat = class _ExcelRangeFontFormat2 {
  constructor(range) {
    __publicField(this, "range", range);
  }
  value() {
    return this.range.fontById(this.range.getResolvedFormat().fontId);
  }
  setValue(font, options = {}) {
    const normalized = __spreadProps(__spreadValues({}, font), {
      color: normalizeExcelColor(font.color, "ExcelRange.format.font.setValue")
    });
    removeUndefined(normalized);
    this.range.updateFormat(
      (format) => {
        format.fontId = this.range.ensureFont(normalized);
        format.applyFont = true;
        return format;
      },
      __spreadProps(__spreadValues({}, options), { recordUnsafe: false })
    );
    this.range.recordReplayableMutation({
      kind: "range.format.font.setValue",
      address: this.range.address(),
      font: normalized
    });
  }
  bold() {
    return this.value().bold;
  }
  setBold(value) {
    this.patch({ bold: value });
  }
  italic() {
    return this.value().italic;
  }
  setItalic(value) {
    this.patch({ italic: value });
  }
  underline() {
    return this.value().underline;
  }
  setUnderline(value) {
    this.patch({ underline: value });
  }
  color() {
    return this.value().color;
  }
  setColor(color) {
    const normalized = normalizeExcelColor(color, "ExcelRange.format.font.setColor");
    this.patch({ color: normalized }, { recordUnsafe: false });
    this.range.recordReplayableMutation({
      kind: "range.format.font.setColor",
      address: this.range.address(),
      color: normalized
    });
  }
  size() {
    return this.value().size;
  }
  setSize(size) {
    this.patch({ size });
  }
  name() {
    return this.value().name;
  }
  setName(name) {
    this.patch({ name });
  }
  patch(patch, options = {}) {
    this.range.updateFormat(
      (format) => {
        const next = __spreadValues(__spreadValues({}, this.range.fontById(format.fontId)), patch);
        removeUndefined(next);
        format.fontId = this.range.ensureFont(next);
        format.applyFont = true;
        return format;
      },
      options
    );
  }
};
__name(_ExcelRangeFontFormat, "ExcelRangeFontFormat");
var ExcelRangeFontFormat = _ExcelRangeFontFormat;
var _ExcelRangeFillFormat = class _ExcelRangeFillFormat2 {
  constructor(range) {
    __publicField(this, "range", range);
  }
  value() {
    return this.range.fillById(this.range.getResolvedFormat().fillId);
  }
  setValue(fill, options = {}) {
    var _a;
    const normalized = __spreadProps(__spreadValues({}, fill), {
      patternType: (_a = fill.patternType) != null ? _a : fill.foregroundColor ? "solid" : void 0,
      foregroundColor: normalizeExcelColor(
        fill.foregroundColor,
        "ExcelRange.format.fill.setValue.foregroundColor"
      ),
      backgroundColor: normalizeExcelColor(
        fill.backgroundColor,
        "ExcelRange.format.fill.setValue.backgroundColor"
      )
    });
    removeUndefined(normalized);
    this.range.updateFormat(
      (format) => {
        format.fillId = this.range.ensureFill(normalized);
        format.applyFill = true;
        return format;
      },
      options
    );
  }
  patternType() {
    return this.value().patternType;
  }
  setPatternType(patternType) {
    this.patch({ patternType });
  }
  foregroundColor() {
    return this.value().foregroundColor;
  }
  setForegroundColor(color) {
    const normalized = normalizeExcelColor(color, "ExcelRange.format.fill.setForegroundColor");
    this.patch(
      {
        foregroundColor: normalized,
        patternType: normalized ? "solid" : this.patternType()
      },
      { recordUnsafe: false }
    );
    this.range.recordReplayableMutation({
      kind: "range.format.fill.setForegroundColor",
      address: this.range.address(),
      color: normalized
    });
  }
  backgroundColor() {
    return this.value().backgroundColor;
  }
  setBackgroundColor(color) {
    this.patch({
      backgroundColor: normalizeExcelColor(color, "ExcelRange.format.fill.setBackgroundColor")
    });
  }
  patch(patch, options = {}) {
    const next = __spreadValues(__spreadValues({}, this.value()), patch);
    removeUndefined(next);
    this.setValue(next, options);
  }
};
__name(_ExcelRangeFillFormat, "ExcelRangeFillFormat");
var ExcelRangeFillFormat = _ExcelRangeFillFormat;
var _ExcelRangeBorderFormat = class _ExcelRangeBorderFormat2 {
  constructor(range) {
    __publicField(this, "range", range);
  }
  value() {
    return this.range.borderById(this.range.getResolvedFormat().borderId);
  }
  setValue(border) {
    const normalized = normalizeBorder(border, "ExcelRange.format.border.setValue");
    this.range.updateFormat(
      (format) => {
        format.borderId = this.range.ensureBorder(normalized);
        format.applyBorder = true;
        return format;
      },
      { recordUnsafe: false }
    );
    this.range.recordReplayableMutation({
      kind: "range.format.border.setValue",
      address: this.range.address(),
      border: normalized
    });
  }
  setLeft(side) {
    this.patch({ left: side });
  }
  setRight(side) {
    this.patch({ right: side });
  }
  setTop(side) {
    this.patch({ top: side });
  }
  setBottom(side) {
    this.patch({ bottom: side });
  }
  patch(patch) {
    const next = __spreadValues(__spreadValues({}, this.value()), patch);
    removeUndefined(next);
    this.setValue(next);
  }
};
__name(_ExcelRangeBorderFormat, "ExcelRangeBorderFormat");
var ExcelRangeBorderFormat = _ExcelRangeBorderFormat;
function normalizeBorder(border, context) {
  const normalized = {};
  for (const name of ["left", "right", "top", "bottom", "diagonal"]) {
    const side = border[name];
    if (!side) continue;
    normalized[name] = __spreadProps(__spreadValues({}, side), {
      color: normalizeExcelColor(side.color, `${context}.${name}.color`)
    });
    removeUndefined(normalized[name]);
  }
  return normalized;
}
__name(normalizeBorder, "normalizeBorder");
var _ExcelRangeAlignmentFormat = class _ExcelRangeAlignmentFormat2 {
  constructor(range) {
    __publicField(this, "range", range);
  }
  value() {
    const value = this.range.getResolvedFormat().alignment;
    return value ? __spreadValues({}, value) : void 0;
  }
  setValue(alignment) {
    this.range.updateFormat((format) => {
      if (alignment === void 0) {
        delete format.alignment;
        delete format.applyAlignment;
      } else {
        format.alignment = __spreadValues({}, alignment);
        format.applyAlignment = true;
      }
      return format;
    }, { recordUnsafe: false });
    this.range.recordReplayableMutation({
      kind: "range.format.alignment.setValue",
      address: this.range.address(),
      alignment: alignment ? __spreadValues({}, alignment) : void 0
    });
  }
  setHorizontal(horizontal) {
    this.patch({ horizontal });
  }
  setVertical(vertical) {
    this.patch({ vertical });
  }
  setWrapText(wrapText) {
    this.patch({ wrapText });
  }
  patch(patch) {
    var _a;
    const next = __spreadValues(__spreadValues({}, (_a = this.value()) != null ? _a : {}), patch);
    removeUndefined(next);
    this.setValue(Object.keys(next).length ? next : void 0);
  }
};
__name(_ExcelRangeAlignmentFormat, "ExcelRangeAlignmentFormat");
var ExcelRangeAlignmentFormat = _ExcelRangeAlignmentFormat;
function blankCell(address) {
  const match = /^([A-Z]+)(\d+)$/.exec(address);
  return {
    address,
    row: match ? Number(match[2]) : 0,
    column: match ? columnNameToIndexSafe(match[1]) : 0,
    kind: "blank",
    value: null
  };
}
__name(blankCell, "blankCell");
function columnNameToIndexSafe(columnName) {
  let value = 0;
  for (const ch of columnName) value = value * 26 + (ch.charCodeAt(0) - 64);
  return value;
}
__name(columnNameToIndexSafe, "columnNameToIndexSafe");
function cellToText(cell) {
  if (cell.value === null) return "";
  return String(cell.value);
}
__name(cellToText, "cellToText");
function normalizeSheetCells(sheet) {
  sheet.cells.sort((a2, b2) => a2.row - b2.row || a2.column - b2.column);
  sheet.dimension = computeDimension(sheet.cells);
}
__name(normalizeSheetCells, "normalizeSheetCells");
function normalizeColumns(sheet) {
  sheet.columns.sort((a2, b2) => a2.min - b2.min || a2.max - b2.max);
}
__name(normalizeColumns, "normalizeColumns");
function createEmptyStyles() {
  return {
    numberFormats: [],
    fonts: [{}],
    fills: [{}, { patternType: "gray125" }],
    borders: [{}],
    cellFormats: [{}]
  };
}
__name(createEmptyStyles, "createEmptyStyles");
function ensureCellFormat(styles, format) {
  const normalized = cloneCellFormat(format);
  removeUndefined(normalized);
  return ensureStyleItem(styles.cellFormats, normalized, cloneCellFormat);
}
__name(ensureCellFormat, "ensureCellFormat");
function ensureStyleItem(items, item, clone2) {
  const normalized = clone2(item);
  removeUndefined(normalized);
  const key2 = stableStringify(normalized);
  const existing = items.findIndex((candidate) => stableStringify(candidate) === key2);
  if (existing !== -1) return existing;
  items.push(normalized);
  return items.length - 1;
}
__name(ensureStyleItem, "ensureStyleItem");
function cloneCellFormat(format) {
  return __spreadProps(__spreadValues({}, format), {
    alignment: format.alignment ? __spreadValues({}, format.alignment) : void 0
  });
}
__name(cloneCellFormat, "cloneCellFormat");
function cloneFont(font) {
  return __spreadProps(__spreadValues({}, font), { color: font.color ? __spreadValues({}, font.color) : void 0 });
}
__name(cloneFont, "cloneFont");
function cloneFill(fill) {
  return __spreadProps(__spreadValues({}, fill), {
    foregroundColor: fill.foregroundColor ? __spreadValues({}, fill.foregroundColor) : void 0,
    backgroundColor: fill.backgroundColor ? __spreadValues({}, fill.backgroundColor) : void 0
  });
}
__name(cloneFill, "cloneFill");
function cloneBorder(border) {
  return {
    left: border.left ? __spreadProps(__spreadValues({}, border.left), { color: border.left.color ? __spreadValues({}, border.left.color) : void 0 }) : void 0,
    right: border.right ? __spreadProps(__spreadValues({}, border.right), { color: border.right.color ? __spreadValues({}, border.right.color) : void 0 }) : void 0,
    top: border.top ? __spreadProps(__spreadValues({}, border.top), { color: border.top.color ? __spreadValues({}, border.top.color) : void 0 }) : void 0,
    bottom: border.bottom ? __spreadProps(__spreadValues({}, border.bottom), { color: border.bottom.color ? __spreadValues({}, border.bottom.color) : void 0 }) : void 0,
    diagonal: border.diagonal ? __spreadProps(__spreadValues({}, border.diagonal), {
      color: border.diagonal.color ? __spreadValues({}, border.diagonal.color) : void 0
    }) : void 0
  };
}
__name(cloneBorder, "cloneBorder");
function removeUndefined(value) {
  for (const key2 of Object.keys(value)) {
    if (value[key2] === void 0)
      delete value[key2];
  }
}
__name(removeUndefined, "removeUndefined");
function stableStringify(value) {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(",")}]`;
  return `{${Object.keys(value).sort().map(
    (key2) => `${JSON.stringify(key2)}:${stableStringify(value[key2])}`
  ).join(",")}}`;
}
__name(stableStringify, "stableStringify");
function builtInNumberFormatId(code) {
  const builtIns = {
    General: 0,
    "0": 1,
    "0.00": 2,
    "#,##0": 3,
    "#,##0.00": 4,
    "0%": 9,
    "0.00%": 10
  };
  return builtIns[code];
}
__name(builtInNumberFormatId, "builtInNumberFormatId");
function computeDimension(cells) {
  if (cells.length === 0) return void 0;
  let minRow = Number.POSITIVE_INFINITY;
  let minColumn = Number.POSITIVE_INFINITY;
  let maxRow = 0;
  let maxColumn = 0;
  for (const cell of cells) {
    minRow = Math.min(minRow, cell.row);
    minColumn = Math.min(minColumn, cell.column);
    maxRow = Math.max(maxRow, cell.row);
    maxColumn = Math.max(maxColumn, cell.column);
  }
  return formatRangeAddress(minRow, minColumn, maxRow - minRow + 1, maxColumn - minColumn + 1);
}
__name(computeDimension, "computeDimension");
var _ExcelTable = class _ExcelTable2 {
  constructor(model, remove) {
    __publicField(this, "model", model);
    __publicField(this, "remove", remove);
    __publicField(this, "columns");
    __publicField(this, "style");
    this.columns = new ExcelTableColumnCollection(() => this.model.columns);
    this.style = new ExcelTableStyle(() => {
      var _a, _b;
      return (_b = (_a = this.model).style) != null ? _b : _a.style = {};
    });
  }
  id() {
    return this.model.id;
  }
  name() {
    return this.model.name;
  }
  displayName() {
    return this.model.displayName;
  }
  setName(name) {
    this.model.name = name;
  }
  setDisplayName(displayName) {
    this.model.displayName = displayName;
  }
  rangeAddress() {
    return this.model.ref;
  }
  setRange(address) {
    parseRangeAddress(address);
    this.model.ref = address;
    if (this.model.autoFilterRef) this.setAutoFilterRange(address);
  }
  resize(address) {
    this.setRange(address);
    const range = parseRangeAddress(address);
    const current = this.model.columns;
    if (range.columnCount < current.length) {
      current.splice(range.columnCount);
    }
    while (current.length < range.columnCount) {
      const id = nextTableColumnId(current);
      current.push({ id, name: `Column${id}` });
    }
  }
  autoFilterRangeAddress() {
    return this.model.autoFilterRef;
  }
  setAutoFilterRange(address) {
    var _a, _b;
    if (address !== void 0) parseRangeAddress(address);
    this.model.autoFilterRef = address;
    if (address === void 0) {
      delete this.model.autoFilter;
    } else {
      (_b = (_a = this.model).autoFilter) != null ? _b : _a.autoFilter = { ref: address, filterColumns: [] };
      this.model.autoFilter.ref = address;
    }
  }
  headerRowCount() {
    return this.model.headerRowCount;
  }
  setHeaderRowCount(count) {
    assertOptionalNonNegativeInteger(count, "ExcelTable.setHeaderRowCount");
    this.model.headerRowCount = count;
  }
  totalsRowCount() {
    return this.model.totalsRowCount;
  }
  setTotalsRowCount(count) {
    assertOptionalNonNegativeInteger(count, "ExcelTable.setTotalsRowCount");
    this.model.totalsRowCount = count;
  }
  totalsRowShown() {
    return this.model.totalsRowShown;
  }
  setTotalsRowShown(value) {
    this.model.totalsRowShown = value;
  }
  autoFilter() {
    return this.model.autoFilter ? cloneAutoFilter(this.model.autoFilter) : void 0;
  }
  setAutoFilter(model) {
    if (!model) {
      delete this.model.autoFilter;
      delete this.model.autoFilterRef;
      return;
    }
    const copy = cloneAutoFilter(model);
    if (copy.ref) parseRangeAddress(copy.ref);
    this.model.autoFilter = copy;
    this.model.autoFilterRef = copy.ref;
  }
  sortState() {
    var _a;
    return ((_a = this.model.autoFilter) == null ? void 0 : _a.sortState) ? cloneSortState(this.model.autoFilter.sortState) : void 0;
  }
  setSortState(sortState) {
    var _a, _b, _c;
    if (!sortState) {
      if (this.model.autoFilter) delete this.model.autoFilter.sortState;
      return;
    }
    (_c = (_b = this.model).autoFilter) != null ? _c : _b.autoFilter = { ref: (_a = this.model.autoFilterRef) != null ? _a : this.model.ref, filterColumns: [] };
    this.model.autoFilter.sortState = cloneSortState(sortState);
  }
  toModel() {
    return cloneTable(this.model);
  }
  delete() {
    var _a;
    (_a = this.remove) == null ? void 0 : _a.call(this);
  }
};
__name(_ExcelTable, "ExcelTable");
var ExcelTable = _ExcelTable;
var _ExcelTableColumn = class _ExcelTableColumn2 {
  constructor(model, remove) {
    __publicField(this, "model", model);
    __publicField(this, "remove", remove);
  }
  id() {
    return this.model.id;
  }
  name() {
    return this.model.name;
  }
  setName(name) {
    this.model.name = name;
  }
  totalsRowLabel() {
    return this.model.totalsRowLabel;
  }
  setTotalsRowLabel(label) {
    this.model.totalsRowLabel = label;
  }
  totalsRowFunction() {
    return this.model.totalsRowFunction;
  }
  setTotalsRowFunction(fn2) {
    this.model.totalsRowFunction = fn2;
  }
  toModel() {
    return __spreadValues({}, this.model);
  }
  delete() {
    var _a;
    (_a = this.remove) == null ? void 0 : _a.call(this);
  }
};
__name(_ExcelTableColumn, "ExcelTableColumn");
var ExcelTableColumn = _ExcelTableColumn;
var _ExcelTableColumnCollection = class _ExcelTableColumnCollection2 {
  constructor(getModels) {
    __publicField(this, "getModels", getModels);
  }
  items() {
    return this.getModels().map((model) => this.wrap(model));
  }
  getItem(nameOrId) {
    const item = this.getItemOrNullObject(nameOrId);
    if (!item) throw new Error(`ExcelTableColumnCollection: column not found: ${nameOrId}`);
    return item;
  }
  getItemOrNullObject(nameOrId) {
    const model = this.getModels().find((column) => column.name === nameOrId || column.id === nameOrId);
    return model ? this.wrap(model) : null;
  }
  add(model) {
    var _a;
    const models = this.getModels();
    if (models.some((column) => column.name === model.name || column.id === model.id)) {
      throw new Error(`ExcelTableColumnCollection: duplicate column: ${model.name || model.id}`);
    }
    const copy = __spreadProps(__spreadValues({}, model), { id: (_a = model.id) != null ? _a : nextTableColumnId(models) });
    this.getModels().push(copy);
    return this.wrap(copy);
  }
  delete(nameOrId) {
    const models = this.getModels();
    const index = models.findIndex((column) => column.name === nameOrId || column.id === nameOrId);
    if (index >= 0) models.splice(index, 1);
  }
  deleteItem(nameOrId) {
    const models = this.getModels();
    const index = models.findIndex((column) => column.name === nameOrId || column.id === nameOrId);
    if (index === -1) throw new Error(`ExcelTableColumnCollection: column not found: ${nameOrId}`);
    models.splice(index, 1);
  }
  toModel() {
    return this.getModels().map((column) => __spreadValues({}, column));
  }
  wrap(model) {
    return new ExcelTableColumn(model, () => {
      const models = this.getModels();
      const index = models.indexOf(model);
      if (index >= 0) models.splice(index, 1);
    });
  }
};
__name(_ExcelTableColumnCollection, "ExcelTableColumnCollection");
var ExcelTableColumnCollection = _ExcelTableColumnCollection;
var _ExcelTableStyle = class _ExcelTableStyle2 {
  constructor(getModel) {
    __publicField(this, "getModel", getModel);
  }
  name() {
    return this.getModel().name;
  }
  setName(name) {
    this.getModel().name = name;
  }
  showFirstColumn() {
    return this.getModel().showFirstColumn;
  }
  setShowFirstColumn(value) {
    this.getModel().showFirstColumn = value;
  }
  showLastColumn() {
    return this.getModel().showLastColumn;
  }
  setShowLastColumn(value) {
    this.getModel().showLastColumn = value;
  }
  showRowStripes() {
    return this.getModel().showRowStripes;
  }
  setShowRowStripes(value) {
    this.getModel().showRowStripes = value;
  }
  showColumnStripes() {
    return this.getModel().showColumnStripes;
  }
  setShowColumnStripes(value) {
    this.getModel().showColumnStripes = value;
  }
  toModel() {
    return __spreadValues({}, this.getModel());
  }
};
__name(_ExcelTableStyle, "ExcelTableStyle");
var ExcelTableStyle = _ExcelTableStyle;
var _ExcelTableCollection = class _ExcelTableCollection2 {
  constructor(getModels) {
    __publicField(this, "getModels", getModels);
  }
  items() {
    return this.getModels().map((model) => this.wrap(model));
  }
  getItem(nameOrDisplayName) {
    const item = this.getItemOrNullObject(nameOrDisplayName);
    if (!item) throw new Error(`ExcelTableCollection: table not found: ${nameOrDisplayName}`);
    return item;
  }
  getItemOrNullObject(nameOrDisplayName) {
    var _a;
    const model = (_a = this.getModels().find((table) => table.name === nameOrDisplayName || table.displayName === nameOrDisplayName)) != null ? _a : null;
    return model ? this.wrap(model) : null;
  }
  add(model) {
    const copy = cloneTable(model);
    this.getModels().push(copy);
    return this.wrap(copy);
  }
  delete(nameOrDisplayName) {
    const models = this.getModels();
    const index = models.findIndex((table) => table.name === nameOrDisplayName || table.displayName === nameOrDisplayName);
    if (index >= 0) models.splice(index, 1);
  }
  toModel() {
    return this.getModels().map((model) => cloneTable(model));
  }
  wrap(model) {
    return new ExcelTable(model, () => {
      const models = this.getModels();
      const index = models.indexOf(model);
      if (index >= 0) models.splice(index, 1);
    });
  }
};
__name(_ExcelTableCollection, "ExcelTableCollection");
var ExcelTableCollection = _ExcelTableCollection;
var _ExcelHyperlink = class _ExcelHyperlink2 {
  constructor(model, remove) {
    __publicField(this, "model", model);
    __publicField(this, "remove", remove);
  }
  ref() {
    return this.model.ref;
  }
  setRef(ref) {
    this.model.ref = ref;
  }
  target() {
    return this.model.target;
  }
  targetMode() {
    return this.model.targetMode;
  }
  display() {
    return this.model.display;
  }
  setDisplay(display) {
    this.model.display = display;
  }
  setLocation(location) {
    this.model.location = location;
  }
  toModel() {
    return __spreadValues({}, this.model);
  }
  delete() {
    var _a;
    (_a = this.remove) == null ? void 0 : _a.call(this);
  }
};
__name(_ExcelHyperlink, "ExcelHyperlink");
var ExcelHyperlink = _ExcelHyperlink;
var _ExcelHyperlinkCollection = class _ExcelHyperlinkCollection2 {
  constructor(getModels) {
    __publicField(this, "getModels", getModels);
  }
  items() {
    return this.getModels().map((model) => this.wrap(model));
  }
  add(model) {
    const copy = __spreadValues({}, model);
    this.getModels().push(copy);
    return this.wrap(copy);
  }
  getItem(ref) {
    const item = this.getItemOrNullObject(ref);
    if (!item) throw new Error(`hyperlink not found: ${ref}`);
    return item;
  }
  getItemOrNullObject(ref) {
    const model = this.getModels().find((item) => item.ref === ref);
    return model ? this.wrap(model) : null;
  }
  delete(ref) {
    var _a;
    const models = this.getModels();
    for (let i2 = models.length - 1; i2 >= 0; i2--) {
      if (((_a = models[i2]) == null ? void 0 : _a.ref) === ref) models.splice(i2, 1);
    }
  }
  toModel() {
    return this.getModels().map((model) => __spreadValues({}, model));
  }
  wrap(model) {
    return new ExcelHyperlink(model, () => {
      const models = this.getModels();
      const index = models.indexOf(model);
      if (index >= 0) models.splice(index, 1);
    });
  }
};
__name(_ExcelHyperlinkCollection, "ExcelHyperlinkCollection");
var ExcelHyperlinkCollection = _ExcelHyperlinkCollection;
var _ExcelDataValidation = class _ExcelDataValidation2 {
  constructor(model, remove) {
    __publicField(this, "model", model);
    __publicField(this, "remove", remove);
  }
  rangeAddress() {
    return this.model.sqref;
  }
  setRange(address) {
    this.model.sqref = address;
  }
  type() {
    return this.model.type;
  }
  setType(type) {
    this.model.type = type;
  }
  operator() {
    return this.model.operator;
  }
  setOperator(operator) {
    this.model.operator = operator;
  }
  allowBlank() {
    return this.model.allowBlank;
  }
  setAllowBlank(value) {
    this.model.allowBlank = value;
  }
  showDropDown() {
    return this.model.showDropDown;
  }
  setShowDropDown(value) {
    this.model.showDropDown = value;
  }
  showInputMessage() {
    return this.model.showInputMessage;
  }
  setShowInputMessage(value) {
    this.model.showInputMessage = value;
  }
  showErrorMessage() {
    return this.model.showErrorMessage;
  }
  setShowErrorMessage(value) {
    this.model.showErrorMessage = value;
  }
  errorStyle() {
    return this.model.errorStyle;
  }
  setErrorStyle(style) {
    this.model.errorStyle = style;
  }
  errorTitle() {
    return this.model.errorTitle;
  }
  error() {
    return this.model.error;
  }
  setError(title, message) {
    this.model.errorTitle = title;
    this.model.error = message;
  }
  promptTitle() {
    return this.model.promptTitle;
  }
  prompt() {
    return this.model.prompt;
  }
  setPrompt(title, message) {
    this.model.promptTitle = title;
    this.model.prompt = message;
  }
  formula1() {
    return this.model.formula1;
  }
  setFormula1(formula) {
    this.model.formula1 = formula;
  }
  formula2() {
    return this.model.formula2;
  }
  setFormula2(formula) {
    this.model.formula2 = formula;
  }
  toModel() {
    return __spreadValues({}, this.model);
  }
  delete() {
    var _a;
    (_a = this.remove) == null ? void 0 : _a.call(this);
  }
};
__name(_ExcelDataValidation, "ExcelDataValidation");
var ExcelDataValidation = _ExcelDataValidation;
var _ExcelDataValidationCollection = class _ExcelDataValidationCollection2 {
  constructor(getModels) {
    __publicField(this, "getModels", getModels);
  }
  items() {
    return this.getModels().map((model) => this.wrap(model));
  }
  add(model) {
    const copy = __spreadValues({}, model);
    this.getModels().push(copy);
    return this.wrap(copy);
  }
  getItem(rangeAddress) {
    const item = this.getItemOrNullObject(rangeAddress);
    if (!item) throw new Error(`data validation not found: ${rangeAddress}`);
    return item;
  }
  getItemOrNullObject(rangeAddress) {
    const model = this.getModels().find((validation) => validation.sqref === rangeAddress);
    return model ? this.wrap(model) : null;
  }
  delete(rangeAddress) {
    var _a;
    const models = this.getModels();
    for (let i2 = models.length - 1; i2 >= 0; i2--) {
      if (((_a = models[i2]) == null ? void 0 : _a.sqref) === rangeAddress) models.splice(i2, 1);
    }
  }
  toModel() {
    return this.getModels().map((model) => __spreadValues({}, model));
  }
  wrap(model) {
    return new ExcelDataValidation(model, () => {
      const models = this.getModels();
      const index = models.indexOf(model);
      if (index >= 0) models.splice(index, 1);
    });
  }
};
__name(_ExcelDataValidationCollection, "ExcelDataValidationCollection");
var ExcelDataValidationCollection = _ExcelDataValidationCollection;
var _ExcelConditionalFormat = class _ExcelConditionalFormat2 {
  constructor(model, remove) {
    __publicField(this, "model", model);
    __publicField(this, "remove", remove);
    __publicField(this, "rules");
    this.rules = new ExcelConditionalFormatRuleCollection(() => this.model.rules);
  }
  rangeAddress() {
    return this.model.sqref;
  }
  setRange(address) {
    this.model.sqref = address;
  }
  toModel() {
    return cloneConditionalFormat(this.model);
  }
  delete() {
    var _a;
    (_a = this.remove) == null ? void 0 : _a.call(this);
  }
};
__name(_ExcelConditionalFormat, "ExcelConditionalFormat");
var ExcelConditionalFormat = _ExcelConditionalFormat;
var _ExcelConditionalFormatRule = class _ExcelConditionalFormatRule2 {
  constructor(model, remove) {
    __publicField(this, "model", model);
    __publicField(this, "remove", remove);
  }
  type() {
    return this.model.type;
  }
  setType(type) {
    this.model.type = type;
  }
  priority() {
    return this.model.priority;
  }
  setPriority(priority) {
    this.model.priority = priority;
  }
  operator() {
    return this.model.operator;
  }
  setOperator(operator) {
    this.model.operator = operator;
  }
  stopIfTrue() {
    return this.model.stopIfTrue;
  }
  setStopIfTrue(value) {
    this.model.stopIfTrue = value;
  }
  formulas() {
    return [...this.model.formulas];
  }
  setFormula(index, formula) {
    this.model.formulas[index] = formula;
  }
  addFormula(formula) {
    this.model.formulas.push(formula);
  }
  deleteFormula(index) {
    this.model.formulas.splice(index, 1);
  }
  toModel() {
    return __spreadProps(__spreadValues({}, this.model), { formulas: [...this.model.formulas] });
  }
  delete() {
    var _a;
    (_a = this.remove) == null ? void 0 : _a.call(this);
  }
};
__name(_ExcelConditionalFormatRule, "ExcelConditionalFormatRule");
var ExcelConditionalFormatRule = _ExcelConditionalFormatRule;
var _ExcelConditionalFormatRuleCollection = class _ExcelConditionalFormatRuleCollection2 {
  constructor(getModels) {
    __publicField(this, "getModels", getModels);
  }
  items() {
    return this.getModels().map((model) => this.wrap(model));
  }
  getItem(index) {
    const item = this.getItemOrNullObject(index);
    if (!item) throw new Error(`conditional format rule not found: ${index}`);
    return item;
  }
  getItemOrNullObject(index) {
    const model = this.getModels()[index];
    return model ? this.wrap(model) : null;
  }
  add(model) {
    const copy = __spreadProps(__spreadValues({}, model), { formulas: [...model.formulas] });
    this.getModels().push(copy);
    return this.wrap(copy);
  }
  delete(index) {
    this.getModels().splice(index, 1);
  }
  toModel() {
    return this.getModels().map((model) => __spreadProps(__spreadValues({}, model), { formulas: [...model.formulas] }));
  }
  wrap(model) {
    return new ExcelConditionalFormatRule(model, () => {
      const models = this.getModels();
      const index = models.indexOf(model);
      if (index >= 0) models.splice(index, 1);
    });
  }
};
__name(_ExcelConditionalFormatRuleCollection, "ExcelConditionalFormatRuleCollection");
var ExcelConditionalFormatRuleCollection = _ExcelConditionalFormatRuleCollection;
var _ExcelConditionalFormatCollection = class _ExcelConditionalFormatCollection2 {
  constructor(getModels) {
    __publicField(this, "getModels", getModels);
  }
  items() {
    return this.getModels().map((model) => this.wrap(model));
  }
  add(model) {
    const copy = cloneConditionalFormat(model);
    this.getModels().push(copy);
    return this.wrap(copy);
  }
  getItem(rangeAddress) {
    const item = this.getItemOrNullObject(rangeAddress);
    if (!item) throw new Error(`conditional format not found: ${rangeAddress}`);
    return item;
  }
  getItemOrNullObject(rangeAddress) {
    const model = this.getModels().find((format) => format.sqref === rangeAddress);
    return model ? this.wrap(model) : null;
  }
  delete(rangeAddress) {
    var _a;
    const models = this.getModels();
    for (let i2 = models.length - 1; i2 >= 0; i2--) {
      if (((_a = models[i2]) == null ? void 0 : _a.sqref) === rangeAddress) models.splice(i2, 1);
    }
  }
  toModel() {
    return this.getModels().map((model) => cloneConditionalFormat(model));
  }
  wrap(model) {
    return new ExcelConditionalFormat(model, () => {
      const models = this.getModels();
      const index = models.indexOf(model);
      if (index >= 0) models.splice(index, 1);
    });
  }
};
__name(_ExcelConditionalFormatCollection, "ExcelConditionalFormatCollection");
var ExcelConditionalFormatCollection = _ExcelConditionalFormatCollection;
var _ExcelComment = class _ExcelComment2 {
  constructor(model, remove) {
    __publicField(this, "model", model);
    __publicField(this, "remove", remove);
  }
  ref() {
    return this.model.ref;
  }
  setRef(ref) {
    this.model.ref = ref;
  }
  text() {
    return this.model.text;
  }
  setText(text) {
    this.model.text = text;
  }
  toModel() {
    return __spreadValues({}, this.model);
  }
  delete() {
    var _a;
    (_a = this.remove) == null ? void 0 : _a.call(this);
  }
};
__name(_ExcelComment, "ExcelComment");
var ExcelComment = _ExcelComment;
var _ExcelCommentCollection = class _ExcelCommentCollection2 {
  constructor(getModels) {
    __publicField(this, "getModels", getModels);
  }
  items() {
    return this.getModels().map((model) => this.wrap(model));
  }
  add(model) {
    const copy = __spreadValues({}, model);
    this.getModels().push(copy);
    return this.wrap(copy);
  }
  getItem(ref) {
    const item = this.getItemOrNullObject(ref);
    if (!item) throw new Error(`comment not found: ${ref}`);
    return item;
  }
  getItemOrNullObject(ref) {
    const model = this.getModels().find((comment) => comment.ref === ref);
    return model ? this.wrap(model) : null;
  }
  delete(ref) {
    var _a;
    const models = this.getModels();
    for (let i2 = models.length - 1; i2 >= 0; i2--) {
      if (((_a = models[i2]) == null ? void 0 : _a.ref) === ref) models.splice(i2, 1);
    }
  }
  toModel() {
    return this.getModels().map((model) => __spreadValues({}, model));
  }
  wrap(model) {
    return new ExcelComment(model, () => {
      const models = this.getModels();
      const index = models.indexOf(model);
      if (index >= 0) models.splice(index, 1);
    });
  }
};
__name(_ExcelCommentCollection, "ExcelCommentCollection");
var ExcelCommentCollection = _ExcelCommentCollection;
var _ExcelThreadedComment = class _ExcelThreadedComment2 {
  constructor(model, deleteSelf) {
    __publicField(this, "model", model);
    __publicField(this, "deleteSelf", deleteSelf);
  }
  ref() {
    return this.model.ref;
  }
  setRef(ref) {
    this.model.ref = ref;
  }
  text() {
    return this.model.text;
  }
  setText(text) {
    this.model.text = text;
  }
  delete() {
    var _a;
    (_a = this.deleteSelf) == null ? void 0 : _a.call(this);
  }
  toModel() {
    return __spreadValues({}, this.model);
  }
};
__name(_ExcelThreadedComment, "ExcelThreadedComment");
var ExcelThreadedComment = _ExcelThreadedComment;
var _ExcelThreadedCommentCollection = class _ExcelThreadedCommentCollection2 {
  constructor(getModels) {
    __publicField(this, "getModels", getModels);
  }
  items() {
    return this.getModels().map((model) => this.wrap(model));
  }
  getItem(ref) {
    const item = this.getItemOrNullObject(ref);
    if (!item) throw new Error(`threaded comment not found: ${ref}`);
    return item;
  }
  getItemOrNullObject(ref) {
    const model = this.getModels().find((comment) => comment.ref === ref);
    return model ? this.wrap(model) : null;
  }
  delete(ref) {
    const models = this.getModels();
    const index = models.findIndex((comment) => comment.ref === ref);
    if (index >= 0) models.splice(index, 1);
  }
  toModel() {
    return this.getModels().map((model) => __spreadValues({}, model));
  }
  wrap(model) {
    return new ExcelThreadedComment(model, () => {
      const models = this.getModels();
      const index = models.indexOf(model);
      if (index >= 0) models.splice(index, 1);
    });
  }
};
__name(_ExcelThreadedCommentCollection, "ExcelThreadedCommentCollection");
var ExcelThreadedCommentCollection = _ExcelThreadedCommentCollection;
var _ExcelDrawingCollection = class _ExcelDrawingCollection2 {
  constructor(getModels) {
    __publicField(this, "getModels", getModels);
  }
  items() {
    return this.getModels().map((model) => new ExcelDrawing(model));
  }
  toModel() {
    return this.getModels().map((drawing) => __spreadProps(__spreadValues({}, drawing), {
      anchors: drawing.anchors.map(cloneDrawingAnchor)
    }));
  }
};
__name(_ExcelDrawingCollection, "ExcelDrawingCollection");
var ExcelDrawingCollection = _ExcelDrawingCollection;
var _ExcelDrawing = class _ExcelDrawing2 {
  constructor(model) {
    __publicField(this, "model", model);
    __publicField(this, "anchors");
    this.anchors = new ExcelDrawingAnchorCollection(() => this.model.anchors);
  }
  relationshipId() {
    return this.model.relationshipId;
  }
  path() {
    return this.model.path;
  }
  toModel() {
    return cloneDrawing(this.model);
  }
};
__name(_ExcelDrawing, "ExcelDrawing");
var ExcelDrawing = _ExcelDrawing;
var _ExcelDrawingAnchorCollection = class _ExcelDrawingAnchorCollection2 {
  constructor(getModels) {
    __publicField(this, "getModels", getModels);
  }
  items() {
    return this.getModels().map((model) => new ExcelDrawingAnchor(model));
  }
  getItem(index) {
    const item = this.getItemOrNullObject(index);
    if (!item) throw new Error(`drawing anchor not found: ${index}`);
    return item;
  }
  getItemOrNullObject(index) {
    const model = this.getModels()[index];
    return model ? new ExcelDrawingAnchor(model) : null;
  }
  toModel() {
    return this.getModels().map((anchor) => cloneDrawingAnchor(anchor));
  }
};
__name(_ExcelDrawingAnchorCollection, "ExcelDrawingAnchorCollection");
var ExcelDrawingAnchorCollection = _ExcelDrawingAnchorCollection;
var _ExcelDrawingAnchor = class _ExcelDrawingAnchor2 {
  constructor(model) {
    __publicField(this, "model", model);
    __publicField(this, "from");
    __publicField(this, "to");
    this.from = new ExcelDrawingMarker(() => {
      var _a, _b;
      return (_b = (_a = this.model).from) != null ? _b : _a.from = {};
    });
    this.to = new ExcelDrawingMarker(() => {
      var _a, _b;
      return (_b = (_a = this.model).to) != null ? _b : _a.to = {};
    });
  }
  setPosition(position) {
    if (position.kind !== this.model.kind) throw new Error("Cannot change the drawing anchor type");
    this.model.from = position.from && __spreadValues({}, position.from);
    this.model.to = position.to && __spreadValues({}, position.to);
    this.model.x = position.x;
    this.model.y = position.y;
    this.model.width = position.width;
    this.model.height = position.height;
    this.model.transform = position.transform && __spreadValues({}, position.transform);
  }
  kind() {
    return this.model.kind;
  }
  object() {
    return this.model.object ? __spreadValues({}, this.model.object) : void 0;
  }
  toModel() {
    return cloneDrawingAnchor(this.model);
  }
};
__name(_ExcelDrawingAnchor, "ExcelDrawingAnchor");
var ExcelDrawingAnchor = _ExcelDrawingAnchor;
var _ExcelDrawingMarker = class _ExcelDrawingMarker2 {
  constructor(getModel) {
    __publicField(this, "getModel", getModel);
  }
  row() {
    return this.getModel().row;
  }
  setRow(row) {
    this.getModel().row = row;
  }
  column() {
    return this.getModel().column;
  }
  setColumn(column) {
    this.getModel().column = column;
  }
  rowOffset() {
    return this.getModel().rowOffset;
  }
  setRowOffset(offset) {
    this.getModel().rowOffset = offset;
  }
  columnOffset() {
    return this.getModel().columnOffset;
  }
  setColumnOffset(offset) {
    this.getModel().columnOffset = offset;
  }
  toModel() {
    return __spreadValues({}, this.getModel());
  }
};
__name(_ExcelDrawingMarker, "ExcelDrawingMarker");
var ExcelDrawingMarker = _ExcelDrawingMarker;
var _ExcelChartCollection = class _ExcelChartCollection2 {
  constructor(getModels, getDrawings) {
    __publicField(this, "getModels", getModels);
    __publicField(this, "getDrawings", getDrawings);
  }
  items() {
    return this.getModels().map((model) => new ExcelChart(model));
  }
  add(options) {
    var _a, _b;
    validateChartAddOptions(options);
    const models = this.getModels();
    const chart = {
      type: options.type,
      title: options.title,
      categoryRange: options.categoryRange,
      series: options.series.map((series) => __spreadValues({}, series)),
      position: {
        from: __spreadValues({}, options.position.from),
        to: __spreadValues({}, options.position.to)
      },
      formulaRefs: chartFormulaRefs(options)
    };
    models.push(chart);
    const drawings = (_a = this.getDrawings) == null ? void 0 : _a.call(this);
    if (drawings) {
      const drawing = (_b = drawings[0]) != null ? _b : { anchors: [] };
      if (!drawings[0]) drawings.push(drawing);
      drawing.anchors.push({
        kind: "twoCell",
        from: __spreadValues({}, options.position.from),
        to: __spreadValues({}, options.position.to),
        object: {
          kind: "chart",
          name: options.title
        }
      });
    }
    return new ExcelChart(chart);
  }
  toModel() {
    return this.getModels().map((chart) => {
      var _a;
      return __spreadProps(__spreadValues({}, chart), {
        series: (_a = chart.series) == null ? void 0 : _a.map((series) => __spreadValues({}, series)),
        position: chart.position ? { from: __spreadValues({}, chart.position.from), to: __spreadValues({}, chart.position.to) } : void 0,
        formulaRefs: [...chart.formulaRefs]
      });
    });
  }
};
__name(_ExcelChartCollection, "ExcelChartCollection");
var ExcelChartCollection = _ExcelChartCollection;
function chartFormulaRefs(options) {
  return [
    options.categoryRange,
    ...options.series.flatMap(
      (series) => {
        var _a, _b;
        return ((_a = series.name) == null ? void 0 : _a.includes("!")) || ((_b = series.name) == null ? void 0 : _b.includes("$")) ? [series.name, series.values] : [series.values];
      }
    )
  ];
}
__name(chartFormulaRefs, "chartFormulaRefs");
function validateChartAddOptions(options) {
  if (!options.type) throw new Error("ExcelChartCollection.add: chart type is required");
  if (!options.categoryRange) throw new Error("ExcelChartCollection.add: categoryRange is required");
  if (!options.series.length) throw new Error("ExcelChartCollection.add: at least one series is required");
  if ((options.type === "pie" || options.type === "doughnut") && options.series.length !== 1) {
    throw new Error(`ExcelChartCollection.add: ${options.type} charts require exactly one series`);
  }
  for (const series of options.series) {
    if (!series.values) throw new Error("ExcelChartCollection.add: series values range is required");
  }
}
__name(validateChartAddOptions, "validateChartAddOptions");
var _ExcelChart = class _ExcelChart2 {
  constructor(model) {
    __publicField(this, "model", model);
    __publicField(this, "formulaRefs");
    this.formulaRefs = new ExcelFormulaRefCollection(() => this.model.formulaRefs);
  }
  relationshipId() {
    return this.model.relationshipId;
  }
  drawingPath() {
    return this.model.drawingPath;
  }
  path() {
    return this.model.path;
  }
  title() {
    return this.model.title;
  }
  setTitle(title) {
    this.model.title = title;
  }
  toModel() {
    return __spreadProps(__spreadValues({}, this.model), { formulaRefs: [...this.model.formulaRefs] });
  }
};
__name(_ExcelChart, "ExcelChart");
var ExcelChart = _ExcelChart;
var _ExcelFormulaRefCollection = class _ExcelFormulaRefCollection2 {
  constructor(getModels) {
    __publicField(this, "getModels", getModels);
  }
  items() {
    return [...this.getModels()];
  }
  getItem(index) {
    return this.getModels()[index];
  }
  setItem(index, formulaRef) {
    this.getModels()[index] = formulaRef;
  }
  add(formulaRef) {
    this.getModels().push(formulaRef);
  }
  delete(index) {
    this.getModels().splice(index, 1);
  }
  toModel() {
    return this.items();
  }
};
__name(_ExcelFormulaRefCollection, "ExcelFormulaRefCollection");
var ExcelFormulaRefCollection = _ExcelFormulaRefCollection;
var _ExcelImageCollection = class _ExcelImageCollection2 {
  constructor(getModels) {
    __publicField(this, "getModels", getModels);
  }
  items() {
    return this.getModels().map((model) => new ExcelImage(model));
  }
  toModel() {
    return this.getModels().map((image) => __spreadValues({}, image));
  }
};
__name(_ExcelImageCollection, "ExcelImageCollection");
var ExcelImageCollection = _ExcelImageCollection;
var _ExcelImage = class _ExcelImage2 {
  constructor(model) {
    __publicField(this, "model", model);
  }
  relationshipId() {
    return this.model.relationshipId;
  }
  drawingPath() {
    return this.model.drawingPath;
  }
  path() {
    return this.model.path;
  }
  targetMode() {
    return this.model.targetMode;
  }
  name() {
    return this.model.name;
  }
  toModel() {
    return __spreadValues({}, this.model);
  }
};
__name(_ExcelImage, "ExcelImage");
var ExcelImage = _ExcelImage;
var _ExcelShapeCollection = class _ExcelShapeCollection2 {
  constructor(getDrawings) {
    __publicField(this, "getDrawings", getDrawings);
  }
  items() {
    return this.getShapeEntries().map((entry) => new ExcelShape(entry));
  }
  getItem(name) {
    const item = this.getItemOrNullObject(name);
    if (!item) throw new Error(`shape not found: ${name}`);
    return item;
  }
  getItemOrNullObject(name) {
    const entry = this.getShapeEntries().find((item) => {
      var _a;
      return ((_a = item.anchor.object) == null ? void 0 : _a.name) === name;
    });
    return entry ? new ExcelShape(entry) : null;
  }
  toModel() {
    return this.getShapeEntries().map((entry) => {
      var _a;
      return {
        drawingPath: entry.drawing.path,
        name: (_a = entry.anchor.object) == null ? void 0 : _a.name,
        anchor: cloneDrawingAnchor(entry.anchor)
      };
    });
  }
  getShapeEntries() {
    return this.getDrawings().flatMap(
      (drawing) => drawing.anchors.filter((anchor) => {
        var _a;
        return ((_a = anchor.object) == null ? void 0 : _a.kind) === "shape";
      }).map((anchor) => ({ drawing, anchor }))
    );
  }
};
__name(_ExcelShapeCollection, "ExcelShapeCollection");
var ExcelShapeCollection = _ExcelShapeCollection;
var _ExcelShape = class _ExcelShape2 {
  constructor(entry) {
    __publicField(this, "entry", entry);
    __publicField(this, "anchor");
    this.anchor = new ExcelDrawingAnchor(entry.anchor);
  }
  drawingPath() {
    return this.entry.drawing.path;
  }
  name() {
    var _a;
    return (_a = this.entry.anchor.object) == null ? void 0 : _a.name;
  }
  setName(name) {
    var _a, _b;
    (_b = (_a = this.entry.anchor).object) != null ? _b : _a.object = { kind: "shape" };
    this.entry.anchor.object.name = name;
  }
  toModel() {
    var _a;
    return {
      drawingPath: this.entry.drawing.path,
      name: (_a = this.entry.anchor.object) == null ? void 0 : _a.name,
      anchor: cloneDrawingAnchor(this.entry.anchor)
    };
  }
};
__name(_ExcelShape, "ExcelShape");
var ExcelShape = _ExcelShape;
function cloneTable(table) {
  return __spreadProps(__spreadValues({}, table), {
    columns: table.columns.map((column) => __spreadValues({}, column)),
    autoFilter: table.autoFilter ? cloneAutoFilter(table.autoFilter) : void 0,
    style: table.style ? __spreadValues({}, table.style) : void 0
  });
}
__name(cloneTable, "cloneTable");
function cloneAutoFilter(autoFilter) {
  const clone2 = __spreadProps(__spreadValues({}, autoFilter), {
    filterColumns: autoFilter.filterColumns.map((column) => __spreadProps(__spreadValues({}, column), {
      filters: column.filters ? [...column.filters] : void 0
    })),
    sortState: autoFilter.sortState ? cloneSortState(autoFilter.sortState) : void 0
  });
  if (clone2.sortState === void 0) delete clone2.sortState;
  for (const column of clone2.filterColumns) {
    if (column.filters === void 0) delete column.filters;
  }
  return clone2;
}
__name(cloneAutoFilter, "cloneAutoFilter");
function cloneSortState(sortState) {
  return __spreadProps(__spreadValues({}, sortState), {
    conditions: sortState.conditions.map((condition) => __spreadValues({}, condition))
  });
}
__name(cloneSortState, "cloneSortState");
function nextTableColumnId(columns) {
  return columns.reduce((max, column) => Math.max(max, column.id), 0) + 1;
}
__name(nextTableColumnId, "nextTableColumnId");
function assertOptionalNonNegativeInteger(value, operation) {
  if (value !== void 0 && (!Number.isInteger(value) || value < 0)) {
    throw new Error(`${operation}: value must be a non-negative integer`);
  }
}
__name(assertOptionalNonNegativeInteger, "assertOptionalNonNegativeInteger");
function cloneDrawing(drawing) {
  return __spreadProps(__spreadValues({}, drawing), {
    anchors: drawing.anchors.map((anchor) => cloneDrawingAnchor(anchor))
  });
}
__name(cloneDrawing, "cloneDrawing");
function cloneDrawingAnchor(anchor) {
  return __spreadProps(__spreadValues({}, anchor), {
    from: anchor.from ? __spreadValues({}, anchor.from) : void 0,
    to: anchor.to ? __spreadValues({}, anchor.to) : void 0,
    transform: anchor.transform ? __spreadValues({}, anchor.transform) : void 0,
    object: anchor.object ? __spreadValues({}, anchor.object) : void 0
  });
}
__name(cloneDrawingAnchor, "cloneDrawingAnchor");
function cloneConditionalFormat(format) {
  return __spreadProps(__spreadValues({}, format), {
    rules: format.rules.map((rule) => __spreadProps(__spreadValues({}, rule), {
      formulas: [...rule.formulas]
    }))
  });
}
__name(cloneConditionalFormat, "cloneConditionalFormat");
function renameSheetInReference(address, oldName, newName) {
  const ref = parseReference(address);
  if (ref.sheetName !== oldName) return formatReference(ref);
  return formatReference(__spreadProps(__spreadValues({}, ref), { sheetName: newName }));
}
__name(renameSheetInReference, "renameSheetInReference");
function rewriteFormulaReferences(formula, rewrite) {
  let output = "";
  let index = 0;
  while (index < formula.length) {
    const ch = formula[index];
    if (ch === '"') {
      const literal = readFormulaStringLiteral(formula, index);
      output += literal.text;
      index = literal.end;
      continue;
    }
    const match = matchReferenceAt(formula, index);
    if (!match) {
      if (ch === "[") {
        let depth = 1;
        let end = index + 1;
        while (end < formula.length && depth) {
          if (formula[end] === "[") depth++;
          if (formula[end] === "]") depth--;
          end++;
        }
        output += formula.slice(index, end);
        index = end;
        continue;
      }
      output += ch;
      index += 1;
      continue;
    }
    const rewritten = rewrite(match.reference);
    output += rewritten.ok ? rewritten.address : rewritten.address;
    index = match.end;
  }
  return output;
}
__name(rewriteFormulaReferences, "rewriteFormulaReferences");
function renameSheetInFormula(formula, oldName, newName) {
  return rewriteFormulaReferences(formula, (reference) => ({
    ok: true,
    address: renameSheetInReference(reference, oldName, newName)
  }));
}
__name(renameSheetInFormula, "renameSheetInFormula");
function rewriteFormulaForRowInsert(formula, rowIndex, count = 1, options = {}) {
  return rewriteFormulaReferences(
    formula,
    (reference) => rewriteReferenceForRowInsert(reference, rowIndex, count, options)
  );
}
__name(rewriteFormulaForRowInsert, "rewriteFormulaForRowInsert");
function rewriteFormulaForRowDelete(formula, rowIndex, count = 1, options = {}) {
  return rewriteFormulaReferences(
    formula,
    (reference) => rewriteReferenceForRowDelete(reference, rowIndex, count, options)
  );
}
__name(rewriteFormulaForRowDelete, "rewriteFormulaForRowDelete");
function rewriteFormulaForColumnInsert(formula, columnIndex, count = 1, options = {}) {
  return rewriteFormulaReferences(
    formula,
    (reference) => rewriteReferenceForColumnInsert(reference, columnIndex, count, options)
  );
}
__name(rewriteFormulaForColumnInsert, "rewriteFormulaForColumnInsert");
function rewriteFormulaForColumnDelete(formula, columnIndex, count = 1, options = {}) {
  return rewriteFormulaReferences(
    formula,
    (reference) => rewriteReferenceForColumnDelete(reference, columnIndex, count, options)
  );
}
__name(rewriteFormulaForColumnDelete, "rewriteFormulaForColumnDelete");
function rewriteFormulaForRowMove(formula, rowIndex, count, beforeRowIndex, options = {}) {
  return rewriteFormulaReferences(
    formula,
    (reference) => rewriteReferenceForRowMove(reference, rowIndex, count, beforeRowIndex, options)
  );
}
__name(rewriteFormulaForRowMove, "rewriteFormulaForRowMove");
function rewriteFormulaForColumnMove(formula, columnIndex, count, beforeColumnIndex, options = {}) {
  return rewriteFormulaReferences(
    formula,
    (reference) => rewriteReferenceForColumnMove(reference, columnIndex, count, beforeColumnIndex, options)
  );
}
__name(rewriteFormulaForColumnMove, "rewriteFormulaForColumnMove");
function shiftFormulaReferences(formula, rowOffset, columnOffset) {
  assertInteger(rowOffset, "rowOffset");
  assertInteger(columnOffset, "columnOffset");
  return rewriteFormulaReferences(formula, (reference) => shiftReferenceRelative(reference, rowOffset, columnOffset));
}
__name(shiftFormulaReferences, "shiftFormulaReferences");
function rewriteFormulaForRowSort(formula, rowMap, options = {}) {
  return rewriteFormulaReferences(formula, (reference) => {
    const ref = parseReference(reference);
    if (!isTargetSheet(ref, options.sheetName)) return { ok: true, address: formatReference(ref) };
    const rewriteCell = /* @__PURE__ */ __name((cell) => {
      var _a;
      const row = cell.rowAbsolute ? cell.row : (_a = rowMap.get(cell.row)) != null ? _a : cell.row;
      return __spreadProps(__spreadValues({}, cell), { row });
    }, "rewriteCell");
    return {
      ok: true,
      address: formatReference(__spreadProps(__spreadValues({}, ref), { start: rewriteCell(ref.start), end: rewriteCell(ref.end) }))
    };
  });
}
__name(rewriteFormulaForRowSort, "rewriteFormulaForRowSort");
function shiftReferenceRelative(address, rowOffset, columnOffset) {
  assertInteger(rowOffset, "rowOffset");
  assertInteger(columnOffset, "columnOffset");
  const ref = parseReference(address);
  const start = shiftCellRelative(ref.start, rowOffset, columnOffset);
  const end = shiftCellRelative(ref.end, rowOffset, columnOffset);
  if (!start || !end) return { ok: false, address: "#REF!" };
  return { ok: true, address: formatReference(__spreadProps(__spreadValues({}, ref), { start, end })) };
}
__name(shiftReferenceRelative, "shiftReferenceRelative");
function rewriteReferenceForRowInsert(address, rowIndex, count = 1, options = {}) {
  assertPositiveInteger(rowIndex, "rowIndex");
  assertPositiveInteger(count, "count");
  const ref = parseReference(address);
  if (!isTargetSheet(ref, options.sheetName)) return { ok: true, address: formatReference(ref) };
  return {
    ok: true,
    address: formatReference(__spreadProps(__spreadValues({}, ref), {
      start: shiftCellRowsForInsert(ref.start, rowIndex, count),
      end: shiftCellRowsForInsert(ref.end, rowIndex, count)
    }))
  };
}
__name(rewriteReferenceForRowInsert, "rewriteReferenceForRowInsert");
function rewriteReferenceForRowDelete(address, rowIndex, count = 1, options = {}) {
  assertPositiveInteger(rowIndex, "rowIndex");
  assertPositiveInteger(count, "count");
  const ref = parseReference(address);
  if (!isTargetSheet(ref, options.sheetName)) return { ok: true, address: formatReference(ref) };
  const rows = rewriteAxisForDelete(ref.start.row, ref.end.row, { start: rowIndex, count });
  if (!rows) return { ok: false, address: "#REF!" };
  return {
    ok: true,
    address: formatReference(__spreadProps(__spreadValues({}, ref), {
      start: __spreadProps(__spreadValues({}, ref.start), { row: rows.start }),
      end: __spreadProps(__spreadValues({}, ref.end), { row: rows.end })
    }))
  };
}
__name(rewriteReferenceForRowDelete, "rewriteReferenceForRowDelete");
function rewriteReferenceForColumnInsert(address, columnIndex, count = 1, options = {}) {
  assertPositiveInteger(columnIndex, "columnIndex");
  assertPositiveInteger(count, "count");
  const ref = parseReference(address);
  if (!isTargetSheet(ref, options.sheetName)) return { ok: true, address: formatReference(ref) };
  return {
    ok: true,
    address: formatReference(__spreadProps(__spreadValues({}, ref), {
      start: shiftCellColumnsForInsert(ref.start, columnIndex, count),
      end: shiftCellColumnsForInsert(ref.end, columnIndex, count)
    }))
  };
}
__name(rewriteReferenceForColumnInsert, "rewriteReferenceForColumnInsert");
function rewriteReferenceForColumnDelete(address, columnIndex, count = 1, options = {}) {
  assertPositiveInteger(columnIndex, "columnIndex");
  assertPositiveInteger(count, "count");
  const ref = parseReference(address);
  if (!isTargetSheet(ref, options.sheetName)) return { ok: true, address: formatReference(ref) };
  const columns = rewriteAxisForDelete(ref.start.column, ref.end.column, {
    start: columnIndex,
    count
  });
  if (!columns) return { ok: false, address: "#REF!" };
  return {
    ok: true,
    address: formatReference(__spreadProps(__spreadValues({}, ref), {
      start: __spreadProps(__spreadValues({}, ref.start), { column: columns.start }),
      end: __spreadProps(__spreadValues({}, ref.end), { column: columns.end })
    }))
  };
}
__name(rewriteReferenceForColumnDelete, "rewriteReferenceForColumnDelete");
function rewriteReferenceForRowMove(address, rowIndex, count, beforeRowIndex, options = {}) {
  assertMoveArguments(rowIndex, count, beforeRowIndex, "row");
  const ref = parseReference(address);
  if (!isTargetSheet(ref, options.sheetName)) return { ok: true, address: formatReference(ref) };
  const rows = rewriteAxisForMove(ref.start.row, ref.end.row, rowIndex, count, beforeRowIndex);
  if (!rows) return { ok: false, address: "#REF!" };
  return {
    ok: true,
    address: formatReference(__spreadProps(__spreadValues({}, ref), {
      start: __spreadProps(__spreadValues({}, ref.start), { row: rows.start }),
      end: __spreadProps(__spreadValues({}, ref.end), { row: rows.end })
    }))
  };
}
__name(rewriteReferenceForRowMove, "rewriteReferenceForRowMove");
function rewriteReferenceForColumnMove(address, columnIndex, count, beforeColumnIndex, options = {}) {
  assertMoveArguments(columnIndex, count, beforeColumnIndex, "column");
  const ref = parseReference(address);
  if (!isTargetSheet(ref, options.sheetName)) return { ok: true, address: formatReference(ref) };
  const columns = rewriteAxisForMove(
    ref.start.column,
    ref.end.column,
    columnIndex,
    count,
    beforeColumnIndex
  );
  if (!columns) return { ok: false, address: "#REF!" };
  return {
    ok: true,
    address: formatReference(__spreadProps(__spreadValues({}, ref), {
      start: __spreadProps(__spreadValues({}, ref.start), { column: columns.start }),
      end: __spreadProps(__spreadValues({}, ref.end), { column: columns.end })
    }))
  };
}
__name(rewriteReferenceForColumnMove, "rewriteReferenceForColumnMove");
function parseReference(address) {
  var _a;
  const qualified = splitSheetQualifiedAddress(address);
  const parts = qualified.address.split(":");
  if (parts.length > 2 || !parts[0]) {
    throw new Error(`ExcelReference: invalid reference ${address}`);
  }
  const start = parseCellRef(parts[0]);
  const end = parseCellRef((_a = parts[1]) != null ? _a : parts[0]);
  const reversed = start.row > end.row || start.column > end.column;
  return {
    sheetName: qualified.sheetName,
    start: {
      row: Math.min(start.row, end.row),
      column: Math.min(start.column, end.column),
      rowAbsolute: reversed ? false : start.rowAbsolute,
      columnAbsolute: reversed ? false : start.columnAbsolute
    },
    end: {
      row: Math.max(start.row, end.row),
      column: Math.max(start.column, end.column),
      rowAbsolute: reversed ? false : end.rowAbsolute,
      columnAbsolute: reversed ? false : end.columnAbsolute
    }
  };
}
__name(parseReference, "parseReference");
function parseCellRef(address) {
  const normalized = address.trim();
  const match = /^(\$?)([A-Za-z]+)(\$?)(\d+)$/.exec(normalized);
  if (!match) {
    throw new Error(`ExcelReference: invalid cell reference ${address}`);
  }
  const row = Number(match[4]);
  if (!Number.isInteger(row) || row < 1) {
    throw new Error(`ExcelReference: invalid cell reference ${address}`);
  }
  return {
    row,
    column: columnNameToIndex(match[2]),
    columnAbsolute: match[1] === "$",
    rowAbsolute: match[3] === "$"
  };
}
__name(parseCellRef, "parseCellRef");
function formatReference(ref) {
  const first = formatCellRef(ref.start);
  const last = formatCellRef(ref.end);
  const local = first === last ? first : `${first}:${last}`;
  return ref.sheetName ? `${quoteSheetName(ref.sheetName)}!${local}` : local;
}
__name(formatReference, "formatReference");
function formatCellRef(ref) {
  return `${ref.columnAbsolute ? "$" : ""}${columnIndexToName(ref.column)}${ref.rowAbsolute ? "$" : ""}${ref.row}`;
}
__name(formatCellRef, "formatCellRef");
function quoteSheetName(sheetName) {
  if (/^[A-Za-z_][A-Za-z0-9_.]*$/.test(sheetName)) return sheetName;
  return `'${sheetName.replace(/'/g, "''")}'`;
}
__name(quoteSheetName, "quoteSheetName");
function shiftCellRowsForInsert(cell, rowIndex, count) {
  return cell.row >= rowIndex ? __spreadProps(__spreadValues({}, cell), { row: cell.row + count }) : __spreadValues({}, cell);
}
__name(shiftCellRowsForInsert, "shiftCellRowsForInsert");
function shiftCellColumnsForInsert(cell, columnIndex, count) {
  return cell.column >= columnIndex ? __spreadProps(__spreadValues({}, cell), { column: cell.column + count }) : __spreadValues({}, cell);
}
__name(shiftCellColumnsForInsert, "shiftCellColumnsForInsert");
function shiftCellRelative(cell, rowOffset, columnOffset) {
  const row = cell.rowAbsolute ? cell.row : cell.row + rowOffset;
  const column = cell.columnAbsolute ? cell.column : cell.column + columnOffset;
  if (row < 1 || column < 1 || column > 16384) return null;
  return __spreadProps(__spreadValues({}, cell), { row, column });
}
__name(shiftCellRelative, "shiftCellRelative");
function rewriteAxisForDelete(start, end, deletion) {
  const deleteEnd = deletion.start + deletion.count - 1;
  const survivors = [];
  for (let value = start; value <= end; value++) {
    if (value >= deletion.start && value <= deleteEnd) continue;
    survivors.push(value > deleteEnd ? value - deletion.count : value);
  }
  if (survivors.length === 0) return null;
  return {
    start: Math.min(...survivors),
    end: Math.max(...survivors)
  };
}
__name(rewriteAxisForDelete, "rewriteAxisForDelete");
function moveAxisIndex(value, sourceIndex, count, beforeIndex) {
  const sourceEnd = sourceIndex + count - 1;
  if (beforeIndex >= sourceIndex && beforeIndex <= sourceEnd + 1) return value;
  if (beforeIndex < sourceIndex) {
    if (value >= sourceIndex && value <= sourceEnd) return beforeIndex + value - sourceIndex;
    if (value >= beforeIndex && value < sourceIndex) return value + count;
    return value;
  }
  if (value >= sourceIndex && value <= sourceEnd) {
    return beforeIndex - count + value - sourceIndex;
  }
  if (value > sourceEnd && value < beforeIndex) return value - count;
  return value;
}
__name(moveAxisIndex, "moveAxisIndex");
function rewriteAxisForMove(start, end, sourceIndex, count, beforeIndex) {
  const moved = /* @__PURE__ */ new Set();
  for (let value = start; value <= end; value += 1) {
    moved.add(moveAxisIndex(value, sourceIndex, count, beforeIndex));
  }
  const values = [...moved].sort((a2, b2) => a2 - b2);
  if (values.length === 0) return null;
  const first = values[0];
  const last = values[values.length - 1];
  if (last - first + 1 !== values.length) return null;
  return { start: first, end: last };
}
__name(rewriteAxisForMove, "rewriteAxisForMove");
function assertMoveArguments(sourceIndex, count, beforeIndex, axis) {
  assertPositiveInteger(sourceIndex, `${axis}Index`);
  assertPositiveInteger(count, "count");
  assertPositiveInteger(beforeIndex, `before${axis === "row" ? "Row" : "Column"}Index`);
}
__name(assertMoveArguments, "assertMoveArguments");
function isTargetSheet(ref, sheetName) {
  return sheetName === void 0 || ref.sheetName === void 0 || ref.sheetName === sheetName;
}
__name(isTargetSheet, "isTargetSheet");
function assertPositiveInteger(value, name) {
  if (!Number.isInteger(value) || value < 1) {
    throw new Error(`ExcelReference: ${name} must be a positive integer`);
  }
}
__name(assertPositiveInteger, "assertPositiveInteger");
function assertInteger(value, name) {
  if (!Number.isInteger(value)) {
    throw new Error(`ExcelReference: ${name} must be an integer`);
  }
}
__name(assertInteger, "assertInteger");
function readFormulaStringLiteral(formula, start) {
  let index = start + 1;
  while (index < formula.length) {
    if (formula[index] !== '"') {
      index += 1;
      continue;
    }
    if (formula[index + 1] === '"') {
      index += 2;
      continue;
    }
    return { text: formula.slice(start, index + 1), end: index + 1 };
  }
  return { text: formula.slice(start), end: formula.length };
}
__name(readFormulaStringLiteral, "readFormulaStringLiteral");
function matchReferenceAt(formula, start) {
  if (!isReferenceLeftBoundary(formula[start - 1])) return null;
  const sheet = readSheetPrefix(formula, start);
  const cellStart = sheet ? sheet.end : start;
  const firstCell = readCellToken(formula, cellStart);
  if (!firstCell) return null;
  let end = firstCell.end;
  if (formula[end] === ":") {
    const secondCell = readCellToken(formula, end + 1);
    if (secondCell) end = secondCell.end;
  }
  if (!isReferenceRightBoundary(formula[end])) return null;
  if (formula[end] === "(") return null;
  return { reference: formula.slice(start, end), end };
}
__name(matchReferenceAt, "matchReferenceAt");
function readSheetPrefix(formula, start) {
  if (formula[start] === "'") {
    let index = start + 1;
    while (index < formula.length) {
      if (formula[index] !== "'") {
        index += 1;
        continue;
      }
      if (formula[index + 1] === "'") {
        index += 2;
        continue;
      }
      return formula[index + 1] === "!" ? { end: index + 2 } : null;
    }
    return null;
  }
  const match = /^(?:\[[^\]]+\])?[A-Za-z_\u0080-\uFFFF][A-Za-z0-9_.\u0080-\uFFFF]*(?::[A-Za-z_\u0080-\uFFFF][A-Za-z0-9_.\u0080-\uFFFF]*)?!/.exec(formula.slice(start));
  return match ? { end: start + match[0].length } : null;
}
__name(readSheetPrefix, "readSheetPrefix");
function readCellToken(formula, start) {
  const match = /^\$?[A-Za-z]{1,3}\$?[1-9][0-9]*/.exec(formula.slice(start));
  if (!match) return null;
  const token = match[0];
  const normalized = token.replace(/\$/g, "");
  const cell = /^([A-Za-z]+)([1-9][0-9]*)$/.exec(normalized);
  if (!cell) return null;
  const column = columnNameToIndex(cell[1]);
  if (column > 16384) return null;
  return { end: start + token.length };
}
__name(readCellToken, "readCellToken");
function isReferenceLeftBoundary(ch) {
  return ch === void 0 || !/[A-Za-z0-9_.$]/.test(ch);
}
__name(isReferenceLeftBoundary, "isReferenceLeftBoundary");
function isReferenceRightBoundary(ch) {
  return ch === void 0 || !/[A-Za-z0-9_.$]/.test(ch);
}
__name(isReferenceRightBoundary, "isReferenceRightBoundary");
var _ExcelWorksheet = class _ExcelWorksheet2 {
  constructor(model, workbook, recordMutation) {
    __publicField(this, "hyperlinks");
    __publicField(this, "tables");
    __publicField(this, "dataValidations");
    __publicField(this, "conditionalFormats");
    __publicField(this, "comments");
    __publicField(this, "threadedComments");
    __publicField(this, "drawings");
    __publicField(this, "charts");
    __publicField(this, "images");
    __publicField(this, "shapes");
    __publicField(this, "model");
    __publicField(this, "workbook");
    __publicField(this, "recordMutation");
    this.model = model;
    this.workbook = workbook;
    this.recordMutation = recordMutation;
    this.hyperlinks = new ExcelHyperlinkCollection(() => model.hyperlinks);
    this.tables = new ExcelTableCollection(() => model.tables);
    this.dataValidations = new ExcelDataValidationCollection(() => model.dataValidations);
    this.conditionalFormats = new ExcelConditionalFormatCollection(() => model.conditionalFormats);
    this.comments = new ExcelCommentCollection(() => model.comments);
    this.threadedComments = new ExcelThreadedCommentCollection(() => model.threadedComments);
    this.drawings = new ExcelDrawingCollection(() => model.drawings);
    this.charts = new ExcelChartCollection(
      () => model.charts,
      () => model.drawings
    );
    this.images = new ExcelImageCollection(() => model.images);
    this.shapes = new ExcelShapeCollection(() => model.drawings);
  }
  id() {
    return this.model.id;
  }
  name() {
    return this.model.name;
  }
  rename(name) {
    var _a;
    assertValidWorksheetName(name);
    this.assertUniqueWorksheetName(name, this.model);
    const oldName = this.model.name;
    this.model.name = name;
    this.rewriteWorkbookSheetFormulas((text) => renameSheetInFormula(text, oldName, name));
    this.rewriteDefinedNames((text) => renameSheetInFormula(text, oldName, name));
    (_a = this.recordMutation) == null ? void 0 : _a.call(this, {
      kind: "worksheet.rename",
      sheetId: this.model.id,
      sheetName: name,
      oldName,
      newName: name
    });
  }
  insertRows(rowIndex, count = 1) {
    var _a;
    assertPositiveIndex(rowIndex, "rowIndex");
    assertPositiveCount(count, "count");
    for (const cell of this.model.cells) {
      if (cell.row >= rowIndex) {
        cell.row += count;
        cell.address = formatCellAddress(cell.row, cell.column);
      }
      if (cell.formula) {
        cell.formula = rewriteFormulaForRowInsert(cell.formula, rowIndex, count, {
          sheetName: this.model.name
        });
      }
    }
    this.rewriteDefinedNames(
      (text) => rewriteFormulaForRowInsert(text, rowIndex, count, { sheetName: this.model.name })
    );
    this.rewriteRuleFormulas(
      (text) => rewriteFormulaForRowInsert(text, rowIndex, count, { sheetName: this.model.name })
    );
    this.rewriteChartFormulaRefs(
      (text) => rewriteFormulaForRowInsert(text, rowIndex, count, { sheetName: this.model.name })
    );
    this.rewriteRangeReferences(
      (address) => rewriteReferenceForRowInsert(address, rowIndex, count, { sheetName: this.model.name })
    );
    this.moveRowMetadataForInsert(rowIndex, count);
    this.moveDrawingAnchorsForRowInsert(rowIndex, count);
    normalizeSheetCells2(this.model);
    (_a = this.recordMutation) == null ? void 0 : _a.call(this, {
      kind: "unsafe",
      scope: "worksheet",
      sheetId: this.model.id,
      sheetName: this.model.name,
      reason: "worksheet.insertRows is not replayable by first-phase mutation writeback"
    });
  }
  deleteRows(rowIndex, count = 1) {
    var _a;
    assertPositiveIndex(rowIndex, "rowIndex");
    assertPositiveCount(count, "count");
    const endRow = rowIndex + count - 1;
    this.model.cells = this.model.cells.filter((cell) => {
      if (cell.row >= rowIndex && cell.row <= endRow) return false;
      if (cell.row > endRow) {
        cell.row -= count;
        cell.address = formatCellAddress(cell.row, cell.column);
      }
      if (cell.formula) {
        cell.formula = rewriteFormulaForRowDelete(cell.formula, rowIndex, count, {
          sheetName: this.model.name
        });
      }
      return true;
    });
    this.rewriteDefinedNames(
      (text) => rewriteFormulaForRowDelete(text, rowIndex, count, { sheetName: this.model.name })
    );
    this.rewriteRuleFormulas(
      (text) => rewriteFormulaForRowDelete(text, rowIndex, count, { sheetName: this.model.name })
    );
    this.rewriteChartFormulaRefs(
      (text) => rewriteFormulaForRowDelete(text, rowIndex, count, { sheetName: this.model.name })
    );
    this.rewriteRangeReferences(
      (address) => rewriteReferenceForRowDelete(address, rowIndex, count, { sheetName: this.model.name })
    );
    this.moveRowMetadataForDelete(rowIndex, count);
    this.moveDrawingAnchorsForRowDelete(rowIndex, count);
    normalizeSheetCells2(this.model);
    (_a = this.recordMutation) == null ? void 0 : _a.call(this, {
      kind: "unsafe",
      scope: "worksheet",
      sheetId: this.model.id,
      sheetName: this.model.name,
      reason: "worksheet.deleteRows is not replayable by first-phase mutation writeback"
    });
  }
  insertColumns(columnIndex, count = 1) {
    var _a;
    assertPositiveIndex(columnIndex, "columnIndex");
    assertPositiveCount(count, "count");
    for (const cell of this.model.cells) {
      if (cell.column >= columnIndex) {
        cell.column += count;
        cell.address = formatCellAddress(cell.row, cell.column);
      }
      if (cell.formula) {
        cell.formula = rewriteFormulaForColumnInsert(cell.formula, columnIndex, count, {
          sheetName: this.model.name
        });
      }
    }
    this.rewriteDefinedNames(
      (text) => rewriteFormulaForColumnInsert(text, columnIndex, count, { sheetName: this.model.name })
    );
    this.rewriteRuleFormulas(
      (text) => rewriteFormulaForColumnInsert(text, columnIndex, count, { sheetName: this.model.name })
    );
    this.rewriteChartFormulaRefs(
      (text) => rewriteFormulaForColumnInsert(text, columnIndex, count, { sheetName: this.model.name })
    );
    this.rewriteRangeReferences(
      (address) => rewriteReferenceForColumnInsert(address, columnIndex, count, { sheetName: this.model.name })
    );
    this.moveColumnMetadataForInsert(columnIndex, count);
    this.moveDrawingAnchorsForColumnInsert(columnIndex, count);
    normalizeSheetCells2(this.model);
    (_a = this.recordMutation) == null ? void 0 : _a.call(this, {
      kind: "unsafe",
      scope: "worksheet",
      sheetId: this.model.id,
      sheetName: this.model.name,
      reason: "worksheet.insertColumns is not replayable by first-phase mutation writeback"
    });
  }
  deleteColumns(columnIndex, count = 1) {
    var _a;
    assertPositiveIndex(columnIndex, "columnIndex");
    assertPositiveCount(count, "count");
    const endColumn = columnIndex + count - 1;
    this.model.cells = this.model.cells.filter((cell) => {
      if (cell.column >= columnIndex && cell.column <= endColumn) return false;
      if (cell.column > endColumn) {
        cell.column -= count;
        cell.address = formatCellAddress(cell.row, cell.column);
      }
      if (cell.formula) {
        cell.formula = rewriteFormulaForColumnDelete(cell.formula, columnIndex, count, {
          sheetName: this.model.name
        });
      }
      return true;
    });
    this.rewriteDefinedNames(
      (text) => rewriteFormulaForColumnDelete(text, columnIndex, count, { sheetName: this.model.name })
    );
    this.rewriteRuleFormulas(
      (text) => rewriteFormulaForColumnDelete(text, columnIndex, count, { sheetName: this.model.name })
    );
    this.rewriteChartFormulaRefs(
      (text) => rewriteFormulaForColumnDelete(text, columnIndex, count, { sheetName: this.model.name })
    );
    this.rewriteRangeReferences(
      (address) => rewriteReferenceForColumnDelete(address, columnIndex, count, { sheetName: this.model.name })
    );
    this.moveColumnMetadataForDelete(columnIndex, count);
    this.moveDrawingAnchorsForColumnDelete(columnIndex, count);
    normalizeSheetCells2(this.model);
    (_a = this.recordMutation) == null ? void 0 : _a.call(this, {
      kind: "unsafe",
      scope: "worksheet",
      sheetId: this.model.id,
      sheetName: this.model.name,
      reason: "worksheet.deleteColumns is not replayable by first-phase mutation writeback"
    });
  }
  moveRows(rowIndex, count, beforeRowIndex) {
    var _a;
    assertMoveArguments2(rowIndex, count, beforeRowIndex, "row");
    if (isMoveNoop(rowIndex, count, beforeRowIndex)) return;
    for (const cell of this.model.cells) {
      cell.row = moveAxisIndex(cell.row, rowIndex, count, beforeRowIndex);
      cell.address = formatCellAddress(cell.row, cell.column);
      if (cell.formula) {
        cell.formula = rewriteFormulaForRowMove(cell.formula, rowIndex, count, beforeRowIndex, {
          sheetName: this.model.name
        });
      }
    }
    this.rewriteDefinedNames(
      (text) => rewriteFormulaForRowMove(text, rowIndex, count, beforeRowIndex, {
        sheetName: this.model.name
      })
    );
    this.rewriteRuleFormulas(
      (text) => rewriteFormulaForRowMove(text, rowIndex, count, beforeRowIndex, {
        sheetName: this.model.name
      })
    );
    this.rewriteChartFormulaRefs(
      (text) => rewriteFormulaForRowMove(text, rowIndex, count, beforeRowIndex, {
        sheetName: this.model.name
      })
    );
    this.rewriteRangeReferences(
      (address) => rewriteReferenceForRowMove(address, rowIndex, count, beforeRowIndex, {
        sheetName: this.model.name
      })
    );
    for (const row of this.model.rows) {
      row.index = moveAxisIndex(row.index, rowIndex, count, beforeRowIndex);
    }
    for (const marker2 of this.drawingMarkers()) {
      if (marker2.row !== void 0) {
        marker2.row = moveAxisIndex(marker2.row + 1, rowIndex, count, beforeRowIndex) - 1;
      }
    }
    normalizeSheetCells2(this.model);
    (_a = this.recordMutation) == null ? void 0 : _a.call(this, {
      kind: "unsafe",
      scope: "worksheet",
      sheetId: this.model.id,
      sheetName: this.model.name,
      reason: "worksheet.moveRows is not replayable by first-phase mutation writeback"
    });
  }
  moveColumns(columnIndex, count, beforeColumnIndex) {
    var _a;
    assertMoveArguments2(columnIndex, count, beforeColumnIndex, "column");
    if (isMoveNoop(columnIndex, count, beforeColumnIndex)) return;
    for (const cell of this.model.cells) {
      cell.column = moveAxisIndex(cell.column, columnIndex, count, beforeColumnIndex);
      cell.address = formatCellAddress(cell.row, cell.column);
      if (cell.formula) {
        cell.formula = rewriteFormulaForColumnMove(
          cell.formula,
          columnIndex,
          count,
          beforeColumnIndex,
          { sheetName: this.model.name }
        );
      }
    }
    this.rewriteDefinedNames(
      (text) => rewriteFormulaForColumnMove(text, columnIndex, count, beforeColumnIndex, {
        sheetName: this.model.name
      })
    );
    this.rewriteRuleFormulas(
      (text) => rewriteFormulaForColumnMove(text, columnIndex, count, beforeColumnIndex, {
        sheetName: this.model.name
      })
    );
    this.rewriteChartFormulaRefs(
      (text) => rewriteFormulaForColumnMove(text, columnIndex, count, beforeColumnIndex, {
        sheetName: this.model.name
      })
    );
    this.rewriteRangeReferences(
      (address) => rewriteReferenceForColumnMove(address, columnIndex, count, beforeColumnIndex, {
        sheetName: this.model.name
      })
    );
    this.model.columns = moveColumnMetadata(
      this.model.columns,
      columnIndex,
      count,
      beforeColumnIndex
    );
    for (const marker2 of this.drawingMarkers()) {
      if (marker2.column !== void 0) {
        marker2.column = moveAxisIndex(marker2.column + 1, columnIndex, count, beforeColumnIndex) - 1;
      }
    }
    normalizeSheetCells2(this.model);
    (_a = this.recordMutation) == null ? void 0 : _a.call(this, {
      kind: "unsafe",
      scope: "worksheet",
      sheetId: this.model.id,
      sheetName: this.model.name,
      reason: "worksheet.moveColumns is not replayable by first-phase mutation writeback"
    });
  }
  visibility() {
    return this.model.visibility;
  }
  setVisibility(visibility) {
    var _a;
    if (visibility !== void 0 && !["visible", "hidden", "veryHidden"].includes(visibility)) {
      throw new Error(`ExcelWorksheet.setVisibility: invalid visibility: ${visibility}`);
    }
    this.model.visibility = visibility;
    (_a = this.recordMutation) == null ? void 0 : _a.call(this, {
      kind: "unsafe",
      scope: "worksheet",
      sheetId: this.model.id,
      sheetName: this.model.name,
      reason: "worksheet.setVisibility is not replayable by first-phase mutation writeback"
    });
  }
  path() {
    return this.model.path;
  }
  dimension() {
    return this.model.dimension;
  }
  getRange(address) {
    var _a;
    return new ExcelRange(this.model, address, (_a = this.workbook) == null ? void 0 : _a.styles, this.recordMutation);
  }
  getCell(address) {
    var _a;
    return new ExcelCell(this.model, address, (_a = this.workbook) == null ? void 0 : _a.styles, this.recordMutation);
  }
  getUsedRange() {
    if (!this.model.dimension) return null;
    return this.getRange(this.model.dimension);
  }
  cells() {
    return this.model.cells.map(cloneExcelCell);
  }
  sheetViews() {
    return cloneSheetViews(this.model.sheetViews);
  }
  setSheetViews(sheetViews) {
    var _a;
    this.model.sheetViews = cloneSheetViews(sheetViews);
    (_a = this.recordMutation) == null ? void 0 : _a.call(this, {
      kind: "worksheet.setSheetViews",
      sheetId: this.model.id,
      sheetName: this.model.name,
      sheetViews: cloneSheetViews(sheetViews)
    });
  }
  columns() {
    return this.model.columns.map((column) => __spreadValues({}, column));
  }
  rows() {
    return this.model.rows.map((row) => __spreadValues({}, row));
  }
  mergedRanges() {
    return this.model.mergedRanges.map((range) => __spreadValues({}, range));
  }
  toModel() {
    return __spreadProps(__spreadValues({}, this.model), {
      sheetViews: this.sheetViews(),
      columns: this.model.columns.map((column) => __spreadValues({}, column)),
      rows: this.model.rows.map((row) => __spreadValues({}, row)),
      mergedRanges: this.model.mergedRanges.map((range) => __spreadValues({}, range)),
      hyperlinks: this.hyperlinks.toModel(),
      tables: this.tables.toModel(),
      dataValidations: this.dataValidations.toModel(),
      conditionalFormats: this.conditionalFormats.toModel(),
      comments: this.comments.toModel(),
      threadedComments: this.threadedComments.toModel(),
      drawings: this.drawings.toModel(),
      charts: this.charts.toModel(),
      images: this.images.toModel(),
      cells: this.model.cells.map(cloneExcelCell)
    });
  }
  rewriteDefinedNames(rewrite) {
    if (!this.workbook) return;
    const localSheetIndex = this.workbook.sheets.indexOf(this.model);
    for (const name of this.workbook.definedNames) {
      if (name.localSheetId !== void 0 && name.localSheetId !== localSheetIndex) continue;
      name.text = rewrite(name.text);
    }
  }
  rewriteRuleFormulas(rewrite) {
    for (const validation of this.model.dataValidations) {
      if (validation.formula1) validation.formula1 = rewrite(validation.formula1);
      if (validation.formula2) validation.formula2 = rewrite(validation.formula2);
    }
    for (const format of this.model.conditionalFormats) {
      for (const rule of format.rules) {
        rule.formulas = rule.formulas.map((formula) => rewrite(formula));
      }
    }
  }
  rewriteWorkbookSheetFormulas(rewrite) {
    var _a, _b;
    const sheets = (_b = (_a = this.workbook) == null ? void 0 : _a.sheets) != null ? _b : [this.model];
    for (const sheet of sheets) {
      for (const cell of sheet.cells) {
        if (cell.formula) cell.formula = rewrite(cell.formula);
      }
      for (const validation of sheet.dataValidations) {
        if (validation.formula1) validation.formula1 = rewrite(validation.formula1);
        if (validation.formula2) validation.formula2 = rewrite(validation.formula2);
      }
      for (const format of sheet.conditionalFormats) {
        for (const rule of format.rules) {
          rule.formulas = rule.formulas.map((formula) => rewrite(formula));
        }
      }
      for (const chart of sheet.charts) {
        chart.formulaRefs = chart.formulaRefs.map((reference) => rewrite(reference));
      }
    }
  }
  rewriteChartFormulaRefs(rewrite) {
    for (const chart of this.model.charts) {
      chart.formulaRefs = chart.formulaRefs.map((reference) => rewrite(reference));
    }
  }
  rewriteRangeReferences(rewrite) {
    var _a;
    this.model.mergedRanges = this.model.mergedRanges.flatMap((range) => {
      const result = rewrite(range.address);
      return result.ok ? [__spreadProps(__spreadValues({}, range), { address: result.address })] : [];
    });
    this.model.hyperlinks = this.model.hyperlinks.flatMap((hyperlink) => {
      const result = rewrite(hyperlink.ref);
      return result.ok ? [__spreadProps(__spreadValues({}, hyperlink), { ref: result.address })] : [];
    });
    this.model.comments = this.model.comments.flatMap((comment) => {
      const result = rewrite(comment.ref);
      return result.ok ? [__spreadProps(__spreadValues({}, comment), { ref: result.address })] : [];
    });
    this.model.threadedComments = this.model.threadedComments.flatMap((comment) => {
      const result = rewrite(comment.ref);
      return result.ok ? [__spreadProps(__spreadValues({}, comment), { ref: result.address })] : [];
    });
    for (const view of this.model.sheetViews) {
      if ((_a = view.pane) == null ? void 0 : _a.topLeftCell) {
        const result = rewrite(view.pane.topLeftCell);
        view.pane.topLeftCell = result.ok ? result.address : void 0;
      }
      for (const selection of view.selections) {
        if (selection.activeCell) {
          const result = rewrite(selection.activeCell);
          selection.activeCell = result.ok ? result.address : void 0;
        }
        if (selection.sqref) {
          selection.sqref = rewriteSqref(selection.sqref, rewrite);
        }
      }
    }
    this.model.tables = this.model.tables.flatMap((table) => {
      const ref = table.ref ? rewrite(table.ref) : void 0;
      if (table.ref && !(ref == null ? void 0 : ref.ok)) return [];
      const autoFilterRef = table.autoFilterRef ? rewrite(table.autoFilterRef) : void 0;
      return [
        __spreadProps(__spreadValues({}, table), {
          ref: ref == null ? void 0 : ref.address,
          autoFilterRef: (autoFilterRef == null ? void 0 : autoFilterRef.ok) ? autoFilterRef.address : void 0,
          autoFilter: table.autoFilter && (autoFilterRef == null ? void 0 : autoFilterRef.ok) ? __spreadProps(__spreadValues({}, table.autoFilter), { ref: autoFilterRef.address }) : table.autoFilter
        })
      ];
    });
    this.model.dataValidations = this.model.dataValidations.flatMap((validation) => {
      const sqref = validation.sqref ? rewriteSqref(validation.sqref, rewrite) : void 0;
      if (validation.sqref && !sqref) return [];
      return [__spreadProps(__spreadValues({}, validation), { sqref })];
    });
    this.model.conditionalFormats = this.model.conditionalFormats.flatMap((format) => {
      const sqref = format.sqref ? rewriteSqref(format.sqref, rewrite) : void 0;
      if (format.sqref && !sqref) return [];
      return [__spreadProps(__spreadValues({}, format), { sqref })];
    });
  }
  moveRowMetadataForInsert(rowIndex, count) {
    for (const row of this.model.rows) {
      if (row.index >= rowIndex) row.index += count;
    }
  }
  moveRowMetadataForDelete(rowIndex, count) {
    const endRow = rowIndex + count - 1;
    this.model.rows = this.model.rows.flatMap((row) => {
      if (row.index >= rowIndex && row.index <= endRow) return [];
      if (row.index > endRow) return [__spreadProps(__spreadValues({}, row), { index: row.index - count })];
      return [row];
    });
  }
  moveColumnMetadataForInsert(columnIndex, count) {
    this.model.columns = this.model.columns.map((column) => {
      if (column.min >= columnIndex) {
        return __spreadProps(__spreadValues({}, column), { min: column.min + count, max: column.max + count });
      }
      if (column.max >= columnIndex) {
        return __spreadProps(__spreadValues({}, column), { max: column.max + count });
      }
      return column;
    });
  }
  moveColumnMetadataForDelete(columnIndex, count) {
    const endColumn = columnIndex + count - 1;
    this.model.columns = this.model.columns.flatMap((column) => {
      if (column.min >= columnIndex && column.max <= endColumn) return [];
      if (column.min > endColumn) {
        return [__spreadProps(__spreadValues({}, column), { min: column.min - count, max: column.max - count })];
      }
      if (column.min < columnIndex && column.max > endColumn) {
        return [__spreadProps(__spreadValues({}, column), { max: column.max - count })];
      }
      if (column.min < columnIndex && column.max >= columnIndex) {
        return [__spreadProps(__spreadValues({}, column), { max: columnIndex - 1 })];
      }
      if (column.min <= endColumn && column.max > endColumn) {
        return [__spreadProps(__spreadValues({}, column), { min: columnIndex, max: column.max - count })];
      }
      return [column];
    });
  }
  moveDrawingAnchorsForRowInsert(rowIndex, count) {
    const markerIndex = rowIndex - 1;
    for (const marker2 of this.drawingMarkers()) {
      if (marker2.row !== void 0 && marker2.row >= markerIndex) marker2.row += count;
    }
  }
  moveDrawingAnchorsForRowDelete(rowIndex, count) {
    const markerIndex = rowIndex - 1;
    const endIndex = markerIndex + count - 1;
    for (const marker2 of this.drawingMarkers()) {
      if (marker2.row === void 0) continue;
      if (marker2.row > endIndex) marker2.row -= count;
      else if (marker2.row >= markerIndex) marker2.row = markerIndex;
    }
  }
  moveDrawingAnchorsForColumnInsert(columnIndex, count) {
    const markerIndex = columnIndex - 1;
    for (const marker2 of this.drawingMarkers()) {
      if (marker2.column !== void 0 && marker2.column >= markerIndex) marker2.column += count;
    }
  }
  moveDrawingAnchorsForColumnDelete(columnIndex, count) {
    const markerIndex = columnIndex - 1;
    const endIndex = markerIndex + count - 1;
    for (const marker2 of this.drawingMarkers()) {
      if (marker2.column === void 0) continue;
      if (marker2.column > endIndex) marker2.column -= count;
      else if (marker2.column >= markerIndex) marker2.column = markerIndex;
    }
  }
  drawingMarkers() {
    return this.model.drawings.flatMap(
      (drawing) => drawing.anchors.flatMap((anchor) => {
        const markers = [];
        if (anchor.from) markers.push(anchor.from);
        if (anchor.to) markers.push(anchor.to);
        return markers;
      })
    );
  }
  assertUniqueWorksheetName(name, current) {
    if (!this.workbook) return;
    if (this.workbook.sheets.some((sheet) => sheet !== current && sheet.name === name)) {
      throw new Error(`ExcelWorkbook: worksheet already exists: ${name}`);
    }
  }
};
__name(_ExcelWorksheet, "ExcelWorksheet");
var ExcelWorksheet = _ExcelWorksheet;
function assertValidWorksheetName(name) {
  if (name.length < 1) {
    throw new Error("ExcelWorksheet.rename: worksheet name must not be empty");
  }
  if (name.length > 31) {
    throw new Error("ExcelWorksheet.rename: worksheet name must be 31 characters or fewer");
  }
  if (/[:\\/?*[\]]/.test(name)) {
    throw new Error(`ExcelWorksheet.rename: invalid worksheet name: ${name}`);
  }
  if (name.startsWith("'") || name.endsWith("'")) {
    throw new Error(`ExcelWorksheet.rename: worksheet name must not start or end with apostrophe`);
  }
}
__name(assertValidWorksheetName, "assertValidWorksheetName");
function assertPositiveIndex(value, name) {
  if (!Number.isInteger(value) || value < 1) {
    throw new Error(`ExcelWorksheet: ${name} must be a positive integer`);
  }
}
__name(assertPositiveIndex, "assertPositiveIndex");
function assertPositiveCount(value, name) {
  if (!Number.isInteger(value) || value < 1) {
    throw new Error(`ExcelWorksheet: ${name} must be a positive integer`);
  }
}
__name(assertPositiveCount, "assertPositiveCount");
function assertMoveArguments2(sourceIndex, count, beforeIndex, axis) {
  assertPositiveIndex(sourceIndex, axis === "row" ? "rowIndex" : "columnIndex");
  assertPositiveCount(count, "count");
  assertPositiveIndex(beforeIndex, axis === "row" ? "beforeRowIndex" : "beforeColumnIndex");
}
__name(assertMoveArguments2, "assertMoveArguments");
function isMoveNoop(sourceIndex, count, beforeIndex) {
  return beforeIndex >= sourceIndex && beforeIndex <= sourceIndex + count;
}
__name(isMoveNoop, "isMoveNoop");
function moveColumnMetadata(columns, sourceIndex, count, beforeIndex) {
  const moved = columns.flatMap((column) => {
    const out = [];
    for (let index = column.min; index <= column.max; index += 1) {
      const next = moveAxisIndex(index, sourceIndex, count, beforeIndex);
      out.push(__spreadProps(__spreadValues({}, column), { min: next, max: next }));
    }
    return out;
  });
  moved.sort((a2, b2) => a2.min - b2.min);
  const merged = [];
  for (const column of moved) {
    const previous = merged[merged.length - 1];
    if (previous && previous.max + 1 === column.min && sameColumnMetadata(previous, column)) {
      previous.max = column.max;
    } else {
      merged.push(__spreadValues({}, column));
    }
  }
  return merged;
}
__name(moveColumnMetadata, "moveColumnMetadata");
function sameColumnMetadata(left, right) {
  const _a = left, { min: _leftMin, max: _leftMax } = _a, leftRest = __objRest(_a, ["min", "max"]);
  const _b = right, { min: _rightMin, max: _rightMax } = _b, rightRest = __objRest(_b, ["min", "max"]);
  return JSON.stringify(leftRest) === JSON.stringify(rightRest);
}
__name(sameColumnMetadata, "sameColumnMetadata");
function normalizeSheetCells2(sheet) {
  sheet.cells.sort((a2, b2) => a2.row - b2.row || a2.column - b2.column);
  sheet.dimension = computeDimension2(sheet);
}
__name(normalizeSheetCells2, "normalizeSheetCells");
function computeDimension2(sheet) {
  if (sheet.cells.length === 0) return void 0;
  let minRow = Number.POSITIVE_INFINITY;
  let minColumn = Number.POSITIVE_INFINITY;
  let maxRow = 0;
  let maxColumn = 0;
  for (const cell of sheet.cells) {
    minRow = Math.min(minRow, cell.row);
    minColumn = Math.min(minColumn, cell.column);
    maxRow = Math.max(maxRow, cell.row);
    maxColumn = Math.max(maxColumn, cell.column);
  }
  return formatRangeAddress(minRow, minColumn, maxRow - minRow + 1, maxColumn - minColumn + 1);
}
__name(computeDimension2, "computeDimension");
function rewriteSqref(sqref, rewrite) {
  const refs = [];
  for (const ref of sqref.split(/\s+/)) {
    if (!ref) continue;
    const result = rewrite(ref);
    if (result.ok) refs.push(result.address);
  }
  return refs.length ? refs.join(" ") : void 0;
}
__name(rewriteSqref, "rewriteSqref");
var _ExcelWorksheetCollection = class _ExcelWorksheetCollection2 {
  constructor(sheets, workbook, recordMutation) {
    __publicField(this, "worksheets");
    __publicField(this, "sheets");
    __publicField(this, "workbook");
    __publicField(this, "recordMutation");
    this.sheets = sheets;
    this.workbook = workbook;
    this.recordMutation = recordMutation;
    this.worksheets = sheets.map((sheet) => new ExcelWorksheet(sheet, workbook, recordMutation));
  }
  items() {
    return [...this.worksheets];
  }
  getItem(nameOrId) {
    const sheet = this.getItemOrNullObject(nameOrId);
    if (!sheet) {
      throw new Error(`ExcelWorkbook: worksheet not found: ${nameOrId}`);
    }
    return sheet;
  }
  getItemOrNullObject(nameOrId) {
    var _a;
    return (_a = this.worksheets.find((sheet) => sheet.name() === nameOrId || sheet.id() === nameOrId)) != null ? _a : null;
  }
  add(name) {
    var _a;
    assertValidWorksheetName(name);
    if (this.getItemOrNullObject(name)) {
      throw new Error(`ExcelWorkbook: worksheet already exists: ${name}`);
    }
    const sheet = createBlankSheetModel(name, nextSheetId(this.sheets));
    this.sheets.push(sheet);
    const worksheet = new ExcelWorksheet(sheet, this.workbook, this.recordMutation);
    this.worksheets.push(worksheet);
    (_a = this.recordMutation) == null ? void 0 : _a.call(this, {
      kind: "worksheet.add",
      sheetId: sheet.id,
      sheetName: sheet.name
    });
    return worksheet;
  }
  deleteItem(nameOrId) {
    var _a;
    const index = this.worksheets.findIndex(
      (sheet2) => sheet2.name() === nameOrId || sheet2.id() === nameOrId
    );
    if (index === -1) throw new Error(`ExcelWorkbook: worksheet not found: ${nameOrId}`);
    if (this.worksheets.length === 1)
      throw new Error("ExcelWorkbook: cannot delete the last worksheet");
    const sheet = this.sheets[index];
    this.worksheets.splice(index, 1);
    this.sheets.splice(index, 1);
    (_a = this.recordMutation) == null ? void 0 : _a.call(this, {
      kind: "worksheet.delete",
      sheetId: sheet.id,
      sheetName: sheet.name
    });
  }
  move(nameOrId, toIndex) {
    if (!Number.isInteger(toIndex) || toIndex < 0 || toIndex >= this.worksheets.length) {
      throw new Error(`ExcelWorksheetCollection.move: toIndex out of bounds: ${toIndex}`);
    }
    const fromIndex = this.worksheets.findIndex(
      (sheet2) => sheet2.name() === nameOrId || sheet2.id() === nameOrId
    );
    if (fromIndex === -1) throw new Error(`ExcelWorkbook: worksheet not found: ${nameOrId}`);
    if (fromIndex === toIndex) return;
    const [worksheet] = this.worksheets.splice(fromIndex, 1);
    const [sheet] = this.sheets.splice(fromIndex, 1);
    this.worksheets.splice(toIndex, 0, worksheet);
    this.sheets.splice(toIndex, 0, sheet);
  }
  copy(nameOrId, newName) {
    var _a;
    const sourceIndex = this.worksheets.findIndex(
      (sheet) => sheet.name() === nameOrId || sheet.id() === nameOrId
    );
    if (sourceIndex === -1) throw new Error(`ExcelWorkbook: worksheet not found: ${nameOrId}`);
    const source = this.sheets[sourceIndex];
    const name = newName != null ? newName : uniqueWorksheetName(source.name, this.sheets);
    assertValidWorksheetName(name);
    if (this.getItemOrNullObject(name)) {
      throw new Error(`ExcelWorkbook: worksheet already exists: ${name}`);
    }
    const clone2 = cloneSheetModel(source);
    clone2.id = nextSheetId(this.sheets);
    clone2.name = name;
    clone2.relationshipId = void 0;
    clone2.path = void 0;
    this.sheets.splice(sourceIndex + 1, 0, clone2);
    const worksheet = new ExcelWorksheet(clone2, this.workbook, this.recordMutation);
    this.worksheets.splice(sourceIndex + 1, 0, worksheet);
    (_a = this.recordMutation) == null ? void 0 : _a.call(this, {
      kind: "unsafe",
      scope: "worksheet",
      sheetId: clone2.id,
      sheetName: clone2.name,
      reason: "worksheet.copy is not replayable by first-phase mutation writeback"
    });
    return worksheet;
  }
};
__name(_ExcelWorksheetCollection, "ExcelWorksheetCollection");
var ExcelWorksheetCollection = _ExcelWorksheetCollection;
function createBlankSheetModel(name, id) {
  return {
    id,
    name,
    sheetViews: [{ workbookViewId: 0, selections: [{ activeCell: "A1", sqref: "A1" }] }],
    columns: [],
    rows: [],
    mergedRanges: [],
    hyperlinks: [],
    tables: [],
    dataValidations: [],
    conditionalFormats: [],
    comments: [],
    threadedComments: [],
    drawings: [],
    charts: [],
    images: [],
    cells: []
  };
}
__name(createBlankSheetModel, "createBlankSheetModel");
function cloneSheetViews(sheetViews) {
  return sheetViews.map((view) => __spreadProps(__spreadValues({}, view), {
    pane: view.pane ? __spreadValues({}, view.pane) : void 0,
    selections: view.selections.map((selection) => __spreadValues({}, selection))
  }));
}
__name(cloneSheetViews, "cloneSheetViews");
function nextSheetId(sheets) {
  let max = 0;
  for (const sheet of sheets) {
    const value = Number(sheet.id);
    if (Number.isFinite(value)) max = Math.max(max, value);
  }
  return String(max + 1 || sheets.length + 1);
}
__name(nextSheetId, "nextSheetId");
function uniqueWorksheetName(baseName, sheets) {
  const names = new Set(sheets.map((sheet) => sheet.name));
  for (let index = 2; index < 1e3; index++) {
    const name = `${baseName} (${index})`;
    if (name.length <= 31 && !names.has(name)) return name;
  }
  throw new Error(
    `ExcelWorksheetCollection.copy: unable to create unique worksheet name for ${baseName}`
  );
}
__name(uniqueWorksheetName, "uniqueWorksheetName");
function cloneSheetModel(sheet) {
  return JSON.parse(JSON.stringify(sheet));
}
__name(cloneSheetModel, "cloneSheetModel");
var _ExcelMutationLog = class _ExcelMutationLog2 {
  constructor() {
    __publicField(this, "items", []);
  }
  record(mutation) {
    this.items.push(cloneMutation(mutation));
  }
  list() {
    return this.items.map(cloneMutation);
  }
  clear() {
    this.items.length = 0;
  }
  hasUnsafe() {
    return this.items.some((item) => item.kind === "unsafe");
  }
};
__name(_ExcelMutationLog, "ExcelMutationLog");
var ExcelMutationLog = _ExcelMutationLog;
function cloneMutation(mutation) {
  return JSON.parse(JSON.stringify(mutation));
}
__name(cloneMutation, "cloneMutation");
function changedSheetNamesFromMutations(mutations) {
  const names = /* @__PURE__ */ new Set();
  for (const mutation of mutations) {
    if (mutation.kind === "worksheet.rename") {
      names.add(mutation.oldName);
      names.add(mutation.newName);
      continue;
    }
    if ("sheetName" in mutation && mutation.sheetName) {
      names.add(mutation.sheetName);
    }
  }
  return [...names];
}
__name(changedSheetNamesFromMutations, "changedSheetNamesFromMutations");
function captureExcelCellStyle(styles, styleId) {
  var _a, _b, _c, _d, _e2, _f, _g, _h, _i, _j;
  const format = (_a = styles.cellFormats[styleId != null ? styleId : 0]) != null ? _a : {};
  const code = (_c = format.numberFormatCode) != null ? _c : (_b = styles.numberFormats.find((item) => item.id === format.numberFormatId)) == null ? void 0 : _b.code;
  return clone(__spreadValues(__spreadValues({
    font: (_e2 = styles.fonts[(_d = format.fontId) != null ? _d : 0]) != null ? _e2 : {},
    fill: (_g = styles.fills[(_f = format.fillId) != null ? _f : 0]) != null ? _g : {},
    border: (_i = styles.borders[(_h = format.borderId) != null ? _h : 0]) != null ? _i : {}
  }, format.alignment ? { alignment: format.alignment } : {}), code !== void 0 ? { numberFormatCode: code } : { numberFormatId: (_j = format.numberFormatId) != null ? _j : 0 }));
}
__name(captureExcelCellStyle, "captureExcelCellStyle");
function importExcelCellStyles(styles, snapshots) {
  const known = new Map(styles.cellFormats.map((_2, id) => [key(captureExcelCellStyle(styles, id)), id]));
  const component = /* @__PURE__ */ __name((items, value) => {
    const fingerprint = key(value);
    const existing = items.findIndex((item) => key(item) === fingerprint);
    if (existing !== -1) return existing;
    items.push(clone(value));
    return items.length - 1;
  }, "component");
  return snapshots.map((snapshot) => {
    var _a, _b;
    const fingerprint = key(snapshot);
    const found = known.get(fingerprint);
    if (found !== void 0) return found;
    let numberFormatId = (_a = snapshot.numberFormatId) != null ? _a : 0;
    if (snapshot.numberFormatCode !== void 0) {
      const existing = styles.numberFormats.find((item) => item.code === snapshot.numberFormatCode);
      numberFormatId = (_b = existing == null ? void 0 : existing.id) != null ? _b : styles.numberFormats.reduce((max, item) => Math.max(max, item.id), 163) + 1;
      if (!existing) styles.numberFormats.push({ id: numberFormatId, code: snapshot.numberFormatCode });
    }
    const format = __spreadProps(__spreadValues(__spreadValues({
      fontId: component(styles.fonts, snapshot.font),
      fillId: component(styles.fills, snapshot.fill),
      borderId: component(styles.borders, snapshot.border),
      numberFormatId
    }, snapshot.numberFormatCode !== void 0 ? { numberFormatCode: snapshot.numberFormatCode } : {}), snapshot.alignment ? { alignment: clone(snapshot.alignment), applyAlignment: true } : {}), {
      applyFont: true,
      applyFill: true,
      applyBorder: true,
      applyNumberFormat: true
    });
    styles.cellFormats.push(format);
    const id = styles.cellFormats.length - 1;
    known.set(fingerprint, id);
    return id;
  });
}
__name(importExcelCellStyles, "importExcelCellStyles");
function equalExcelCellStyles(left, right) {
  return key(left) === key(right);
}
__name(equalExcelCellStyles, "equalExcelCellStyles");
function clone(value) {
  return JSON.parse(JSON.stringify(value));
}
__name(clone, "clone");
function key(value) {
  if (value === void 0) return "";
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(key).join(",")}]`;
  return `{${Object.keys(value).sort().filter((name) => value[name] !== void 0).map((name) => `${JSON.stringify(name)}:${key(value[name])}`).join(",")}}`;
}
__name(key, "key");
var DRAWING_CONTENT_TYPE2 = "application/vnd.openxmlformats-officedocument.drawing+xml";
var RELATIONSHIP_CONTENT_TYPE = "application/vnd.openxmlformats-package.relationships+xml";
var DRAWING_RELATIONSHIP_TYPE = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing";
var RELATIONSHIP_NS = "http://schemas.openxmlformats.org/package/2006/relationships";
var OFFICE_RELATIONSHIP_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
function addWorksheetLinesToPackage(pkg, sheetPath, lines) {
  var _a;
  if (lines.length === 0) return;
  const sheetPart = requireXmlPart2(pkg, sheetPath);
  const sheetDoc = sheetPart.xmlDom;
  if (elementChildren(sheetDoc.documentElement).some((child) => child.localName === "drawing")) {
    throw new Error("Adding lines to a worksheet that already has drawings is not supported yet.");
  }
  const drawingPath = nextDrawingPath(pkg);
  const drawing = sheetDoc.createElementNS(sheetDoc.documentElement.namespaceURI, "drawing");
  const relationshipPath = sheetPath.replace(/([^/]+)$/, "_rels/$1.rels");
  const relationshipPart = pkg.parts.get(relationshipPath);
  const relationshipDoc = (_a = relationshipPart == null ? void 0 : relationshipPart.xmlDom) != null ? _a : sheetDoc.implementation.createDocument(RELATIONSHIP_NS, "Relationships", null);
  const relationshipId = nextRelationshipId2(relationshipDoc, "rIdCocoDrawing");
  drawing.setAttributeNS(OFFICE_RELATIONSHIP_NS, "r:id", relationshipId);
  sheetDoc.documentElement.appendChild(drawing);
  sheetPart._dirty = true;
  const relationship = relationshipDoc.createElementNS(RELATIONSHIP_NS, "Relationship");
  relationship.setAttribute("Id", relationshipId);
  relationship.setAttribute("Type", DRAWING_RELATIONSHIP_TYPE);
  relationship.setAttribute("Target", `../drawings/${drawingPath.split("/").pop()}`);
  relationshipDoc.documentElement.appendChild(relationship);
  pkg.parts.set(relationshipPath, {
    path: relationshipPath,
    contentType: RELATIONSHIP_CONTENT_TYPE,
    xmlDom: relationshipDoc,
    _dirty: true
  });
  pkg.parts.set(drawingPath, {
    path: drawingPath,
    contentType: DRAWING_CONTENT_TYPE2,
    bytes: new TextEncoder().encode(serializeLines(lines)),
    _dirty: true
  });
  ensureContentTypeOverride2(pkg, drawingPath, DRAWING_CONTENT_TYPE2);
}
__name(addWorksheetLinesToPackage, "addWorksheetLinesToPackage");
function setWorksheetPrintSetupInPackage(pkg, sheetPath, sheetName, localSheetId, options) {
  var _a, _b, _c, _d, _e2;
  const sheetPart = requireXmlPart2(pkg, sheetPath);
  const sheetDoc = sheetPart.xmlDom;
  const root = sheetDoc.documentElement;
  const namespace = root.namespaceURI;
  for (const child of elementChildren(root)) {
    if (["printOptions", "pageMargins", "pageSetup"].includes(child.localName)) root.removeChild(child);
  }
  let sheetPr = elementChildren(root).find((child) => child.localName === "sheetPr");
  if (!sheetPr) {
    sheetPr = sheetDoc.createElementNS(namespace, "sheetPr");
    root.insertBefore(sheetPr, root.firstChild);
  }
  for (const child of elementChildren(sheetPr)) {
    if (child.localName === "pageSetUpPr") sheetPr.removeChild(child);
  }
  const pageSetUpPr = sheetDoc.createElementNS(namespace, "pageSetUpPr");
  pageSetUpPr.setAttribute("fitToPage", "1");
  sheetPr.appendChild(pageSetUpPr);
  const printOptions = sheetDoc.createElementNS(namespace, "printOptions");
  printOptions.setAttribute("horizontalCentered", options.horizontalCentered === false ? "0" : "1");
  const pageMargins = sheetDoc.createElementNS(namespace, "pageMargins");
  const margins = __spreadValues({ left: 0, right: 0, top: 0, bottom: 0, header: 0, footer: 0 }, options.margins);
  for (const [name, value] of Object.entries(margins)) pageMargins.setAttribute(name, String(value));
  const pageSetup = sheetDoc.createElementNS(namespace, "pageSetup");
  pageSetup.setAttribute("paperSize", String((_a = options.paperSize) != null ? _a : 9));
  pageSetup.setAttribute("orientation", (_b = options.orientation) != null ? _b : "portrait");
  pageSetup.setAttribute("fitToWidth", String((_c = options.fitToWidth) != null ? _c : 1));
  pageSetup.setAttribute("fitToHeight", String((_d = options.fitToHeight) != null ? _d : 1));
  const insertionPoint = (_e2 = elementChildren(root).find(
    (child) => ["drawing", "legacyDrawing", "legacyDrawingHF", "picture", "oleObjects", "controls", "webPublishItems", "tableParts", "extLst"].includes(child.localName)
  )) != null ? _e2 : null;
  root.insertBefore(printOptions, insertionPoint);
  root.insertBefore(pageMargins, insertionPoint);
  root.insertBefore(pageSetup, insertionPoint);
  sheetPart._dirty = true;
  if (options.printArea) setPrintArea(pkg, sheetName, localSheetId, options.printArea);
}
__name(setWorksheetPrintSetupInPackage, "setWorksheetPrintSetupInPackage");
function setPrintArea(pkg, sheetName, localSheetId, range) {
  var _a;
  const workbookPart = requireXmlPart2(pkg, "xl/workbook.xml");
  const workbookDoc = workbookPart.xmlDom;
  const workbookRoot = workbookDoc.documentElement;
  let definedNames = elementChildren(workbookRoot).find((child) => child.localName === "definedNames");
  if (!definedNames) {
    definedNames = workbookDoc.createElementNS(workbookRoot.namespaceURI, "definedNames");
    const insertionPoint = (_a = elementChildren(workbookRoot).find(
      (child) => ["calcPr", "oleSize", "customWorkbookViews", "pivotCaches", "smartTagPr", "smartTagTypes", "webPublishing", "fileRecoveryPr", "webPublishObjects", "extLst"].includes(child.localName)
    )) != null ? _a : null;
    workbookRoot.insertBefore(definedNames, insertionPoint);
  }
  for (const child of elementChildren(definedNames)) {
    if (child.localName === "definedName" && child.getAttribute("name") === "_xlnm.Print_Area" && child.getAttribute("localSheetId") === String(localSheetId)) {
      definedNames.removeChild(child);
    }
  }
  const printArea = workbookDoc.createElementNS(workbookRoot.namespaceURI, "definedName");
  printArea.setAttribute("name", "_xlnm.Print_Area");
  printArea.setAttribute("localSheetId", String(localSheetId));
  printArea.appendChild(workbookDoc.createTextNode(`'${sheetName.replace(/'/g, "''")}'!${range}`));
  definedNames.appendChild(printArea);
  workbookPart._dirty = true;
}
__name(setPrintArea, "setPrintArea");
function serializeLines(lines) {
  return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">' + lines.map((line, index) => serializeLine(line, index + 2)).join("") + "</xdr:wsDr>";
}
__name(serializeLines, "serializeLines");
function serializeLine(line, id) {
  var _a, _b, _c, _d, _e2, _f;
  const color = ((_a = line.color) != null ? _a : "#4F9185").replace(/^#/, "").toUpperCase();
  const dash = line.dash === "solid" ? "solid" : (_b = line.dash) != null ? _b : "dash";
  return '<xdr:twoCellAnchor editAs="oneCell">' + marker("from", line.from) + marker("to", line.to) + `<xdr:sp macro="" textlink=""><xdr:nvSpPr><xdr:cNvPr id="${id}" name="${xmlAttr3(line.name)}"/><xdr:cNvSpPr><a:spLocks noSelect="1" noMove="1" noResize="1"/></xdr:cNvSpPr><xdr:nvPr/></xdr:nvSpPr><xdr:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="${(_c = line.width) != null ? _c : 0}" cy="${(_d = line.height) != null ? _d : 0}"/></a:xfrm><a:prstGeom prst="line"><a:avLst/></a:prstGeom><a:noFill/><a:ln w="${(_e2 = line.lineWidth) != null ? _e2 : 9525}" cap="flat"><a:solidFill><a:srgbClr val="${color}"><a:alpha val="${(_f = line.alpha) != null ? _f : 72e3}"/></a:srgbClr></a:solidFill><a:prstDash val="${dash}"/></a:ln></xdr:spPr><xdr:style><a:lnRef idx="0"><a:schemeClr val="accent1"/></a:lnRef><a:fillRef idx="0"><a:schemeClr val="accent1"/></a:fillRef><a:effectRef idx="0"><a:schemeClr val="accent1"/></a:effectRef><a:fontRef idx="minor"><a:schemeClr val="tx1"/></a:fontRef></xdr:style><xdr:txBody><a:bodyPr/><a:lstStyle/><a:p/></xdr:txBody></xdr:sp><xdr:clientData fLocksWithSheet="1" fPrintsWithSheet="1"/></xdr:twoCellAnchor>`;
}
__name(serializeLine, "serializeLine");
function marker(kind, value) {
  return `<xdr:${kind}><xdr:col>${value.column}</xdr:col><xdr:colOff>${value.columnOffset}</xdr:colOff><xdr:row>${value.row}</xdr:row><xdr:rowOff>${value.rowOffset}</xdr:rowOff></xdr:${kind}>`;
}
__name(marker, "marker");
function requireXmlPart2(pkg, path) {
  const part = pkg.parts.get(path);
  if (!(part == null ? void 0 : part.xmlDom)) throw new Error(`Worksheet layout requires a package-backed workbook part: ${path}`);
  return part;
}
__name(requireXmlPart2, "requireXmlPart");
function elementChildren(node) {
  return Array.from(node.childNodes).filter((child) => child.nodeType === 1);
}
__name(elementChildren, "elementChildren");
function nextDrawingPath(pkg) {
  for (let index = 1; index < 1e3; index += 1) {
    const path = `xl/drawings/drawing${index}.xml`;
    if (!pkg.parts.has(path)) return path;
  }
  throw new Error("Unable to allocate an Excel drawing part.");
}
__name(nextDrawingPath, "nextDrawingPath");
function nextRelationshipId2(document, baseId) {
  const used = new Set(elementChildren(document.documentElement).map((node) => node.getAttribute("Id")).filter(Boolean));
  if (!used.has(baseId)) return baseId;
  for (let index = 2; index < 1e3; index += 1) {
    const candidate = `${baseId}${index}`;
    if (!used.has(candidate)) return candidate;
  }
  throw new Error("Unable to allocate an Excel drawing relationship.");
}
__name(nextRelationshipId2, "nextRelationshipId");
function ensureContentTypeOverride2(pkg, path, contentType) {
  const typesPart = requireXmlPart2(pkg, "[Content_Types].xml");
  const typesDoc = typesPart.xmlDom;
  const partName = `/${path}`;
  const exists = elementChildren(typesDoc.documentElement).some((child) => child.localName === "Override" && child.getAttribute("PartName") === partName);
  if (exists) return;
  const override = typesDoc.createElementNS(typesDoc.documentElement.namespaceURI, "Override");
  override.setAttribute("PartName", partName);
  override.setAttribute("ContentType", contentType);
  typesDoc.documentElement.appendChild(override);
  typesPart._dirty = true;
}
__name(ensureContentTypeOverride2, "ensureContentTypeOverride");
function xmlAttr3(value) {
  return value.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
__name(xmlAttr3, "xmlAttr");
var _ExcelWorkbookCore = class _ExcelWorkbookCore2 {
  constructor(init) {
    __publicField(this, "workbookId");
    __publicField(this, "worksheets");
    __publicField(this, "names");
    __publicField(this, "pkg");
    __publicField(this, "model");
    __publicField(this, "baselineModel");
    __publicField(this, "mutationLog", new ExcelMutationLog());
    this.workbookId = init.workbookId;
    this.pkg = init.pkg;
    this.model = init.model;
    this.baselineModel = structuredCloneModel(init.model);
    this.worksheets = new ExcelWorksheetCollection(
      init.model.sheets,
      init.model,
      (mutation) => this.mutationLog.record(mutation)
    );
    this.names = new ExcelNamedItemCollection(init.model.definedNames);
  }
  static async fromZip(bytes, opts = {}) {
    const pkg = await fromZip(bytes);
    return _ExcelWorkbookCore2.fromPackage(pkg, opts);
  }
  static fromPackage(pkg, opts = {}) {
    var _a;
    return new _ExcelWorkbookCore2({
      workbookId: (_a = opts.workbookId) != null ? _a : `excel:${Date.now()}`,
      pkg,
      model: readWorkbookModel(pkg)
    });
  }
  static fromModel(model, opts = {}) {
    var _a;
    return new _ExcelWorkbookCore2({
      workbookId: (_a = opts.workbookId) != null ? _a : `excel:${Date.now()}`,
      pkg: createPackage(),
      model: structuredCloneModel(model)
    });
  }
  toModel() {
    return structuredCloneModel(this.model);
  }
  styles() {
    return cloneStyles(this.model.styles);
  }
  importCellStyles(snapshots) {
    const count = this.model.styles.cellFormats.length;
    const ids = importExcelCellStyles(this.model.styles, snapshots);
    if (count !== this.model.styles.cellFormats.length) this.mutationLog.record({ kind: "unsafe", scope: "workbook", reason: "Imported portable cell styles" });
    return ids;
  }
  getMutations() {
    return this.mutationLog.list();
  }
  _replaceModelForHistory(model) {
    const next = structuredCloneModel(model);
    this.model.sharedStrings.splice(0, this.model.sharedStrings.length, ...next.sharedStrings);
    this.model.definedNames.splice(0, this.model.definedNames.length, ...next.definedNames);
    this.model.styles = next.styles;
    this.model.sheets.splice(0, this.model.sheets.length, ...next.sheets);
    Object.defineProperty(this, "worksheets", {
      value: new ExcelWorksheetCollection(
        this.model.sheets,
        this.model,
        (mutation) => this.mutationLog.record(mutation)
      ),
      writable: true,
      configurable: true
    });
    Object.defineProperty(this, "names", {
      value: new ExcelNamedItemCollection(this.model.definedNames),
      writable: true,
      configurable: true
    });
  }
  clearMutations() {
    this.mutationLog.clear();
  }
  getPackage() {
    return this.pkg;
  }
  addWorksheetLines(sheetNameOrId, lines) {
    const sheet = this.worksheets.getItem(sheetNameOrId);
    this.materializePackage();
    const sheetPath = this.resolveWorksheetPackagePath(sheet.id());
    addWorksheetLinesToPackage(this.pkg, sheetPath, lines);
    this.mutationLog.record({
      kind: "worksheet.addLines",
      sheetId: sheet.id(),
      sheetName: sheet.name(),
      lines: [...lines]
    });
  }
  setWorksheetPrintSetup(sheetNameOrId, options) {
    const sheet = this.worksheets.getItem(sheetNameOrId);
    this.materializePackage();
    const sheetPath = this.resolveWorksheetPackagePath(sheet.id());
    const localSheetId = this.worksheets.items().findIndex((candidate) => candidate.id() === sheet.id());
    setWorksheetPrintSetupInPackage(this.pkg, sheetPath, sheet.name(), localSheetId, options);
    this.mutationLog.record({
      kind: "worksheet.setPrintSetup",
      sheetId: sheet.id(),
      sheetName: sheet.name(),
      options
    });
  }
  async toZip() {
    if (this.pkg.parts.size === 0) {
      this.materializePackage();
      return toZip(this.pkg);
    }
    let cellPatches = collectContentOnlyCellPatches(this.baselineModel, this.model);
    const drawingPatches = cellPatches ? null : collectDrawingPositionPatches(this.pkg, this.baselineModel, this.model);
    if (drawingPatches == null ? void 0 : drawingPatches.length) {
      cellPatches = collectContentOnlyCellPatches(this.baselineModel, this.model, true);
    }
    if (cellPatches) {
      patchWorkbookCellsInPackage(this.pkg, cellPatches);
      if (drawingPatches) patchDrawingPositions(drawingPatches);
    } else {
      syncWorkbookModelToPackage(this.pkg, this.model);
    }
    const bytes = await toZip(this.pkg);
    this.baselineModel = structuredCloneModel(this.model);
    return bytes;
  }
  materializePackage() {
    if (this.pkg.parts.size > 0) return;
    const materialized = createWorkbookPackageFromModel(this.model);
    for (const [path, part] of materialized.parts) this.pkg.parts.set(path, part);
  }
  resolveWorksheetPackagePath(sheetId) {
    var _a, _b;
    const index = this.model.sheets.findIndex((sheet) => sheet.id === sheetId);
    if (index < 0) throw new Error(`Worksheet not found: ${sheetId}`);
    const path = (_b = (_a = this.model.sheets[index]) == null ? void 0 : _a.path) != null ? _b : `xl/worksheets/sheet${index + 1}.xml`;
    if (!this.pkg.parts.has(path)) throw new Error(`Worksheet has no package part: ${sheetId}`);
    return path;
  }
};
__name(_ExcelWorkbookCore, "ExcelWorkbookCore");
var ExcelWorkbookCore = _ExcelWorkbookCore;
function structuredCloneModel(model) {
  return {
    date1904: model.date1904,
    sharedStrings: [...model.sharedStrings],
    definedNames: model.definedNames.map((name) => __spreadValues({}, name)),
    styles: cloneStyles(model.styles),
    sheets: model.sheets.map((sheet) => __spreadProps(__spreadValues({}, sheet), {
      sheetViews: sheet.sheetViews.map((view) => {
        const result = __spreadProps(__spreadValues({}, view), {
          selections: view.selections.map((selection) => __spreadValues({}, selection))
        });
        if (view.pane) {
          result.pane = __spreadValues({}, view.pane);
        }
        return result;
      }),
      columns: sheet.columns.map((column) => __spreadValues({}, column)),
      rows: sheet.rows.map((row) => __spreadValues({}, row)),
      mergedRanges: sheet.mergedRanges.map((range) => __spreadValues({}, range)),
      hyperlinks: sheet.hyperlinks.map((hyperlink) => __spreadValues({}, hyperlink)),
      tables: sheet.tables.map((table) => __spreadProps(__spreadValues({}, table), {
        columns: table.columns.map((column) => __spreadValues({}, column)),
        autoFilter: table.autoFilter ? __spreadProps(__spreadValues({}, table.autoFilter), {
          filterColumns: table.autoFilter.filterColumns.map((column) => __spreadProps(__spreadValues({}, column), {
            filters: column.filters ? [...column.filters] : void 0
          })),
          sortState: table.autoFilter.sortState ? __spreadProps(__spreadValues({}, table.autoFilter.sortState), {
            conditions: table.autoFilter.sortState.conditions.map((condition) => __spreadValues({}, condition))
          }) : void 0
        }) : void 0,
        style: table.style ? __spreadValues({}, table.style) : void 0
      })),
      dataValidations: sheet.dataValidations.map((validation) => __spreadValues({}, validation)),
      conditionalFormats: sheet.conditionalFormats.map((format) => __spreadProps(__spreadValues({}, format), {
        rules: format.rules.map((rule) => __spreadProps(__spreadValues({}, rule), {
          formulas: [...rule.formulas]
        }))
      })),
      comments: sheet.comments.map((comment) => __spreadValues({}, comment)),
      threadedComments: sheet.threadedComments.map((comment) => __spreadValues({}, comment)),
      drawings: sheet.drawings.map((drawing) => __spreadProps(__spreadValues({}, drawing), {
        anchors: drawing.anchors.map(cloneDrawingAnchor)
      })),
      charts: sheet.charts.map((chart) => __spreadProps(__spreadValues({}, chart), {
        formulaRefs: [...chart.formulaRefs]
      })),
      images: sheet.images.map((image) => __spreadValues({}, image)),
      cells: sheet.cells.map(cloneExcelCell)
    }))
  };
}
__name(structuredCloneModel, "structuredCloneModel");
function cloneStyles(styles) {
  return {
    numberFormats: styles.numberFormats.map((format) => __spreadValues({}, format)),
    fonts: styles.fonts.map((font) => __spreadProps(__spreadValues({}, font), {
      color: font.color ? __spreadValues({}, font.color) : void 0
    })),
    fills: styles.fills.map((fill) => __spreadProps(__spreadValues({}, fill), {
      foregroundColor: fill.foregroundColor ? __spreadValues({}, fill.foregroundColor) : void 0,
      backgroundColor: fill.backgroundColor ? __spreadValues({}, fill.backgroundColor) : void 0
    })),
    borders: styles.borders.map((border) => ({
      left: border.left ? __spreadProps(__spreadValues({}, border.left), { color: border.left.color ? __spreadValues({}, border.left.color) : void 0 }) : void 0,
      right: border.right ? __spreadProps(__spreadValues({}, border.right), { color: border.right.color ? __spreadValues({}, border.right.color) : void 0 }) : void 0,
      top: border.top ? __spreadProps(__spreadValues({}, border.top), { color: border.top.color ? __spreadValues({}, border.top.color) : void 0 }) : void 0,
      bottom: border.bottom ? __spreadProps(__spreadValues({}, border.bottom), { color: border.bottom.color ? __spreadValues({}, border.bottom.color) : void 0 }) : void 0,
      diagonal: border.diagonal ? __spreadProps(__spreadValues({}, border.diagonal), { color: border.diagonal.color ? __spreadValues({}, border.diagonal.color) : void 0 }) : void 0
    })),
    cellFormats: styles.cellFormats.map((format) => __spreadProps(__spreadValues({}, format), {
      alignment: format.alignment ? __spreadValues({}, format.alignment) : void 0
    }))
  };
}
__name(cloneStyles, "cloneStyles");
function aggregateExcelTable(workbook, options) {
  var _a;
  if (options.groupBy.length === 0) {
    throw new Error("aggregateExcelTable: groupBy must contain at least one column");
  }
  if (options.metrics.length === 0) {
    throw new Error("aggregateExcelTable: metrics must contain at least one metric");
  }
  const source = readSourceTable(workbook, options.source);
  const groups = /* @__PURE__ */ new Map();
  const groupColumns = options.groupBy.map((group) => resolveColumn(source, group.column));
  const metricColumns = options.metrics.map(
    (metric) => metric.column ? resolveColumn(source, metric.column) : null
  );
  for (const row of source.rows) {
    const groupValues = groupColumns.map(
      (columnIndex, index) => {
        var _a2, _b, _c;
        return bucketValue((_a2 = row.values[columnIndex]) != null ? _a2 : null, (_c = (_b = options.groupBy[index]) == null ? void 0 : _b.bucket) != null ? _c : "none");
      }
    );
    const keyText = groupValues.map((item) => stableKey(item.value)).join("");
    let group = groups.get(keyText);
    if (!group) {
      group = {
        key: groupValues.map((item) => item.value),
        sortKeys: groupValues.map((item) => item.sortKey),
        rowCount: 0,
        metrics: options.metrics.map((metric) => ({
          op: metric.op,
          sum: 0,
          count: 0,
          min: null,
          max: null
        }))
      };
      groups.set(keyText, group);
    }
    group.rowCount += 1;
    options.metrics.forEach((metric, index) => {
      var _a2;
      const acc = group.metrics[index];
      const value = metric.op === "count" && !metric.column ? 1 : metricColumns[index] === null ? null : (_a2 = row.values[metricColumns[index]]) != null ? _a2 : null;
      accumulate(acc, value);
    });
  }
  const sortedGroups = Array.from(groups.values());
  if (((_a = options.sort) != null ? _a : "asc") !== "none") {
    const direction = options.sort === "desc" ? -1 : 1;
    sortedGroups.sort((a2, b2) => direction * compareSortKeys(a2.sortKeys, b2.sortKeys));
  }
  const rows = sortedGroups.map((group) => ({
    key: group.key,
    values: group.metrics.map(finalizeMetric),
    rowCount: group.rowCount
  }));
  const headers = [
    ...options.groupBy.map((group) => {
      var _a2;
      return (_a2 = group.name) != null ? _a2 : group.column;
    }),
    ...options.metrics.map((metric) => {
      var _a2;
      return (_a2 = metric.name) != null ? _a2 : defaultMetricName(metric);
    })
  ];
  return {
    ok: true,
    sheetName: source.sheetName,
    sourceAddress: source.address,
    headers,
    rows,
    values: [headers, ...rows.map((row) => [...row.key, ...row.values])],
    inputRowCount: source.rows.length,
    outputRowCount: rows.length
  };
}
__name(aggregateExcelTable, "aggregateExcelTable");
function readSourceTable(workbook, source) {
  var _a, _b, _c;
  const sheet = workbook.sheets.find(
    (item) => item.name === source.sheetName || item.id === source.sheetName
  );
  if (!sheet) throw new Error(`aggregateExcelTable: worksheet not found: ${source.sheetName}`);
  const table = source.tableName ? sheet.tables.find(
    (item) => item.name === source.tableName || item.displayName === source.tableName
  ) : void 0;
  const address = (_b = (_a = source.address) != null ? _a : table == null ? void 0 : table.ref) != null ? _b : sheet.dimension;
  if (!address) throw new Error(`aggregateExcelTable: source range is empty: ${source.sheetName}`);
  const parsed = parseRangeAddress(address);
  const byAddress = new Map(sheet.cells.map((cell) => [cell.address, cell]));
  const matrix = [];
  for (let r2 = 0; r2 < parsed.rowCount; r2 += 1) {
    const row = [];
    for (let c2 = 0; c2 < parsed.columnCount; c2 += 1) {
      row.push(byAddress.get(formatCellAddress(parsed.startRow + r2, parsed.startColumn + c2)));
    }
    matrix.push(row);
  }
  const hasHeader = source.header !== "none";
  const headerCells = hasHeader ? (_c = matrix[0]) != null ? _c : [] : [];
  const headers = Array.from({ length: parsed.columnCount }, (_2, index) => {
    var _a2;
    const value = (_a2 = headerCells[index]) == null ? void 0 : _a2.value;
    if (hasHeader && value !== null && value !== void 0 && String(value).trim().length > 0) {
      return String(value);
    }
    return columnIndexToName(parsed.startColumn + index);
  });
  const dataRows = hasHeader ? matrix.slice(1) : matrix;
  return {
    sheetName: sheet.name,
    address: parsed.address,
    headers,
    rows: dataRows.map((cells) => ({
      cells,
      values: cells.map((cell) => {
        var _a2;
        return (_a2 = cell == null ? void 0 : cell.value) != null ? _a2 : null;
      })
    })),
    startColumn: parsed.startColumn
  };
}
__name(readSourceTable, "readSourceTable");
function resolveColumn(source, column) {
  const normalized = column.trim();
  const headerIndex = source.headers.findIndex((header) => header === normalized);
  if (headerIndex >= 0) return headerIndex;
  if (/^[A-Za-z]+$/.test(normalized)) {
    const absoluteIndex = columnNameToIndex(normalized.toUpperCase());
    const offset = absoluteIndex - source.startColumn;
    if (offset >= 0 && offset < source.headers.length) return offset;
  }
  throw new Error(`aggregateExcelTable: column not found: ${column}`);
}
__name(resolveColumn, "resolveColumn");
function bucketValue(value, bucket) {
  if (bucket === "none") return { value, sortKey: stableKey(value) };
  const date = coerceExcelDate(value);
  if (!date) {
    return { value: value === null ? null : String(value), sortKey: stableKey(value) };
  }
  const year = date.getUTCFullYear();
  const month = date.getUTCMonth() + 1;
  const day = date.getUTCDate();
  if (bucket === "year") return { value: String(year), sortKey: `${year}` };
  if (bucket === "quarter") {
    const quarter = Math.floor((month - 1) / 3) + 1;
    return { value: `${year}Q${quarter}`, sortKey: `${year}-${quarter}` };
  }
  if (bucket === "month") {
    return {
      value: `${year}-${String(month).padStart(2, "0")}`,
      sortKey: `${year}-${String(month).padStart(2, "0")}`
    };
  }
  return {
    value: `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`,
    sortKey: `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`
  };
}
__name(bucketValue, "bucketValue");
function coerceExcelDate(value) {
  if (typeof value === "number" && Number.isFinite(value)) {
    const epoch = Date.UTC(1899, 11, 30);
    return new Date(epoch + Math.round(value * 864e5));
  }
  if (typeof value !== "string") return null;
  const trimmed = value.trim();
  const match = /^(\d{4})[-/年](\d{1,2})(?:[-/月](\d{1,2}))?/.exec(trimmed);
  if (!match) return null;
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = match[3] ? Number(match[3]) : 1;
  if (month < 1 || month > 12 || day < 1 || day > 31) return null;
  return new Date(Date.UTC(year, month - 1, day));
}
__name(coerceExcelDate, "coerceExcelDate");
function accumulate(acc, value) {
  if (acc.op === "count") {
    if (value !== null && value !== "") acc.count += 1;
    return;
  }
  const numeric = coerceNumber(value);
  if (numeric === null) return;
  acc.sum += numeric;
  acc.count += 1;
  acc.min = acc.min === null ? numeric : Math.min(acc.min, numeric);
  acc.max = acc.max === null ? numeric : Math.max(acc.max, numeric);
}
__name(accumulate, "accumulate");
function finalizeMetric(acc) {
  if (acc.op === "count") return acc.count;
  if (acc.count === 0) return null;
  if (acc.op === "sum") return acc.sum;
  if (acc.op === "average") return acc.sum / acc.count;
  if (acc.op === "min") return acc.min;
  return acc.max;
}
__name(finalizeMetric, "finalizeMetric");
function coerceNumber(value) {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value !== "string") return null;
  const normalized = value.replace(/,/g, "").trim();
  if (normalized.length === 0) return null;
  const number = Number(normalized);
  return Number.isFinite(number) ? number : null;
}
__name(coerceNumber, "coerceNumber");
function defaultMetricName(metric) {
  return metric.column ? `${metric.op}_${metric.column}` : metric.op;
}
__name(defaultMetricName, "defaultMetricName");
function stableKey(value) {
  if (value === null) return "";
  return `${typeof value}:${String(value)}`;
}
__name(stableKey, "stableKey");
function compareSortKeys(left, right) {
  var _a, _b;
  const count = Math.max(left.length, right.length);
  for (let index = 0; index < count; index += 1) {
    const result = ((_a = left[index]) != null ? _a : "").localeCompare((_b = right[index]) != null ? _b : "", void 0, {
      numeric: true
    });
    if (result !== 0) return result;
  }
  return 0;
}
__name(compareSortKeys, "compareSortKeys");
async function executeExcelScript(workbook, code, args, timeoutMs, signal) {
  if (signal == null ? void 0 : signal.aborted) {
    throw new Error("excel script aborted before dispatch");
  }
  const runner = new Function(
    "workbook",
    "args",
    `"use strict"; return (async () => {
${code}
})()`
  );
  const execution = runner(workbook, args);
  const races = [execution];
  let timeoutHandle;
  let abortHandler;
  if (timeoutMs > 0) {
    races.push(
      new Promise((_2, reject) => {
        timeoutHandle = setTimeout(
          () => reject(new Error(`excel script timeout after ${timeoutMs}ms`)),
          timeoutMs
        );
      })
    );
  }
  if (signal) {
    races.push(
      new Promise((_2, reject) => {
        abortHandler = /* @__PURE__ */ __name(() => reject(new Error("excel script aborted")), "abortHandler");
        signal.addEventListener("abort", abortHandler, { once: true });
      })
    );
  }
  try {
    return await Promise.race(races);
  } finally {
    if (timeoutHandle) clearTimeout(timeoutHandle);
    if (signal && abortHandler) signal.removeEventListener("abort", abortHandler);
  }
}
__name(executeExcelScript, "executeExcelScript");
var _ExcelWorkbookHistory = class _ExcelWorkbookHistory2 {
  constructor(workbook, options = {}) {
    __publicField(this, "workbook", workbook);
    __publicField(this, "options", options);
    __publicField(this, "undoStack", []);
    __publicField(this, "redoStack", []);
  }
  canUndo() {
    return this.undoStack.length > 0;
  }
  canRedo() {
    return this.redoStack.length > 0;
  }
  undoGroups() {
    return this.undoStack.map(cloneTransactionGroup);
  }
  redoGroups() {
    return this.redoStack.map(cloneTransactionGroup);
  }
  async runGroup(options, run) {
    const builder = new ExcelTransactionGroupBuilder(this.workbook, options);
    await run(builder);
    const group = await builder.commit();
    if (!group) return null;
    const committedGroup = this.pushUndo(group, { allowMerge: true });
    this.redoStack.length = 0;
    return {
      group: cloneTransactionGroup(committedGroup),
      affectedSheets: [...committedGroup.affectedSheets],
      affectedRanges: [...committedGroup.affectedRanges],
      summary: summarizeExcelTransactionGroup(committedGroup)
    };
  }
  async runAgentGroup(options, run) {
    var _a, _b, _c, _d, _e2, _f, _g, _h, _i, _j, _k, _l;
    return this.runGroup(
      {
        id: options.id,
        source: "agent",
        label: options.label,
        mergeKey: options.mergeKey,
        mergeWindowMs: options.mergeWindowMs,
        metadata: normalizeTransactionMetadata(__spreadProps(__spreadValues({}, options.metadata), {
          actor: (_b = options.actor) != null ? _b : (_a = options.metadata) == null ? void 0 : _a.actor,
          description: (_d = options.description) != null ? _d : (_c = options.metadata) == null ? void 0 : _c.description,
          agentRunId: (_f = options.agentRunId) != null ? _f : (_e2 = options.metadata) == null ? void 0 : _e2.agentRunId,
          agentStepId: (_h = options.agentStepId) != null ? _h : (_g = options.metadata) == null ? void 0 : _g.agentStepId,
          agentActionId: (_j = options.agentActionId) != null ? _j : (_i = options.metadata) == null ? void 0 : _i.agentActionId,
          mergeKey: (_l = options.mergeKey) != null ? _l : (_k = options.metadata) == null ? void 0 : _k.mergeKey
        }))
      },
      run
    );
  }
  async undo() {
    const group = this.undoStack.pop();
    if (!group) return null;
    for (const transaction of [...group.transactions].reverse()) {
      for (const patch of [...transaction.inverse].reverse()) await applyExcelPatch(this.workbook, patch);
    }
    this.redoStack.push(group);
    return {
      group: cloneTransactionGroup(group),
      affectedSheets: [...group.affectedSheets],
      affectedRanges: [...group.affectedRanges],
      summary: summarizeExcelTransactionGroup(group)
    };
  }
  async redo() {
    const group = this.redoStack.pop();
    if (!group) return null;
    for (const transaction of group.transactions) {
      for (const patch of transaction.forward) await applyExcelPatch(this.workbook, patch);
    }
    this.pushUndo(group, { allowMerge: false });
    return {
      group: cloneTransactionGroup(group),
      affectedSheets: [...group.affectedSheets],
      affectedRanges: [...group.affectedRanges],
      summary: summarizeExcelTransactionGroup(group)
    };
  }
  clear() {
    this.undoStack.length = 0;
    this.redoStack.length = 0;
  }
  pushUndo(group, options = { allowMerge: false }) {
    var _a;
    if (options.allowMerge) {
      const previous = this.undoStack[this.undoStack.length - 1];
      if (previous && canMergeTransactionGroups(previous, group)) {
        const merged = mergeTransactionGroups(previous, group);
        this.undoStack[this.undoStack.length - 1] = merged;
        return merged;
      }
    }
    this.undoStack.push(group);
    const limit = (_a = this.options.limit) != null ? _a : 100;
    while (this.undoStack.length > limit) this.undoStack.shift();
    return group;
  }
};
__name(_ExcelWorkbookHistory, "ExcelWorkbookHistory");
var ExcelWorkbookHistory = _ExcelWorkbookHistory;
var _ExcelTransactionGroupBuilder = class _ExcelTransactionGroupBuilder2 {
  constructor(workbook, options) {
    __publicField(this, "workbook", workbook);
    __publicField(this, "options", options);
    __publicField(this, "createdAt", Date.now());
    __publicField(this, "transactions", []);
  }
  async setCellValue(sheetName, address, value) {
    await this.setRangeValues(sheetName, address, [[value]]);
  }
  async setCellRichText(sheetName, address, runs) {
    await this.recordRangeCells(sheetName, address, "Set cell rich text", async () => {
      await this.workbook.worksheets.getItem(sheetName).getRange(address).setRichText(runs);
    });
  }
  async setCellFormula(sheetName, address, formula) {
    await this.recordRangeCells(sheetName, address, "Set cell formula", async () => {
      await this.workbook.worksheets.getItem(sheetName).getRange(address).setFormulas([[formula]]);
    });
  }
  async setRangeValues(sheetName, address, values) {
    await this.recordRangeCells(sheetName, address, "Set range values", async () => {
      await this.workbook.worksheets.getItem(sheetName).getRange(address).setValues(values);
    });
  }
  async clearRange(sheetName, address) {
    await this.recordRangeCells(sheetName, address, "Clear range", async () => {
      await this.workbook.worksheets.getItem(sheetName).getRange(address).clear();
    });
  }
  async setRangeBold(sheetName, address, value) {
    await this.recordRangeFormat(sheetName, address, "Set range bold", async () => {
      await this.workbook.worksheets.getItem(sheetName).getRange(address).format.font.setBold(value);
    });
  }
  async setRangeItalic(sheetName, address, value) {
    await this.recordRangeFormat(sheetName, address, "Set range italic", async () => {
      await this.workbook.worksheets.getItem(sheetName).getRange(address).format.font.setItalic(value);
    });
  }
  async setRangeUnderline(sheetName, address, value) {
    await this.recordRangeFormat(sheetName, address, "Set range underline", async () => {
      await this.workbook.worksheets.getItem(sheetName).getRange(address).format.font.setUnderline(value);
    });
  }
  async setRangeFontColor(sheetName, address, color) {
    await this.recordRangeFormat(sheetName, address, "Set range font color", async () => {
      await this.workbook.worksheets.getItem(sheetName).getRange(address).format.font.setColor(color);
    });
  }
  async setRangeFillColor(sheetName, address, color) {
    await this.recordRangeFormat(sheetName, address, "Set range fill color", async () => {
      await this.workbook.worksheets.getItem(sheetName).getRange(address).format.fill.setForegroundColor(color);
    });
  }
  async setRangeHorizontalAlign(sheetName, address, horizontal) {
    await this.recordRangeFormat(sheetName, address, "Set range horizontal align", async () => {
      await this.workbook.worksheets.getItem(sheetName).getRange(address).format.alignment.setHorizontal(horizontal);
    });
  }
  async setRangeVerticalAlign(sheetName, address, vertical) {
    await this.recordRangeFormat(sheetName, address, "Set range vertical align", async () => {
      await this.workbook.worksheets.getItem(sheetName).getRange(address).format.alignment.setVertical(vertical);
    });
  }
  async setRangeNumberFormat(sheetName, address, code) {
    await this.recordRangeFormat(sheetName, address, "Set range number format", async () => {
      await this.workbook.worksheets.getItem(sheetName).getRange(address).format.setNumberFormatCode(code);
    });
  }
  async clearRangeFormat(sheetName, address) {
    await this.recordRangeFormat(sheetName, address, "Clear range format", async () => {
      await this.workbook.executeCode(
        `
        const sheet = workbook.worksheets.getItem(args.sheetName);
        const range = sheet.getRange(args.address);
        range.format.font.setBold(undefined);
        range.format.font.setItalic(undefined);
        range.format.font.setUnderline(undefined);
        range.format.font.setColor(undefined);
        range.format.fill.setForegroundColor(undefined);
        range.format.border.setValue({});
        range.format.alignment.setValue(undefined);
        range.format.setNumberFormatCode(undefined);
        `,
        { sheetName, address }
      );
    });
  }
  async setRangeStyleId(sheetName, address, styleId) {
    await this.recordRangeFormat(sheetName, address, "Set range style", async () => {
      await this.workbook.worksheets.getItem(sheetName).getRange(address).setStyleId(styleId);
    });
  }
  async setSheetViews(sheetName, sheetViews) {
    const sheet = this.workbook.worksheets.getItem(sheetName);
    const before = await sheet.sheetViews();
    await sheet.setSheetViews(sheetViews);
    const after = await sheet.sheetViews();
    if (JSON.stringify(before) === JSON.stringify(after)) return;
    const address = "views";
    this.transactions.push({
      id: createExcelHistoryId("tx"),
      label: "Set sheet views",
      forward: [{ kind: "sheet.views", sheetName, address, sheetViews: after }],
      inverse: [{ kind: "sheet.views", sheetName, address, sheetViews: before }]
    });
  }
  async addSheet(name) {
    await this.recordWorkbookSheets("Add worksheet", name, async () => {
      await this.workbook.worksheets.add(name);
    });
  }
  async deleteSheet(nameOrId) {
    await this.recordWorkbookSheets("Delete worksheet", nameOrId, async () => {
      await this.workbook.worksheets.deleteItem(nameOrId);
    });
  }
  async renameSheet(nameOrId, name) {
    await this.recordWorkbookSheets("Rename worksheet", nameOrId, async () => {
      await this.workbook.worksheets.getItem(nameOrId).rename(name);
    });
  }
  async copySheet(nameOrId, newName) {
    await this.recordWorkbookSheets("Copy worksheet", nameOrId, async () => {
      await this.workbook.worksheets.copy(nameOrId, newName);
    });
  }
  async moveSheet(nameOrId, toIndex) {
    await this.recordWorkbookSheets("Move worksheet", nameOrId, async () => {
      await this.workbook.worksheets.move(nameOrId, toIndex);
    });
  }
  async mergeRange(sheetName, address) {
    const beforeCells = await captureRangeCells(this.workbook, sheetName, address);
    const beforeMergedRanges = await captureMergedRanges(this.workbook, sheetName);
    await this.workbook.worksheets.getItem(sheetName).getRange(address).merge();
    const afterCells = await captureRangeCells(this.workbook, sheetName, address);
    const afterMergedRanges = await captureMergedRanges(this.workbook, sheetName);
    if (JSON.stringify(beforeCells) === JSON.stringify(afterCells) && JSON.stringify(beforeMergedRanges) === JSON.stringify(afterMergedRanges)) {
      return;
    }
    this.transactions.push({
      id: createExcelHistoryId("tx"),
      label: "Merge range",
      forward: [
        { kind: "range.cells", sheetName, address, cells: afterCells },
        { kind: "sheet.mergedRanges", sheetName, address, mergedRanges: afterMergedRanges }
      ],
      inverse: [
        { kind: "range.cells", sheetName, address, cells: beforeCells },
        { kind: "sheet.mergedRanges", sheetName, address, mergedRanges: beforeMergedRanges }
      ]
    });
  }
  async unmergeRange(sheetName, address) {
    await this.recordMergedRanges(sheetName, address, "Unmerge range", async () => {
      await this.workbook.worksheets.getItem(sheetName).getRange(address).unmerge();
    });
  }
  async insertRows(sheetName, rowIndex, count = 1) {
    await this.workbook.worksheets.getItem(sheetName).insertRows(rowIndex, count);
    const address = `rows:${rowIndex}:${count}`;
    this.transactions.push({
      id: createExcelHistoryId("tx"),
      label: "Insert rows",
      forward: [{ kind: "sheet.rows.insert", sheetName, address, rowIndex, count }],
      inverse: [{ kind: "sheet.rows.delete", sheetName, address, rowIndex, count }]
    });
  }
  async deleteRows(sheetName, rowIndex, count = 1) {
    const before = await captureSheetModel(this.workbook, sheetName);
    const restoreDelta = canUseStructuralRestoreDelta(before) ? buildRowsRestoreDeltaPatch(sheetName, `rows:${rowIndex}:${count}`, rowIndex, count, before) : null;
    await this.workbook.worksheets.getItem(sheetName).deleteRows(rowIndex, count);
    const after = await captureSheetModel(this.workbook, sheetName);
    if (JSON.stringify(before) === JSON.stringify(after)) return;
    const address = `rows:${rowIndex}:${count}`;
    this.transactions.push({
      id: createExcelHistoryId("tx"),
      label: "Delete rows",
      forward: [{ kind: "sheet.rows.delete", sheetName, address, rowIndex, count }],
      inverse: [
        restoreDelta != null ? restoreDelta : {
          kind: "sheet.rows.restore",
          sheetName,
          address,
          rowIndex,
          count,
          sheet: before.sheet,
          definedNames: before.definedNames
        }
      ]
    });
  }
  async insertColumns(sheetName, columnIndex, count = 1) {
    await this.workbook.worksheets.getItem(sheetName).insertColumns(columnIndex, count);
    const address = `columns:${columnIndex}:${count}`;
    this.transactions.push({
      id: createExcelHistoryId("tx"),
      label: "Insert columns",
      forward: [{ kind: "sheet.columns.insert", sheetName, address, columnIndex, count }],
      inverse: [{ kind: "sheet.columns.delete", sheetName, address, columnIndex, count }]
    });
  }
  async deleteColumns(sheetName, columnIndex, count = 1) {
    const before = await captureSheetModel(this.workbook, sheetName);
    const restoreDelta = canUseStructuralRestoreDelta(before) ? buildColumnsRestoreDeltaPatch(sheetName, `columns:${columnIndex}:${count}`, columnIndex, count, before) : null;
    await this.workbook.worksheets.getItem(sheetName).deleteColumns(columnIndex, count);
    const after = await captureSheetModel(this.workbook, sheetName);
    if (JSON.stringify(before) === JSON.stringify(after)) return;
    const address = `columns:${columnIndex}:${count}`;
    this.transactions.push({
      id: createExcelHistoryId("tx"),
      label: "Delete columns",
      forward: [{ kind: "sheet.columns.delete", sheetName, address, columnIndex, count }],
      inverse: [
        restoreDelta != null ? restoreDelta : {
          kind: "sheet.columns.restore",
          sheetName,
          address,
          columnIndex,
          count,
          sheet: before.sheet,
          definedNames: before.definedNames
        }
      ]
    });
  }
  async setRangeBorder(sheetName, address, border) {
    await this.recordRangeFormat(sheetName, address, "Set range border", async () => {
      await this.workbook.worksheets.getItem(sheetName).getRange(address).format.border.setValue(border);
    });
  }
  async setRowHeight(sheetName, row, height) {
    const address = formatCellAddress(row, 1);
    const range = this.workbook.worksheets.getItem(sheetName).getRange(address);
    const before = (await range.rowHeights())[0];
    await range.setRowHeight(height);
    const after = (await range.rowHeights())[0];
    if (before === after) return;
    this.transactions.push({
      id: createExcelHistoryId("tx"),
      label: "Set row height",
      forward: [{ kind: "row.height", sheetName, row, height: after }],
      inverse: [{ kind: "row.height", sheetName, row, height: before }]
    });
  }
  async setColumnWidth(sheetName, column, width) {
    const address = formatCellAddress(1, column);
    const range = this.workbook.worksheets.getItem(sheetName).getRange(address);
    const before = (await range.columnWidths())[0];
    await range.setColumnWidth(width);
    const after = (await range.columnWidths())[0];
    if (before === after) return;
    this.transactions.push({
      id: createExcelHistoryId("tx"),
      label: "Set column width",
      forward: [{ kind: "column.width", sheetName, column, width: after }],
      inverse: [{ kind: "column.width", sheetName, column, width: before }]
    });
  }
  async runSnapshot(label, reason, mutate) {
    const before = await this.workbook.toModel();
    await mutate();
    const after = await this.workbook.toModel();
    if (JSON.stringify(before) === JSON.stringify(after)) return;
    this.transactions.push({
      id: createExcelHistoryId("tx"),
      label,
      forward: [{ kind: "snapshot", reason, beforeModel: before, afterModel: after }],
      inverse: [{ kind: "snapshot", reason, beforeModel: after, afterModel: before }]
    });
  }
  async commit() {
    var _a, _b, _c, _d, _e2;
    if (this.transactions.length === 0) return null;
    const affectedSheets = unique(this.transactions.flatMap((transaction) => transaction.forward.map(patchSheetName)));
    const affectedRanges = unique(this.transactions.flatMap((transaction) => transaction.forward.map(patchRangeAddress).filter(Boolean)));
    return {
      id: (_a = this.options.id) != null ? _a : createExcelHistoryId("group"),
      source: this.options.source,
      label: this.options.label,
      metadata: normalizeTransactionMetadata(__spreadProps(__spreadValues({}, this.options.metadata), {
        mergeKey: (_c = this.options.mergeKey) != null ? _c : (_b = this.options.metadata) == null ? void 0 : _b.mergeKey
      })),
      mergeKey: (_e2 = this.options.mergeKey) != null ? _e2 : (_d = this.options.metadata) == null ? void 0 : _d.mergeKey,
      mergeWindowMs: this.options.mergeWindowMs,
      workbookId: this.workbook.workbookId,
      transactions: this.transactions.map(cloneTransaction),
      affectedSheets,
      affectedRanges,
      createdAt: this.createdAt,
      committedAt: Date.now()
    };
  }
  async recordRangeCells(sheetName, address, label, mutate) {
    const before = await captureRangeCells(this.workbook, sheetName, address);
    await mutate();
    const after = await captureRangeCells(this.workbook, sheetName, address);
    if (JSON.stringify(before) === JSON.stringify(after)) return;
    this.transactions.push({
      id: createExcelHistoryId("tx"),
      label,
      forward: [{ kind: "range.cells", sheetName, address, cells: after }],
      inverse: [{ kind: "range.cells", sheetName, address, cells: before }]
    });
  }
  async recordRangeFormat(sheetName, address, label, mutate) {
    const before = await captureRangeFormats(this.workbook, sheetName, address);
    await mutate();
    const after = await captureRangeFormats(this.workbook, sheetName, address);
    if (JSON.stringify(before) === JSON.stringify(after)) return;
    this.transactions.push({
      id: createExcelHistoryId("tx"),
      label,
      forward: [{ kind: "range.format", sheetName, address, formats: after }],
      inverse: [{ kind: "range.format", sheetName, address, formats: before }]
    });
  }
  async recordMergedRanges(sheetName, address, label, mutate) {
    const before = await captureMergedRanges(this.workbook, sheetName);
    await mutate();
    const after = await captureMergedRanges(this.workbook, sheetName);
    if (JSON.stringify(before) === JSON.stringify(after)) return;
    this.transactions.push({
      id: createExcelHistoryId("tx"),
      label,
      forward: [{ kind: "sheet.mergedRanges", sheetName, address, mergedRanges: after }],
      inverse: [{ kind: "sheet.mergedRanges", sheetName, address, mergedRanges: before }]
    });
  }
  async recordSheetModel(sheetName, address, label, mutate) {
    const before = await captureSheetModel(this.workbook, sheetName);
    await mutate();
    const after = await captureSheetModel(this.workbook, sheetName);
    if (JSON.stringify(before) === JSON.stringify(after)) return;
    this.transactions.push({
      id: createExcelHistoryId("tx"),
      label,
      forward: [{ kind: "sheet.model", sheetName, address, sheet: after.sheet, definedNames: after.definedNames }],
      inverse: [{ kind: "sheet.model", sheetName, address, sheet: before.sheet, definedNames: before.definedNames }]
    });
  }
  async recordWorkbookSheets(label, sheetName, mutate) {
    const before = await captureWorkbookSheets(this.workbook);
    await mutate();
    const after = await captureWorkbookSheets(this.workbook);
    if (JSON.stringify(before) === JSON.stringify(after)) return;
    const address = "sheets";
    this.transactions.push({
      id: createExcelHistoryId("tx"),
      label,
      forward: [{ kind: "workbook.sheets", sheetName, address, sheets: after.sheets, definedNames: after.definedNames }],
      inverse: [{ kind: "workbook.sheets", sheetName, address, sheets: before.sheets, definedNames: before.definedNames }]
    });
  }
};
__name(_ExcelTransactionGroupBuilder, "ExcelTransactionGroupBuilder");
var ExcelTransactionGroupBuilder = _ExcelTransactionGroupBuilder;
async function applyExcelPatch(workbook, patch) {
  if (patch.kind === "range.cells") {
    await applyRangeCellsPatch(workbook, patch);
    return;
  }
  if (patch.kind === "range.format") {
    await applyRangeFormatPatch(workbook, patch);
    return;
  }
  if (patch.kind === "sheet.mergedRanges") {
    await applyMergedRangesPatch(workbook, patch);
    return;
  }
  if (patch.kind === "sheet.views") {
    await workbook.worksheets.getItem(patch.sheetName).setSheetViews(patch.sheetViews);
    return;
  }
  if (patch.kind === "workbook.sheets") {
    await applyWorkbookSheetsPatch(workbook, patch);
    return;
  }
  if (patch.kind === "sheet.model") {
    await applySheetModelPatch(workbook, patch);
    return;
  }
  if (patch.kind === "sheet.rows.insert") {
    await workbook.worksheets.getItem(patch.sheetName).insertRows(patch.rowIndex, patch.count);
    return;
  }
  if (patch.kind === "sheet.rows.delete") {
    await workbook.worksheets.getItem(patch.sheetName).deleteRows(patch.rowIndex, patch.count);
    return;
  }
  if (patch.kind === "sheet.rows.restore") {
    await applySheetStructuralRestorePatch(workbook, patch);
    return;
  }
  if (patch.kind === "sheet.rows.restoreDelta") {
    await applyRowsRestoreDeltaPatch(workbook, patch);
    return;
  }
  if (patch.kind === "sheet.columns.insert") {
    await workbook.worksheets.getItem(patch.sheetName).insertColumns(patch.columnIndex, patch.count);
    return;
  }
  if (patch.kind === "sheet.columns.delete") {
    await workbook.worksheets.getItem(patch.sheetName).deleteColumns(patch.columnIndex, patch.count);
    return;
  }
  if (patch.kind === "sheet.columns.restore") {
    await applySheetStructuralRestorePatch(workbook, patch);
    return;
  }
  if (patch.kind === "sheet.columns.restoreDelta") {
    await applyColumnsRestoreDeltaPatch(workbook, patch);
    return;
  }
  if (patch.kind === "row.height") {
    await workbook.worksheets.getItem(patch.sheetName).getRange(formatCellAddress(patch.row, 1)).setRowHeight(patch.height);
    return;
  }
  if (patch.kind === "column.width") {
    await workbook.worksheets.getItem(patch.sheetName).getRange(formatCellAddress(1, patch.column)).setColumnWidth(patch.width);
    return;
  }
  await applySnapshotPatch(workbook, patch);
}
__name(applyExcelPatch, "applyExcelPatch");
function summarizeExcelTransactionGroup(group) {
  const transactions = group.transactions.map(summarizeExcelTransaction);
  const patches = transactions.flatMap((transaction) => transaction.patches);
  const restoreStrategies = unique(
    patches.map((patch) => patch.restoreStrategy).filter((strategy) => strategy !== void 0)
  );
  return {
    id: group.id,
    source: group.source,
    label: group.label,
    metadata: group.metadata ? cloneJson(group.metadata) : void 0,
    mergeKey: group.mergeKey,
    workbookId: group.workbookId,
    transactionCount: group.transactions.length,
    patchCount: patches.length,
    forwardPatchKinds: unique(
      group.transactions.flatMap((transaction) => transaction.forward.map((patch) => patch.kind))
    ),
    inversePatchKinds: unique(
      group.transactions.flatMap((transaction) => transaction.inverse.map((patch) => patch.kind))
    ),
    affectedSheets: [...group.affectedSheets],
    affectedRanges: [...group.affectedRanges],
    containsSnapshot: patches.some((patch) => patch.snapshot),
    containsStructuralPatch: patches.some((patch) => patch.structural),
    restoreStrategies,
    transactions,
    createdAt: group.createdAt,
    committedAt: group.committedAt
  };
}
__name(summarizeExcelTransactionGroup, "summarizeExcelTransactionGroup");
function summarizeExcelTransaction(transaction) {
  return {
    id: transaction.id,
    label: transaction.label,
    forwardPatchKinds: unique(transaction.forward.map((patch) => patch.kind)),
    inversePatchKinds: unique(transaction.inverse.map((patch) => patch.kind)),
    patches: [
      ...transaction.forward.map((patch) => summarizeExcelPatch(patch, "forward")),
      ...transaction.inverse.map((patch) => summarizeExcelPatch(patch, "inverse"))
    ]
  };
}
__name(summarizeExcelTransaction, "summarizeExcelTransaction");
function summarizeExcelPatch(patch, direction) {
  return {
    kind: patch.kind,
    direction,
    sheetName: patchSheetName(patch),
    address: patchRangeAddress(patch),
    snapshot: patch.kind === "snapshot",
    structural: isStructuralPatch(patch),
    restoreStrategy: patchRestoreStrategy(patch)
  };
}
__name(summarizeExcelPatch, "summarizeExcelPatch");
async function captureMergedRanges(workbook, sheetName) {
  return (await workbook.worksheets.getItem(sheetName).mergedRanges()).map((range) => range.address);
}
__name(captureMergedRanges, "captureMergedRanges");
async function captureSheetModel(workbook, sheetName) {
  const model = await workbook.toModel();
  const sheet = model.sheets.find((item) => item.name === sheetName || item.id === sheetName);
  if (!sheet) throw new Error(`ExcelWorkbookHistory: sheet not found: ${sheetName}`);
  return {
    sheet,
    definedNames: model.definedNames
  };
}
__name(captureSheetModel, "captureSheetModel");
async function captureWorkbookSheets(workbook) {
  const model = await workbook.toModel();
  return { sheets: model.sheets, definedNames: model.definedNames };
}
__name(captureWorkbookSheets, "captureWorkbookSheets");
async function captureRangeCells(workbook, sheetName, address) {
  return workbook.worksheets.getItem(sheetName).getRange(address).toModel();
}
__name(captureRangeCells, "captureRangeCells");
async function captureRangeFormats(workbook, sheetName, address) {
  var _a;
  const range = parseRangeAddress(address);
  const styleIds = await workbook.worksheets.getItem(sheetName).getRange(address).styleIds();
  const formats = [];
  for (let rowOffset = 0; rowOffset < range.rowCount; rowOffset++) {
    for (let columnOffset = 0; columnOffset < range.columnCount; columnOffset++) {
      formats.push({
        row: range.startRow + rowOffset,
        column: range.startColumn + columnOffset,
        styleId: (_a = styleIds[rowOffset]) == null ? void 0 : _a[columnOffset]
      });
    }
  }
  return formats;
}
__name(captureRangeFormats, "captureRangeFormats");
async function applyRangeCellsPatch(workbook, patch) {
  await workbook.executeCode(
    `
    const sheet = workbook.worksheets.getItem(args.sheetName);
    const range = sheet.getRange(args.address);
    range.clear();
    for (const cell of args.cells) {
      const target = sheet.getCell(cell.address);
      if (cell.formula !== undefined) target.setFormula(cell.formula);
      else if (cell.richText) target.toRange().setRichText(cell.richText);
      else target.setValue(cell.value);
      if (cell.styleId !== undefined) target.setStyleId(cell.styleId);
    }
    `,
    { sheetName: patch.sheetName, address: patch.address, cells: patch.cells }
  );
}
__name(applyRangeCellsPatch, "applyRangeCellsPatch");
async function applyRangeFormatPatch(workbook, patch) {
  const formats = patch.formats.map((item) => ({
    address: formatCellAddress(item.row, item.column),
    styleId: item.styleId
  }));
  await workbook.executeCode(
    `
    const sheet = workbook.worksheets.getItem(args.sheetName);
    for (const item of args.formats) {
      sheet.getCell(item.address).setStyleId(item.styleId);
    }
    `,
    { sheetName: patch.sheetName, formats }
  );
}
__name(applyRangeFormatPatch, "applyRangeFormatPatch");
async function applyMergedRangesPatch(workbook, patch) {
  await workbook.executeCode(
    `
    const sheet = workbook.worksheets.getItem(args.sheetName);
    sheet.model.mergedRanges = args.mergedRanges.map((address) => ({ address }));
    `,
    { sheetName: patch.sheetName, mergedRanges: patch.mergedRanges }
  );
}
__name(applyMergedRangesPatch, "applyMergedRangesPatch");
async function applySheetModelPatch(workbook, patch) {
  await workbook.executeCode(
    `
    const model = workbook.toModel();
    const index = model.sheets.findIndex((sheet) => sheet.name === args.sheetName || sheet.id === args.sheetName);
    if (index === -1) throw new Error('ExcelWorkbookHistory: sheet not found: ' + args.sheetName);
    model.sheets[index] = args.sheet;
    model.definedNames = args.definedNames;
    workbook._replaceModelForHistory(model);
    `,
    {
      sheetName: patch.sheetName,
      sheet: patch.sheet,
      definedNames: patch.definedNames
    }
  );
}
__name(applySheetModelPatch, "applySheetModelPatch");
async function applyWorkbookSheetsPatch(workbook, patch) {
  await workbook.executeCode(
    `
    const model = workbook.toModel();
    model.sheets = args.sheets;
    model.definedNames = args.definedNames;
    workbook._replaceModelForHistory(model);
    `,
    { sheets: patch.sheets, definedNames: patch.definedNames }
  );
}
__name(applyWorkbookSheetsPatch, "applyWorkbookSheetsPatch");
async function applySheetStructuralRestorePatch(workbook, patch) {
  await workbook.executeCode(
    `
    const model = workbook.toModel();
    const index = model.sheets.findIndex((sheet) => sheet.name === args.sheetName || sheet.id === args.sheetName);
    if (index === -1) throw new Error('ExcelWorkbookHistory: sheet not found: ' + args.sheetName);
    model.sheets[index] = args.sheet;
    model.definedNames = args.definedNames;
    workbook._replaceModelForHistory(model);
    `,
    {
      sheetName: patch.sheetName,
      sheet: patch.sheet,
      definedNames: patch.definedNames
    }
  );
}
__name(applySheetStructuralRestorePatch, "applySheetStructuralRestorePatch");
async function applyRowsRestoreDeltaPatch(workbook, patch) {
  await workbook.executeCode(
    `
    function columnIndexToName(column) {
      let value = column;
      let name = '';
      while (value > 0) {
        const rem = (value - 1) % 26;
        name = String.fromCharCode(65 + rem) + name;
        value = Math.floor((value - 1) / 26);
      }
      return name;
    }

    function formatCellAddress(row, column) {
      return columnIndexToName(column) + String(row);
    }

    function computeDimension(cells) {
      if (!cells.length) return undefined;
      let minRow = Infinity;
      let minColumn = Infinity;
      let maxRow = 0;
      let maxColumn = 0;
      for (const cell of cells) {
        minRow = Math.min(minRow, cell.row);
        minColumn = Math.min(minColumn, cell.column);
        maxRow = Math.max(maxRow, cell.row);
        maxColumn = Math.max(maxColumn, cell.column);
      }
      const first = formatCellAddress(minRow, minColumn);
      const last = formatCellAddress(maxRow, maxColumn);
      return first === last ? first : first + ':' + last;
    }

    const sheet = workbook.worksheets.getItem(args.sheetName);
    sheet.insertRows(args.rowIndex, args.count);

    const model = workbook.toModel();
    const index = model.sheets.findIndex((item) => item.name === args.sheetName || item.id === args.sheetName);
    if (index === -1) throw new Error('ExcelWorkbookHistory: sheet not found: ' + args.sheetName);
    const sheetModel = model.sheets[index];
    const endRow = args.rowIndex + args.count - 1;

    sheetModel.cells = sheetModel.cells.filter((cell) => cell.row < args.rowIndex || cell.row > endRow);
    sheetModel.cells.push(...args.cells.map((cell) => ({ ...cell })));
    sheetModel.cells.sort((a, b) => a.row - b.row || a.column - b.column);

    sheetModel.rows = sheetModel.rows.filter((row) => row.index < args.rowIndex || row.index > endRow);
    sheetModel.rows.push(...args.rows.map((row) => ({ ...row })));
    sheetModel.rows.sort((a, b) => a.index - b.index);

    sheetModel.mergedRanges = args.mergedRanges.map((range) => ({ ...range }));
    sheetModel.dimension = computeDimension(sheetModel.cells);
    model.definedNames = args.definedNames.map((name) => ({ ...name }));
    workbook._replaceModelForHistory(model);
    `,
    {
      sheetName: patch.sheetName,
      rowIndex: patch.rowIndex,
      count: patch.count,
      cells: patch.cells,
      rows: patch.rows,
      mergedRanges: patch.mergedRanges,
      definedNames: patch.definedNames
    }
  );
}
__name(applyRowsRestoreDeltaPatch, "applyRowsRestoreDeltaPatch");
async function applyColumnsRestoreDeltaPatch(workbook, patch) {
  await workbook.executeCode(
    `
    function columnIndexToName(column) {
      let value = column;
      let name = '';
      while (value > 0) {
        const rem = (value - 1) % 26;
        name = String.fromCharCode(65 + rem) + name;
        value = Math.floor((value - 1) / 26);
      }
      return name;
    }

    function formatCellAddress(row, column) {
      return columnIndexToName(column) + String(row);
    }

    function computeDimension(cells) {
      if (!cells.length) return undefined;
      let minRow = Infinity;
      let minColumn = Infinity;
      let maxRow = 0;
      let maxColumn = 0;
      for (const cell of cells) {
        minRow = Math.min(minRow, cell.row);
        minColumn = Math.min(minColumn, cell.column);
        maxRow = Math.max(maxRow, cell.row);
        maxColumn = Math.max(maxColumn, cell.column);
      }
      const first = formatCellAddress(minRow, minColumn);
      const last = formatCellAddress(maxRow, maxColumn);
      return first === last ? first : first + ':' + last;
    }

    const sheet = workbook.worksheets.getItem(args.sheetName);
    sheet.insertColumns(args.columnIndex, args.count);

    const model = workbook.toModel();
    const index = model.sheets.findIndex((item) => item.name === args.sheetName || item.id === args.sheetName);
    if (index === -1) throw new Error('ExcelWorkbookHistory: sheet not found: ' + args.sheetName);
    const sheetModel = model.sheets[index];
    const endColumn = args.columnIndex + args.count - 1;

    sheetModel.cells = sheetModel.cells.filter((cell) => cell.column < args.columnIndex || cell.column > endColumn);
    sheetModel.cells.push(...args.cells.map((cell) => ({ ...cell })));
    sheetModel.cells.sort((a, b) => a.row - b.row || a.column - b.column);

    sheetModel.columns = args.columns.map((column) => ({ ...column }));
    sheetModel.columns.sort((a, b) => a.min - b.min || a.max - b.max);

    sheetModel.mergedRanges = args.mergedRanges.map((range) => ({ ...range }));
    sheetModel.dimension = computeDimension(sheetModel.cells);
    model.definedNames = args.definedNames.map((name) => ({ ...name }));
    workbook._replaceModelForHistory(model);
    `,
    {
      sheetName: patch.sheetName,
      columnIndex: patch.columnIndex,
      count: patch.count,
      cells: patch.cells,
      columns: patch.columns,
      mergedRanges: patch.mergedRanges,
      definedNames: patch.definedNames
    }
  );
}
__name(applyColumnsRestoreDeltaPatch, "applyColumnsRestoreDeltaPatch");
async function applySnapshotPatch(workbook, patch) {
  await workbook.executeCode(
    `
    workbook._replaceModelForHistory(args.model);
    `,
    { model: patch.afterModel }
  );
}
__name(applySnapshotPatch, "applySnapshotPatch");
function patchSheetName(patch) {
  if (patch.kind === "snapshot") return "";
  return patch.sheetName;
}
__name(patchSheetName, "patchSheetName");
function patchRangeAddress(patch) {
  if (patch.kind === "row.height") return `${patch.sheetName}!${formatCellAddress(patch.row, 1)}`;
  if (patch.kind === "column.width") return `${patch.sheetName}!${formatCellAddress(1, patch.column)}`;
  if (patch.kind === "snapshot") return "";
  if (patch.kind === "sheet.model") return `${patch.sheetName}!${patch.address}`;
  if (patch.kind === "sheet.views") return `${patch.sheetName}!${patch.address}`;
  if (patch.kind === "workbook.sheets") return `${patch.sheetName}!${patch.address}`;
  if (patch.kind === "sheet.rows.insert" || patch.kind === "sheet.rows.delete" || patch.kind === "sheet.rows.restore" || patch.kind === "sheet.rows.restoreDelta" || patch.kind === "sheet.columns.insert" || patch.kind === "sheet.columns.delete" || patch.kind === "sheet.columns.restore" || patch.kind === "sheet.columns.restoreDelta") {
    return `${patch.sheetName}!${patch.address}`;
  }
  if (patch.kind === "sheet.mergedRanges") return `${patch.sheetName}!${patch.address}`;
  return `${patch.sheetName}!${patch.address}`;
}
__name(patchRangeAddress, "patchRangeAddress");
function isStructuralPatch(patch) {
  return patch.kind === "sheet.model" || patch.kind === "workbook.sheets" || patch.kind === "sheet.rows.insert" || patch.kind === "sheet.rows.delete" || patch.kind === "sheet.rows.restore" || patch.kind === "sheet.rows.restoreDelta" || patch.kind === "sheet.columns.insert" || patch.kind === "sheet.columns.delete" || patch.kind === "sheet.columns.restore" || patch.kind === "sheet.columns.restoreDelta" || patch.kind === "sheet.mergedRanges" || patch.kind === "snapshot";
}
__name(isStructuralPatch, "isStructuralPatch");
function patchRestoreStrategy(patch) {
  if (patch.kind === "sheet.rows.restoreDelta" || patch.kind === "sheet.columns.restoreDelta") return "delta";
  if (patch.kind === "sheet.rows.restore" || patch.kind === "sheet.columns.restore") return "full";
  if (patch.kind === "sheet.model" || patch.kind === "snapshot") return "full";
  if (patch.kind === "workbook.sheets") return "full";
  return void 0;
}
__name(patchRestoreStrategy, "patchRestoreStrategy");
function canMergeTransactionGroups(previous, next) {
  var _a, _b;
  if (!previous.mergeKey || !next.mergeKey) return false;
  if (previous.mergeKey !== next.mergeKey) return false;
  if (previous.source !== next.source) return false;
  if (previous.workbookId !== next.workbookId) return false;
  const windowMs = (_b = (_a = next.mergeWindowMs) != null ? _a : previous.mergeWindowMs) != null ? _b : 0;
  if (windowMs <= 0) return false;
  return next.createdAt - previous.committedAt <= windowMs;
}
__name(canMergeTransactionGroups, "canMergeTransactionGroups");
function mergeTransactionGroups(previous, next) {
  var _a;
  return __spreadProps(__spreadValues({}, previous), {
    label: next.label,
    metadata: normalizeTransactionMetadata(__spreadProps(__spreadValues(__spreadValues({}, previous.metadata), next.metadata), {
      mergeKey: next.mergeKey
    })),
    mergeKey: previous.mergeKey,
    mergeWindowMs: (_a = next.mergeWindowMs) != null ? _a : previous.mergeWindowMs,
    transactions: [...previous.transactions.map(cloneTransaction), ...next.transactions.map(cloneTransaction)],
    affectedSheets: unique([...previous.affectedSheets, ...next.affectedSheets]),
    affectedRanges: unique([...previous.affectedRanges, ...next.affectedRanges]),
    committedAt: next.committedAt
  });
}
__name(mergeTransactionGroups, "mergeTransactionGroups");
function cloneTransactionGroup(group) {
  return JSON.parse(JSON.stringify(group));
}
__name(cloneTransactionGroup, "cloneTransactionGroup");
function cloneTransaction(transaction) {
  return JSON.parse(JSON.stringify(transaction));
}
__name(cloneTransaction, "cloneTransaction");
function buildRowsRestoreDeltaPatch(sheetName, address, rowIndex, count, model) {
  const endRow = rowIndex + count - 1;
  return {
    kind: "sheet.rows.restoreDelta",
    sheetName,
    address,
    rowIndex,
    count,
    cells: model.sheet.cells.filter((cell) => cell.row >= rowIndex && cell.row <= endRow).map(cloneJson),
    rows: model.sheet.rows.filter((row) => row.index >= rowIndex && row.index <= endRow).map(cloneJson),
    mergedRanges: model.sheet.mergedRanges.map(cloneJson),
    definedNames: model.definedNames.map(cloneJson)
  };
}
__name(buildRowsRestoreDeltaPatch, "buildRowsRestoreDeltaPatch");
function buildColumnsRestoreDeltaPatch(sheetName, address, columnIndex, count, model) {
  const endColumn = columnIndex + count - 1;
  return {
    kind: "sheet.columns.restoreDelta",
    sheetName,
    address,
    columnIndex,
    count,
    cells: model.sheet.cells.filter((cell) => cell.column >= columnIndex && cell.column <= endColumn).map(cloneJson),
    columns: model.sheet.columns.map(cloneJson),
    mergedRanges: model.sheet.mergedRanges.map(cloneJson),
    definedNames: model.definedNames.map(cloneJson)
  };
}
__name(buildColumnsRestoreDeltaPatch, "buildColumnsRestoreDeltaPatch");
function canUseStructuralRestoreDelta(model) {
  const sheet = model.sheet;
  return model.definedNames.length === 0 && !sheet.cells.some((cell) => cell.formula !== void 0) && sheet.hyperlinks.length === 0 && sheet.tables.length === 0 && sheet.dataValidations.length === 0 && sheet.conditionalFormats.length === 0 && sheet.comments.length === 0 && sheet.threadedComments.length === 0 && sheet.drawings.length === 0 && sheet.charts.length === 0 && sheet.images.length === 0;
}
__name(canUseStructuralRestoreDelta, "canUseStructuralRestoreDelta");
function cloneJson(value) {
  return JSON.parse(JSON.stringify(value));
}
__name(cloneJson, "cloneJson");
function normalizeTransactionMetadata(metadata) {
  if (!metadata) return void 0;
  const normalized = {};
  for (const [key2, value] of Object.entries(metadata)) {
    if (value !== void 0) normalized[key2] = value;
  }
  return Object.keys(normalized).length > 0 ? normalized : void 0;
}
__name(normalizeTransactionMetadata, "normalizeTransactionMetadata");
function createExcelHistoryId(prefix) {
  return `${prefix}:${Date.now()}:${Math.random().toString(16).slice(2)}`;
}
__name(createExcelHistoryId, "createExcelHistoryId");
function unique(values) {
  return [...new Set(values.filter(Boolean))];
}
__name(unique, "unique");
function deserializeExcelError(error2) {
  var _a;
  const err = new Error(error2.message);
  err.name = (_a = error2.name) != null ? _a : "Error";
  if (error2.stack) err.stack = error2.stack;
  return err;
}
__name(deserializeExcelError, "deserializeExcelError");
var _ExcelWorkerTransport = class _ExcelWorkerTransport2 {
  constructor(port) {
    __publicField(this, "port", port);
    __publicField(this, "pending", /* @__PURE__ */ new Map());
    __publicField(this, "nextId", 0);
    __publicField(this, "disposed", false);
    port.onMessage((data) => this.handleIncoming(data));
    port.onError((error2) => this.rejectAll(error2));
  }
  call(method, args, timeoutMs = 0) {
    if (this.disposed) throw new Error("ExcelWorkerTransport has been disposed");
    const id = `excel-${Date.now()}-${this.nextId++}`;
    const req = { kind: "request", id, method, args };
    return new Promise((resolve, reject) => {
      let timeoutHandle;
      if (timeoutMs > 0) {
        timeoutHandle = setTimeout(() => {
          this.pending.delete(id);
          reject(new Error(`excel worker call timeout after ${timeoutMs}ms: ${method}`));
        }, timeoutMs);
      }
      this.pending.set(id, {
        resolve: /* @__PURE__ */ __name((value) => resolve(value), "resolve"),
        reject,
        timeoutHandle
      });
      this.port.postMessage(req);
    });
  }
  async dispose() {
    if (this.disposed) return;
    this.disposed = true;
    this.rejectAll(new Error("ExcelWorkerTransport disposed"));
    await this.port.terminate();
  }
  handleIncoming(data) {
    if (data === null || typeof data !== "object") return;
    const msg = data;
    if (msg.kind !== "response" && msg.kind !== "error") return;
    const pending = this.pending.get(msg.id);
    if (!pending) return;
    this.pending.delete(msg.id);
    if (pending.timeoutHandle) clearTimeout(pending.timeoutHandle);
    if (msg.kind === "response") {
      pending.resolve(msg.result);
    } else {
      pending.reject(deserializeExcelError(msg.error));
    }
  }
  rejectAll(error2) {
    for (const [id, pending] of this.pending) {
      if (pending.timeoutHandle) clearTimeout(pending.timeoutHandle);
      pending.reject(error2);
      this.pending.delete(id);
    }
  }
};
__name(_ExcelWorkerTransport, "ExcelWorkerTransport");
var ExcelWorkerTransport = _ExcelWorkerTransport;
async function createNodeExcelWorkerPort(bundleUrl) {
  const { Worker } = await import("worker_threads");
  const worker = new Worker(bundleUrl);
  return {
    postMessage(data, transferList) {
      worker.postMessage(
        data,
        transferList
      );
    },
    onMessage(listener) {
      worker.on("message", listener);
    },
    onError(listener) {
      worker.on("error", listener);
      worker.on("exit", (code) => {
        if (code !== 0) listener(new Error(`excel worker exited with code ${code}`));
      });
    },
    async terminate() {
      await worker.terminate();
    }
  };
}
__name(createNodeExcelWorkerPort, "createNodeExcelWorkerPort");
var defaults = {
  mode: "auto"
};
var _ExcelWorkbook = class _ExcelWorkbook2 {
  constructor(init) {
    __publicField(this, "workbookId");
    __publicField(this, "mode");
    __publicField(this, "modeSource");
    __publicField(this, "worksheets");
    __publicField(this, "names");
    __publicField(this, "inlineWorkbook");
    __publicField(this, "workerTransport");
    __publicField(this, "workbookHistory");
    __publicField(this, "disposed", false);
    this.workbookId = init.workbookId;
    this.mode = init.mode;
    this.modeSource = init.modeSource;
    this.inlineWorkbook = init.inlineWorkbook;
    this.workerTransport = init.workerTransport;
    this.worksheets = new ExcelWorksheetCollection2(this);
    this.names = new ExcelNamedItemCollection2(this);
    this.workbookHistory = new ExcelWorkbookHistory(this);
  }
  static async fromZip(bytes, opts = {}) {
    var _a, _b;
    const decision = this.detectModeDecision(opts.mode);
    if (decision.mode === "inline") {
      const workbook = await ExcelWorkbookCore.fromZip(bytes, opts);
      (_a = opts.onModeResolved) == null ? void 0 : _a.call(opts, decision, workbook.workbookId);
      return new _ExcelWorkbook2({
        workbookId: workbook.workbookId,
        mode: "inline",
        modeSource: decision.source,
        inlineWorkbook: workbook
      });
    }
    const transport = await this.createWorkerTransport();
    const loaded = await transport.call(
      "load.zip",
      [bytes, toCoreLoadOptions(opts)],
      3e4
    );
    (_b = opts.onModeResolved) == null ? void 0 : _b.call(opts, decision, loaded.workbookId);
    return new _ExcelWorkbook2({
      workbookId: loaded.workbookId,
      mode: "worker",
      modeSource: decision.source,
      workerTransport: transport
    });
  }
  static async fromModel(model, opts = {}) {
    var _a, _b;
    const decision = this.detectModeDecision(opts.mode);
    if (decision.mode === "inline") {
      const workbook = ExcelWorkbookCore.fromModel(model, opts);
      (_a = opts.onModeResolved) == null ? void 0 : _a.call(opts, decision, workbook.workbookId);
      return new _ExcelWorkbook2({
        workbookId: workbook.workbookId,
        mode: "inline",
        modeSource: decision.source,
        inlineWorkbook: workbook
      });
    }
    const transport = await this.createWorkerTransport();
    const loaded = await transport.call(
      "load.model",
      [model, toCoreLoadOptions(opts)],
      3e4
    );
    (_b = opts.onModeResolved) == null ? void 0 : _b.call(opts, decision, loaded.workbookId);
    return new _ExcelWorkbook2({
      workbookId: loaded.workbookId,
      mode: "worker",
      modeSource: decision.source,
      workerTransport: transport
    });
  }
  static fromPackage(pkg, opts = {}) {
    var _a;
    if (opts.mode === "worker") {
      throw new Error("ExcelWorkbook.fromPackage currently supports inline mode only; use fromZip for worker mode");
    }
    const workbook = ExcelWorkbookCore.fromPackage(pkg, opts);
    const decision = { mode: "inline", source: opts.mode === "inline" ? "explicit-inline" : "auto/node-no-worker-config" };
    (_a = opts.onModeResolved) == null ? void 0 : _a.call(opts, decision, workbook.workbookId);
    return new _ExcelWorkbook2({
      workbookId: workbook.workbookId,
      mode: "inline",
      modeSource: decision.source,
      inlineWorkbook: workbook
    });
  }
  static setDefaultMode(mode) {
    defaults.mode = mode;
  }
  static setWorkerFactory(factory) {
    defaults.workerFactory = factory;
  }
  static setWorkerBundleUrl(url) {
    defaults.workerBundleUrl = url;
  }
  static detectMode() {
    return this.detectModeDecision().mode;
  }
  static detectModeDecision(mode = defaults.mode) {
    if (mode === "inline") return { mode: "inline", source: "explicit-inline" };
    if (mode === "worker") {
      if (!this.hasWorkerConfig()) {
        throw new Error("ExcelWorkbook: worker mode requires workerFactory or workerBundleUrl");
      }
      return { mode: "worker", source: "explicit-worker" };
    }
    if (defaults.workerFactory) return { mode: "worker", source: "auto/browser-factory" };
    if (defaults.workerBundleUrl) return { mode: "worker", source: "auto/node-with-worker-config" };
    return { mode: "inline", source: "auto/node-no-worker-config" };
  }
  static _resetDefaults() {
    defaults.mode = "auto";
    defaults.workerFactory = void 0;
    defaults.workerBundleUrl = void 0;
  }
  async executeCode(code, args, timeoutMs = 3e4, signal) {
    this.assertNotDisposed();
    if (this.inlineWorkbook) {
      return await executeExcelScript(this.inlineWorkbook, code, args, timeoutMs, signal);
    }
    if (signal == null ? void 0 : signal.aborted) {
      await this.dispose();
      throw new Error("excel worker script aborted before dispatch");
    }
    let abortHandler;
    const abortPromise = signal && new Promise((_2, reject) => {
      abortHandler = /* @__PURE__ */ __name(() => {
        signal.removeEventListener("abort", abortHandler);
        reject(new Error("excel worker script aborted"));
      }, "abortHandler");
      signal.addEventListener("abort", abortHandler, { once: true });
    });
    try {
      const call = this.workerTransport.call("script.execute", [code, args, 0], timeoutMs);
      return abortPromise ? await Promise.race([call, abortPromise]) : await call;
    } catch (error2) {
      if (isWorkerTerminalScriptError(error2)) {
        await this.dispose();
      }
      throw error2;
    } finally {
      if (signal && abortHandler) {
        signal.removeEventListener("abort", abortHandler);
      }
    }
  }
  async toModel() {
    this.assertNotDisposed();
    if (this.inlineWorkbook) return this.inlineWorkbook.toModel();
    return this.workerTransport.call("to.model", [], 3e4);
  }
  async getMutations() {
    this.assertNotDisposed();
    if (this.inlineWorkbook) return this.inlineWorkbook.getMutations();
    return this.workerTransport.call("mutations.list", [], 3e4);
  }
  async clearMutations() {
    this.assertNotDisposed();
    if (this.inlineWorkbook) {
      this.inlineWorkbook.clearMutations();
      return;
    }
    await this.workerTransport.call("mutations.clear", [], 3e4);
  }
  history() {
    this.assertNotDisposed();
    return this.workbookHistory;
  }
  async aggregateTable(options) {
    this.assertNotDisposed();
    return aggregateExcelTable(await this.toModel(), options);
  }
  async importCellStyles(snapshots) {
    return this.executeCode("return workbook.importCellStyles(args.snapshots);", { snapshots });
  }
  async toZip() {
    this.assertNotDisposed();
    if (this.inlineWorkbook) return this.inlineWorkbook.toZip();
    return this.workerTransport.call("to.zip", [], 6e4);
  }
  async dispose() {
    if (this.disposed) return;
    this.disposed = true;
    if (this.workerTransport) {
      await this.workerTransport.dispose();
    }
  }
  static hasWorkerConfig() {
    return Boolean(defaults.workerFactory || defaults.workerBundleUrl);
  }
  static async createWorkerTransport() {
    const port = defaults.workerFactory ? await defaults.workerFactory() : await createNodeExcelWorkerPort(defaults.workerBundleUrl);
    return new ExcelWorkerTransport(port);
  }
  assertNotDisposed() {
    if (this.disposed) throw new Error("ExcelWorkbook has been disposed");
  }
};
__name(_ExcelWorkbook, "ExcelWorkbook");
var ExcelWorkbook = _ExcelWorkbook;
function toCoreLoadOptions(opts) {
  return {
    workbookId: opts.workbookId
  };
}
__name(toCoreLoadOptions, "toCoreLoadOptions");
var _ExcelWorksheetCollection22 = class _ExcelWorksheetCollection23 {
  constructor(workbook) {
    __publicField(this, "workbook", workbook);
  }
  async items() {
    const sheets = await this.workbook.executeCode(`
      return workbook.worksheets.items().map((sheet) => ({ id: sheet.id(), name: sheet.name() }));
    `);
    return sheets.map((sheet) => new ExcelWorksheet2(this.workbook, sheet.name, sheet.id));
  }
  getItem(nameOrId) {
    return new ExcelWorksheet2(this.workbook, nameOrId);
  }
  async getItemOrNullObject(nameOrId) {
    const exists = await this.workbook.executeCode(
      `
      return workbook.worksheets.getItemOrNullObject(args.nameOrId) !== null;
    `,
      { nameOrId }
    );
    return exists ? new ExcelWorksheet2(this.workbook, nameOrId) : null;
  }
  async add(name) {
    const sheet = await this.workbook.executeCode(
      `
      const sheet = workbook.worksheets.add(args.name);
      return { id: sheet.id(), name: sheet.name() };
    `,
      { name }
    );
    return new ExcelWorksheet2(this.workbook, sheet.name, sheet.id);
  }
  async deleteItem(nameOrId) {
    await this.workbook.executeCode(`workbook.worksheets.deleteItem(args.nameOrId);`, { nameOrId });
  }
  async move(nameOrId, toIndex) {
    await this.workbook.executeCode(`workbook.worksheets.move(args.nameOrId, args.toIndex);`, {
      nameOrId,
      toIndex
    });
  }
  async copy(nameOrId, newName) {
    const sheet = await this.workbook.executeCode(
      `
      const sheet = workbook.worksheets.copy(args.nameOrId, args.newName);
      return { id: sheet.id(), name: sheet.name() };
    `,
      { nameOrId, newName }
    );
    return new ExcelWorksheet2(this.workbook, sheet.name, sheet.id);
  }
};
__name(_ExcelWorksheetCollection22, "ExcelWorksheetCollection");
var ExcelWorksheetCollection2 = _ExcelWorksheetCollection22;
var _ExcelWorksheet22 = class _ExcelWorksheet23 {
  constructor(workbook, nameOrId, knownId) {
    __publicField(this, "workbook", workbook);
    __publicField(this, "nameOrId", nameOrId);
    __publicField(this, "knownId", knownId);
    __publicField(this, "tables");
    __publicField(this, "hyperlinks");
    __publicField(this, "comments");
    __publicField(this, "threadedComments");
    __publicField(this, "dataValidations");
    __publicField(this, "conditionalFormats");
    __publicField(this, "drawings");
    __publicField(this, "charts");
    __publicField(this, "images");
    __publicField(this, "shapes");
    this.tables = new ExcelTableCollection2(workbook, nameOrId);
    this.hyperlinks = new ExcelHyperlinkCollection2(workbook, nameOrId);
    this.comments = new ExcelCommentCollection2(workbook, nameOrId);
    this.threadedComments = new ExcelThreadedCommentCollection2(workbook, nameOrId);
    this.dataValidations = new ExcelDataValidationCollection2(workbook, nameOrId);
    this.conditionalFormats = new ExcelConditionalFormatCollection2(workbook, nameOrId);
    this.drawings = new ExcelDrawingCollection2(workbook, nameOrId);
    this.charts = new ExcelChartCollection2(workbook, nameOrId);
    this.images = new ExcelImageCollection2(workbook, nameOrId);
    this.shapes = new ExcelShapeCollection2(workbook, nameOrId);
  }
  async id() {
    if (this.knownId) return this.knownId;
    return this.run(`return sheet.id();`);
  }
  async name() {
    return this.run(`return sheet.name();`);
  }
  async rename(name) {
    await this.run(`sheet.rename(args.name);`, { name });
  }
  async visibility() {
    return this.run(`return sheet.visibility();`);
  }
  async setVisibility(visibility) {
    await this.run(`sheet.setVisibility(args.visibility);`, { visibility });
  }
  async path() {
    return this.run(`return sheet.path();`);
  }
  async dimension() {
    return this.run(`return sheet.dimension();`);
  }
  getRange(address) {
    return new ExcelRange2(this.workbook, this.nameOrId, address);
  }
  getCell(address) {
    return new ExcelCell2(this.workbook, this.nameOrId, address);
  }
  async getUsedRange() {
    const address = await this.run(`
      const range = sheet.getUsedRange();
      return range ? range.address() : null;
    `);
    return address ? this.getRange(address) : null;
  }
  async cells() {
    return this.run(`return sheet.cells();`);
  }
  async sheetViews() {
    return this.run(`return sheet.sheetViews();`);
  }
  async setSheetViews(sheetViews) {
    await this.run(`sheet.setSheetViews(args.sheetViews);`, { sheetViews });
  }
  async columns() {
    return this.run(`return sheet.columns();`);
  }
  async rows() {
    return this.run(`return sheet.rows();`);
  }
  async mergedRanges() {
    return this.run(`return sheet.mergedRanges();`);
  }
  async insertRows(rowIndex, count = 1) {
    await this.run(`sheet.insertRows(args.rowIndex, args.count);`, { rowIndex, count });
  }
  async deleteRows(rowIndex, count = 1) {
    await this.run(`sheet.deleteRows(args.rowIndex, args.count);`, { rowIndex, count });
  }
  async insertColumns(columnIndex, count = 1) {
    await this.run(`sheet.insertColumns(args.columnIndex, args.count);`, { columnIndex, count });
  }
  async deleteColumns(columnIndex, count = 1) {
    await this.run(`sheet.deleteColumns(args.columnIndex, args.count);`, { columnIndex, count });
  }
  async moveRows(rowIndex, count, beforeRowIndex) {
    await this.run(`sheet.moveRows(args.rowIndex, args.count, args.beforeRowIndex);`, {
      rowIndex,
      count,
      beforeRowIndex
    });
  }
  async moveColumns(columnIndex, count, beforeColumnIndex) {
    await this.run(
      `sheet.moveColumns(args.columnIndex, args.count, args.beforeColumnIndex);`,
      { columnIndex, count, beforeColumnIndex }
    );
  }
  async toModel() {
    return this.run(`return sheet.toModel();`);
  }
  run(code, args) {
    return this.workbook.executeCode(
      `
      const sheet = workbook.worksheets.getItem(args.nameOrId);
      ${code}
    `,
      __spreadProps(__spreadValues({}, args != null ? args : {}), { nameOrId: this.nameOrId })
    );
  }
};
__name(_ExcelWorksheet22, "ExcelWorksheet");
var ExcelWorksheet2 = _ExcelWorksheet22;
var _ExcelRange22 = class _ExcelRange23 {
  constructor(workbook, sheetNameOrId, rangeAddress) {
    __publicField(this, "workbook", workbook);
    __publicField(this, "sheetNameOrId", sheetNameOrId);
    __publicField(this, "rangeAddress", rangeAddress);
    __publicField(this, "format");
    this.format = new ExcelRangeFormat2(this);
  }
  async address() {
    return this.run(`return range.address();`);
  }
  async rowIndex() {
    return this.run(`return range.rowIndex();`);
  }
  async columnIndex() {
    return this.run(`return range.columnIndex();`);
  }
  async rowCount() {
    return this.run(`return range.rowCount();`);
  }
  async columnCount() {
    return this.run(`return range.columnCount();`);
  }
  async values() {
    return this.run(`return range.values();`);
  }
  async formulas() {
    return this.run(`return range.formulas();`);
  }
  async text() {
    return this.run(`return range.text();`);
  }
  async valueTypes() {
    return this.run(`return range.valueTypes();`);
  }
  async rawValues() {
    return this.run(`return range.rawValues();`);
  }
  async styleIds() {
    return this.run(`return range.styleIds();`);
  }
  async setStyleId(styleId) {
    await this.run(`range.setStyleId(args.styleId);`, { styleId });
  }
  async rowHeights() {
    return this.run(`return range.rowHeights();`);
  }
  async setRowHeight(height) {
    await this.run(`range.setRowHeight(args.height);`, { height });
  }
  async columnWidths() {
    return this.run(`return range.columnWidths();`);
  }
  async setColumnWidth(width) {
    await this.run(`range.setColumnWidth(args.width);`, { width });
  }
  async merge() {
    await this.run(`range.merge();`);
  }
  async unmerge() {
    await this.run(`range.unmerge();`);
  }
  async setValues(values) {
    await this.run(`range.setValues(args.values);`, { values });
  }
  async setRichText(runs) {
    await this.run(`range.setRichText(args.runs);`, { runs });
  }
  async setFormulas(formulas) {
    await this.run(`range.setFormulas(args.formulas);`, { formulas });
  }
  async clear() {
    await this.run(`range.clear();`);
  }
  getCell(rowOffset, columnOffset) {
    return new ExcelCell2(this.workbook, this.sheetNameOrId, this.rangeAddress, rowOffset, columnOffset);
  }
  getRow(rowOffset) {
    return new ExcelDerivedRange(this.workbook, this.sheetNameOrId, this.rangeAddress, `range.getRow(args.rowOffset)`, {
      rowOffset
    });
  }
  getColumn(columnOffset) {
    return new ExcelDerivedRange(
      this.workbook,
      this.sheetNameOrId,
      this.rangeAddress,
      `range.getColumn(args.columnOffset)`,
      { columnOffset }
    );
  }
  resize(rowCount, columnCount) {
    return new ExcelDerivedRange(
      this.workbook,
      this.sheetNameOrId,
      this.rangeAddress,
      `range.resize(args.rowCount, args.columnCount)`,
      { rowCount, columnCount }
    );
  }
  offset(rowOffset, columnOffset, rowCount, columnCount) {
    return new ExcelDerivedRange(
      this.workbook,
      this.sheetNameOrId,
      this.rangeAddress,
      `range.offset(args.rowOffset, args.columnOffset, args.rowCount, args.columnCount)`,
      { rowOffset, columnOffset, rowCount, columnCount }
    );
  }
  slice(rowOffset, columnOffset, rowCount, columnCount) {
    return new ExcelDerivedRange(
      this.workbook,
      this.sheetNameOrId,
      this.rangeAddress,
      `range.slice(args.rowOffset, args.columnOffset, args.rowCount, args.columnCount)`,
      { rowOffset, columnOffset, rowCount, columnCount }
    );
  }
  async toModel() {
    return this.run(`return range.toModel();`);
  }
  runFormat(code, args) {
    return this.run(code, args);
  }
  run(code, args) {
    return this.workbook.executeCode(
      `
      const sheet = workbook.worksheets.getItem(args.sheetNameOrId);
      const range = sheet.getRange(args.rangeAddress);
      ${code}
    `,
      __spreadProps(__spreadValues({}, args != null ? args : {}), { sheetNameOrId: this.sheetNameOrId, rangeAddress: this.rangeAddress })
    );
  }
};
__name(_ExcelRange22, "ExcelRange");
var ExcelRange2 = _ExcelRange22;
var _ExcelDerivedRange = class _ExcelDerivedRange2 extends ExcelRange2 {
  constructor(workbook, sheetNameOrId, rangeAddress, expression, expressionArgs) {
    super(workbook, sheetNameOrId, rangeAddress);
    __publicField(this, "expression", expression);
    __publicField(this, "expressionArgs", expressionArgs);
  }
  run(code, args) {
    return this.workbook.executeCode(
      `
      const sheet = workbook.worksheets.getItem(args.sheetNameOrId);
      let range = sheet.getRange(args.rangeAddress);
      range = ${this.expression};
      ${code}
    `,
      __spreadProps(__spreadValues(__spreadValues({}, args != null ? args : {}), this.expressionArgs), { sheetNameOrId: this.sheetNameOrId, rangeAddress: this.rangeAddress })
    );
  }
};
__name(_ExcelDerivedRange, "ExcelDerivedRange");
var ExcelDerivedRange = _ExcelDerivedRange;
var _ExcelCell22 = class _ExcelCell23 {
  constructor(workbook, sheetNameOrId, cellAddressOrRangeAddress, rowOffset, columnOffset) {
    __publicField(this, "workbook", workbook);
    __publicField(this, "sheetNameOrId", sheetNameOrId);
    __publicField(this, "cellAddressOrRangeAddress", cellAddressOrRangeAddress);
    __publicField(this, "rowOffset", rowOffset);
    __publicField(this, "columnOffset", columnOffset);
  }
  async address() {
    return this.run(`return cell.address();`);
  }
  async value() {
    return this.run(`return cell.value();`);
  }
  async formula() {
    return this.run(`return cell.formula();`);
  }
  async text() {
    return this.run(`return cell.text();`);
  }
  async valueType() {
    return this.run(`return cell.valueType();`);
  }
  async rawValue() {
    return this.run(`return cell.rawValue();`);
  }
  async styleId() {
    return this.run(`return cell.styleId();`);
  }
  async setStyleId(styleId) {
    await this.run(`cell.setStyleId(args.styleId);`, { styleId });
  }
  async setValue(value) {
    await this.run(`cell.setValue(args.value);`, { value });
  }
  async setFormula(formula) {
    await this.run(`cell.setFormula(args.formula);`, { formula });
  }
  async clear() {
    await this.run(`cell.clear();`);
  }
  toRange() {
    return new ExcelRange2(this.workbook, this.sheetNameOrId, this.cellAddressOrRangeAddress);
  }
  async toModel() {
    return this.run(`return cell.toModel();`);
  }
  run(code, args) {
    const isOffsetCell = this.rowOffset !== void 0 && this.columnOffset !== void 0;
    return this.workbook.executeCode(
      `
      const sheet = workbook.worksheets.getItem(args.sheetNameOrId);
      const cell = args.isOffsetCell
        ? sheet.getRange(args.address).getCell(args.rowOffset, args.columnOffset)
        : sheet.getCell(args.address);
      ${code}
    `,
      __spreadProps(__spreadValues({}, args != null ? args : {}), {
        sheetNameOrId: this.sheetNameOrId,
        address: this.cellAddressOrRangeAddress,
        isOffsetCell,
        rowOffset: this.rowOffset,
        columnOffset: this.columnOffset
      })
    );
  }
};
__name(_ExcelCell22, "ExcelCell");
var ExcelCell2 = _ExcelCell22;
var _ExcelRangeFormat22 = class _ExcelRangeFormat23 {
  constructor(range) {
    __publicField(this, "range", range);
    __publicField(this, "font");
    __publicField(this, "fill");
    __publicField(this, "border");
    __publicField(this, "alignment");
    this.font = new ExcelRangeFontFormat2(range);
    this.fill = new ExcelRangeFillFormat2(range);
    this.border = new ExcelRangeBorderFormat2(range);
    this.alignment = new ExcelRangeAlignmentFormat2(range);
  }
  numberFormatCode() {
    return this.range.runFormat(`return range.format.numberFormatCode();`);
  }
  setNumberFormatCode(code) {
    return this.range.runFormat(`range.format.setNumberFormatCode(args.code);`, { code });
  }
};
__name(_ExcelRangeFormat22, "ExcelRangeFormat");
var ExcelRangeFormat2 = _ExcelRangeFormat22;
var _ExcelRangeFontFormat22 = class _ExcelRangeFontFormat23 {
  constructor(range) {
    __publicField(this, "range", range);
  }
  value() {
    return this.range.runFormat(`return range.format.font.value();`);
  }
  setValue(font) {
    return this.range.runFormat(`range.format.font.setValue(args.font);`, { font });
  }
  bold() {
    return this.range.runFormat(`return range.format.font.bold();`);
  }
  setBold(value) {
    return this.range.runFormat(`range.format.font.setBold(args.value);`, { value });
  }
  italic() {
    return this.range.runFormat(`return range.format.font.italic();`);
  }
  setItalic(value) {
    return this.range.runFormat(`range.format.font.setItalic(args.value);`, { value });
  }
  underline() {
    return this.range.runFormat(`return range.format.font.underline();`);
  }
  setUnderline(value) {
    return this.range.runFormat(`range.format.font.setUnderline(args.value);`, { value });
  }
  color() {
    return this.range.runFormat(`return range.format.font.color();`);
  }
  setColor(color) {
    return this.range.runFormat(`range.format.font.setColor(args.color);`, { color });
  }
  size() {
    return this.range.runFormat(`return range.format.font.size();`);
  }
  setSize(size) {
    return this.range.runFormat(`range.format.font.setSize(args.size);`, { size });
  }
  name() {
    return this.range.runFormat(`return range.format.font.name();`);
  }
  setName(name) {
    return this.range.runFormat(`range.format.font.setName(args.name);`, { name });
  }
};
__name(_ExcelRangeFontFormat22, "ExcelRangeFontFormat");
var ExcelRangeFontFormat2 = _ExcelRangeFontFormat22;
var _ExcelRangeFillFormat22 = class _ExcelRangeFillFormat23 {
  constructor(range) {
    __publicField(this, "range", range);
  }
  value() {
    return this.range.runFormat(`return range.format.fill.value();`);
  }
  setValue(fill) {
    return this.range.runFormat(`range.format.fill.setValue(args.fill);`, { fill });
  }
  patternType() {
    return this.range.runFormat(`return range.format.fill.patternType();`);
  }
  setPatternType(patternType) {
    return this.range.runFormat(`range.format.fill.setPatternType(args.patternType);`, { patternType });
  }
  foregroundColor() {
    return this.range.runFormat(`return range.format.fill.foregroundColor();`);
  }
  setForegroundColor(color) {
    return this.range.runFormat(`range.format.fill.setForegroundColor(args.color);`, { color });
  }
  backgroundColor() {
    return this.range.runFormat(`return range.format.fill.backgroundColor();`);
  }
  setBackgroundColor(color) {
    return this.range.runFormat(`range.format.fill.setBackgroundColor(args.color);`, { color });
  }
};
__name(_ExcelRangeFillFormat22, "ExcelRangeFillFormat");
var ExcelRangeFillFormat2 = _ExcelRangeFillFormat22;
var _ExcelRangeBorderFormat22 = class _ExcelRangeBorderFormat23 {
  constructor(range) {
    __publicField(this, "range", range);
  }
  value() {
    return this.range.runFormat(`return range.format.border.value();`);
  }
  setValue(border) {
    return this.range.runFormat(`range.format.border.setValue(args.border);`, { border });
  }
  setLeft(side) {
    return this.range.runFormat(`range.format.border.setLeft(args.side);`, { side });
  }
  setRight(side) {
    return this.range.runFormat(`range.format.border.setRight(args.side);`, { side });
  }
  setTop(side) {
    return this.range.runFormat(`range.format.border.setTop(args.side);`, { side });
  }
  setBottom(side) {
    return this.range.runFormat(`range.format.border.setBottom(args.side);`, { side });
  }
};
__name(_ExcelRangeBorderFormat22, "ExcelRangeBorderFormat");
var ExcelRangeBorderFormat2 = _ExcelRangeBorderFormat22;
var _ExcelRangeAlignmentFormat22 = class _ExcelRangeAlignmentFormat23 {
  constructor(range) {
    __publicField(this, "range", range);
  }
  value() {
    return this.range.runFormat(`return range.format.alignment.value();`);
  }
  setValue(alignment) {
    return this.range.runFormat(`range.format.alignment.setValue(args.alignment);`, { alignment });
  }
  setHorizontal(horizontal) {
    return this.range.runFormat(`range.format.alignment.setHorizontal(args.horizontal);`, { horizontal });
  }
  setVertical(vertical) {
    return this.range.runFormat(`range.format.alignment.setVertical(args.vertical);`, { vertical });
  }
  setWrapText(wrapText) {
    return this.range.runFormat(`range.format.alignment.setWrapText(args.wrapText);`, { wrapText });
  }
};
__name(_ExcelRangeAlignmentFormat22, "ExcelRangeAlignmentFormat");
var ExcelRangeAlignmentFormat2 = _ExcelRangeAlignmentFormat22;
var _ExcelTableCollection22 = class _ExcelTableCollection23 {
  constructor(workbook, sheetNameOrId) {
    __publicField(this, "workbook", workbook);
    __publicField(this, "sheetNameOrId", sheetNameOrId);
  }
  async items() {
    const tables = await runSheetCollection(this.workbook, this.sheetNameOrId, "tables", "toModel");
    return tables.map((table) => {
      var _a, _b;
      return new ExcelTable2(this.workbook, this.sheetNameOrId, (_b = (_a = table.name) != null ? _a : table.displayName) != null ? _b : "");
    });
  }
  getItem(nameOrDisplayName) {
    return new ExcelTable2(this.workbook, this.sheetNameOrId, nameOrDisplayName);
  }
  async getItemOrNullObject(nameOrDisplayName) {
    return await sheetCollectionItemExists(this.workbook, this.sheetNameOrId, "tables", nameOrDisplayName) ? this.getItem(nameOrDisplayName) : null;
  }
  async add(model) {
    var _a, _b;
    const added = await runSheetCollection(this.workbook, this.sheetNameOrId, "tables", "add", { model });
    return new ExcelTable2(this.workbook, this.sheetNameOrId, (_b = (_a = added.name) != null ? _a : added.displayName) != null ? _b : "");
  }
  async delete(nameOrDisplayName) {
    await runSheetCollection(this.workbook, this.sheetNameOrId, "tables", "delete", { key: nameOrDisplayName });
  }
  async toModel() {
    return runSheetCollection(this.workbook, this.sheetNameOrId, "tables", "toModel");
  }
};
__name(_ExcelTableCollection22, "ExcelTableCollection");
var ExcelTableCollection2 = _ExcelTableCollection22;
var _ExcelTable22 = class _ExcelTable23 {
  constructor(workbook, sheetNameOrId, nameOrDisplayName) {
    __publicField(this, "workbook", workbook);
    __publicField(this, "sheetNameOrId", sheetNameOrId);
    __publicField(this, "nameOrDisplayName", nameOrDisplayName);
    __publicField(this, "columns");
    __publicField(this, "style");
    this.columns = new ExcelTableColumnCollection2(workbook, sheetNameOrId, nameOrDisplayName);
    this.style = new ExcelTableStyle2(workbook, sheetNameOrId, nameOrDisplayName);
  }
  async id() {
    return this.run(`return item.id();`);
  }
  async name() {
    return this.run(`return item.name();`);
  }
  async displayName() {
    return this.run(`return item.displayName();`);
  }
  async setName(name) {
    await this.run(`item.setName(args.name);`, { name });
  }
  async setDisplayName(displayName) {
    await this.run(`item.setDisplayName(args.displayName);`, { displayName });
  }
  async rangeAddress() {
    return this.run(`return item.rangeAddress();`);
  }
  async setRange(address) {
    await this.run(`item.setRange(args.address);`, { address });
  }
  async resize(address) {
    await this.run(`item.resize(args.address);`, { address });
  }
  async autoFilterRangeAddress() {
    return this.run(`return item.autoFilterRangeAddress();`);
  }
  async setAutoFilterRange(address) {
    await this.run(`item.setAutoFilterRange(args.address);`, { address });
  }
  async headerRowCount() {
    return this.run(`return item.headerRowCount();`);
  }
  async setHeaderRowCount(count) {
    await this.run(`item.setHeaderRowCount(args.count);`, { count });
  }
  async totalsRowCount() {
    return this.run(`return item.totalsRowCount();`);
  }
  async setTotalsRowCount(count) {
    await this.run(`item.setTotalsRowCount(args.count);`, { count });
  }
  async totalsRowShown() {
    return this.run(`return item.totalsRowShown();`);
  }
  async setTotalsRowShown(value) {
    await this.run(`item.setTotalsRowShown(args.value);`, { value });
  }
  async autoFilter() {
    return this.run(`return item.autoFilter();`);
  }
  async setAutoFilter(model) {
    await this.run(`item.setAutoFilter(args.model);`, { model });
  }
  async sortState() {
    return this.run(`return item.sortState();`);
  }
  async setSortState(sortState) {
    await this.run(`item.setSortState(args.sortState);`, { sortState });
  }
  async toModel() {
    return this.run(`return item.toModel();`);
  }
  async delete() {
    await this.run(`item.delete();`);
  }
  run(code, args) {
    return runSheetItem(this.workbook, this.sheetNameOrId, "tables", this.nameOrDisplayName, code, args);
  }
};
__name(_ExcelTable22, "ExcelTable");
var ExcelTable2 = _ExcelTable22;
var _ExcelTableColumnCollection22 = class _ExcelTableColumnCollection23 {
  constructor(workbook, sheetNameOrId, tableNameOrDisplayName) {
    __publicField(this, "workbook", workbook);
    __publicField(this, "sheetNameOrId", sheetNameOrId);
    __publicField(this, "tableNameOrDisplayName", tableNameOrDisplayName);
  }
  async items() {
    const columns = await this.run(`return item.columns.toModel();`);
    return columns.map((column) => new ExcelTableColumn2(this.workbook, this.sheetNameOrId, this.tableNameOrDisplayName, column.id));
  }
  getItem(nameOrId) {
    return new ExcelTableColumn2(this.workbook, this.sheetNameOrId, this.tableNameOrDisplayName, nameOrId);
  }
  async add(model) {
    const added = await this.run(`return item.columns.add(args.model).toModel();`, { model });
    return this.getItem(added.id);
  }
  async delete(nameOrId) {
    await this.run(`item.columns.delete(args.nameOrId);`, { nameOrId });
  }
  async deleteItem(nameOrId) {
    await this.run(`item.columns.deleteItem(args.nameOrId);`, { nameOrId });
  }
  async toModel() {
    return this.run(`return item.columns.toModel();`);
  }
  run(code, args) {
    return runSheetItem(this.workbook, this.sheetNameOrId, "tables", this.tableNameOrDisplayName, code, args);
  }
};
__name(_ExcelTableColumnCollection22, "ExcelTableColumnCollection");
var ExcelTableColumnCollection2 = _ExcelTableColumnCollection22;
var _ExcelTableColumn22 = class _ExcelTableColumn23 {
  constructor(workbook, sheetNameOrId, tableNameOrDisplayName, nameOrId) {
    __publicField(this, "workbook", workbook);
    __publicField(this, "sheetNameOrId", sheetNameOrId);
    __publicField(this, "tableNameOrDisplayName", tableNameOrDisplayName);
    __publicField(this, "nameOrId", nameOrId);
  }
  async id() {
    return this.run(`return column.id();`);
  }
  async name() {
    return this.run(`return column.name();`);
  }
  async setName(name) {
    await this.run(`column.setName(args.name);`, { name });
  }
  async totalsRowLabel() {
    return this.run(`return column.totalsRowLabel();`);
  }
  async setTotalsRowLabel(label) {
    await this.run(`column.setTotalsRowLabel(args.label);`, { label });
  }
  async totalsRowFunction() {
    return this.run(`return column.totalsRowFunction();`);
  }
  async setTotalsRowFunction(fn2) {
    await this.run(`column.setTotalsRowFunction(args.fn);`, { fn: fn2 });
  }
  async toModel() {
    return this.run(`return column.toModel();`);
  }
  async delete() {
    await this.run(`column.delete();`);
  }
  run(code, args) {
    return this.workbook.executeCode(
      `
      const sheet = workbook.worksheets.getItem(args.sheetNameOrId);
      const table = sheet.tables.getItem(args.tableNameOrDisplayName);
      const column = table.columns.getItem(args.nameOrId);
      ${code}
    `,
      __spreadProps(__spreadValues({}, args != null ? args : {}), { sheetNameOrId: this.sheetNameOrId, tableNameOrDisplayName: this.tableNameOrDisplayName, nameOrId: this.nameOrId })
    );
  }
};
__name(_ExcelTableColumn22, "ExcelTableColumn");
var ExcelTableColumn2 = _ExcelTableColumn22;
var _ExcelTableStyle22 = class _ExcelTableStyle23 {
  constructor(workbook, sheetNameOrId, tableNameOrDisplayName) {
    __publicField(this, "workbook", workbook);
    __publicField(this, "sheetNameOrId", sheetNameOrId);
    __publicField(this, "tableNameOrDisplayName", tableNameOrDisplayName);
  }
  async toModel() {
    return runSheetItem(
      this.workbook,
      this.sheetNameOrId,
      "tables",
      this.tableNameOrDisplayName,
      `return item.style.toModel();`
    );
  }
  async name() {
    return this.run(`return item.style.name();`);
  }
  async setName(name) {
    await this.run(`item.style.setName(args.name);`, { name });
  }
  async showFirstColumn() {
    return this.run(`return item.style.showFirstColumn();`);
  }
  async setShowFirstColumn(value) {
    await this.run(`item.style.setShowFirstColumn(args.value);`, { value });
  }
  async showLastColumn() {
    return this.run(`return item.style.showLastColumn();`);
  }
  async setShowLastColumn(value) {
    await this.run(`item.style.setShowLastColumn(args.value);`, { value });
  }
  async showRowStripes() {
    return this.run(`return item.style.showRowStripes();`);
  }
  async setShowRowStripes(value) {
    await this.run(`item.style.setShowRowStripes(args.value);`, { value });
  }
  async showColumnStripes() {
    return this.run(`return item.style.showColumnStripes();`);
  }
  async setShowColumnStripes(value) {
    await this.run(`item.style.setShowColumnStripes(args.value);`, { value });
  }
  run(code, args) {
    return runSheetItem(this.workbook, this.sheetNameOrId, "tables", this.tableNameOrDisplayName, code, args);
  }
};
__name(_ExcelTableStyle22, "ExcelTableStyle");
var ExcelTableStyle2 = _ExcelTableStyle22;
var _SimpleSheetCollection = class _SimpleSheetCollection2 {
  constructor(workbook, sheetNameOrId, collection, wrap) {
    __publicField(this, "workbook", workbook);
    __publicField(this, "sheetNameOrId", sheetNameOrId);
    __publicField(this, "collection", collection);
    __publicField(this, "wrap", wrap);
  }
  async items() {
    const models = await this.toModel();
    return models.map((model) => this.wrap(this.workbook, this.sheetNameOrId, model));
  }
  getItem(key2) {
    return this.wrap(this.workbook, this.sheetNameOrId, { ref: key2, sqref: key2 });
  }
  async getItemOrNullObject(key2) {
    return await sheetCollectionItemExists(this.workbook, this.sheetNameOrId, this.collection, key2) ? this.getItem(key2) : null;
  }
  async add(model) {
    const added = await runSheetCollection(this.workbook, this.sheetNameOrId, this.collection, "add", { model });
    return this.wrap(this.workbook, this.sheetNameOrId, added);
  }
  async delete(key2) {
    await runSheetCollection(this.workbook, this.sheetNameOrId, this.collection, "delete", { key: key2 });
  }
  async toModel() {
    return runSheetCollection(this.workbook, this.sheetNameOrId, this.collection, "toModel");
  }
};
__name(_SimpleSheetCollection, "SimpleSheetCollection");
var SimpleSheetCollection = _SimpleSheetCollection;
var _SimpleSheetItem = class _SimpleSheetItem2 {
  constructor(workbook, sheetNameOrId, key2) {
    __publicField(this, "workbook", workbook);
    __publicField(this, "sheetNameOrId", sheetNameOrId);
    __publicField(this, "key", key2);
  }
  async toModel() {
    return runSheetItem(this.workbook, this.sheetNameOrId, this.collection, this.key, `return item.toModel();`);
  }
  async delete() {
    await runSheetItem(this.workbook, this.sheetNameOrId, this.collection, this.key, `item.delete();`);
  }
  run(code, args) {
    return runSheetItem(this.workbook, this.sheetNameOrId, this.collection, this.key, code, args);
  }
};
__name(_SimpleSheetItem, "SimpleSheetItem");
var SimpleSheetItem = _SimpleSheetItem;
var _ReadonlySheetCollection = class _ReadonlySheetCollection2 {
  constructor(workbook, sheetNameOrId, collection, wrap) {
    __publicField(this, "workbook", workbook);
    __publicField(this, "sheetNameOrId", sheetNameOrId);
    __publicField(this, "collection", collection);
    __publicField(this, "wrap", wrap);
  }
  async items() {
    const models = await this.toModel();
    return models.map((_2, index) => this.wrap(this.workbook, this.sheetNameOrId, index));
  }
  async toModel() {
    return runSheetCollection(this.workbook, this.sheetNameOrId, this.collection, "toModel");
  }
};
__name(_ReadonlySheetCollection, "ReadonlySheetCollection");
var ReadonlySheetCollection = _ReadonlySheetCollection;
var _IndexedSheetItem = class _IndexedSheetItem2 {
  constructor(workbook, sheetNameOrId, indexOrName) {
    __publicField(this, "workbook", workbook);
    __publicField(this, "sheetNameOrId", sheetNameOrId);
    __publicField(this, "indexOrName", indexOrName);
  }
  async toModel() {
    return this.run(`return item.toModel();`);
  }
  run(code, args) {
    return this.workbook.executeCode(
      `
      const sheet = workbook.worksheets.getItem(args.sheetNameOrId);
      const collection = sheet[args.collection];
      const item = typeof args.indexOrName === 'number' ? collection.items()[args.indexOrName] : collection.getItem(args.indexOrName);
      ${code}
    `,
      __spreadProps(__spreadValues({}, args != null ? args : {}), { sheetNameOrId: this.sheetNameOrId, collection: this.collection, indexOrName: this.indexOrName })
    );
  }
};
__name(_IndexedSheetItem, "IndexedSheetItem");
var IndexedSheetItem = _IndexedSheetItem;
var _ExcelHyperlinkCollection22 = class _ExcelHyperlinkCollection23 extends SimpleSheetCollection {
  constructor(workbook, sheetNameOrId) {
    super(workbook, sheetNameOrId, "hyperlinks", (workbook2, sheetNameOrId2, model) => new ExcelHyperlink2(workbook2, sheetNameOrId2, model.ref));
  }
};
__name(_ExcelHyperlinkCollection22, "ExcelHyperlinkCollection");
var ExcelHyperlinkCollection2 = _ExcelHyperlinkCollection22;
var _ExcelHyperlink22 = class _ExcelHyperlink23 extends SimpleSheetItem {
  constructor() {
    super(...arguments);
    __publicField(this, "collection", "hyperlinks");
  }
  async ref() {
    return this.run(`return item.ref();`);
  }
  async setRef(ref) {
    await this.run(`item.setRef(args.ref);`, { ref });
    this.key = ref;
  }
  async target() {
    return this.run(`return item.target();`);
  }
  async targetMode() {
    return this.run(`return item.targetMode();`);
  }
  async display() {
    return this.run(`return item.display();`);
  }
  async setDisplay(display) {
    await this.run(`item.setDisplay(args.display);`, { display });
  }
  async setLocation(location) {
    await this.run(`item.setLocation(args.location);`, { location });
  }
};
__name(_ExcelHyperlink22, "ExcelHyperlink");
var ExcelHyperlink2 = _ExcelHyperlink22;
var _ExcelCommentCollection22 = class _ExcelCommentCollection23 extends SimpleSheetCollection {
  constructor(workbook, sheetNameOrId) {
    super(workbook, sheetNameOrId, "comments", (workbook2, sheetNameOrId2, model) => new ExcelComment2(workbook2, sheetNameOrId2, model.ref));
  }
};
__name(_ExcelCommentCollection22, "ExcelCommentCollection");
var ExcelCommentCollection2 = _ExcelCommentCollection22;
var _ExcelComment22 = class _ExcelComment23 extends SimpleSheetItem {
  constructor() {
    super(...arguments);
    __publicField(this, "collection", "comments");
  }
  async ref() {
    return this.run(`return item.ref();`);
  }
  async setRef(ref) {
    await this.run(`item.setRef(args.ref);`, { ref });
    this.key = ref;
  }
  async text() {
    return this.run(`return item.text();`);
  }
  async setText(text) {
    await this.run(`item.setText(args.text);`, { text });
  }
};
__name(_ExcelComment22, "ExcelComment");
var ExcelComment2 = _ExcelComment22;
var _ExcelThreadedCommentCollection22 = class _ExcelThreadedCommentCollection23 extends SimpleSheetCollection {
  constructor(workbook, sheetNameOrId) {
    super(workbook, sheetNameOrId, "threadedComments", (workbook2, sheetNameOrId2, model) => new ExcelThreadedComment2(workbook2, sheetNameOrId2, model.ref));
  }
};
__name(_ExcelThreadedCommentCollection22, "ExcelThreadedCommentCollection");
var ExcelThreadedCommentCollection2 = _ExcelThreadedCommentCollection22;
var _ExcelThreadedComment22 = class _ExcelThreadedComment23 extends SimpleSheetItem {
  constructor() {
    super(...arguments);
    __publicField(this, "collection", "threadedComments");
  }
  async ref() {
    return this.run(`return item.ref();`);
  }
  async setRef(ref) {
    await this.run(`item.setRef(args.ref);`, { ref });
    this.key = ref;
  }
  async text() {
    return this.run(`return item.text();`);
  }
  async setText(text) {
    await this.run(`item.setText(args.text);`, { text });
  }
};
__name(_ExcelThreadedComment22, "ExcelThreadedComment");
var ExcelThreadedComment2 = _ExcelThreadedComment22;
var _ExcelDataValidationCollection22 = class _ExcelDataValidationCollection23 extends SimpleSheetCollection {
  constructor(workbook, sheetNameOrId) {
    super(workbook, sheetNameOrId, "dataValidations", (workbook2, sheetNameOrId2, model) => {
      var _a;
      return new ExcelDataValidation2(workbook2, sheetNameOrId2, (_a = model.sqref) != null ? _a : "");
    });
  }
};
__name(_ExcelDataValidationCollection22, "ExcelDataValidationCollection");
var ExcelDataValidationCollection2 = _ExcelDataValidationCollection22;
var _ExcelDataValidation22 = class _ExcelDataValidation23 extends SimpleSheetItem {
  constructor() {
    super(...arguments);
    __publicField(this, "collection", "dataValidations");
  }
  async rangeAddress() {
    return this.run(`return item.rangeAddress();`);
  }
  async setRange(address) {
    await this.run(`item.setRange(args.address);`, { address });
    this.key = address;
  }
  async type() {
    return this.run(`return item.type();`);
  }
  async setType(type) {
    await this.run(`item.setType(args.type);`, { type });
  }
  async operator() {
    return this.run(`return item.operator();`);
  }
  async setOperator(operator) {
    await this.run(`item.setOperator(args.operator);`, { operator });
  }
  async allowBlank() {
    return this.run(`return item.allowBlank();`);
  }
  async setAllowBlank(value) {
    await this.run(`item.setAllowBlank(args.value);`, { value });
  }
  async showDropDown() {
    return this.run(`return item.showDropDown();`);
  }
  async setShowDropDown(value) {
    await this.run(`item.setShowDropDown(args.value);`, { value });
  }
  async showInputMessage() {
    return this.run(`return item.showInputMessage();`);
  }
  async setShowInputMessage(value) {
    await this.run(`item.setShowInputMessage(args.value);`, { value });
  }
  async showErrorMessage() {
    return this.run(`return item.showErrorMessage();`);
  }
  async setShowErrorMessage(value) {
    await this.run(`item.setShowErrorMessage(args.value);`, { value });
  }
  async errorStyle() {
    return this.run(`return item.errorStyle();`);
  }
  async setErrorStyle(style) {
    await this.run(`item.setErrorStyle(args.style);`, { style });
  }
  async errorTitle() {
    return this.run(`return item.errorTitle();`);
  }
  async error() {
    return this.run(`return item.error();`);
  }
  async setError(title, message) {
    await this.run(`item.setError(args.title, args.message);`, { title, message });
  }
  async promptTitle() {
    return this.run(`return item.promptTitle();`);
  }
  async prompt() {
    return this.run(`return item.prompt();`);
  }
  async setPrompt(title, message) {
    await this.run(`item.setPrompt(args.title, args.message);`, { title, message });
  }
  async formula1() {
    return this.run(`return item.formula1();`);
  }
  async setFormula1(formula) {
    await this.run(`item.setFormula1(args.formula);`, { formula });
  }
  async formula2() {
    return this.run(`return item.formula2();`);
  }
  async setFormula2(formula) {
    await this.run(`item.setFormula2(args.formula);`, { formula });
  }
};
__name(_ExcelDataValidation22, "ExcelDataValidation");
var ExcelDataValidation2 = _ExcelDataValidation22;
var _ExcelConditionalFormatCollection22 = class _ExcelConditionalFormatCollection23 extends SimpleSheetCollection {
  constructor(workbook, sheetNameOrId) {
    super(workbook, sheetNameOrId, "conditionalFormats", (workbook2, sheetNameOrId2, model) => {
      var _a;
      return new ExcelConditionalFormat2(workbook2, sheetNameOrId2, (_a = model.sqref) != null ? _a : "");
    });
  }
};
__name(_ExcelConditionalFormatCollection22, "ExcelConditionalFormatCollection");
var ExcelConditionalFormatCollection2 = _ExcelConditionalFormatCollection22;
var _ExcelConditionalFormat22 = class _ExcelConditionalFormat23 extends SimpleSheetItem {
  constructor(workbook, sheetNameOrId, key2) {
    super(workbook, sheetNameOrId, key2);
    __publicField(this, "collection", "conditionalFormats");
    __publicField(this, "rules");
    this.rules = new ExcelConditionalFormatRuleCollection2(workbook, sheetNameOrId, key2);
  }
  async rangeAddress() {
    return this.run(`return item.rangeAddress();`);
  }
  async setRange(address) {
    await this.run(`item.setRange(args.address);`, { address });
    this.key = address;
    this.rules.formatKey = address;
  }
};
__name(_ExcelConditionalFormat22, "ExcelConditionalFormat");
var ExcelConditionalFormat2 = _ExcelConditionalFormat22;
var _ExcelConditionalFormatRuleCollection22 = class _ExcelConditionalFormatRuleCollection23 {
  constructor(workbook, sheetNameOrId, formatKey) {
    __publicField(this, "workbook", workbook);
    __publicField(this, "sheetNameOrId", sheetNameOrId);
    __publicField(this, "formatKey", formatKey);
  }
  async items() {
    const models = await this.toModel();
    return models.map((_2, index) => new ExcelConditionalFormatRule2(this.workbook, this.sheetNameOrId, this.formatKey, index));
  }
  getItem(index) {
    return new ExcelConditionalFormatRule2(this.workbook, this.sheetNameOrId, this.formatKey, index);
  }
  async getItemOrNullObject(index) {
    const exists = await this.workbook.executeCode(
      `
      const sheet = workbook.worksheets.getItem(args.sheetNameOrId);
      const format = sheet.conditionalFormats.getItem(args.formatKey);
      return format.rules.getItemOrNullObject(args.index) !== null;
    `,
      { sheetNameOrId: this.sheetNameOrId, formatKey: this.formatKey, index }
    );
    return exists ? this.getItem(index) : null;
  }
  async add(model) {
    const addedIndex = await this.workbook.executeCode(
      `
      const sheet = workbook.worksheets.getItem(args.sheetNameOrId);
      const format = sheet.conditionalFormats.getItem(args.formatKey);
      format.rules.add(args.model);
      return format.rules.items().length - 1;
    `,
      { sheetNameOrId: this.sheetNameOrId, formatKey: this.formatKey, model }
    );
    return this.getItem(addedIndex);
  }
  async delete(index) {
    await this.workbook.executeCode(
      `
      const sheet = workbook.worksheets.getItem(args.sheetNameOrId);
      const format = sheet.conditionalFormats.getItem(args.formatKey);
      format.rules.delete(args.index);
    `,
      { sheetNameOrId: this.sheetNameOrId, formatKey: this.formatKey, index }
    );
  }
  async toModel() {
    return this.workbook.executeCode(
      `
      const sheet = workbook.worksheets.getItem(args.sheetNameOrId);
      const format = sheet.conditionalFormats.getItem(args.formatKey);
      return format.rules.toModel();
    `,
      { sheetNameOrId: this.sheetNameOrId, formatKey: this.formatKey }
    );
  }
};
__name(_ExcelConditionalFormatRuleCollection22, "ExcelConditionalFormatRuleCollection");
var ExcelConditionalFormatRuleCollection2 = _ExcelConditionalFormatRuleCollection22;
var _ExcelConditionalFormatRule22 = class _ExcelConditionalFormatRule23 {
  constructor(workbook, sheetNameOrId, formatKey, index) {
    __publicField(this, "workbook", workbook);
    __publicField(this, "sheetNameOrId", sheetNameOrId);
    __publicField(this, "formatKey", formatKey);
    __publicField(this, "index", index);
  }
  async type() {
    return this.run(`return rule.type();`);
  }
  async setType(type) {
    await this.run(`rule.setType(args.type);`, { type });
  }
  async priority() {
    return this.run(`return rule.priority();`);
  }
  async setPriority(priority) {
    await this.run(`rule.setPriority(args.priority);`, { priority });
  }
  async operator() {
    return this.run(`return rule.operator();`);
  }
  async setOperator(operator) {
    await this.run(`rule.setOperator(args.operator);`, { operator });
  }
  async stopIfTrue() {
    return this.run(`return rule.stopIfTrue();`);
  }
  async setStopIfTrue(value) {
    await this.run(`rule.setStopIfTrue(args.value);`, { value });
  }
  async formulas() {
    return this.run(`return rule.formulas();`);
  }
  async setFormula(index, formula) {
    await this.run(`rule.setFormula(args.index, args.formula);`, { index, formula });
  }
  async addFormula(formula) {
    await this.run(`rule.addFormula(args.formula);`, { formula });
  }
  async deleteFormula(index) {
    await this.run(`rule.deleteFormula(args.index);`, { index });
  }
  async toModel() {
    return this.run(`return rule.toModel();`);
  }
  async delete() {
    await this.run(`rule.delete();`);
  }
  run(code, args) {
    return this.workbook.executeCode(
      `
      const sheet = workbook.worksheets.getItem(args.sheetNameOrId);
      const format = sheet.conditionalFormats.getItem(args.formatKey);
      const rule = format.rules.getItem(args.ruleIndex);
      ${code}
    `,
      __spreadProps(__spreadValues({}, args != null ? args : {}), { sheetNameOrId: this.sheetNameOrId, formatKey: this.formatKey, ruleIndex: this.index })
    );
  }
};
__name(_ExcelConditionalFormatRule22, "ExcelConditionalFormatRule");
var ExcelConditionalFormatRule2 = _ExcelConditionalFormatRule22;
var _ExcelDrawingCollection22 = class _ExcelDrawingCollection23 extends ReadonlySheetCollection {
  constructor(workbook, sheetNameOrId) {
    super(workbook, sheetNameOrId, "drawings", (workbook2, sheetNameOrId2, index) => new ExcelDrawing2(workbook2, sheetNameOrId2, index));
  }
};
__name(_ExcelDrawingCollection22, "ExcelDrawingCollection");
var ExcelDrawingCollection2 = _ExcelDrawingCollection22;
var _ExcelDrawing22 = class _ExcelDrawing23 extends IndexedSheetItem {
  constructor(workbook, sheetNameOrId, index) {
    super(workbook, sheetNameOrId, index);
    __publicField(this, "collection", "drawings");
    __publicField(this, "anchors");
    this.anchors = new ExcelDrawingAnchorCollection2(workbook, sheetNameOrId, index);
  }
  async relationshipId() {
    return this.run(`return item.relationshipId();`);
  }
  async path() {
    return this.run(`return item.path();`);
  }
};
__name(_ExcelDrawing22, "ExcelDrawing");
var ExcelDrawing2 = _ExcelDrawing22;
var _ExcelDrawingAnchorCollection22 = class _ExcelDrawingAnchorCollection23 {
  constructor(workbook, sheetNameOrId, drawingIndex) {
    __publicField(this, "workbook", workbook);
    __publicField(this, "sheetNameOrId", sheetNameOrId);
    __publicField(this, "drawingIndex", drawingIndex);
  }
  async items() {
    const models = await this.toModel();
    return models.map((_2, index) => new ExcelDrawingAnchor2(this.workbook, this.sheetNameOrId, this.drawingIndex, index));
  }
  getItem(index) {
    return new ExcelDrawingAnchor2(this.workbook, this.sheetNameOrId, this.drawingIndex, index);
  }
  async getItemOrNullObject(index) {
    const exists = await this.workbook.executeCode(
      `
      const sheet = workbook.worksheets.getItem(args.sheetNameOrId);
      const drawing = sheet.drawings.items()[args.drawingIndex];
      return Boolean(drawing?.anchors.getItemOrNullObject(args.index));
    `,
      { sheetNameOrId: this.sheetNameOrId, drawingIndex: this.drawingIndex, index }
    );
    return exists ? this.getItem(index) : null;
  }
  async toModel() {
    return this.workbook.executeCode(
      `
      const sheet = workbook.worksheets.getItem(args.sheetNameOrId);
      return sheet.drawings.items()[args.drawingIndex].anchors.toModel();
    `,
      { sheetNameOrId: this.sheetNameOrId, drawingIndex: this.drawingIndex }
    );
  }
};
__name(_ExcelDrawingAnchorCollection22, "ExcelDrawingAnchorCollection");
var ExcelDrawingAnchorCollection2 = _ExcelDrawingAnchorCollection22;
var _ExcelDrawingAnchor22 = class _ExcelDrawingAnchor23 {
  constructor(workbook, sheetNameOrId, drawingIndex, anchorIndex) {
    __publicField(this, "workbook", workbook);
    __publicField(this, "sheetNameOrId", sheetNameOrId);
    __publicField(this, "drawingIndex", drawingIndex);
    __publicField(this, "anchorIndex", anchorIndex);
    __publicField(this, "from");
    __publicField(this, "to");
    this.from = new ExcelDrawingMarker2(workbook, sheetNameOrId, drawingIndex, anchorIndex, "from");
    this.to = new ExcelDrawingMarker2(workbook, sheetNameOrId, drawingIndex, anchorIndex, "to");
  }
  async kind() {
    return this.run(`return anchor.kind();`);
  }
  async object() {
    return this.run(`return anchor.object();`);
  }
  async toModel() {
    return this.run(`return anchor.toModel();`);
  }
  async setPosition(position) {
    await this.run(`anchor.setPosition(args.position);`, { position });
  }
  run(code, args) {
    return this.workbook.executeCode(
      `
      const sheet = workbook.worksheets.getItem(args.sheetNameOrId);
      const anchor = sheet.drawings.items()[args.drawingIndex].anchors.getItem(args.anchorIndex);
      ${code}
    `,
      __spreadProps(__spreadValues({}, args), { sheetNameOrId: this.sheetNameOrId, drawingIndex: this.drawingIndex, anchorIndex: this.anchorIndex })
    );
  }
};
__name(_ExcelDrawingAnchor22, "ExcelDrawingAnchor");
var ExcelDrawingAnchor2 = _ExcelDrawingAnchor22;
var _ExcelDrawingMarker22 = class _ExcelDrawingMarker23 {
  constructor(workbook, sheetNameOrId, drawingIndex, anchorIndex, markerName) {
    __publicField(this, "workbook", workbook);
    __publicField(this, "sheetNameOrId", sheetNameOrId);
    __publicField(this, "drawingIndex", drawingIndex);
    __publicField(this, "anchorIndex", anchorIndex);
    __publicField(this, "markerName", markerName);
  }
  async row() {
    return this.run(`return marker.row();`);
  }
  async setRow(row) {
    await this.run(`marker.setRow(args.row);`, { row });
  }
  async column() {
    return this.run(`return marker.column();`);
  }
  async setColumn(column) {
    await this.run(`marker.setColumn(args.column);`, { column });
  }
  async rowOffset() {
    return this.run(`return marker.rowOffset();`);
  }
  async setRowOffset(offset) {
    await this.run(`marker.setRowOffset(args.offset);`, { offset });
  }
  async columnOffset() {
    return this.run(`return marker.columnOffset();`);
  }
  async setColumnOffset(offset) {
    await this.run(`marker.setColumnOffset(args.offset);`, { offset });
  }
  async toModel() {
    return this.run(`return marker.toModel();`);
  }
  run(code, args) {
    return this.workbook.executeCode(
      `
      const sheet = workbook.worksheets.getItem(args.sheetNameOrId);
      const anchor = sheet.drawings.items()[args.drawingIndex].anchors.getItem(args.anchorIndex);
      const marker = anchor[args.markerName];
      ${code}
    `,
      __spreadProps(__spreadValues({}, args != null ? args : {}), {
        sheetNameOrId: this.sheetNameOrId,
        drawingIndex: this.drawingIndex,
        anchorIndex: this.anchorIndex,
        markerName: this.markerName
      })
    );
  }
};
__name(_ExcelDrawingMarker22, "ExcelDrawingMarker");
var ExcelDrawingMarker2 = _ExcelDrawingMarker22;
var _ExcelChartCollection22 = class _ExcelChartCollection23 extends ReadonlySheetCollection {
  constructor(workbook, sheetNameOrId) {
    super(workbook, sheetNameOrId, "charts", (workbook2, sheetNameOrId2, index) => new ExcelChart2(workbook2, sheetNameOrId2, index));
  }
  async add(options) {
    const index = await this.workbook.executeCode(
      `
      const sheet = workbook.worksheets.getItem(args.sheetNameOrId);
      sheet.charts.add(args.options);
      return sheet.charts.items().length - 1;
    `,
      { sheetNameOrId: this.sheetNameOrId, options }
    );
    return new ExcelChart2(this.workbook, this.sheetNameOrId, index);
  }
};
__name(_ExcelChartCollection22, "ExcelChartCollection");
var ExcelChartCollection2 = _ExcelChartCollection22;
var _ExcelChart22 = class _ExcelChart23 extends IndexedSheetItem {
  constructor(workbook, sheetNameOrId, index) {
    super(workbook, sheetNameOrId, index);
    __publicField(this, "collection", "charts");
    __publicField(this, "formulaRefs");
    this.formulaRefs = new ExcelFormulaRefCollection2(workbook, sheetNameOrId, index);
  }
  async relationshipId() {
    return this.run(`return item.relationshipId();`);
  }
  async drawingPath() {
    return this.run(`return item.drawingPath();`);
  }
  async path() {
    return this.run(`return item.path();`);
  }
  async title() {
    return this.run(`return item.title();`);
  }
  async setTitle(title) {
    await this.run(`item.setTitle(args.title);`, { title });
  }
};
__name(_ExcelChart22, "ExcelChart");
var ExcelChart2 = _ExcelChart22;
var _ExcelFormulaRefCollection22 = class _ExcelFormulaRefCollection23 {
  constructor(workbook, sheetNameOrId, chartIndex) {
    __publicField(this, "workbook", workbook);
    __publicField(this, "sheetNameOrId", sheetNameOrId);
    __publicField(this, "chartIndex", chartIndex);
  }
  async items() {
    return this.run(`return item.formulaRefs.items();`);
  }
  async getItem(index) {
    return this.run(`return item.formulaRefs.getItem(args.index);`, { index });
  }
  async setItem(index, formulaRef) {
    await this.run(`item.formulaRefs.setItem(args.index, args.formulaRef);`, { index, formulaRef });
  }
  async add(formulaRef) {
    await this.run(`item.formulaRefs.add(args.formulaRef);`, { formulaRef });
  }
  async delete(index) {
    await this.run(`item.formulaRefs.delete(args.index);`, { index });
  }
  async toModel() {
    return this.run(`return item.formulaRefs.toModel();`);
  }
  run(code, args) {
    return this.workbook.executeCode(
      `
      const sheet = workbook.worksheets.getItem(args.sheetNameOrId);
      const item = sheet.charts.items()[args.chartIndex];
      ${code}
    `,
      __spreadProps(__spreadValues({}, args != null ? args : {}), { sheetNameOrId: this.sheetNameOrId, chartIndex: this.chartIndex })
    );
  }
};
__name(_ExcelFormulaRefCollection22, "ExcelFormulaRefCollection");
var ExcelFormulaRefCollection2 = _ExcelFormulaRefCollection22;
var _ExcelImageCollection22 = class _ExcelImageCollection23 extends ReadonlySheetCollection {
  constructor(workbook, sheetNameOrId) {
    super(workbook, sheetNameOrId, "images", (workbook2, sheetNameOrId2, index) => new ExcelImage2(workbook2, sheetNameOrId2, index));
  }
};
__name(_ExcelImageCollection22, "ExcelImageCollection");
var ExcelImageCollection2 = _ExcelImageCollection22;
var _ExcelImage22 = class _ExcelImage23 extends IndexedSheetItem {
  constructor() {
    super(...arguments);
    __publicField(this, "collection", "images");
  }
  async relationshipId() {
    return this.run(`return item.relationshipId();`);
  }
  async drawingPath() {
    return this.run(`return item.drawingPath();`);
  }
  async path() {
    return this.run(`return item.path();`);
  }
  async targetMode() {
    return this.run(`return item.targetMode();`);
  }
  async name() {
    return this.run(`return item.name();`);
  }
};
__name(_ExcelImage22, "ExcelImage");
var ExcelImage2 = _ExcelImage22;
var _ExcelShapeCollection22 = class _ExcelShapeCollection23 extends ReadonlySheetCollection {
  constructor(workbook, sheetNameOrId) {
    super(workbook, sheetNameOrId, "shapes", (workbook2, sheetNameOrId2, index) => new ExcelShape2(workbook2, sheetNameOrId2, index));
  }
  getItem(name) {
    return new ExcelShape2(this.workbook, this.sheetNameOrId, name);
  }
};
__name(_ExcelShapeCollection22, "ExcelShapeCollection");
var ExcelShapeCollection2 = _ExcelShapeCollection22;
var _ExcelShape22 = class _ExcelShape23 extends IndexedSheetItem {
  constructor() {
    super(...arguments);
    __publicField(this, "collection", "shapes");
  }
  async drawingPath() {
    return this.run(`return item.drawingPath();`);
  }
  async name() {
    return this.run(`return item.name();`);
  }
  async setName(name) {
    await this.run(`item.setName(args.name);`, { name });
    if (name !== void 0) this.indexOrName = name;
  }
};
__name(_ExcelShape22, "ExcelShape");
var ExcelShape2 = _ExcelShape22;
function runSheetCollection(workbook, sheetNameOrId, collection, method, args) {
  return workbook.executeCode(
    `
    const sheet = workbook.worksheets.getItem(args.sheetNameOrId);
    const collection = sheet[args.collection];
    if (args.method === 'add') return collection.add(args.model).toModel();
    if (args.method === 'delete') return collection.delete(args.key);
    if (args.method === 'toModel') return collection.toModel();
    throw new Error('unsupported collection method: ' + args.method);
  `,
    __spreadProps(__spreadValues({}, args != null ? args : {}), { sheetNameOrId, collection, method })
  );
}
__name(runSheetCollection, "runSheetCollection");
function runSheetItem(workbook, sheetNameOrId, collection, key2, code, args) {
  return workbook.executeCode(
    `
    const sheet = workbook.worksheets.getItem(args.sheetNameOrId);
    const item = sheet[args.collection].getItem(args.key);
    ${code}
  `,
    __spreadProps(__spreadValues({}, args != null ? args : {}), { sheetNameOrId, collection, key: key2 })
  );
}
__name(runSheetItem, "runSheetItem");
function sheetCollectionItemExists(workbook, sheetNameOrId, collection, key2) {
  return workbook.executeCode(
    `
    const sheet = workbook.worksheets.getItem(args.sheetNameOrId);
    return sheet[args.collection].getItemOrNullObject(args.key) !== null;
  `,
    { sheetNameOrId, collection, key: key2 }
  );
}
__name(sheetCollectionItemExists, "sheetCollectionItemExists");
var _ExcelNamedItemCollection22 = class _ExcelNamedItemCollection23 {
  constructor(workbook) {
    __publicField(this, "workbook", workbook);
  }
  async items() {
    const names = await this.workbook.executeCode(`
      return workbook.names.items().map((name) => ({ name: name.name() }));
    `);
    return names.map((name) => new ExcelNamedItem2(this.workbook, name.name));
  }
  getItem(name) {
    return new ExcelNamedItem2(this.workbook, name);
  }
  async getItemOrNullObject(name) {
    const exists = await this.workbook.executeCode(
      `return workbook.names.getItemOrNullObject(args.name) !== null;`,
      { name }
    );
    return exists ? new ExcelNamedItem2(this.workbook, name) : null;
  }
  async add(model) {
    const added = await this.workbook.executeCode(
      `return workbook.names.add(args.model).toModel();`,
      { model }
    );
    return new ExcelNamedItem2(this.workbook, added.name);
  }
  async deleteItem(name) {
    await this.workbook.executeCode(`workbook.names.deleteItem(args.name);`, { name });
  }
};
__name(_ExcelNamedItemCollection22, "ExcelNamedItemCollection");
var ExcelNamedItemCollection2 = _ExcelNamedItemCollection22;
var _ExcelNamedItem22 = class _ExcelNamedItem23 {
  constructor(workbook, nameValue) {
    __publicField(this, "workbook", workbook);
    __publicField(this, "nameValue", nameValue);
  }
  async name() {
    return this.run(`return item.name();`);
  }
  async text() {
    return this.run(`return item.text();`);
  }
  async setText(text) {
    await this.run(`item.setText(args.text);`, { text });
  }
  async rename(name) {
    await this.run(`item.rename(args.nextName);`, { nextName: name });
    this.nameValue = name;
  }
  async localSheetId() {
    return this.run(`return item.localSheetId();`);
  }
  async setLocalSheetId(localSheetId) {
    await this.run(`item.setLocalSheetId(args.localSheetId);`, { localSheetId });
  }
  run(code, args) {
    return this.workbook.executeCode(
      `
      const item = workbook.names.getItem(args.name);
      ${code}
    `,
      __spreadProps(__spreadValues({}, args != null ? args : {}), { name: this.nameValue })
    );
  }
};
__name(_ExcelNamedItem22, "ExcelNamedItem");
var ExcelNamedItem2 = _ExcelNamedItem22;
function isWorkerTerminalScriptError(error2) {
  const message = error2 instanceof Error ? error2.message : String(error2);
  return message.includes("excel worker call timeout") || message.includes("excel worker script aborted");
}
__name(isWorkerTerminalScriptError, "isWorkerTerminalScriptError");
function evaluateSpreadsheetFormulaAst(ast, context) {
  return evaluateNode(ast, context);
}
__name(evaluateSpreadsheetFormulaAst, "evaluateSpreadsheetFormulaAst");
function evaluateNode(ast, context) {
  var _a, _b, _c;
  switch (ast.kind) {
    case "number":
    case "string":
      return ok(ast.value);
    case "name":
      return (_b = (_a = context.getNameValue) == null ? void 0 : _a.call(context, ast.name)) != null ? _b : error("#NAME?");
    case "cell": {
      const evaluated = (_c = context.getCellEvaluation) == null ? void 0 : _c.call(context, ast.address, ast.sheetName);
      if (evaluated) {
        const reference = ast.sheetName ? { kind: "cell", address: ast.address, sheetName: ast.sheetName } : { kind: "cell", address: ast.address };
        return {
          value: evaluated.value,
          error: evaluated.error,
          dependencies: [reference]
        };
      }
      const value = context.getCellValue(ast.address, ast.sheetName);
      return ok(value, [{ kind: "cell", address: ast.address, sheetName: ast.sheetName }]);
    }
    case "range":
      return evaluateRange(ast.startAddress, ast.endAddress, ast.sheetName, context);
    case "unary":
      return evaluateUnary(ast, context);
    case "binary":
      return evaluateBinary(ast, context);
    case "call":
      return evaluateCall(ast.name, ast.args, context);
  }
}
__name(evaluateNode, "evaluateNode");
function evaluateRange(startAddress, endAddress, sheetName, context) {
  const start = parseCellAddress(startAddress);
  const end = parseCellAddress(endAddress);
  const startRow = Math.min(start.row, end.row);
  const endRow = Math.max(start.row, end.row);
  const startColumn = Math.min(start.column, end.column);
  const endColumn = Math.max(start.column, end.column);
  const values = [];
  for (let row = startRow; row <= endRow; row++) {
    const rowValues = [];
    for (let column = startColumn; column <= endColumn; column++) {
      rowValues.push(context.getCellValue(formatCellAddress(row, column), sheetName));
    }
    values.push(rowValues);
  }
  return ok(values, [{ kind: "range", startAddress, endAddress, sheetName }]);
}
__name(evaluateRange, "evaluateRange");
function evaluateUnary(ast, context) {
  const argument = evaluateNode(ast.argument, context);
  if (argument.error) return argument;
  const number = toNumber(argument.value);
  if (number === null) return error("#VALUE!", argument.dependencies);
  if (ast.operator === "%") return ok(number / 100, argument.dependencies);
  return ok(ast.operator === "-" ? -number : number, argument.dependencies);
}
__name(evaluateUnary, "evaluateUnary");
function evaluateBinary(ast, context) {
  const left = evaluateNode(ast.left, context);
  if (left.error) return left;
  const right = evaluateNode(ast.right, context);
  const dependencies = [...left.dependencies, ...right.dependencies];
  if (right.error) return __spreadProps(__spreadValues({}, right), { dependencies });
  if (Array.isArray(left.value) || Array.isArray(right.value)) {
    return evaluateMatrixBinary(ast.operator, left.value, right.value, dependencies);
  }
  if (["=", "<>", ">", ">=", "<", "<="].includes(ast.operator)) {
    return ok(compareValues(left.value, right.value, ast.operator), dependencies);
  }
  if (ast.operator === "&") {
    return ok(`${toText(left.value)}${toText(right.value)}`, dependencies);
  }
  const leftNumber = toNumber(left.value);
  const rightNumber = toNumber(right.value);
  if (leftNumber === null || rightNumber === null) return error("#VALUE!", dependencies);
  if (ast.operator === "/" && rightNumber === 0) return error("#DIV/0!", dependencies);
  const value = ast.operator === "+" ? leftNumber + rightNumber : ast.operator === "-" ? leftNumber - rightNumber : ast.operator === "*" ? leftNumber * rightNumber : leftNumber / rightNumber;
  return ok(value, dependencies);
}
__name(evaluateBinary, "evaluateBinary");
function evaluateCall(name, args, context) {
  var _a, _b, _c, _d, _e2, _f, _g, _h, _i, _j, _k, _l, _m, _n2, _o, _p, _q, _r2, _s, _t2, _u, _v, _w, _x, _y, _z, _A, _B, _C, _D, _E, _F, _G, _H, _I, _J, _K, _L, _M, _N, _O, _P, _Q, _R, _S, _T, _U, _V, _W, _X;
  if (name === "IF") return evaluateIf(args, context);
  if (name === "IFERROR") return evaluateIfError(args, context);
  if (name === "IFNA") return evaluateIfNa(args, context);
  if (name === "ISERROR" || name === "ISERR" || name === "ISNA") return evaluateErrorPredicate(name, args, context);
  if (name === "LET") return evaluateLet(args, context);
  if (name === "IFS") return evaluateIfs(args, context);
  if (name === "SWITCH") return evaluateSwitch(args, context);
  if (name === "SUBTOTAL") return evaluateSubtotal(args, context);
  if (name === "AGGREGATE") return evaluateAggregate(args, context);
  const values = [];
  let dependencies = [];
  for (const arg of args) {
    const evaluated = evaluateNode(arg, context);
    dependencies = [...dependencies, ...evaluated.dependencies];
    if (evaluated.error) return __spreadProps(__spreadValues({}, evaluated), { dependencies });
    values.push(evaluated.value);
  }
  if (name === "SUMPRODUCT") return evaluateSumProduct(values, dependencies);
  switch (name) {
    case "TRUE":
      return args.length === 0 ? ok(true, dependencies) : error("#VALUE!", dependencies);
    case "FALSE":
      return args.length === 0 ? ok(false, dependencies) : error("#VALUE!", dependencies);
    case "NA":
      return args.length === 0 ? error("#N/A", dependencies) : error("#VALUE!", dependencies);
    case "N": {
      const value = (_a = values[0]) != null ? _a : null;
      if (typeof value === "number") return ok(value, dependencies);
      if (typeof value === "boolean") return ok(value ? 1 : 0, dependencies);
      return ok(0, dependencies);
    }
    case "AND":
      return ok(values.every(truthy), dependencies);
    case "OR":
      return ok(values.some(truthy), dependencies);
    case "NOT":
      return values.length === 1 ? ok(!truthy(values[0]), dependencies) : error("#VALUE!", dependencies);
    case "SUM":
      return ok(numericValues(values).reduce((sum, value) => sum + value, 0), dependencies);
    case "PRODUCT": {
      const numbers = numericValues(values);
      return ok(numbers.reduce((product, value) => product * value, 1), dependencies);
    }
    case "SUMSQ":
      return ok(numericValues(values).reduce((sum, value) => sum + value * value, 0), dependencies);
    case "AVERAGE": {
      const numbers = numericValues(values);
      return numbers.length === 0 ? error("#DIV/0!", dependencies) : ok(numbers.reduce((sum, value) => sum + value, 0) / numbers.length, dependencies);
    }
    case "COUNT":
      return ok(numericValues(values).length, dependencies);
    case "COUNTA":
      return ok(flatten(values).filter((value) => value !== null).length, dependencies);
    case "MIN": {
      const numbers = numericValues(values);
      return numbers.length === 0 ? ok(0, dependencies) : ok(Math.min(...numbers), dependencies);
    }
    case "MAX": {
      const numbers = numericValues(values);
      return numbers.length === 0 ? ok(0, dependencies) : ok(Math.max(...numbers), dependencies);
    }
    case "MEDIAN": {
      const numbers = numericValues(values).sort((left, right) => left - right);
      if (!numbers.length) return error("#NUM!", dependencies);
      const middle = Math.floor(numbers.length / 2);
      return ok(numbers.length % 2 ? numbers[middle] : (numbers[middle - 1] + numbers[middle]) / 2, dependencies);
    }
    case "LARGE":
    case "SMALL": {
      const numbers = numericValues([(_b = values[0]) != null ? _b : null]).sort((left, right) => name === "LARGE" ? right - left : left - right);
      const index = toNumber((_c = values[1]) != null ? _c : null);
      if (index === null || !Number.isInteger(index) || index < 1 || index > numbers.length) return error("#NUM!", dependencies);
      return ok(numbers[index - 1], dependencies);
    }
    case "RANK":
    case "RANK.EQ":
    case "RANK.AVG": {
      const number = toNumber((_d = values[0]) != null ? _d : null);
      const reference = numericValues([(_e2 = values[1]) != null ? _e2 : null]);
      const order = toNumber((_f = values[2]) != null ? _f : 0);
      if (number === null || order === null || !reference.length) return error("#N/A", dependencies);
      const rank = reference.filter((value) => order === 0 ? value > number : value < number).length + 1;
      if (name === "RANK.AVG") {
        const tieCount = reference.filter((value) => value === number).length;
        return ok(tieCount > 1 ? rank + (tieCount - 1) / 2 : rank, dependencies);
      }
      return ok(rank, dependencies);
    }
    case "ABS": {
      const number = toNumber((_g = values[0]) != null ? _g : null);
      return number === null ? error("#VALUE!", dependencies) : ok(Math.abs(number), dependencies);
    }
    case "SIGN": {
      const number = toNumber((_h = values[0]) != null ? _h : null);
      return number === null ? error("#VALUE!", dependencies) : ok(number < 0 ? -1 : number > 0 ? 1 : 0, dependencies);
    }
    case "POWER": {
      const base = toNumber((_i = values[0]) != null ? _i : null);
      const exponent = toNumber((_j = values[1]) != null ? _j : null);
      if (base === null || exponent === null) return error("#VALUE!", dependencies);
      const result = base ** exponent;
      return Number.isFinite(result) ? ok(result, dependencies) : error("#NUM!", dependencies);
    }
    case "SQRT": {
      const number = toNumber((_k = values[0]) != null ? _k : null);
      return number === null ? error("#VALUE!", dependencies) : number < 0 ? error("#NUM!", dependencies) : ok(Math.sqrt(number), dependencies);
    }
    case "EXP": {
      const number = toNumber((_l = values[0]) != null ? _l : null);
      if (number === null) return error("#VALUE!", dependencies);
      const result = Math.exp(number);
      return Number.isFinite(result) ? ok(result, dependencies) : error("#NUM!", dependencies);
    }
    case "LN": {
      const number = toNumber((_m = values[0]) != null ? _m : null);
      return number === null ? error("#VALUE!", dependencies) : number <= 0 ? error("#NUM!", dependencies) : ok(Math.log(number), dependencies);
    }
    case "LOG": {
      const number = toNumber((_n2 = values[0]) != null ? _n2 : null);
      const base = toNumber((_o = values[1]) != null ? _o : 10);
      return number === null || base === null || number <= 0 || base <= 0 || base === 1 ? error(number === null || base === null ? "#VALUE!" : "#NUM!", dependencies) : ok(Math.log(number) / Math.log(base), dependencies);
    }
    case "PMT":
    case "FV":
    case "PV":
      return evaluateFinancial(name, values, dependencies);
    case "NPV": {
      const rate = toNumber((_p = values[0]) != null ? _p : null);
      const cashFlows = numericValues(values.slice(1));
      if (rate === null || rate <= -1) return error(rate === null ? "#VALUE!" : "#NUM!", dependencies);
      return ok(cashFlows.reduce((total, cashFlow, index) => total + cashFlow / (1 + rate) ** (index + 1), 0), dependencies);
    }
    case "IRR":
      return evaluateIrr(values, dependencies);
    case "RATE":
      return evaluateRate(values, dependencies);
    case "VAR":
    case "VAR.P":
    case "VAR.S":
    case "STDEV":
    case "STDEV.P":
    case "STDEV.S":
      return evaluateVariance(name, values, dependencies);
    case "PERCENTILE":
    case "PERCENTILE.INC":
    case "PERCENTILE.EXC":
      return evaluatePercentile(name, values, dependencies);
    case "QUARTILE":
    case "QUARTILE.INC":
    case "QUARTILE.EXC":
      return evaluateQuartile(name, values, dependencies);
    case "ROUND": {
      const number = toNumber((_q = values[0]) != null ? _q : null);
      const digits = toNumber((_r2 = values[1]) != null ? _r2 : 0);
      if (number === null || digits === null) return error("#VALUE!", dependencies);
      const factor = 10 ** Math.trunc(digits);
      return ok(Math.round(number * factor) / factor, dependencies);
    }
    case "ROUNDUP":
    case "ROUNDDOWN": {
      const number = toNumber((_s = values[0]) != null ? _s : null);
      const digits = toNumber((_t2 = values[1]) != null ? _t2 : 0);
      if (number === null || digits === null) return error("#VALUE!", dependencies);
      return ok(roundDirectional(number, Math.trunc(digits), name === "ROUNDUP"), dependencies);
    }
    case "CEILING":
    case "FLOOR": {
      const number = toNumber((_u = values[0]) != null ? _u : null);
      const significance = toNumber((_v = values[1]) != null ? _v : 1);
      if (number === null || significance === null || significance === 0) return error("#VALUE!", dependencies);
      const step = Math.abs(significance);
      const rounded = name === "CEILING" ? Math.ceil(number / step) * step : Math.floor(number / step) * step;
      return ok(rounded, dependencies);
    }
    case "INT": {
      const number = toNumber((_w = values[0]) != null ? _w : null);
      return number === null ? error("#VALUE!", dependencies) : ok(Math.floor(number), dependencies);
    }
    case "MOD": {
      const number = toNumber((_x = values[0]) != null ? _x : null);
      const divisor = toNumber((_y = values[1]) != null ? _y : null);
      if (number === null || divisor === null) return error("#VALUE!", dependencies);
      return divisor === 0 ? error("#DIV/0!", dependencies) : ok(number % divisor, dependencies);
    }
    case "LEN":
      return values.length === 1 ? ok(toText(values[0]).length, dependencies) : error("#VALUE!", dependencies);
    case "TRIM":
      return values.length === 1 ? ok(toText(values[0]).trim().replace(/\s+/g, " "), dependencies) : error("#VALUE!", dependencies);
    case "LOWER":
      return values.length === 1 ? ok(toText(values[0]).toLowerCase(), dependencies) : error("#VALUE!", dependencies);
    case "UPPER":
      return values.length === 1 ? ok(toText(values[0]).toUpperCase(), dependencies) : error("#VALUE!", dependencies);
    case "LEFT": {
      const text = toText((_z = values[0]) != null ? _z : "");
      const count = toNumber((_A = values[1]) != null ? _A : 1);
      return count === null || count < 0 ? error("#VALUE!", dependencies) : ok(text.slice(0, Math.trunc(count)), dependencies);
    }
    case "RIGHT": {
      const text = toText((_B = values[0]) != null ? _B : "");
      const count = toNumber((_C = values[1]) != null ? _C : 1);
      return count === null || count < 0 ? error("#VALUE!", dependencies) : ok(text.slice(Math.max(0, text.length - Math.trunc(count))), dependencies);
    }
    case "MID": {
      const text = toText((_D = values[0]) != null ? _D : "");
      const start = toNumber((_E = values[1]) != null ? _E : null);
      const count = toNumber((_F = values[2]) != null ? _F : null);
      if (start === null || count === null || start < 1 || count < 0) return error("#VALUE!", dependencies);
      return ok(text.slice(Math.trunc(start) - 1, Math.trunc(start) - 1 + Math.trunc(count)), dependencies);
    }
    case "FIND":
    case "SEARCH": {
      const needle = toText((_G = values[0]) != null ? _G : "");
      const haystack = toText((_H = values[1]) != null ? _H : "");
      const start = toNumber((_I = values[2]) != null ? _I : 1);
      if (start === null || start < 1) return error("#VALUE!", dependencies);
      const source = name === "SEARCH" ? haystack.toLowerCase() : haystack;
      const target = name === "SEARCH" ? needle.toLowerCase() : needle;
      const index = source.indexOf(target, Math.trunc(start) - 1);
      return index < 0 ? error("#VALUE!", dependencies) : ok(index + 1, dependencies);
    }
    case "SUBSTITUTE": {
      const text = toText((_J = values[0]) != null ? _J : "");
      const oldText = toText((_K = values[1]) != null ? _K : "");
      const newText = toText((_L = values[2]) != null ? _L : "");
      if (oldText === "") return ok(text, dependencies);
      const instance = values[3] === void 0 ? null : toNumber(values[3]);
      if (instance !== null && (instance === null || instance < 1)) return error("#VALUE!", dependencies);
      if (instance === null) return ok(text.split(oldText).join(newText), dependencies);
      let occurrence = 0;
      return ok(text.split(oldText).map((part, index, parts) => {
        if (index === parts.length - 1) return part;
        occurrence++;
        return `${part}${occurrence === Math.trunc(instance) ? newText : oldText}`;
      }).join(""), dependencies);
    }
    case "REPLACE": {
      const text = toText((_M = values[0]) != null ? _M : "");
      const start = toNumber((_N = values[1]) != null ? _N : null);
      const count = toNumber((_O = values[2]) != null ? _O : null);
      if (start === null || count === null || start < 1 || count < 0) return error("#VALUE!", dependencies);
      return ok(text.slice(0, Math.trunc(start) - 1) + toText((_P = values[3]) != null ? _P : "") + text.slice(Math.trunc(start) - 1 + Math.trunc(count)), dependencies);
    }
    case "TEXT":
      return values.length === 2 ? ok(formatTextValue(values[0], toText(values[1])), dependencies) : error("#VALUE!", dependencies);
    case "CONCAT":
    case "CONCATENATE":
      return ok(flatten(values).map((value) => toText(value)).join(""), dependencies);
    case "TEXTJOIN": {
      const delimiter = toText((_Q = values[0]) != null ? _Q : "");
      const ignoreEmpty = truthy((_R = values[1]) != null ? _R : false);
      const textValues = flatten(values.slice(2)).map((value) => toText(value));
      return ok(textValues.filter((value) => !ignoreEmpty || value !== "").join(delimiter), dependencies);
    }
    case "TEXTBEFORE":
      return evaluateTextBoundary("before", values, dependencies);
    case "TEXTAFTER":
      return evaluateTextBoundary("after", values, dependencies);
    case "DATEDIF":
      return evaluateDateDifference(values, dependencies);
    case "TODAY":
      return args.length === 0 ? ok((_T = (_S = context.getToday) == null ? void 0 : _S.call(context)) != null ? _T : excelSerialFromDate(/* @__PURE__ */ new Date()), dependencies) : error("#VALUE!", dependencies);
    case "VALUE": {
      const number = toNumber((_U = values[0]) != null ? _U : null);
      return number === null ? error("#VALUE!", dependencies) : ok(number, dependencies);
    }
    case "COUNTBLANK": {
      const matrix = toMatrix(values[0]);
      return !matrix ? error("#VALUE!", dependencies) : ok(flatten([matrix]).filter((value) => value === null || value === "").length, dependencies);
    }
    case "ISBLANK":
      return values.length === 1 ? ok(values[0] === null, dependencies) : error("#VALUE!", dependencies);
    case "ISNUMBER":
      return values.length === 1 ? ok(typeof values[0] === "number" && Number.isFinite(values[0]), dependencies) : error("#VALUE!", dependencies);
    case "ISTEXT":
      return values.length === 1 ? ok(typeof values[0] === "string", dependencies) : error("#VALUE!", dependencies);
    case "DATE":
      return evaluateDate(values, dependencies);
    case "DATEVALUE": {
      const date = toDateParts(values[0]);
      return values.length === 1 && date ? ok(excelSerialFromTime(date.time), dependencies) : error("#VALUE!", dependencies);
    }
    case "TIME": {
      const hour = toNumber((_V = values[0]) != null ? _V : null);
      const minute = toNumber((_W = values[1]) != null ? _W : null);
      const second = toNumber((_X = values[2]) != null ? _X : null);
      if (values.length !== 3 || hour === null || minute === null || second === null) return error("#VALUE!", dependencies);
      return ok((Math.trunc(hour) * 3600 + Math.trunc(minute) * 60 + Math.trunc(second)) / 86400, dependencies);
    }
    case "YEAR":
    case "MONTH":
    case "DAY":
      return evaluateDatePart(name, values, dependencies);
    case "HOUR":
    case "MINUTE":
    case "SECOND":
      return evaluateTimePart(name, values, dependencies);
    case "DAYS":
      return evaluateDays(values, dependencies);
    case "WEEKDAY":
      return evaluateWeekday(values, dependencies);
    case "EDATE":
    case "EOMONTH":
      return evaluateMonthShift(name, values, dependencies);
    case "WORKDAY":
      return evaluateWorkday(values, dependencies);
    case "NETWORKDAYS":
      return evaluateNetworkdays(values, dependencies);
    case "SUMIF":
      return evaluateConditionalAggregate("SUMIF", values, dependencies);
    case "COUNTIF":
      return evaluateConditionalAggregate("COUNTIF", values, dependencies);
    case "AVERAGEIF":
      return evaluateConditionalAggregate("AVERAGEIF", values, dependencies);
    case "SUMIFS":
      return evaluateMultiConditionalAggregate("SUMIFS", values, dependencies);
    case "COUNTIFS":
      return evaluateMultiConditionalAggregate("COUNTIFS", values, dependencies);
    case "AVERAGEIFS":
      return evaluateMultiConditionalAggregate("AVERAGEIFS", values, dependencies);
    case "MAXIFS":
      return evaluateMultiConditionalAggregate("MAXIFS", values, dependencies);
    case "MINIFS":
      return evaluateMultiConditionalAggregate("MINIFS", values, dependencies);
    case "VLOOKUP":
      return evaluateLookup("VLOOKUP", values, dependencies);
    case "HLOOKUP":
      return evaluateLookup("HLOOKUP", values, dependencies);
    case "INDEX":
      return evaluateIndex(values, dependencies);
    case "MATCH":
      return evaluateMatch(values, dependencies);
    case "XLOOKUP":
      return evaluateXLookup(values, dependencies);
    case "XMATCH":
      return evaluateXMatch(values, dependencies);
    case "FILTER":
      return evaluateFilter(values, dependencies);
    case "SORT":
      return evaluateSort(values, dependencies);
    case "UNIQUE":
      return evaluateUnique(values, dependencies);
    case "SEQUENCE":
      return evaluateSequence(values, dependencies);
    case "SORTBY":
      return evaluateSortBy(values, dependencies);
    case "TAKE":
      return evaluateTakeDrop("TAKE", values, dependencies);
    case "DROP":
      return evaluateTakeDrop("DROP", values, dependencies);
    case "CHOOSECOLS":
      return evaluateChooseAxis("columns", values, dependencies);
    case "CHOOSEROWS":
      return evaluateChooseAxis("rows", values, dependencies);
    case "TOCOL":
      return evaluateToLine("column", values, dependencies);
    case "TOROW":
      return evaluateToLine("row", values, dependencies);
    default:
      return error("#NAME?", dependencies);
  }
}
__name(evaluateCall, "evaluateCall");
function evaluateMatrixBinary(operator, left, right, dependencies) {
  var _a, _b, _c, _d, _e2, _f, _g, _h;
  const leftMatrix = toMatrix(left);
  const rightMatrix = toMatrix(right);
  if (!leftMatrix || !rightMatrix) return error("#VALUE!", dependencies);
  const rows = Math.max(leftMatrix.length, rightMatrix.length);
  const columns = Math.max((_b = (_a = leftMatrix[0]) == null ? void 0 : _a.length) != null ? _b : 0, (_d = (_c = rightMatrix[0]) == null ? void 0 : _c.length) != null ? _d : 0);
  if (!isScalar(left) && !isScalar(right) && !sameShape(leftMatrix, rightMatrix)) return error("#VALUE!", dependencies);
  const output = [];
  for (let row = 0; row < rows; row++) {
    const values = [];
    for (let column = 0; column < columns; column++) {
      const leftValue = isScalar(left) ? left : (_f = (_e2 = leftMatrix[row]) == null ? void 0 : _e2[column]) != null ? _f : null;
      const rightValue = isScalar(right) ? right : (_h = (_g = rightMatrix[row]) == null ? void 0 : _g[column]) != null ? _h : null;
      const result = evaluateScalarBinary(operator, leftValue, rightValue, dependencies);
      if (result.error) return result;
      if (Array.isArray(result.value)) return error("#VALUE!", dependencies);
      values.push(result.value);
    }
    output.push(values);
  }
  return ok(output, dependencies);
}
__name(evaluateMatrixBinary, "evaluateMatrixBinary");
function evaluateScalarBinary(operator, left, right, dependencies) {
  if (["=", "<>", ">", ">=", "<", "<="].includes(operator)) {
    return ok(compareValues(left, right, operator), dependencies);
  }
  if (operator === "&") return ok(`${toText(left)}${toText(right)}`, dependencies);
  const leftNumber = toNumber(left);
  const rightNumber = toNumber(right);
  if (leftNumber === null || rightNumber === null) return error("#VALUE!", dependencies);
  if (operator === "/" && rightNumber === 0) return error("#DIV/0!", dependencies);
  const value = operator === "+" ? leftNumber + rightNumber : operator === "-" ? leftNumber - rightNumber : operator === "*" ? leftNumber * rightNumber : leftNumber / rightNumber;
  return ok(value, dependencies);
}
__name(evaluateScalarBinary, "evaluateScalarBinary");
function evaluateSumProduct(values, dependencies) {
  const matrices = values.map(toMatrix);
  if (matrices.some((matrix) => !matrix) || matrices.length === 0) return error("#VALUE!", dependencies);
  const first = matrices[0];
  if (matrices.some((matrix) => !sameShape(first, matrix))) return error("#VALUE!", dependencies);
  let total = 0;
  forEachMatrix(first, (_value, row, column) => {
    var _a, _b;
    let product = 1;
    for (const matrix of matrices) {
      const number = toNumber((_b = (_a = matrix[row]) == null ? void 0 : _a[column]) != null ? _b : null);
      product *= number != null ? number : 0;
    }
    total += product;
  });
  return ok(total, dependencies);
}
__name(evaluateSumProduct, "evaluateSumProduct");
function isScalar(value) {
  return !Array.isArray(value);
}
__name(isScalar, "isScalar");
function evaluateDateDifference(values, dependencies) {
  var _a;
  if (values.length !== 3) return error("#VALUE!", dependencies);
  const start = toDateParts(values[0]);
  const end = toDateParts(values[1]);
  const unit = toText((_a = values[2]) != null ? _a : "").toUpperCase();
  if (!start || !end || !["Y", "M", "D"].includes(unit)) return error("#VALUE!", dependencies);
  if (start.time > end.time) return error("#NUM!", dependencies);
  if (unit === "D") return ok(Math.floor((end.time - start.time) / MS_PER_DAY), dependencies);
  const totalMonths = (end.year - start.year) * 12 + end.month - start.month;
  const adjustedMonths = end.day < start.day ? totalMonths - 1 : totalMonths;
  return ok(unit === "M" ? adjustedMonths : Math.floor(adjustedMonths / 12), dependencies);
}
__name(evaluateDateDifference, "evaluateDateDifference");
function evaluateTextBoundary(mode, values, dependencies) {
  var _a, _b, _c;
  if (values.length < 2 || values.length > 4) return error("#VALUE!", dependencies);
  const text = toText((_a = values[0]) != null ? _a : "");
  const delimiter = toText((_b = values[1]) != null ? _b : "");
  if (delimiter === "") return error("#VALUE!", dependencies);
  const instanceValue = values[2] === void 0 ? 1 : toNumber(values[2]);
  if (instanceValue === null || instanceValue === 0 || !Number.isFinite(instanceValue)) {
    return error("#VALUE!", dependencies);
  }
  const instance = Math.trunc(instanceValue);
  const index = findDelimiterIndex(text, delimiter, instance);
  if (index < 0) {
    return values.length === 4 ? ok(toText((_c = values[3]) != null ? _c : ""), dependencies) : error("#N/A", dependencies);
  }
  return ok(mode === "before" ? text.slice(0, index) : text.slice(index + delimiter.length), dependencies);
}
__name(evaluateTextBoundary, "evaluateTextBoundary");
function findDelimiterIndex(text, delimiter, instance) {
  if (instance > 0) {
    let start = 0;
    let index2 = -1;
    for (let occurrence = 0; occurrence < instance; occurrence++) {
      index2 = text.indexOf(delimiter, start);
      if (index2 < 0) return -1;
      start = index2 + delimiter.length;
    }
    return index2;
  }
  let end = text.length;
  let index = -1;
  for (let occurrence = 0; occurrence < Math.abs(instance); occurrence++) {
    index = text.lastIndexOf(delimiter, end);
    if (index < 0) return -1;
    end = index - 1;
  }
  return index;
}
__name(findDelimiterIndex, "findDelimiterIndex");
function evaluateIf(args, context) {
  if (args.length < 2 || args.length > 3) return error("#VALUE!");
  const condition = evaluateNode(args[0], context);
  if (condition.error) return condition;
  const branch = truthy(condition.value) ? args[1] : args[2];
  if (!branch) return ok(false, condition.dependencies);
  const evaluated = evaluateNode(branch, context);
  return __spreadProps(__spreadValues({}, evaluated), {
    dependencies: [...condition.dependencies, ...evaluated.dependencies]
  });
}
__name(evaluateIf, "evaluateIf");
function evaluateIfError(args, context) {
  if (args.length !== 2) return error("#VALUE!");
  const value = evaluateNode(args[0], context);
  if (!value.error) return value;
  const fallback = evaluateNode(args[1], context);
  return __spreadProps(__spreadValues({}, fallback), {
    dependencies: [...value.dependencies, ...fallback.dependencies]
  });
}
__name(evaluateIfError, "evaluateIfError");
function evaluateIfNa(args, context) {
  if (args.length !== 2) return error("#VALUE!");
  const value = evaluateNode(args[0], context);
  if (!value.error || value.error !== "#N/A") return value;
  const fallback = evaluateNode(args[1], context);
  return __spreadProps(__spreadValues({}, fallback), {
    dependencies: [...value.dependencies, ...fallback.dependencies]
  });
}
__name(evaluateIfNa, "evaluateIfNa");
function evaluateErrorPredicate(name, args, context) {
  if (args.length !== 1) return error("#VALUE!");
  const evaluated = evaluateNode(args[0], context);
  const isError = evaluated.error !== null;
  const matches = name === "ISERROR" ? isError : name === "ISERR" ? isError && evaluated.error !== "#N/A" : evaluated.error === "#N/A";
  return ok(matches, evaluated.dependencies);
}
__name(evaluateErrorPredicate, "evaluateErrorPredicate");
function evaluateLet(args, context) {
  if (args.length < 3 || args.length % 2 === 0) return error("#VALUE!");
  const variables = /* @__PURE__ */ new Map();
  let dependencies = [];
  const scopedContext = /* @__PURE__ */ __name(() => __spreadProps(__spreadValues({}, context), {
    getNameValue: /* @__PURE__ */ __name((name) => {
      var _a, _b, _c;
      return (_c = (_b = variables.get(name.toUpperCase())) != null ? _b : (_a = context.getNameValue) == null ? void 0 : _a.call(context, name)) != null ? _c : error("#NAME?");
    }, "getNameValue")
  }), "scopedContext");
  for (let index = 0; index < args.length - 1; index += 2) {
    const name = args[index];
    if ((name == null ? void 0 : name.kind) !== "name") return error("#NAME?", dependencies);
    const value = evaluateNode(args[index + 1], scopedContext());
    dependencies = [...dependencies, ...value.dependencies];
    if (value.error) return __spreadProps(__spreadValues({}, value), { dependencies });
    variables.set(name.name.toUpperCase(), value);
  }
  const result = evaluateNode(args[args.length - 1], scopedContext());
  return __spreadProps(__spreadValues({}, result), { dependencies: [...dependencies, ...result.dependencies] });
}
__name(evaluateLet, "evaluateLet");
function evaluateIfs(args, context) {
  if (args.length < 2 || args.length % 2 !== 0) return error("#VALUE!");
  let dependencies = [];
  for (let index = 0; index < args.length; index += 2) {
    const condition = evaluateNode(args[index], context);
    dependencies = [...dependencies, ...condition.dependencies];
    if (condition.error) return __spreadProps(__spreadValues({}, condition), { dependencies });
    if (truthy(condition.value)) {
      const result = evaluateNode(args[index + 1], context);
      return __spreadProps(__spreadValues({}, result), { dependencies: [...dependencies, ...result.dependencies] });
    }
  }
  return error("#N/A", dependencies);
}
__name(evaluateIfs, "evaluateIfs");
function evaluateSwitch(args, context) {
  if (args.length < 3) return error("#VALUE!");
  const expression = evaluateNode(args[0], context);
  if (expression.error) return expression;
  const hasDefault = (args.length - 1) % 2 === 1;
  const pairEnd = hasDefault ? args.length - 1 : args.length;
  let dependencies = [...expression.dependencies];
  for (let index = 1; index < pairEnd; index += 2) {
    const match = evaluateNode(args[index], context);
    dependencies = [...dependencies, ...match.dependencies];
    if (match.error) return __spreadProps(__spreadValues({}, match), { dependencies });
    if (compareValues(expression.value, match.value, "=")) {
      const result = evaluateNode(args[index + 1], context);
      return __spreadProps(__spreadValues({}, result), { dependencies: [...dependencies, ...result.dependencies] });
    }
  }
  if (hasDefault) {
    const result = evaluateNode(args[args.length - 1], context);
    return __spreadProps(__spreadValues({}, result), { dependencies: [...dependencies, ...result.dependencies] });
  }
  return error("#N/A", dependencies);
}
__name(evaluateSwitch, "evaluateSwitch");
function evaluateSubtotal(args, context) {
  if (args.length < 2) return error("#VALUE!");
  const functionNumber = evaluateNode(args[0], context);
  const number = toNumber(functionNumber.value);
  if (functionNumber.error || number === null || !Number.isInteger(number) || number < 1 || number > 111) {
    return error("#VALUE!", functionNumber.dependencies);
  }
  const baseFunction = number > 100 ? number - 100 : number;
  if (![1, 2, 3, 4, 5, 6, 9, 101, 102, 103, 104, 105, 106, 109].includes(number)) {
    return error("#VALUE!", functionNumber.dependencies);
  }
  let dependencies = [...functionNumber.dependencies];
  const values = [];
  for (const argument of args.slice(1)) {
    const evaluated = evaluateNode(argument, context);
    dependencies = [...dependencies, ...evaluated.dependencies];
    if (evaluated.error) return __spreadProps(__spreadValues({}, evaluated), { dependencies });
    values.push(number >= 100 ? filterHiddenRows(evaluated.value, argument, context) : evaluated.value);
  }
  return aggregateValues(baseFunction, values, dependencies);
}
__name(evaluateSubtotal, "evaluateSubtotal");
function evaluateAggregate(args, context) {
  if (args.length < 3) return error("#VALUE!");
  const functionNumber = evaluateNode(args[0], context);
  const options = evaluateNode(args[1], context);
  const number = toNumber(functionNumber.value);
  const option = toNumber(options.value);
  if (functionNumber.error || options.error || number === null || option === null || !Number.isInteger(number) || !Number.isInteger(option)) {
    return error("#VALUE!", [...functionNumber.dependencies, ...options.dependencies]);
  }
  const hiddenRows = [1, 3, 5, 7].includes(option);
  let dependencies = [...functionNumber.dependencies, ...options.dependencies];
  const values = [];
  for (const argument of args.slice(2, number === 14 || number === 15 ? 3 : void 0)) {
    const evaluated = evaluateNode(argument, context);
    dependencies = [...dependencies, ...evaluated.dependencies];
    if (evaluated.error) return __spreadProps(__spreadValues({}, evaluated), { dependencies });
    values.push(hiddenRows ? filterHiddenRows(evaluated.value, argument, context) : evaluated.value);
  }
  if (number === 14 || number === 15) {
    const k2 = toNumber(args[3] ? evaluateNode(args[3], context).value : null);
    if (k2 === null) return error("#VALUE!", dependencies);
    values.push(k2);
  }
  return aggregateValues(number, values, dependencies);
}
__name(evaluateAggregate, "evaluateAggregate");
function filterHiddenRows(value, ast, context) {
  const isRowHidden = context.isRowHidden;
  if (!isRowHidden || !Array.isArray(value)) return value;
  if (ast.kind === "cell") {
    return isRowHidden(parseCellAddress(ast.address).row, ast.sheetName) ? [] : value;
  }
  if (ast.kind !== "range") return value;
  const start = parseCellAddress(ast.startAddress);
  const end = parseCellAddress(ast.endAddress);
  return value.filter((_row, offset) => !isRowHidden(start.row + offset, ast.sheetName));
}
__name(filterHiddenRows, "filterHiddenRows");
function aggregateValues(functionNumber, values, dependencies) {
  var _a;
  if (functionNumber === 1) {
    const numbers = numericValues(values);
    return numbers.length ? ok(numbers.reduce((sum, value) => sum + value, 0) / numbers.length, dependencies) : error("#DIV/0!", dependencies);
  }
  if (functionNumber === 2) return ok(numericValues(values).length, dependencies);
  if (functionNumber === 3) return ok(flatten(values).filter((value) => value !== null && value !== "").length, dependencies);
  if (functionNumber === 4) {
    const numbers = numericValues(values);
    return numbers.length ? ok(Math.max(...numbers), dependencies) : ok(0, dependencies);
  }
  if (functionNumber === 5) {
    const numbers = numericValues(values);
    return numbers.length ? ok(Math.min(...numbers), dependencies) : ok(0, dependencies);
  }
  if (functionNumber === 6) {
    return ok(numericValues(values).reduce((product, value) => product * value, 1), dependencies);
  }
  if (functionNumber === 9) return ok(numericValues(values).reduce((sum, value) => sum + value, 0), dependencies);
  if (functionNumber === 12) {
    const numbers = numericValues(values).sort((left, right) => left - right);
    if (!numbers.length) return error("#NUM!", dependencies);
    const middle = Math.floor(numbers.length / 2);
    return ok(numbers.length % 2 ? numbers[middle] : (numbers[middle - 1] + numbers[middle]) / 2, dependencies);
  }
  if (functionNumber === 14 || functionNumber === 15) {
    const k2 = toNumber((_a = values[values.length - 1]) != null ? _a : null);
    const numbers = numericValues(values.slice(0, -1)).sort((left, right) => functionNumber === 14 ? right - left : left - right);
    if (k2 === null || !Number.isInteger(k2) || k2 < 1 || k2 > numbers.length) return error("#NUM!", dependencies);
    return ok(numbers[k2 - 1], dependencies);
  }
  return error("#VALUE!", dependencies);
}
__name(aggregateValues, "aggregateValues");
function roundDirectional(number, digits, roundUp) {
  const factor = 10 ** digits;
  const scaled = number * factor;
  const rounded = roundUp ? Math.sign(scaled) * Math.ceil(Math.abs(scaled)) : Math.trunc(scaled);
  return rounded / factor;
}
__name(roundDirectional, "roundDirectional");
function evaluateFinancial(name, values, dependencies) {
  var _a, _b, _c, _d, _e2;
  if (values.length < 3 || values.length > 5) return error("#VALUE!", dependencies);
  const rate = toNumber((_a = values[0]) != null ? _a : null);
  const periods = toNumber((_b = values[1]) != null ? _b : null);
  const third = toNumber((_c = values[2]) != null ? _c : null);
  const fourth = toNumber((_d = values[3]) != null ? _d : 0);
  const type = toNumber((_e2 = values[4]) != null ? _e2 : 0);
  if (rate === null || periods === null || third === null || fourth === null || type === null) {
    return error("#VALUE!", dependencies);
  }
  if (periods === 0 || ![0, 1].includes(Math.trunc(type))) return error("#NUM!", dependencies);
  const normalizedType = Math.trunc(type);
  const growth = (1 + rate) ** periods;
  if (!Number.isFinite(growth)) return error("#NUM!", dependencies);
  if (rate === 0) {
    if (name === "PMT") return ok(-(third + fourth) / periods, dependencies);
    if (name === "FV") return ok(-(fourth + third * periods), dependencies);
    return ok(-(fourth + third * periods), dependencies);
  }
  const annuity = (growth - 1) / rate * (1 + rate * normalizedType);
  if (name === "PMT") return ok(-(third * growth + fourth) * rate / (growth - 1), dependencies);
  if (name === "FV") return ok(-(fourth * growth + third * annuity), dependencies);
  return ok(-(fourth + third * annuity) / growth, dependencies);
}
__name(evaluateFinancial, "evaluateFinancial");
function evaluateIrr(values, dependencies) {
  var _a, _b;
  const cashFlows = numericValues([(_a = values[0]) != null ? _a : null]);
  const guess = toNumber((_b = values[1]) != null ? _b : 0.1);
  if (!cashFlows.length || guess === null) return error("#VALUE!", dependencies);
  const rate = solveRate(cashFlows, guess);
  return rate === null ? error("#NUM!", dependencies) : ok(rate, dependencies);
}
__name(evaluateIrr, "evaluateIrr");
function evaluateRate(values, dependencies) {
  var _a, _b, _c, _d, _e2, _f;
  if (values.length < 3 || values.length > 6) return error("#VALUE!", dependencies);
  const periods = toNumber((_a = values[0]) != null ? _a : null);
  const payment = toNumber((_b = values[1]) != null ? _b : null);
  const presentValue = toNumber((_c = values[2]) != null ? _c : null);
  const futureValue = toNumber((_d = values[3]) != null ? _d : 0);
  const type = toNumber((_e2 = values[4]) != null ? _e2 : 0);
  const guess = toNumber((_f = values[5]) != null ? _f : 0.1);
  if ([periods, payment, presentValue, futureValue, type, guess].some((value) => value === null)) {
    return error("#VALUE!", dependencies);
  }
  if (periods === 0 || ![0, 1].includes(Math.trunc(type))) return error("#NUM!", dependencies);
  const normalizedPeriods = Math.trunc(periods);
  const normalizedType = Math.trunc(type);
  const cashFlows = [presentValue + (normalizedType === 1 ? payment : 0)];
  for (let index = 1; index <= normalizedPeriods; index++) {
    cashFlows.push((normalizedType === 1 && index === normalizedPeriods ? 0 : payment) + (index === normalizedPeriods ? futureValue : 0));
  }
  const rate = solveRate(cashFlows, guess);
  return rate === null ? error("#NUM!", dependencies) : ok(rate, dependencies);
}
__name(evaluateRate, "evaluateRate");
function solveRate(cashFlows, initialGuess) {
  const evaluate = /* @__PURE__ */ __name((rate2) => cashFlows.reduce((sum, cashFlow, index) => sum + cashFlow / (1 + rate2) ** index, 0), "evaluate");
  const derivative = /* @__PURE__ */ __name((rate2) => cashFlows.reduce((sum, cashFlow, index) => index === 0 ? sum : sum - index * cashFlow / (1 + rate2) ** (index + 1), 0), "derivative");
  let rate = Math.max(-0.9999, initialGuess);
  for (let iteration = 0; iteration < 100; iteration++) {
    const value = evaluate(rate);
    if (Math.abs(value) < 1e-10) return rate;
    const slope = derivative(rate);
    if (!Number.isFinite(value) || !Number.isFinite(slope) || Math.abs(slope) < 1e-14) break;
    const next = rate - value / slope;
    if (!Number.isFinite(next) || next <= -1 || Math.abs(next - rate) > 10) break;
    rate = next;
  }
  let left = -0.9999;
  let leftValue = evaluate(left);
  for (let index = 1; index <= 2e3; index++) {
    const right = -0.9999 + index * 0.01;
    const rightValue = evaluate(right);
    if (Number.isFinite(leftValue) && Number.isFinite(rightValue) && leftValue * rightValue <= 0) {
      let low = left;
      let high = right;
      for (let iteration = 0; iteration < 80; iteration++) {
        const middle = (low + high) / 2;
        const middleValue = evaluate(middle);
        if (Math.abs(middleValue) < 1e-10) return middle;
        if (leftValue * middleValue <= 0) {
          high = middle;
        } else {
          low = middle;
          leftValue = middleValue;
        }
      }
      return (low + high) / 2;
    }
    left = right;
    leftValue = rightValue;
  }
  return null;
}
__name(solveRate, "solveRate");
function evaluateVariance(name, values, dependencies) {
  const numbers = numericValues(values);
  const sample = name === "VAR" || name === "STDEV" || name.endsWith(".S");
  if (numbers.length < (sample ? 2 : 1)) return error("#DIV/0!", dependencies);
  const mean = numbers.reduce((sum, value) => sum + value, 0) / numbers.length;
  const variance = numbers.reduce((sum, value) => sum + (value - mean) ** 2, 0) / (numbers.length - (sample ? 1 : 0));
  return ok(name.startsWith("STDEV") ? Math.sqrt(variance) : variance, dependencies);
}
__name(evaluateVariance, "evaluateVariance");
function evaluatePercentile(name, values, dependencies) {
  if (values.length !== 2) return error("#VALUE!", dependencies);
  return percentileValue(values[0], values[1], name === "PERCENTILE.EXC", dependencies);
}
__name(evaluatePercentile, "evaluatePercentile");
function evaluateQuartile(name, values, dependencies) {
  var _a;
  if (values.length !== 2) return error("#VALUE!", dependencies);
  const quartile = toNumber((_a = values[1]) != null ? _a : null);
  if (quartile === null || !Number.isInteger(quartile) || quartile < 0 || quartile > 4) {
    return error("#NUM!", dependencies);
  }
  return percentileValue(values[0], quartile / 4, name === "QUARTILE.EXC", dependencies);
}
__name(evaluateQuartile, "evaluateQuartile");
function percentileValue(source, percentile, exclusive, dependencies) {
  const numbers = numericValues([source != null ? source : null]).sort((left, right) => left - right);
  const k2 = toNumber(percentile);
  if (!numbers.length || k2 === null) return error("#NUM!", dependencies);
  const position = exclusive ? k2 * (numbers.length + 1) - 1 : k2 * (numbers.length - 1);
  if (position < 0 || position > numbers.length - 1) return error("#NUM!", dependencies);
  const lower = Math.floor(position);
  const upper = Math.ceil(position);
  if (lower === upper) return ok(numbers[lower], dependencies);
  const fraction = position - lower;
  return ok(numbers[lower] + (numbers[upper] - numbers[lower]) * fraction, dependencies);
}
__name(percentileValue, "percentileValue");
function evaluateDate(values, dependencies) {
  var _a, _b, _c;
  if (values.length !== 3) return error("#VALUE!", dependencies);
  const year = toNumber((_a = values[0]) != null ? _a : null);
  const month = toNumber((_b = values[1]) != null ? _b : null);
  const day = toNumber((_c = values[2]) != null ? _c : null);
  if (year === null || month === null || day === null) return error("#VALUE!", dependencies);
  const normalizedYear = Math.trunc(year) < 1900 ? Math.trunc(year) + 1900 : Math.trunc(year);
  const time = Date.UTC(normalizedYear, Math.trunc(month) - 1, Math.trunc(day));
  return Number.isFinite(time) ? ok(Math.floor((time - Date.UTC(1899, 11, 30)) / MS_PER_DAY), dependencies) : error("#NUM!", dependencies);
}
__name(evaluateDate, "evaluateDate");
function evaluateDatePart(name, values, dependencies) {
  const date = toDateParts(values[0]);
  if (!date || values.length !== 1) return error("#VALUE!", dependencies);
  return ok(name === "YEAR" ? date.year : name === "MONTH" ? date.month : date.day, dependencies);
}
__name(evaluateDatePart, "evaluateDatePart");
function evaluateTimePart(name, values, dependencies) {
  const value = values[0];
  const date = toDateParts(value);
  if (!date || values.length !== 1) return error("#VALUE!", dependencies);
  const time = (date.time % MS_PER_DAY + MS_PER_DAY) % MS_PER_DAY;
  const totalSeconds = Math.floor(time / 1e3);
  if (name === "HOUR") return ok(Math.floor(totalSeconds / 3600), dependencies);
  if (name === "MINUTE") return ok(Math.floor(totalSeconds % 3600 / 60), dependencies);
  return ok(totalSeconds % 60, dependencies);
}
__name(evaluateTimePart, "evaluateTimePart");
function evaluateDays(values, dependencies) {
  const end = toDateParts(values[0]);
  const start = toDateParts(values[1]);
  if (!end || !start || values.length !== 2) return error("#VALUE!", dependencies);
  return ok(Math.floor((end.time - start.time) / MS_PER_DAY), dependencies);
}
__name(evaluateDays, "evaluateDays");
function evaluateWeekday(values, dependencies) {
  var _a;
  const date = toDateParts(values[0]);
  const returnType = toNumber((_a = values[1]) != null ? _a : 1);
  if (!date || values.length < 1 || values.length > 2 || returnType === null || ![1, 2, 3].includes(Math.trunc(returnType))) return error("#NUM!", dependencies);
  const day = new Date(date.time).getUTCDay();
  if (Math.trunc(returnType) === 2) return ok(day === 0 ? 7 : day, dependencies);
  if (Math.trunc(returnType) === 3) return ok(day === 0 ? 6 : day - 1, dependencies);
  return ok(day + 1, dependencies);
}
__name(evaluateWeekday, "evaluateWeekday");
function evaluateMonthShift(name, values, dependencies) {
  var _a;
  const date = toDateParts(values[0]);
  const months = toNumber((_a = values[1]) != null ? _a : null);
  if (!date || months === null || values.length !== 2) return error("#VALUE!", dependencies);
  const shifted = new Date(Date.UTC(date.year, date.month - 1 + Math.trunc(months), name === "EOMONTH" ? 0 : date.day));
  return ok(Math.floor((shifted.getTime() - Date.UTC(1899, 11, 30)) / MS_PER_DAY), dependencies);
}
__name(evaluateMonthShift, "evaluateMonthShift");
function evaluateWorkday(values, dependencies) {
  var _a;
  if (values.length < 2 || values.length > 3) return error("#VALUE!", dependencies);
  const start = toDateParts(values[0]);
  const days = toNumber((_a = values[1]) != null ? _a : null);
  const holidays = holidayTimes(values[2]);
  if (!start || days === null || holidays === null) return error("#VALUE!", dependencies);
  const direction = days < 0 ? -1 : 1;
  let remaining = Math.abs(Math.trunc(days));
  let time = start.time;
  while (remaining > 0 || isWeekend(time) || holidays.has(time)) {
    time += direction * MS_PER_DAY;
    if (!isWeekend(time) && !holidays.has(time)) remaining--;
  }
  return ok(excelSerialFromTime(time), dependencies);
}
__name(evaluateWorkday, "evaluateWorkday");
function evaluateNetworkdays(values, dependencies) {
  if (values.length < 2 || values.length > 3) return error("#VALUE!", dependencies);
  const start = toDateParts(values[0]);
  const end = toDateParts(values[1]);
  const holidays = holidayTimes(values[2]);
  if (!start || !end || holidays === null) return error("#VALUE!", dependencies);
  const direction = start.time <= end.time ? 1 : -1;
  let time = direction === 1 ? start.time : end.time;
  const limit = direction === 1 ? end.time : start.time;
  let count = 0;
  while (time <= limit) {
    if (!isWeekend(time) && !holidays.has(time)) count++;
    time += MS_PER_DAY;
  }
  return ok(direction * count, dependencies);
}
__name(evaluateNetworkdays, "evaluateNetworkdays");
function holidayTimes(value) {
  if (value === void 0) return /* @__PURE__ */ new Set();
  const dates = flatten([value]).map(toDateParts);
  if (dates.some((date) => !date)) return null;
  return new Set(dates.map((date) => date.time));
}
__name(holidayTimes, "holidayTimes");
function isWeekend(time) {
  const day = new Date(time).getUTCDay();
  return day === 0 || day === 6;
}
__name(isWeekend, "isWeekend");
function excelSerialFromTime(time) {
  return Math.floor((time - Date.UTC(1899, 11, 30)) / MS_PER_DAY);
}
__name(excelSerialFromTime, "excelSerialFromTime");
function formatTextValue(value, format) {
  const number = toNumber(value);
  if (number === null) return toText(value);
  if (format.includes("%")) {
    const decimals2 = decimalPlaces(format.replace("%", ""));
    return `${(number * 100).toFixed(decimals2)}%`;
  }
  const decimals = decimalPlaces(format);
  if (format.includes(",")) return number.toLocaleString("en-US", { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
  return decimals > 0 ? number.toFixed(decimals) : String(Math.round(number));
}
__name(formatTextValue, "formatTextValue");
function decimalPlaces(format) {
  var _a, _b;
  const match = /\.([0#]+)/.exec(format);
  return (_b = (_a = match == null ? void 0 : match[1]) == null ? void 0 : _a.length) != null ? _b : 0;
}
__name(decimalPlaces, "decimalPlaces");
function evaluateXLookup(values, dependencies) {
  var _a, _b;
  if (values.length < 3 || values.length > 6) return error("#VALUE!", dependencies);
  const lookupValue = values[0];
  const lookupArray = flatten([values[1]]);
  const returnArray = flatten([values[2]]);
  const matchMode = toNumber((_a = values[4]) != null ? _a : 0);
  if (matchMode === null || Math.trunc(matchMode) !== 0 || lookupArray.length !== returnArray.length) return error("#VALUE!", dependencies);
  const index = lookupArray.findIndex((value) => compareValues(value, lookupValue != null ? lookupValue : null, "="));
  if (index < 0) return values[3] === void 0 ? error("#N/A", dependencies) : ok(values[3], dependencies);
  return ok((_b = returnArray[index]) != null ? _b : null, dependencies);
}
__name(evaluateXLookup, "evaluateXLookup");
function evaluateXMatch(values, dependencies) {
  var _a;
  if (values.length < 2 || values.length > 4) return error("#VALUE!", dependencies);
  const lookupArray = flatten([values[1]]);
  const matchMode = toNumber((_a = values[2]) != null ? _a : 0);
  if (matchMode === null || Math.trunc(matchMode) !== 0) return error("#N/A", dependencies);
  const index = lookupArray.findIndex((value) => {
    var _a2;
    return compareValues(value, (_a2 = values[0]) != null ? _a2 : null, "=");
  });
  return index < 0 ? error("#N/A", dependencies) : ok(index + 1, dependencies);
}
__name(evaluateXMatch, "evaluateXMatch");
function evaluateFilter(values, dependencies) {
  var _a, _b, _c, _d, _e2;
  if (values.length < 2 || values.length > 3) return error("#VALUE!", dependencies);
  const source = toMatrix(values[0]);
  const include = toMatrix(values[1]);
  if (!source || !include) return error("#VALUE!", dependencies);
  const rowMode = include.length === source.length && ((_a = include[0]) == null ? void 0 : _a.length) === 1;
  const columnMode = include.length === 1 && ((_b = include[0]) == null ? void 0 : _b.length) === ((_c = source[0]) == null ? void 0 : _c.length);
  if (!rowMode && !columnMode) return error("#VALUE!", dependencies);
  if (rowMode) {
    const rows = source.filter((_row, index) => {
      var _a2, _b2;
      return truthy((_b2 = (_a2 = include[index]) == null ? void 0 : _a2[0]) != null ? _b2 : false);
    });
    return rows.length > 0 ? ok(rows, dependencies) : values[2] !== void 0 ? ok(toMatrix(values[2]), dependencies) : error("#CALC!", dependencies);
  }
  const columns = (_e2 = (_d = source[0]) == null ? void 0 : _d.map((_value, column) => column).filter((column) => {
    var _a2, _b2;
    return truthy((_b2 = (_a2 = include[0]) == null ? void 0 : _a2[column]) != null ? _b2 : false);
  })) != null ? _e2 : [];
  if (columns.length === 0) return values[2] !== void 0 ? ok(toMatrix(values[2]), dependencies) : error("#CALC!", dependencies);
  return ok(source.map((row) => columns.map((column) => {
    var _a2;
    return (_a2 = row[column]) != null ? _a2 : null;
  })), dependencies);
}
__name(evaluateFilter, "evaluateFilter");
function evaluateSort(values, dependencies) {
  var _a, _b, _c, _d, _e2, _f, _g;
  if (values.length < 1 || values.length > 4) return error("#VALUE!", dependencies);
  const source = toMatrix(values[0]);
  const sortIndex = toNumber((_a = values[1]) != null ? _a : 1);
  const sortOrder = toNumber((_b = values[2]) != null ? _b : 1);
  const byColumn = truthy((_c = values[3]) != null ? _c : false);
  if (!source || sortIndex === null || sortOrder === null || ![1, -1].includes(Math.trunc(sortOrder))) return error("#VALUE!", dependencies);
  const index = Math.trunc(sortIndex) - 1;
  if (byColumn) {
    if (index < 0 || index >= source.length) return error("#VALUE!", dependencies);
    const columns = Array.from({ length: (_e2 = (_d = source[0]) == null ? void 0 : _d.length) != null ? _e2 : 0 }, (_2, column) => column);
    columns.sort((left, right) => {
      var _a2, _b2, _c2, _d2;
      return compareForSort((_b2 = (_a2 = source[index]) == null ? void 0 : _a2[left]) != null ? _b2 : null, (_d2 = (_c2 = source[index]) == null ? void 0 : _c2[right]) != null ? _d2 : null) * Math.trunc(sortOrder);
    });
    return ok(source.map((row) => columns.map((column) => {
      var _a2;
      return (_a2 = row[column]) != null ? _a2 : null;
    })), dependencies);
  }
  if (index < 0 || index >= ((_g = (_f = source[0]) == null ? void 0 : _f.length) != null ? _g : 0)) return error("#VALUE!", dependencies);
  const rows = source.map((_row, row) => row);
  rows.sort((left, right) => {
    var _a2, _b2, _c2, _d2;
    return compareForSort((_b2 = (_a2 = source[left]) == null ? void 0 : _a2[index]) != null ? _b2 : null, (_d2 = (_c2 = source[right]) == null ? void 0 : _c2[index]) != null ? _d2 : null) * Math.trunc(sortOrder);
  });
  return ok(rows.map((row) => [...source[row]]), dependencies);
}
__name(evaluateSort, "evaluateSort");
function evaluateUnique(values, dependencies) {
  var _a, _b, _c, _d, _e2;
  if (values.length < 1 || values.length > 3) return error("#VALUE!", dependencies);
  const source = toMatrix(values[0]);
  if (!source) return error("#VALUE!", dependencies);
  const byColumn = truthy((_a = values[1]) != null ? _a : false);
  const exactlyOnce = truthy((_b = values[2]) != null ? _b : false);
  const items = byColumn ? ((_c = source[0]) != null ? _c : []).map((_value, column) => source.map((row) => {
    var _a2;
    return (_a2 = row[column]) != null ? _a2 : null;
  })) : source.map((row) => [...row]);
  const keys = items.map((item) => JSON.stringify(item));
  const counts = /* @__PURE__ */ new Map();
  keys.forEach((key2) => {
    var _a2;
    return counts.set(key2, ((_a2 = counts.get(key2)) != null ? _a2 : 0) + 1);
  });
  const uniqueItems = items.filter((item, index) => {
    const first = keys.indexOf(keys[index]);
    return first === index && (!exactlyOnce || counts.get(keys[index]) === 1);
  });
  if (byColumn) {
    return ok((_e2 = (_d = uniqueItems[0]) == null ? void 0 : _d.map((_value, row) => uniqueItems.map((item) => {
      var _a2;
      return (_a2 = item[row]) != null ? _a2 : null;
    }))) != null ? _e2 : [], dependencies);
  }
  return ok(uniqueItems, dependencies);
}
__name(evaluateUnique, "evaluateUnique");
function evaluateSequence(values, dependencies) {
  var _a, _b, _c, _d;
  if (values.length < 1 || values.length > 4) return error("#VALUE!", dependencies);
  const rows = toNumber((_a = values[0]) != null ? _a : null);
  const columns = toNumber((_b = values[1]) != null ? _b : 1);
  const start = toNumber((_c = values[2]) != null ? _c : 1);
  const step = toNumber((_d = values[3]) != null ? _d : 1);
  if (rows === null || columns === null || start === null || step === null || rows < 1 || columns < 1 || !Number.isInteger(rows) || !Number.isInteger(columns)) return error("#VALUE!", dependencies);
  return ok(Array.from({ length: Math.trunc(rows) }, (_row, row) => Array.from({ length: Math.trunc(columns) }, (_column, column) => start + (row * Math.trunc(columns) + column) * step)), dependencies);
}
__name(evaluateSequence, "evaluateSequence");
function compareForSort(left, right) {
  if (compareValues(left, right, "=")) return 0;
  return compareValues(left, right, "<") ? -1 : 1;
}
__name(compareForSort, "compareForSort");
function evaluateSortBy(values, dependencies) {
  var _a, _b, _c;
  if (values.length < 3 || values.length % 2 === 0) return error("#VALUE!", dependencies);
  const source = toMatrix(values[0]);
  if (!source) return error("#VALUE!", dependencies);
  const rowCount = source.length;
  const columnCount = (_b = (_a = source[0]) == null ? void 0 : _a.length) != null ? _b : 0;
  const keys = [];
  for (let index = 1; index < values.length; index += 2) {
    const keyMatrix = toMatrix(values[index]);
    const order = toNumber((_c = values[index + 1]) != null ? _c : 1);
    if (!keyMatrix || order === null || ![1, -1].includes(Math.trunc(order))) return error("#VALUE!", dependencies);
    const rowKey = keyMatrix.length === rowCount && keyMatrix.every((row) => row.length === 1);
    const columnKey = keyMatrix.length === 1 && keyMatrix[0].length === columnCount;
    if (!rowKey && !columnKey) return error("#VALUE!", dependencies);
    keys.push({
      values: rowKey ? keyMatrix.map((row) => {
        var _a2;
        return (_a2 = row[0]) != null ? _a2 : null;
      }) : keyMatrix[0].slice(),
      order: Math.trunc(order)
    });
  }
  const rowMode = keys[0].values.length === rowCount;
  const positions = Array.from({ length: rowMode ? rowCount : columnCount }, (_2, index) => index);
  positions.sort((left, right) => {
    var _a2, _b2;
    for (const key2 of keys) {
      const comparison = compareForSort((_a2 = key2.values[left]) != null ? _a2 : null, (_b2 = key2.values[right]) != null ? _b2 : null) * key2.order;
      if (comparison !== 0) return comparison;
    }
    return left - right;
  });
  return ok(rowMode ? positions.map((row) => [...source[row]]) : source.map((row) => positions.map((column) => {
    var _a2;
    return (_a2 = row[column]) != null ? _a2 : null;
  })), dependencies);
}
__name(evaluateSortBy, "evaluateSortBy");
function evaluateTakeDrop(name, values, dependencies) {
  var _a;
  if (values.length < 2 || values.length > 3) return error("#VALUE!", dependencies);
  const source = toMatrix(values[0]);
  const rowCount = toNumber((_a = values[1]) != null ? _a : null);
  const columnCount = values[2] === void 0 ? null : toNumber(values[2]);
  if (!source || rowCount === null || columnCount === null && values[2] !== void 0) return error("#VALUE!", dependencies);
  const rows = sliceMatrix(name, source, Math.trunc(rowCount), 0);
  if (!rows.length) return error("#CALC!", dependencies);
  if (columnCount === null) return ok(rows, dependencies);
  const columns = sliceMatrix(name, rows, Math.trunc(columnCount), 1);
  return columns.length && columns[0].length ? ok(columns, dependencies) : error("#CALC!", dependencies);
}
__name(evaluateTakeDrop, "evaluateTakeDrop");
function sliceMatrix(name, source, count, axis) {
  var _a, _b;
  const size = axis === 0 ? source.length : (_b = (_a = source[0]) == null ? void 0 : _a.length) != null ? _b : 0;
  if (count === 0 || Math.abs(count) > size) return [];
  const start = name === "TAKE" ? count > 0 ? 0 : size + count : count > 0 ? count : 0;
  const end = name === "TAKE" ? count > 0 ? count : size : count > 0 ? size : size + count;
  if (axis === 0) return source.slice(start, end).map((row) => [...row]);
  return source.map((row) => row.slice(start, end));
}
__name(sliceMatrix, "sliceMatrix");
function evaluateChooseAxis(axis, values, dependencies) {
  var _a, _b;
  if (values.length < 2) return error("#VALUE!", dependencies);
  const source = toMatrix(values[0]);
  if (!source) return error("#VALUE!", dependencies);
  const size = axis === "rows" ? source.length : (_b = (_a = source[0]) == null ? void 0 : _a.length) != null ? _b : 0;
  const indexes = [];
  for (const value of values.slice(1)) {
    const index = toNumber(value);
    if (index === null || !Number.isInteger(index) || index === 0) return error("#VALUE!", dependencies);
    const normalized = index > 0 ? index - 1 : size + index;
    if (normalized < 0 || normalized >= size) return error("#VALUE!", dependencies);
    indexes.push(normalized);
  }
  if (axis === "rows") return ok(indexes.map((row) => [...source[row]]), dependencies);
  return ok(source.map((row) => indexes.map((column) => {
    var _a2;
    return (_a2 = row[column]) != null ? _a2 : null;
  })), dependencies);
}
__name(evaluateChooseAxis, "evaluateChooseAxis");
function evaluateToLine(axis, values, dependencies) {
  var _a, _b, _c, _d, _e2;
  if (values.length < 1 || values.length > 3) return error("#VALUE!", dependencies);
  const source = toMatrix(values[0]);
  const ignore = toNumber((_a = values[1]) != null ? _a : 0);
  const scanByColumn = truthy((_b = values[2]) != null ? _b : false);
  if (!source || ignore === null || ![0, 1, 2, 3].includes(Math.trunc(ignore))) return error("#VALUE!", dependencies);
  const flattened = [];
  if (scanByColumn) {
    for (let column = 0; column < ((_d = (_c = source[0]) == null ? void 0 : _c.length) != null ? _d : 0); column++) {
      for (const row of source) flattened.push((_e2 = row[column]) != null ? _e2 : null);
    }
  } else {
    for (const row of source) flattened.push(...row);
  }
  const filtered = flattened.filter((value) => {
    const blank = value === null || value === "";
    return ignore === 0 || ignore === 1 && !blank || ignore === 2 || ignore === 3 && !blank;
  });
  return ok(axis === "column" ? filtered.map((value) => [value]) : [filtered], dependencies);
}
__name(evaluateToLine, "evaluateToLine");
function evaluateConditionalAggregate(name, values, dependencies) {
  var _a;
  const criteriaRange = toMatrix(values[0]);
  const criteria = values[1];
  if (!criteriaRange || criteria === void 0) return error("#VALUE!", dependencies);
  const sumRange = toMatrix(name === "COUNTIF" ? values[0] : (_a = values[2]) != null ? _a : values[0]);
  if (!sumRange || !sameShape(criteriaRange, sumRange)) return error("#VALUE!", dependencies);
  const matched = [];
  forEachMatrix(criteriaRange, (criteriaValue, row, column) => {
    var _a2, _b;
    if (matchesCriteria(criteriaValue, criteria)) matched.push((_b = (_a2 = sumRange[row]) == null ? void 0 : _a2[column]) != null ? _b : null);
  });
  if (name === "COUNTIF") return ok(matched.length, dependencies);
  const numbers = numericValues(matched);
  if (name === "SUMIF") return ok(numbers.reduce((sum, value) => sum + value, 0), dependencies);
  return numbers.length === 0 ? error("#DIV/0!", dependencies) : ok(numbers.reduce((sum, value) => sum + value, 0) / numbers.length, dependencies);
}
__name(evaluateConditionalAggregate, "evaluateConditionalAggregate");
function evaluateMultiConditionalAggregate(name, values, dependencies) {
  const valueRange = toMatrix(values[0]);
  if (!valueRange || values.length < 3) return error("#VALUE!", dependencies);
  const criteriaPairs = name === "COUNTIFS" ? values : values.slice(1);
  if (criteriaPairs.length % 2 !== 0) return error("#VALUE!", dependencies);
  const pairs = [];
  for (let index = 0; index < criteriaPairs.length; index += 2) {
    const range = toMatrix(criteriaPairs[index]);
    const criteria = criteriaPairs[index + 1];
    if (!range || criteria === void 0 || !sameShape(valueRange, range)) return error("#VALUE!", dependencies);
    pairs.push({ range, criteria });
  }
  const matched = [];
  forEachMatrix(valueRange, (value, row, column) => {
    if (pairs.every((pair) => {
      var _a, _b;
      return matchesCriteria((_b = (_a = pair.range[row]) == null ? void 0 : _a[column]) != null ? _b : null, pair.criteria);
    })) {
      matched.push(value);
    }
  });
  if (name === "COUNTIFS") return ok(matched.length, dependencies);
  const numbers = numericValues(matched);
  if (name === "MAXIFS") return ok(numbers.length ? Math.max(...numbers) : 0, dependencies);
  if (name === "MINIFS") return ok(numbers.length ? Math.min(...numbers) : 0, dependencies);
  if (name === "SUMIFS") return ok(numbers.reduce((sum, value) => sum + value, 0), dependencies);
  return numbers.length === 0 ? error("#DIV/0!", dependencies) : ok(numbers.reduce((sum, value) => sum + value, 0) / numbers.length, dependencies);
}
__name(evaluateMultiConditionalAggregate, "evaluateMultiConditionalAggregate");
function evaluateLookup(name, values, dependencies) {
  var _a, _b, _c, _d, _e2, _f, _g, _h;
  const lookupValue = values[0];
  const table = toMatrix(values[1]);
  const index = toNumber((_a = values[2]) != null ? _a : null);
  const approximate = values.length >= 4 ? truthy(values[3]) : true;
  if (!table || index === null || index < 1 || approximate) return error(approximate ? "#N/A" : "#VALUE!", dependencies);
  const targetIndex = Math.trunc(index) - 1;
  if (name === "VLOOKUP") {
    if (targetIndex >= ((_c = (_b = table[0]) == null ? void 0 : _b.length) != null ? _c : 0)) return error("#REF!", dependencies);
    const row = table.find((item) => {
      var _a2;
      return compareValues((_a2 = item[0]) != null ? _a2 : null, lookupValue != null ? lookupValue : null, "=");
    });
    return row ? ok((_d = row[targetIndex]) != null ? _d : null, dependencies) : error("#N/A", dependencies);
  }
  if (targetIndex >= table.length) return error("#REF!", dependencies);
  const column = (_f = (_e2 = table[0]) == null ? void 0 : _e2.findIndex((value) => compareValues(value, lookupValue != null ? lookupValue : null, "="))) != null ? _f : -1;
  return column >= 0 ? ok((_h = (_g = table[targetIndex]) == null ? void 0 : _g[column]) != null ? _h : null, dependencies) : error("#N/A", dependencies);
}
__name(evaluateLookup, "evaluateLookup");
function evaluateIndex(values, dependencies) {
  var _a, _b, _c;
  const matrix = toMatrix(values[0]);
  const row = toNumber((_a = values[1]) != null ? _a : 1);
  const column = toNumber((_b = values[2]) != null ? _b : 1);
  if (!matrix || row === null || column === null || row < 1 || column < 1) return error("#VALUE!", dependencies);
  const value = (_c = matrix[Math.trunc(row) - 1]) == null ? void 0 : _c[Math.trunc(column) - 1];
  return value === void 0 ? error("#REF!", dependencies) : ok(value, dependencies);
}
__name(evaluateIndex, "evaluateIndex");
function evaluateMatch(values, dependencies) {
  var _a;
  const lookupValue = values[0];
  const matrix = toMatrix(values[1]);
  const matchType = toNumber((_a = values[2]) != null ? _a : 1);
  if (!matrix || matchType === null || matchType !== 0) return error("#N/A", dependencies);
  const vector = matrix.length === 1 ? matrix[0] : matrix.map((row) => {
    var _a2;
    return (_a2 = row[0]) != null ? _a2 : null;
  });
  const index = vector.findIndex((value) => compareValues(value, lookupValue != null ? lookupValue : null, "="));
  return index >= 0 ? ok(index + 1, dependencies) : error("#N/A", dependencies);
}
__name(evaluateMatch, "evaluateMatch");
function ok(value, dependencies = []) {
  return { value, error: null, dependencies };
}
__name(ok, "ok");
function error(value, dependencies = []) {
  return { value: null, error: value, dependencies };
}
__name(error, "error");
function numericValues(values) {
  return flatten(values).map((value) => toNumber(value)).filter((value) => value !== null);
}
__name(numericValues, "numericValues");
function toMatrix(value) {
  if (value === void 0) return null;
  return Array.isArray(value) ? value : [[value]];
}
__name(toMatrix, "toMatrix");
function sameShape(left, right) {
  return left.length === right.length && left.every((row, index) => {
    var _a, _b;
    return row.length === ((_b = (_a = right[index]) == null ? void 0 : _a.length) != null ? _b : -1);
  });
}
__name(sameShape, "sameShape");
function forEachMatrix(matrix, visit) {
  for (let row = 0; row < matrix.length; row++) {
    for (let column = 0; column < matrix[row].length; column++) {
      visit(matrix[row][column], row, column);
    }
  }
}
__name(forEachMatrix, "forEachMatrix");
function flatten(values) {
  return values.flatMap((value) => Array.isArray(value) ? value.flat() : [value]);
}
__name(flatten, "flatten");
function toText(value) {
  if (Array.isArray(value)) return value.flat().map((item) => toText(item)).join("");
  if (value === null) return "";
  if (typeof value === "boolean") return value ? "TRUE" : "FALSE";
  return String(value);
}
__name(toText, "toText");
function toNumber(value) {
  if (Array.isArray(value)) return null;
  if (value === null || value === "") return 0;
  if (typeof value === "number") return Number.isFinite(value) ? value : null;
  if (typeof value === "boolean") return value ? 1 : 0;
  if (typeof value === "string") {
    const number = Number(value);
    return Number.isFinite(number) ? number : null;
  }
  return null;
}
__name(toNumber, "toNumber");
function matchesCriteria(value, criteria) {
  var _a;
  if (Array.isArray(criteria)) return false;
  if (typeof criteria !== "string") return compareValues(value, criteria, "=");
  const match = /^(<=|>=|<>|=|<|>)(.*)$/.exec(criteria);
  if (!match) return (_a = wildcardMatches(value, criteria)) != null ? _a : compareValues(value, criteria, "=");
  const operator = match[1];
  const rawRight = match[2];
  const numericRight = Number(rawRight);
  const right = rawRight !== "" && Number.isFinite(numericRight) ? numericRight : rawRight;
  if (operator === "=" || operator === "<>") {
    const wildcard = wildcardMatches(value, rawRight);
    if (wildcard !== null) return operator === "=" ? wildcard : !wildcard;
  }
  return compareValues(value, right, operator);
}
__name(matchesCriteria, "matchesCriteria");
function wildcardMatches(value, criteria) {
  if (!criteria.includes("*") && !criteria.includes("?")) return null;
  let pattern = "";
  for (let index = 0; index < criteria.length; index++) {
    const char = criteria[index];
    if (char === "~" && index + 1 < criteria.length) {
      pattern += escapeRegex(criteria[++index]);
    } else if (char === "*") {
      pattern += ".*";
    } else if (char === "?") {
      pattern += ".";
    } else {
      pattern += escapeRegex(char);
    }
  }
  return new RegExp(`^${pattern}$`, "i").test(toText(value));
}
__name(wildcardMatches, "wildcardMatches");
function escapeRegex(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
__name(escapeRegex, "escapeRegex");
function truthy(value) {
  if (Array.isArray(value)) return value.flat().some(truthy);
  if (typeof value === "boolean") return value;
  if (typeof value === "number") return value !== 0;
  if (typeof value === "string") return value.length > 0;
  return false;
}
__name(truthy, "truthy");
function compareValues(left, right, operator) {
  const leftNumber = toNumber(left);
  const rightNumber = toNumber(right);
  const comparableLeft = leftNumber != null ? leftNumber : String(left != null ? left : "");
  const comparableRight = rightNumber != null ? rightNumber : String(right != null ? right : "");
  switch (operator) {
    case "=":
      return comparableLeft === comparableRight;
    case "<>":
      return comparableLeft !== comparableRight;
    case ">":
      return comparableLeft > comparableRight;
    case ">=":
      return comparableLeft >= comparableRight;
    case "<":
      return comparableLeft < comparableRight;
    case "<=":
      return comparableLeft <= comparableRight;
    default:
      return false;
  }
}
__name(compareValues, "compareValues");
var MS_PER_DAY = 864e5;
function toDateParts(value) {
  if (Array.isArray(value) || value === null || value === "") return null;
  if (typeof value === "number" && Number.isFinite(value)) {
    const time2 = Date.UTC(1899, 11, 30) + value * MS_PER_DAY;
    return datePartsFromTime(time2);
  }
  if (typeof value !== "string") return null;
  const match = /^\s*(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})\s*$/.exec(value);
  const time = match ? Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3])) : Date.parse(value);
  return Number.isFinite(time) ? datePartsFromTime(time) : null;
}
__name(toDateParts, "toDateParts");
function datePartsFromTime(time) {
  const date = new Date(time);
  if (!Number.isFinite(date.getTime())) return null;
  return { year: date.getUTCFullYear(), month: date.getUTCMonth() + 1, day: date.getUTCDate(), time };
}
__name(datePartsFromTime, "datePartsFromTime");
function excelSerialFromDate(date) {
  const utcMidnight = Date.UTC(date.getFullYear(), date.getMonth(), date.getDate());
  return Math.floor((utcMidnight - Date.UTC(1899, 11, 30)) / MS_PER_DAY);
}
__name(excelSerialFromDate, "excelSerialFromDate");
function parseSpreadsheetFormula(formula) {
  const parser = new FormulaParser(tokenizeFormula(stripFormulaPrefix(formula)));
  return parser.parse();
}
__name(parseSpreadsheetFormula, "parseSpreadsheetFormula");
function collectSpreadsheetFormulaReferences(formula) {
  const references = [];
  try {
    collectReferences(parseSpreadsheetFormula(formula), references);
  } catch (e2) {
    return [];
  }
  return dedupeReferences(references);
}
__name(collectSpreadsheetFormulaReferences, "collectSpreadsheetFormulaReferences");
function collectReferences(ast, output) {
  switch (ast.kind) {
    case "cell":
      output.push({ kind: "cell", address: ast.address, sheetName: ast.sheetName });
      return;
    case "range":
      output.push({
        kind: "range",
        startAddress: ast.startAddress,
        endAddress: ast.endAddress,
        sheetName: ast.sheetName
      });
      return;
    case "unary":
      collectReferences(ast.argument, output);
      return;
    case "binary":
      collectReferences(ast.left, output);
      collectReferences(ast.right, output);
      return;
    case "call":
      ast.args.forEach((arg) => collectReferences(arg, output));
      return;
    case "number":
    case "string":
    case "name":
      return;
  }
}
__name(collectReferences, "collectReferences");
function dedupeReferences(references) {
  const seen = /* @__PURE__ */ new Set();
  return references.filter((reference) => {
    var _a, _b;
    const key2 = reference.kind === "cell" ? `cell:${(_a = reference.sheetName) != null ? _a : ""}:${reference.address}` : `range:${(_b = reference.sheetName) != null ? _b : ""}:${reference.startAddress}:${reference.endAddress}`;
    if (seen.has(key2)) return false;
    seen.add(key2);
    return true;
  });
}
__name(dedupeReferences, "dedupeReferences");
function stripFormulaPrefix(formula) {
  return formula.trim().startsWith("=") ? formula.trim().slice(1) : formula.trim();
}
__name(stripFormulaPrefix, "stripFormulaPrefix");
function tokenizeFormula(input) {
  var _a;
  const tokens = [];
  let index = 0;
  while (index < input.length) {
    const ch = input[index];
    if (/\s/.test(ch)) {
      index++;
      continue;
    }
    if (/\d/.test(ch) || ch === "." && /\d/.test((_a = input[index + 1]) != null ? _a : "")) {
      const start = index;
      index++;
      while (index < input.length && /[\d.]/.test(input[index])) index++;
      const value = Number(input.slice(start, index));
      if (!Number.isFinite(value)) throw new Error("Invalid number literal");
      tokens.push({ kind: "number", value });
      continue;
    }
    if (ch === '"') {
      let value = "";
      index++;
      while (index < input.length) {
        const next = input[index];
        if (next === '"') {
          if (input[index + 1] === '"') {
            value += '"';
            index += 2;
            continue;
          }
          index++;
          break;
        }
        value += next;
        index++;
      }
      tokens.push({ kind: "string", value });
      continue;
    }
    if (ch === "'") {
      const sheetStart = index + 1;
      let sheetName = "";
      index = sheetStart;
      while (index < input.length) {
        if (input[index] === "'") {
          if (input[index + 1] === "'") {
            sheetName += "'";
            index += 2;
            continue;
          }
          break;
        }
        sheetName += input[index];
        index++;
      }
      if (input[index] !== "'" || input[index + 1] !== "!") throw new Error("Invalid sheet reference");
      index += 2;
      const start = index;
      while (index < input.length && /[A-Za-z0-9_$]/.test(input[index])) index++;
      const cell = normalizeCellReference(input.slice(start, index));
      if (!cell) throw new Error("Invalid sheet cell reference");
      tokens.push({ kind: "cell", value: cell, sheetName });
      continue;
    }
    if (ch === "(" || ch === ")") {
      tokens.push({ kind: "paren", value: ch });
      index++;
      continue;
    }
    if (ch === ",") {
      tokens.push({ kind: "comma", value: ch });
      index++;
      continue;
    }
    if (ch === ":") {
      tokens.push({ kind: "colon", value: ch });
      index++;
      continue;
    }
    const twoChar = input.slice(index, index + 2);
    if (twoChar === ">=" || twoChar === "<=" || twoChar === "<>") {
      tokens.push({ kind: "operator", value: twoChar });
      index += 2;
      continue;
    }
    if ("+-*/&%=><".includes(ch)) {
      tokens.push({ kind: "operator", value: ch });
      index++;
      continue;
    }
    if (/[A-Za-z_$]/.test(ch)) {
      const start = index;
      index++;
      while (index < input.length && /[A-Za-z0-9_$.]/.test(input[index])) index++;
      const raw = input.slice(start, index);
      if (input[index] === "!") {
        index++;
        const cellStart = index;
        while (index < input.length && /[A-Za-z0-9_$]/.test(input[index])) index++;
        const cell2 = normalizeCellReference(input.slice(cellStart, index));
        if (!cell2) throw new Error("Invalid sheet cell reference");
        tokens.push({ kind: "cell", value: cell2, sheetName: raw });
        continue;
      }
      const cell = normalizeCellReference(raw);
      tokens.push(cell ? { kind: "cell", value: cell } : { kind: "identifier", value: raw });
      continue;
    }
    throw new Error(`Unexpected token: ${ch}`);
  }
  tokens.push({ kind: "eof" });
  return tokens;
}
__name(tokenizeFormula, "tokenizeFormula");
var _FormulaParser = class _FormulaParser2 {
  constructor(tokens) {
    __publicField(this, "tokens", tokens);
    __publicField(this, "index", 0);
  }
  parse() {
    const expression = this.parseComparison();
    this.expect("eof");
    return expression;
  }
  parseComparison() {
    let left = this.parseConcatenation();
    while (this.isOperator("=", "<>", ">", ">=", "<", "<=")) {
      const operator = this.advanceOperator();
      left = { kind: "binary", operator, left, right: this.parseConcatenation() };
    }
    return left;
  }
  parseConcatenation() {
    let left = this.parseAdditive();
    while (this.isOperator("&")) {
      this.advanceOperator();
      left = { kind: "binary", operator: "&", left, right: this.parseAdditive() };
    }
    return left;
  }
  parseAdditive() {
    let left = this.parseMultiplicative();
    while (this.isOperator("+", "-")) {
      const operator = this.advanceOperator();
      left = { kind: "binary", operator, left, right: this.parseMultiplicative() };
    }
    return left;
  }
  parseMultiplicative() {
    let left = this.parseUnary();
    while (this.isOperator("*", "/")) {
      const operator = this.advanceOperator();
      left = { kind: "binary", operator, left, right: this.parseUnary() };
    }
    return left;
  }
  parseUnary() {
    if (this.isOperator("+", "-")) {
      const operator = this.advanceOperator();
      return { kind: "unary", operator, argument: this.parseUnary() };
    }
    return this.parsePostfix();
  }
  parsePostfix() {
    let expression = this.parsePrimary();
    while (this.isOperator("%")) {
      this.advanceOperator();
      expression = { kind: "unary", operator: "%", argument: expression };
    }
    return expression;
  }
  parsePrimary() {
    const token = this.advance();
    if (token.kind === "number") return { kind: "number", value: token.value };
    if (token.kind === "string") return { kind: "string", value: token.value };
    if (token.kind === "cell") {
      if (this.peek().kind === "colon") {
        this.advance();
        const end = this.advance();
        if (end.kind !== "cell") throw new Error("Range reference must end with a cell");
        if (end.sheetName && end.sheetName !== token.sheetName) throw new Error("Range sheets must match");
        return {
          kind: "range",
          startAddress: token.value,
          endAddress: end.value,
          sheetName: token.sheetName
        };
      }
      return { kind: "cell", address: token.value, sheetName: token.sheetName };
    }
    if (token.kind === "identifier") {
      return this.isParen("(") ? this.parseCall(token.value) : { kind: "name", name: token.value };
    }
    if (token.kind === "paren" && token.value === "(") {
      const expression = this.parseComparison();
      this.expect("paren", ")");
      return expression;
    }
    throw new Error("Expected expression");
  }
  parseCall(name) {
    this.expect("paren", "(");
    const args = [];
    if (!this.isParen(")")) {
      do {
        args.push(this.parseComparison());
      } while (this.consume("comma"));
    }
    this.expect("paren", ")");
    return { kind: "call", name: name.toUpperCase(), args };
  }
  isOperator(...operators) {
    const token = this.peek();
    return token.kind === "operator" && operators.includes(token.value);
  }
  isParen(value) {
    const token = this.peek();
    return token.kind === "paren" && token.value === value;
  }
  advanceOperator() {
    const token = this.advance();
    if (token.kind !== "operator") throw new Error("Expected operator");
    return token.value;
  }
  consume(kind) {
    if (this.peek().kind !== kind) return false;
    this.advance();
    return true;
  }
  expect(kind, value) {
    const token = this.advance();
    if (token.kind !== kind || value !== void 0 && "value" in token && token.value !== value) {
      throw new Error(`Expected ${kind}`);
    }
    return token;
  }
  peek() {
    var _a;
    return (_a = this.tokens[this.index]) != null ? _a : { kind: "eof" };
  }
  advance() {
    var _a;
    return (_a = this.tokens[this.index++]) != null ? _a : { kind: "eof" };
  }
};
__name(_FormulaParser, "FormulaParser");
var FormulaParser = _FormulaParser;
function normalizeCellReference(raw) {
  try {
    const parsed = parseCellAddress(raw.replace(/\$/g, ""));
    return formatCellAddress(parsed.row, parsed.column);
  } catch (e2) {
    return null;
  }
}
__name(normalizeCellReference, "normalizeCellReference");
function formulaError(error2, dependencies = []) {
  return {
    value: null,
    displayText: error2,
    error: error2,
    dependencies
  };
}
__name(formulaError, "formulaError");
function formulaValue(value, dependencies = []) {
  var _a, _b;
  const displayValue = Array.isArray(value) ? (_b = (_a = value[0]) == null ? void 0 : _a[0]) != null ? _b : null : value;
  return {
    value,
    displayText: displayValue === null ? "" : String(displayValue),
    error: null,
    dependencies
  };
}
__name(formulaValue, "formulaValue");
var _SpreadsheetFormulaEvaluationError = class _SpreadsheetFormulaEvaluationError2 extends Error {
  constructor(formulaError2, dependencies = []) {
    super(formulaError2);
    __publicField(this, "formulaError", formulaError2);
    __publicField(this, "dependencies", dependencies);
  }
};
__name(_SpreadsheetFormulaEvaluationError, "SpreadsheetFormulaEvaluationError");
var SpreadsheetFormulaEvaluationError = _SpreadsheetFormulaEvaluationError;
var _SpreadsheetFormulaEngine = class _SpreadsheetFormulaEngine2 {
  constructor(sheet, options = {}) {
    __publicField(this, "sheet", sheet);
    __publicField(this, "options", options);
    __publicField(this, "cellsByAddress");
    __publicField(this, "resultsByAddress", /* @__PURE__ */ new Map());
    __publicField(this, "resultsBySheetAddress", /* @__PURE__ */ new Map());
    __publicField(this, "dependenciesByAddress", /* @__PURE__ */ new Map());
    __publicField(this, "dependentsByAddress", /* @__PURE__ */ new Map());
    __publicField(this, "evaluating", /* @__PURE__ */ new Set());
    __publicField(this, "cellsBySheet", /* @__PURE__ */ new Map());
    __publicField(this, "sheetsByName", /* @__PURE__ */ new Map());
    var _a;
    this.cellsByAddress = new Map(sheet.cells.map((cell) => [cell.address, cell]));
    const sheets = (_a = options.sheets) != null ? _a : [sheet];
    for (const item of sheets) {
      this.sheetsByName.set(item.name, item);
      this.cellsBySheet.set(item.name, new Map(item.cells.map((cell) => [cell.address, cell])));
    }
  }
  calculate() {
    for (const cell of this.sheet.cells) {
      if (cell.formula) this.evaluateFormulaCell(cell.address);
    }
    return this.withSpillResults(new Map(this.resultsByAddress));
  }
  recalculate(changedAddresses) {
    this.calculate();
    const affected = this.getAffectedFormulaAddresses(changedAddresses);
    for (const address of affected) {
      this.resultsByAddress.delete(address);
      this.resultsBySheetAddress.delete(sheetAddressKey(this.sheet.name, address));
      this.dependenciesByAddress.delete(address);
    }
    this.rebuildDependents();
    for (const address of affected) {
      this.evaluateFormulaCell(address);
    }
    return this.withSpillResults(new Map(
      [...affected].map((address) => [address, this.resultsByAddress.get(address)]).filter((entry) => entry[1] !== void 0)
    ));
  }
  updateCellValue(address, value) {
    const normalized = addressFromKey(normalizeAddressKey(address));
    const affected = /* @__PURE__ */ new Set([
      ...this.getAffectedFormulaAddresses([normalized]),
      normalized
    ]);
    this.setCellValue(normalized, value);
    return this.recalculateKnownAffected(affected);
  }
  updateCellFormula(address, formula) {
    const expression = normalizeExcelCellFormula(formula);
    const normalized = addressFromKey(normalizeAddressKey(address));
    const affected = /* @__PURE__ */ new Set([
      ...this.getAffectedFormulaAddresses([normalized]),
      normalized
    ]);
    this.setCellFormula(normalized, expression);
    return this.recalculateKnownAffected(affected);
  }
  evaluateFormulaCell(address) {
    return this.evaluateFormulaCellAt(this.sheet, address);
  }
  evaluateFormulaCellAt(targetSheet, address) {
    var _a, _b;
    const cacheKey = sheetAddressKey(targetSheet.name, address);
    const cached = this.resultsBySheetAddress.get(cacheKey);
    if (cached) return cached;
    const cell = (_a = targetSheet === this.sheet ? this.cellsByAddress : this.cellsBySheet.get(targetSheet.name)) == null ? void 0 : _a.get(address);
    if (!(cell == null ? void 0 : cell.formula)) return formulaValue((_b = cell == null ? void 0 : cell.value) != null ? _b : null);
    if (this.evaluating.has(cacheKey)) {
      const result2 = formulaError("#CYCLE!");
      this.resultsBySheetAddress.set(cacheKey, result2);
      return result2;
    }
    this.evaluating.add(cacheKey);
    let result;
    try {
      const ast = parseSpreadsheetFormula(cell.formula);
      const evaluated = evaluateSpreadsheetFormulaAst(ast, {
        getToday: /* @__PURE__ */ __name(() => {
          var _a2;
          return excelSerialFromDate2((_a2 = this.options.today) != null ? _a2 : /* @__PURE__ */ new Date());
        }, "getToday"),
        isRowHidden: /* @__PURE__ */ __name((row, sheetName) => {
          var _a2;
          const referencedSheet = sheetName ? this.sheetsByName.get(sheetName) : targetSheet;
          return ((_a2 = referencedSheet == null ? void 0 : referencedSheet.rows.find((item) => item.index === row)) == null ? void 0 : _a2.hidden) === true;
        }, "isRowHidden"),
        getCellEvaluation: /* @__PURE__ */ __name((cellAddress, sheetName) => {
          var _a2;
          const referencedSheet = sheetName ? this.sheetsByName.get(sheetName) : targetSheet;
          const referenced = (_a2 = sheetName ? this.cellsBySheet.get(sheetName) : targetSheet === this.sheet ? this.cellsByAddress : this.cellsBySheet.get(targetSheet.name)) == null ? void 0 : _a2.get(cellAddress);
          if (!referenced) return formulaValue(null);
          if (!referenced.formula) return formulaValue(referenced.value);
          return this.evaluateFormulaCellAt(referencedSheet != null ? referencedSheet : targetSheet, cellAddress);
        }, "getCellEvaluation"),
        getCellValue: /* @__PURE__ */ __name((cellAddress, sheetName) => {
          var _a2, _b2, _c;
          const referencedSheet = sheetName ? this.sheetsByName.get(sheetName) : targetSheet;
          const referenced = (_a2 = sheetName ? this.cellsBySheet.get(sheetName) : targetSheet === this.sheet ? this.cellsByAddress : this.cellsBySheet.get(targetSheet.name)) == null ? void 0 : _a2.get(cellAddress);
          if (!referenced) return null;
          if (!referenced.formula) return referenced.value;
          const nested = this.evaluateFormulaCellAt(referencedSheet != null ? referencedSheet : targetSheet, cellAddress);
          if (nested.error) {
            throw new SpreadsheetFormulaEvaluationError(nested.error, [
              { kind: "cell", address: cellAddress },
              ...nested.dependencies
            ]);
          }
          return Array.isArray(nested.value) ? (_c = (_b2 = nested.value[0]) == null ? void 0 : _b2[0]) != null ? _c : null : nested.value;
        }, "getCellValue")
      });
      result = evaluated.error ? formulaError(evaluated.error, evaluated.dependencies) : formulaValue(evaluated.value, evaluated.dependencies);
    } catch (error2) {
      result = error2 instanceof SpreadsheetFormulaEvaluationError ? formulaError(error2.formulaError, error2.dependencies) : formulaError("#VALUE!");
    } finally {
      this.evaluating.delete(cacheKey);
    }
    this.resultsBySheetAddress.set(cacheKey, result);
    if (targetSheet === this.sheet) {
      this.resultsByAddress.set(address, result);
      this.registerDependencies(address, result.dependencies);
    }
    return result;
  }
  getDependencies(address) {
    var _a;
    if (!this.dependenciesByAddress.has(address)) this.evaluateFormulaCell(address);
    return [...(_a = this.dependenciesByAddress.get(address)) != null ? _a : []];
  }
  getDependents(address) {
    var _a;
    this.calculate();
    return [...(_a = this.dependentsByAddress.get(normalizeAddressKey(address))) != null ? _a : []].sort(compareAddresses);
  }
  getAffectedFormulaAddresses(changedAddresses) {
    this.calculate();
    const affected = /* @__PURE__ */ new Set();
    const queue = [...changedAddresses].map(normalizeAddressKey);
    for (let index = 0; index < queue.length; index++) {
      const address = queue[index];
      const dependents = this.dependentsByAddress.get(address);
      if (!dependents) continue;
      for (const dependent of dependents) {
        if (affected.has(dependent)) continue;
        affected.add(dependent);
        queue.push(normalizeAddressKey(dependent));
      }
    }
    return this.sortAffectedFormulaAddresses(affected);
  }
  registerDependencies(formulaAddress, dependencies) {
    this.dependenciesByAddress.set(formulaAddress, dependencies);
    this.addDependentEdges(formulaAddress, dependencies);
  }
  addDependentEdges(formulaAddress, dependencies) {
    for (const dependency of dependencies) {
      for (const address of expandDependencyAddresses(dependency)) {
        let dependents = this.dependentsByAddress.get(address);
        if (!dependents) {
          dependents = /* @__PURE__ */ new Set();
          this.dependentsByAddress.set(address, dependents);
        }
        dependents.add(formulaAddress);
      }
    }
  }
  rebuildDependents() {
    this.dependentsByAddress.clear();
    for (const [address, dependencies] of this.dependenciesByAddress) {
      this.addDependentEdges(address, dependencies);
    }
  }
  recalculateKnownAffected(affected) {
    this.clearCalculationState();
    this.calculate();
    const sorted = this.sortAffectedFormulaAddresses(
      new Set([...affected].filter((address) => {
        var _a;
        return (_a = this.cellsByAddress.get(address)) == null ? void 0 : _a.formula;
      }))
    );
    return this.withSpillResults(new Map(
      sorted.map((address) => [address, this.resultsByAddress.get(address)]).filter((entry) => entry[1] !== void 0)
    ));
  }
  clearCalculationState() {
    this.resultsByAddress.clear();
    this.resultsBySheetAddress.clear();
    this.dependenciesByAddress.clear();
    this.dependentsByAddress.clear();
    this.evaluating.clear();
  }
  withSpillResults(results) {
    var _a, _b, _c, _d;
    const occupiedSpillCells = /* @__PURE__ */ new Set();
    for (const cell of this.sheet.cells) {
      if (!cell.formula) continue;
      const result = results.get(cell.address);
      if (!result || result.error || !Array.isArray(result.value)) continue;
      const array = result.value;
      const occupied = new Set(this.sheet.cells.filter((item) => item.address !== cell.address && (item.formula || item.value !== null)).map((item) => `${item.row}:${item.column}`));
      const hasConflict = array.some((row, rowOffset) => row.some((_value, columnOffset) => {
        const key2 = `${cell.row + rowOffset}:${cell.column + columnOffset}`;
        return occupied.has(key2) || occupiedSpillCells.has(key2);
      }));
      if (hasConflict) {
        results.set(cell.address, formulaError("#SPILL!", result.dependencies));
        continue;
      }
      for (let rowOffset = 0; rowOffset < array.length; rowOffset++) {
        for (let columnOffset = 0; columnOffset < ((_b = (_a = array[rowOffset]) == null ? void 0 : _a.length) != null ? _b : 0); columnOffset++) {
          if (rowOffset === 0 && columnOffset === 0) continue;
          const address = addressFromRowColumn(cell.row + rowOffset, cell.column + columnOffset);
          occupiedSpillCells.add(`${cell.row + rowOffset}:${cell.column + columnOffset}`);
          results.set(address, formulaValue((_d = (_c = array[rowOffset]) == null ? void 0 : _c[columnOffset]) != null ? _d : null, [{ kind: "cell", address: cell.address }]));
        }
      }
    }
    return results;
  }
  setCellValue(address, value) {
    if (value === null) {
      clearExcelCellContent(this.sheet, this.cellsByAddress, address);
      return;
    }
    const cell = this.ensureCell(address);
    cell.value = value;
    cell.kind = typeof value === "boolean" ? "boolean" : typeof value === "number" ? "number" : "string";
    delete cell.formula;
    clearExcelCellStringMetadata(cell);
  }
  setCellFormula(address, formula) {
    if (formula === null) {
      clearExcelCellContent(this.sheet, this.cellsByAddress, address);
      return;
    }
    const cell = this.ensureCell(address);
    cell.kind = "formula";
    cell.formula = formula;
    cell.value = null;
    clearExcelCellStringMetadata(cell);
  }
  ensureCell(address) {
    const existing = this.cellsByAddress.get(address);
    if (existing) return existing;
    const parsed = parseAddress(address);
    const cell = {
      address,
      row: parsed.row,
      column: parsed.column,
      kind: "blank",
      value: null
    };
    this.sheet.cells.push(cell);
    this.sheet.cells.sort((left, right) => left.row - right.row || left.column - right.column);
    this.cellsByAddress.set(address, cell);
    return cell;
  }
  sortAffectedFormulaAddresses(affected) {
    const remaining = new Set(affected);
    const sorted = [];
    while (remaining.size > 0) {
      const ready = [...remaining].filter((address) => {
        var _a;
        const dependencies = (_a = this.dependenciesByAddress.get(address)) != null ? _a : [];
        return !dependencies.some(
          (dependency) => expandDependencyAddresses(dependency).some(
            (dependencyAddress) => remaining.has(addressFromKey(dependencyAddress))
          )
        );
      }).sort(compareAddresses);
      if (ready.length === 0) {
        sorted.push(...[...remaining].sort(compareAddresses));
        break;
      }
      for (const address of ready) {
        remaining.delete(address);
        sorted.push(address);
      }
    }
    return sorted;
  }
};
__name(_SpreadsheetFormulaEngine, "SpreadsheetFormulaEngine");
var SpreadsheetFormulaEngine = _SpreadsheetFormulaEngine;
function sheetAddressKey(sheetName, address) {
  return `${sheetName}\0${address}`;
}
__name(sheetAddressKey, "sheetAddressKey");
function addressFromRowColumn(row, column) {
  return `${columnIndexToName2(column)}${row}`;
}
__name(addressFromRowColumn, "addressFromRowColumn");
function calculateSpreadsheetSheetFormulas(sheet, options = {}) {
  return new SpreadsheetFormulaEngine(sheet, options).calculate();
}
__name(calculateSpreadsheetSheetFormulas, "calculateSpreadsheetSheetFormulas");
function excelSerialFromDate2(date) {
  const utcMidnight = Date.UTC(date.getFullYear(), date.getMonth(), date.getDate());
  return Math.floor((utcMidnight - Date.UTC(1899, 11, 30)) / 864e5);
}
__name(excelSerialFromDate2, "excelSerialFromDate");
function expandDependencyAddresses(dependency) {
  if (dependency.kind === "cell") return [normalizeAddressKey(dependency.address)];
  const start = parseAddress(dependency.startAddress);
  const end = parseAddress(dependency.endAddress);
  const addresses = [];
  for (let row = Math.min(start.row, end.row); row <= Math.max(start.row, end.row); row++) {
    for (let column = Math.min(start.column, end.column); column <= Math.max(start.column, end.column); column++) {
      addresses.push(`${row}:${column}`);
    }
  }
  return addresses;
}
__name(expandDependencyAddresses, "expandDependencyAddresses");
function normalizeAddressKey(address) {
  const parsed = parseAddress(address);
  return `${parsed.row}:${parsed.column}`;
}
__name(normalizeAddressKey, "normalizeAddressKey");
function addressFromKey(key2) {
  const [row, column] = key2.split(":").map(Number);
  if (!row || !column) return key2;
  return `${columnIndexToName2(column)}${row}`;
}
__name(addressFromKey, "addressFromKey");
function parseAddress(address) {
  const match = /^\$?([A-Za-z]+)\$?(\d+)$/.exec(address.trim());
  if (!match) return { row: 0, column: 0 };
  return {
    row: Number(match[2]),
    column: columnNameToIndex2(match[1])
  };
}
__name(parseAddress, "parseAddress");
function columnNameToIndex2(columnName) {
  let value = 0;
  for (const ch of columnName.toUpperCase()) value = value * 26 + (ch.charCodeAt(0) - 64);
  return value;
}
__name(columnNameToIndex2, "columnNameToIndex");
function columnIndexToName2(columnIndex) {
  let value = columnIndex;
  let name = "";
  while (value > 0) {
    const remainder = (value - 1) % 26;
    name = String.fromCharCode(65 + remainder) + name;
    value = Math.floor((value - 1) / 26);
  }
  return name;
}
__name(columnIndexToName2, "columnIndexToName");
function compareAddresses(left, right) {
  const leftRef = parseAddress(left);
  const rightRef = parseAddress(right);
  return leftRef.row - rightRef.row || leftRef.column - rightRef.column || left.localeCompare(right);
}
__name(compareAddresses, "compareAddresses");
function diffExcelWorkbookModels(before, after) {
  const beforeById = new Map(before.sheets.map((sheet) => [sheet.id, sheet]));
  const afterById = new Map(after.sheets.map((sheet) => [sheet.id, sheet]));
  const sheets = [];
  for (const beforeSheet of before.sheets) {
    const afterSheet = afterById.get(beforeSheet.id);
    if (!afterSheet) {
      sheets.push({
        kind: "deleted",
        sheetId: beforeSheet.id,
        beforeName: beforeSheet.name,
        cellChanges: beforeSheet.cells.length,
        cells: beforeSheet.cells.map((cell) => ({
          kind: "deleted",
          address: cell.address,
          before: cloneExcelCell(cell)
        })),
        structuralChanged: true,
        objectChanged: hasSheetObjects(beforeSheet)
      });
      continue;
    }
    const cells = diffCells(beforeSheet.cells, afterSheet.cells);
    const structuralChanged = sheetStructureKey(beforeSheet) !== sheetStructureKey(afterSheet);
    const objectChanged = sheetObjectsKey(beforeSheet) !== sheetObjectsKey(afterSheet);
    if (beforeSheet.name !== afterSheet.name) {
      sheets.push({
        kind: "renamed",
        sheetId: beforeSheet.id,
        beforeName: beforeSheet.name,
        afterName: afterSheet.name,
        cellChanges: cells.length,
        cells,
        structuralChanged,
        objectChanged
      });
    } else if (cells.length || structuralChanged || objectChanged) {
      sheets.push({
        kind: "modified",
        sheetId: beforeSheet.id,
        beforeName: beforeSheet.name,
        afterName: afterSheet.name,
        cellChanges: cells.length,
        cells,
        structuralChanged,
        objectChanged
      });
    }
  }
  for (const afterSheet of after.sheets) {
    if (!beforeById.has(afterSheet.id)) {
      sheets.push({
        kind: "added",
        sheetId: afterSheet.id,
        afterName: afterSheet.name,
        cellChanges: afterSheet.cells.length,
        cells: afterSheet.cells.map((cell) => ({
          kind: "added",
          address: cell.address,
          after: cloneExcelCell(cell)
        })),
        structuralChanged: true,
        objectChanged: hasSheetObjects(afterSheet)
      });
    }
  }
  return {
    changed: sheets.length > 0 || stableJson(before.definedNames) !== stableJson(after.definedNames) || stableJson(before.styles) !== stableJson(after.styles),
    sheets
  };
}
__name(diffExcelWorkbookModels, "diffExcelWorkbookModels");
function planExcelWriteback(before, after, capabilities, options = {}) {
  var _a;
  const diff = diffExcelWorkbookModels(before, after);
  if (!diff.changed) {
    return { strategy: "no-op", diff, operations: [], warnings: [], unsupportedReasons: [] };
  }
  const preference = (_a = options.preference) != null ? _a : "auto";
  const packagePlan = tryPlanPackage(diff, capabilities);
  if (preference === "package") return packagePlan;
  const shadowPlan = tryPlanSheetShadow(diff, after, capabilities);
  if (preference === "sheet-shadow") return shadowPlan;
  const diffPlan = tryPlanDiff(diff, capabilities);
  if (preference === "diff") return diffPlan;
  if (packagePlan.strategy !== "unsupported") return packagePlan;
  if (shadowPlan.strategy !== "unsupported") return shadowPlan;
  if (diffPlan.strategy !== "unsupported") return diffPlan;
  return unsupported(diff, [
    ...diffPlan.unsupportedReasons,
    ...shadowPlan.unsupportedReasons,
    ...packagePlan.unsupportedReasons
  ]);
}
__name(planExcelWriteback, "planExcelWriteback");
function tryPlanPackage(diff, capabilities) {
  if (!capabilities.canReplaceWorkbookPackage) {
    return unsupported(diff, ["host cannot replace the active workbook package in place"]);
  }
  return {
    strategy: "workbook-package-replace",
    diff,
    operations: [{ type: "replaceWorkbookPackage" }],
    warnings: [],
    unsupportedReasons: []
  };
}
__name(tryPlanPackage, "tryPlanPackage");
function tryPlanDiff(diff, capabilities) {
  var _a;
  if (!capabilities.canPatchCells) {
    return unsupported(diff, ["host cannot patch cells directly"]);
  }
  const maxCellPatchCount = (_a = capabilities.maxCellPatchCount) != null ? _a : Number.POSITIVE_INFINITY;
  const operations = [];
  const warnings = [];
  for (const sheet of diff.sheets) {
    if (sheet.kind === "added" || sheet.kind === "deleted") {
      return unsupported(diff, [`diff patch cannot ${sheet.kind} sheets without sheet lifecycle support`]);
    }
    if (sheet.kind === "renamed") {
      if (!capabilities.canRenameSheet || !sheet.beforeName || !sheet.afterName) {
        return unsupported(diff, ["diff patch cannot rename sheets with current host capabilities"]);
      }
      operations.push({ type: "renameSheet", fromName: sheet.beforeName, toName: sheet.afterName });
    }
    if (sheet.cellChanges > maxCellPatchCount) {
      return unsupported(diff, [`cell patch count ${sheet.cellChanges} exceeds maxCellPatchCount ${maxCellPatchCount}`]);
    }
    if (sheet.cellChanges > 0 && sheet.afterName) {
      operations.push({
        type: "patchCells",
        sheetName: sheet.afterName,
        cellCount: sheet.cellChanges,
        changes: sheet.cells.map(cloneCellDiff)
      });
    }
    if (sheet.structuralChanged || sheet.objectChanged) {
      if (!capabilities.canPatchSheetObjects || !sheet.afterName) {
        return unsupported(diff, ["diff patch cannot patch sheet structure or objects with current host capabilities"]);
      }
      operations.push({ type: "patchSheetObjects", sheetName: sheet.afterName });
      warnings.push("sheet object patch is adapter-defined and may require domain-specific repair logic");
    }
  }
  return { strategy: "diff-patch", diff, operations, warnings, unsupportedReasons: [] };
}
__name(tryPlanDiff, "tryPlanDiff");
function tryPlanSheetShadow(diff, after, capabilities) {
  var _a;
  const missing = requireCapabilities(capabilities, [
    "canInsertShadowSheets",
    "canCopySheetContent",
    "canDeleteSheet",
    "canRenameSheet"
  ]);
  if (missing.length) {
    return unsupported(diff, [`sheet shadow replace requires ${missing.join(", ")}`]);
  }
  const operations = [];
  const warnings = [];
  const afterById = new Map(after.sheets.map((sheet) => [sheet.id, sheet]));
  for (const sheet of diff.sheets) {
    if (sheet.kind === "deleted") {
      if (sheet.beforeName) operations.push({ type: "deleteSheet", sheetName: sheet.beforeName });
      continue;
    }
    if (!sheet.afterName) continue;
    const targetSheet = afterById.get(sheet.sheetId);
    if (!targetSheet) {
      return unsupported(diff, [`target sheet model not found for sheet id ${sheet.sheetId}`]);
    }
    const shadowName = `__coco_shadow_${sheet.sheetId}`;
    operations.push({
      type: "insertShadowSheet",
      sheetId: sheet.sheetId,
      sheetName: shadowName,
      targetSheet: cloneSheet(targetSheet),
      targetStyles: cloneStyles2(after.styles)
    });
    if (sheet.kind === "added") {
      operations.push({ type: "renameSheet", fromName: shadowName, toName: sheet.afterName });
      continue;
    }
    const targetName = (_a = sheet.beforeName) != null ? _a : sheet.afterName;
    operations.push({ type: "copySheetContent", fromSheetName: shadowName, toSheetName: targetName });
    if (sheet.objectChanged) {
      operations.push({ type: "repairSheetObjects", sheetName: targetName });
      warnings.push(`sheet ${targetName} has object changes; adapter must repair host-specific object fidelity`);
    }
    operations.push({ type: "deleteSheet", sheetName: shadowName });
    if (sheet.kind === "renamed" && sheet.beforeName && sheet.afterName) {
      operations.push({ type: "renameSheet", fromName: sheet.beforeName, toName: sheet.afterName });
    }
  }
  return { strategy: "sheet-shadow-replace", diff, operations, warnings, unsupportedReasons: [] };
}
__name(tryPlanSheetShadow, "tryPlanSheetShadow");
function requireCapabilities(capabilities, names) {
  return names.filter((name) => capabilities[name] !== true);
}
__name(requireCapabilities, "requireCapabilities");
function unsupported(diff, unsupportedReasons) {
  return {
    strategy: "unsupported",
    diff,
    operations: [],
    warnings: [],
    unsupportedReasons: [...new Set(unsupportedReasons)]
  };
}
__name(unsupported, "unsupported");
function diffCells(before, after) {
  const beforeByAddress = new Map(before.map((cell) => [cell.address, cell]));
  const afterByAddress = new Map(after.map((cell) => [cell.address, cell]));
  const changes = [];
  for (const beforeCell of before) {
    const afterCell = afterByAddress.get(beforeCell.address);
    if (!afterCell) {
      changes.push({ kind: "deleted", address: beforeCell.address, before: cloneExcelCell(beforeCell) });
    } else if (stableJson(beforeCell) !== stableJson(afterCell)) {
      changes.push({
        kind: "modified",
        address: beforeCell.address,
        before: cloneExcelCell(beforeCell),
        after: cloneExcelCell(afterCell)
      });
    }
  }
  for (const afterCell of after) {
    if (!beforeByAddress.has(afterCell.address)) {
      changes.push({ kind: "added", address: afterCell.address, after: cloneExcelCell(afterCell) });
    }
  }
  return changes.sort((left, right) => left.address.localeCompare(right.address, void 0, { numeric: true }));
}
__name(diffCells, "diffCells");
function cloneCellDiff(diff) {
  return {
    kind: diff.kind,
    address: diff.address,
    before: diff.before ? cloneExcelCell(diff.before) : void 0,
    after: diff.after ? cloneExcelCell(diff.after) : void 0
  };
}
__name(cloneCellDiff, "cloneCellDiff");
function cloneStyles2(styles) {
  return {
    numberFormats: styles.numberFormats.map((format) => __spreadValues({}, format)),
    fonts: styles.fonts.map((font) => __spreadProps(__spreadValues({}, font), {
      color: font.color ? __spreadValues({}, font.color) : void 0
    })),
    fills: styles.fills.map((fill) => __spreadProps(__spreadValues({}, fill), {
      foregroundColor: fill.foregroundColor ? __spreadValues({}, fill.foregroundColor) : void 0,
      backgroundColor: fill.backgroundColor ? __spreadValues({}, fill.backgroundColor) : void 0
    })),
    borders: styles.borders.map((border) => ({
      left: border.left ? __spreadProps(__spreadValues({}, border.left), { color: border.left.color ? __spreadValues({}, border.left.color) : void 0 }) : void 0,
      right: border.right ? __spreadProps(__spreadValues({}, border.right), { color: border.right.color ? __spreadValues({}, border.right.color) : void 0 }) : void 0,
      top: border.top ? __spreadProps(__spreadValues({}, border.top), { color: border.top.color ? __spreadValues({}, border.top.color) : void 0 }) : void 0,
      bottom: border.bottom ? __spreadProps(__spreadValues({}, border.bottom), { color: border.bottom.color ? __spreadValues({}, border.bottom.color) : void 0 }) : void 0,
      diagonal: border.diagonal ? __spreadProps(__spreadValues({}, border.diagonal), { color: border.diagonal.color ? __spreadValues({}, border.diagonal.color) : void 0 }) : void 0
    })),
    cellFormats: styles.cellFormats.map((format) => __spreadProps(__spreadValues({}, format), {
      alignment: format.alignment ? __spreadValues({}, format.alignment) : void 0
    }))
  };
}
__name(cloneStyles2, "cloneStyles");
function cloneSheet(sheet) {
  return __spreadProps(__spreadValues({}, sheet), {
    sheetViews: sheet.sheetViews.map((view) => __spreadProps(__spreadValues({}, view), {
      pane: view.pane ? __spreadValues({}, view.pane) : void 0,
      selections: view.selections.map((selection) => __spreadValues({}, selection))
    })),
    columns: sheet.columns.map((column) => __spreadValues({}, column)),
    rows: sheet.rows.map((row) => __spreadValues({}, row)),
    mergedRanges: sheet.mergedRanges.map((range) => __spreadValues({}, range)),
    hyperlinks: sheet.hyperlinks.map((hyperlink) => __spreadValues({}, hyperlink)),
    tables: sheet.tables.map((table) => __spreadProps(__spreadValues({}, table), {
      columns: table.columns.map((column) => __spreadValues({}, column)),
      autoFilter: table.autoFilter ? __spreadProps(__spreadValues({}, table.autoFilter), {
        filterColumns: table.autoFilter.filterColumns.map((column) => __spreadProps(__spreadValues({}, column), {
          filters: column.filters ? [...column.filters] : void 0
        })),
        sortState: table.autoFilter.sortState ? __spreadProps(__spreadValues({}, table.autoFilter.sortState), {
          conditions: table.autoFilter.sortState.conditions.map((condition) => __spreadValues({}, condition))
        }) : void 0
      }) : void 0,
      style: table.style ? __spreadValues({}, table.style) : void 0
    })),
    dataValidations: sheet.dataValidations.map((validation) => __spreadValues({}, validation)),
    conditionalFormats: sheet.conditionalFormats.map((format) => __spreadProps(__spreadValues({}, format), {
      rules: format.rules.map((rule) => __spreadProps(__spreadValues({}, rule), { formulas: [...rule.formulas] }))
    })),
    comments: sheet.comments.map((comment) => __spreadValues({}, comment)),
    threadedComments: sheet.threadedComments.map((comment) => __spreadValues({}, comment)),
    drawings: sheet.drawings.map((drawing) => __spreadProps(__spreadValues({}, drawing), {
      anchors: drawing.anchors.map(cloneDrawingAnchor)
    })),
    charts: sheet.charts.map((chart) => __spreadProps(__spreadValues({}, chart), { formulaRefs: [...chart.formulaRefs] })),
    images: sheet.images.map((image) => __spreadValues({}, image)),
    cells: sheet.cells.map(cloneExcelCell)
  });
}
__name(cloneSheet, "cloneSheet");
function hasSheetObjects(sheet) {
  return sheet.hyperlinks.length > 0 || sheet.tables.length > 0 || sheet.dataValidations.length > 0 || sheet.conditionalFormats.length > 0 || sheet.comments.length > 0 || sheet.threadedComments.length > 0 || sheet.drawings.length > 0 || sheet.charts.length > 0 || sheet.images.length > 0;
}
__name(hasSheetObjects, "hasSheetObjects");
function sheetStructureKey(sheet) {
  return stableJson({
    name: sheet.name,
    visibility: sheet.visibility,
    dimension: sheet.dimension,
    sheetViews: sheet.sheetViews,
    columns: sheet.columns,
    rows: sheet.rows,
    mergedRanges: sheet.mergedRanges
  });
}
__name(sheetStructureKey, "sheetStructureKey");
function sheetObjectsKey(sheet) {
  return stableJson({
    hyperlinks: sheet.hyperlinks,
    tables: sheet.tables,
    dataValidations: sheet.dataValidations,
    conditionalFormats: sheet.conditionalFormats,
    comments: sheet.comments,
    threadedComments: sheet.threadedComments,
    drawings: sheet.drawings,
    charts: sheet.charts,
    images: sheet.images
  });
}
__name(sheetObjectsKey, "sheetObjectsKey");
function stableJson(value) {
  return JSON.stringify(sortForJson(value));
}
__name(stableJson, "stableJson");
function sortForJson(value) {
  if (Array.isArray(value)) return value.map(sortForJson);
  if (!value || typeof value !== "object") return value;
  return Object.fromEntries(
    Object.entries(value).filter(([, entryValue]) => entryValue !== void 0).sort(([left], [right]) => left.localeCompare(right)).map(([key2, entryValue]) => [key2, sortForJson(entryValue)])
  );
}
__name(sortForJson, "sortForJson");
async function createShadowWorkbookPayload(sheet, options = {}) {
  const model = createShadowWorkbookModel(sheet, options);
  const pkg = createWorkbookPackageFromModel(model);
  const bytes = await toZip(pkg);
  return {
    sheetName: model.sheets[0].name,
    model,
    package: pkg,
    bytes,
    base64: bytesToBase64(bytes)
  };
}
__name(createShadowWorkbookPayload, "createShadowWorkbookPayload");
function createShadowWorkbookModel(sheet, options = {}) {
  var _a, _b, _c, _d;
  const shadowSheet = cloneJson2(sheet);
  shadowSheet.id = (_a = options.sheetId) != null ? _a : shadowSheet.id;
  shadowSheet.name = (_b = options.sheetName) != null ? _b : shadowSheet.name;
  shadowSheet.relationshipId = void 0;
  shadowSheet.path = void 0;
  return {
    sharedStrings: [],
    definedNames: ((_c = options.definedNames) != null ? _c : []).map((name) => __spreadValues({}, name)),
    styles: cloneStyles3((_d = options.styles) != null ? _d : emptyStyles2()),
    sheets: [shadowSheet]
  };
}
__name(createShadowWorkbookModel, "createShadowWorkbookModel");
function emptyStyles2() {
  return {
    numberFormats: [],
    fonts: [],
    fills: [],
    borders: [],
    cellFormats: []
  };
}
__name(emptyStyles2, "emptyStyles");
function cloneStyles3(styles) {
  return cloneJson2(styles);
}
__name(cloneStyles3, "cloneStyles");
function cloneJson2(value) {
  return JSON.parse(JSON.stringify(value));
}
__name(cloneJson2, "cloneJson");
function bytesToBase64(bytes) {
  if (typeof Buffer !== "undefined") {
    return Buffer.from(bytes).toString("base64");
  }
  let binary = "";
  const chunkSize = 32768;
  for (let i2 = 0; i2 < bytes.length; i2 += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i2, i2 + chunkSize));
  }
  return btoa(binary);
}
__name(bytesToBase64, "bytesToBase64");

// coco-engine/packages/application-tools/src/runners/excel-script.ts
var import_jszip2 = __toESM(require_lib3(), 1);
var XLSX_MEDIA_TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
function createExcelScriptRunner() {
  return {
    supports(resource) {
      return resource.type === "excel-script";
    },
    async run(context) {
      const templateResourceId = context.resource.config?.templateResourceId;
      const source = await context.loader.readText(context.resource.source);
      let workbook;
      if (context.manifest.documentAccess === "current") {
        if (!context.document) {
          throw new Error("\u8BF7\u5148\u6253\u5F00\u4E00\u4E2A Excel \u6587\u6863\u518D\u8FD0\u884C\u8BE5\u5DE5\u5177\u3002");
        }
        if (context.document.mediaType !== XLSX_MEDIA_TYPE) {
          throw new Error(`Current document is not an Excel workbook: ${context.document.mediaType}`);
        }
        workbook = await ExcelWorkbook.fromZip(context.document.bytes, { mode: "inline" });
      } else if (templateResourceId === void 0) {
        workbook = await createBlankWorkbook();
      } else {
        const template = typeof templateResourceId === "string" ? context.manifest.resources[templateResourceId] : void 0;
        if (!template || template.type !== "excel-template") {
          throw new Error(`Excel template resource not found: ${templateResourceId}`);
        }
        workbook = await ExcelWorkbook.fromZip(
          await context.loader.readBytes(template.source),
          { mode: "inline" }
        );
      }
      try {
        const wrappedSource = [
          source,
          'if (typeof run !== "function") throw new Error("Excel app-tool script must define run(workbook, args)");',
          "return await run(workbook, args);"
        ].join("\n");
        const metadata = await workbook.executeCode(
          wrappedSource,
          context.inputs,
          3e4,
          context.signal
        );
        let bytes = await workbook.toZip();
        if (context.resource.config?.print === "a4-portrait") {
          const variables = { ...context.inputs, ...metadata };
          const sheetMetadataKey = context.resource.config.printSheetMetadata;
          const areaRange = context.resource.config.printAreaRange;
          const sheetNames = typeof sheetMetadataKey === "string" && Array.isArray(metadata[sheetMetadataKey]) ? metadata[sheetMetadataKey].filter((value) => typeof value === "string") : [];
          if (sheetNames.length > 0 && typeof areaRange === "string") {
            for (const sheetName of sheetNames) {
              const quotedName = sheetName.replace(/'/g, "''");
              bytes = await applyA4PortraitPrintSetup(
                bytes,
                `'${quotedName}'!${areaRange}`,
                sheetName
              );
            }
          } else {
            const printArea = interpolateConfig(context.resource.config.printArea, variables);
            const printSheet = interpolateConfig(context.resource.config.printSheet, variables);
            bytes = await applyA4PortraitPrintSetup(bytes, printArea, printSheet);
          }
        }
        const requestedName = context.inputs.fileName;
        const fileName = context.manifest.documentAccess === "current" && context.document ? ensureXlsxExtension(context.document.fileName) : typeof requestedName === "string" && requestedName.trim() ? ensureXlsxExtension(requestedName.trim()) : `${context.manifest.name}.xlsx`;
        return [{ kind: "file", fileName, mediaType: XLSX_MEDIA_TYPE, bytes, metadata }];
      } finally {
        await workbook.dispose();
      }
    }
  };
}
async function createBlankWorkbook() {
  const seed = await ExcelWorkbook.fromModel({
    sheets: [],
    sharedStrings: [],
    definedNames: [],
    styles: {
      numberFormats: [],
      fonts: [{ name: "Carlito", size: 11 }],
      fills: [{ patternType: "none" }, { patternType: "gray125" }],
      borders: [{}],
      cellFormats: [{ fontId: 0, fillId: 0, borderId: 0, numberFormatId: 0 }]
    }
  }, { mode: "inline" });
  try {
    await seed.worksheets.add("Sheet1");
    return await ExcelWorkbook.fromZip(await seed.toZip(), { mode: "inline" });
  } finally {
    await seed.dispose();
  }
}
async function applyA4PortraitPrintSetup(bytes, printArea, printSheet) {
  const zip = await import_jszip2.default.loadAsync(bytes);
  const target = printSheet ? await resolveWorksheetTarget(zip, printSheet) : void 0;
  const worksheetPaths = target ? [target.path] : Object.keys(zip.files).filter((name) => /^xl\/worksheets\/sheet\d+\.xml$/.test(name));
  const pageXml = '<printOptions horizontalCentered="1"/><pageMargins left="0" right="0" top="0" bottom="0" header="0" footer="0"/><pageSetup paperSize="9" orientation="portrait" fitToWidth="1" fitToHeight="1"/>';
  await Promise.all(
    worksheetPaths.map(async (worksheetPath) => {
      const file = zip.file(worksheetPath);
      if (!file) return;
      let xml = await file.async("string");
      const root = xml.match(/<([A-Za-z_][\w.-]*:)?worksheet\b/);
      const prefix = root?.[1] ?? "";
      xml = xml.replace(new RegExp(`<${prefix}sheetPr\\b[^>]*>[\\s\\S]*?<\\/${prefix}sheetPr>`), "").replace(new RegExp(`<${prefix}(?:printOptions|pageMargins|pageSetup)\\b[^>]*/>`, "g"), "");
      xml = xml.replace(
        new RegExp(`(<${prefix}worksheet\\b[^>]*>)`),
        `$1<${prefix}sheetPr><${prefix}pageSetUpPr fitToPage="1"/></${prefix}sheetPr>`
      );
      const namespacedPageXml = pageXml.replace(/<(\/?)([A-Za-z])/g, `<$1${prefix}$2`);
      const drawingTag = `<${prefix}drawing `;
      xml = xml.includes(drawingTag) ? xml.replace(drawingTag, `${namespacedPageXml}${drawingTag}`) : xml.replace(`</${prefix}worksheet>`, `${namespacedPageXml}</${prefix}worksheet>`);
      zip.file(worksheetPath, xml);
    })
  );
  if (printArea) {
    const workbookFile = zip.file("xl/workbook.xml");
    if (workbookFile) {
      let xml = await workbookFile.async("string");
      const root = xml.match(/<([A-Za-z_][\w.-]*:)?workbook\b/);
      const prefix = root?.[1] ?? "";
      const localSheetId = target?.index ?? 0;
      const existing = new RegExp(
        `<${prefix}definedName\\b(?=[^>]*\\bname="_xlnm\\.Print_Area")(?=[^>]*\\blocalSheetId="${localSheetId}")[^>]*>[\\s\\S]*?<\\/${prefix}definedName>`,
        "g"
      );
      xml = xml.replace(existing, "");
      const definedName = `<${prefix}definedName name="_xlnm.Print_Area" localSheetId="${localSheetId}">${escapeXmlText(printArea)}</${prefix}definedName>`;
      if (xml.includes(`<${prefix}definedNames>`)) {
        xml = xml.replace(`</${prefix}definedNames>`, `${definedName}</${prefix}definedNames>`);
      } else {
        xml = xml.replace(
          `</${prefix}workbook>`,
          `<${prefix}definedNames>${definedName}</${prefix}definedNames></${prefix}workbook>`
        );
      }
      zip.file("xl/workbook.xml", xml);
    }
  }
  return zip.generateAsync({ type: "uint8array" });
}
function interpolateConfig(value, variables) {
  if (typeof value !== "string") return void 0;
  return value.replace(/\{\{([A-Za-z_][A-Za-z0-9_]*)\}\}/g, (_match, key2) => {
    const replacement = variables[key2];
    if (replacement === void 0 || replacement === null) {
      throw new Error(`Missing application tool output for config placeholder: ${key2}`);
    }
    return String(replacement);
  });
}
async function resolveWorksheetTarget(zip, sheetName) {
  const workbookXml = await zip.file("xl/workbook.xml")?.async("string");
  const relationshipsXml = await zip.file("xl/_rels/workbook.xml.rels")?.async("string");
  if (!workbookXml || !relationshipsXml) return void 0;
  const sheets = [...workbookXml.matchAll(/<(?:[A-Za-z_][\w.-]*:)?sheet\b([^>]*)\/?\s*>/g)];
  const index = sheets.findIndex((match) => decodeXmlAttribute(readXmlAttribute(match[1] ?? "", "name")) === sheetName);
  if (index < 0) return void 0;
  const relationshipId = readXmlAttribute(sheets[index]?.[1] ?? "", "r:id") ?? readXmlAttribute(sheets[index]?.[1] ?? "", "id");
  if (!relationshipId) return void 0;
  const relationship = [...relationshipsXml.matchAll(/<(?:[A-Za-z_][\w.-]*:)?Relationship\b([^>]*)\/?\s*>/g)].find((match) => readXmlAttribute(match[1] ?? "", "Id") === relationshipId);
  const relativeTarget = relationship ? readXmlAttribute(relationship[1] ?? "", "Target") : void 0;
  if (!relativeTarget) return void 0;
  const path = relativeTarget.startsWith("/") ? relativeTarget.slice(1) : `xl/${relativeTarget.replace(/^\.\//, "")}`;
  return { index, path };
}
function readXmlAttribute(attributes, name) {
  const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return attributes.match(new RegExp(`(?:^|\\s)${escaped}="([^"]*)"`))?.[1];
}
function decodeXmlAttribute(value) {
  return value?.replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&");
}
function escapeXmlText(value) {
  return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function ensureXlsxExtension(fileName) {
  return fileName.toLowerCase().endsWith(".xlsx") ? fileName : `${fileName}.xlsx`;
}

// coco-dsh/packages/workbuddy/local-skills/src/shared.mjs
init_define_COCO_TOOL_CONFIG();
import { randomUUID } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import { join, sep } from "node:path";
function validateInputs(definitions, provided) {
  if (!provided || typeof provided !== "object" || Array.isArray(provided)) {
    throw new Error("\u8BF7\u4F20\u5165 JSON \u53C2\u6570\u5BF9\u8C61");
  }
  for (const key2 of Object.keys(provided)) {
    if (!definitions.some(({ name }) => name === key2)) throw new Error("\u672A\u77E5\u53C2\u6570 " + key2);
  }
  const inputs = {};
  for (const { name, label, type, options, required, default: fallback } of definitions) {
    const value = Object.hasOwn(provided, name) ? provided[name] : fallback;
    if (value === void 0) {
      if (required) throw new Error("\u7F3A\u5C11\u53C2\u6570\uFF1A" + label);
      continue;
    }
    const valid = type === "string-array" ? Array.isArray(value) && value.every((item) => typeof item === "string") : typeof value === type;
    if (!valid || required && typeof value === "string" && !value.trim() || options && !options.includes(value)) {
      throw new Error("\u53C2\u6570\u4E0D\u7B26\u5408\u5B9A\u4E49\uFF1A" + label);
    }
    inputs[name] = value;
  }
  return inputs;
}
async function main({ name, fileStem, extension, document = void 0, runner, serialize = (artifact) => artifact.bytes }) {
  console.log = console.info = console.debug = console.warn = console.error.bind(console);
  let raw = "";
  if (process.argv[2] === "--input-file") {
    raw = await readFile(process.argv[3], "utf8");
  } else {
    process.stdin.setEncoding("utf8");
    for await (const chunk of process.stdin) raw += chunk;
  }
  const config = define_COCO_TOOL_CONFIG_default;
  const inputs = validateInputs(config.inputs, JSON.parse(raw));
  const manifest = { ...config, name, documentAccess: document ? "current" : "new" };
  const [artifact] = await runner.run({
    manifest,
    resourceId: manifest.entry,
    resource: manifest.resources[manifest.entry],
    inputs,
    loader: { readText: async () => "async function run(workbook, args) {\n  const spacingMode = String(args.spacingMode ?? '');\n  const layout = copybookLayout(spacingMode);\n  if (!layout) {\n    throw new Error('\u8BF7\u9009\u62E9\u95F4\u8DDD\u6A21\u5F0F\uFF1A\u65E0\u95F4\u8DDD\u3001\u5355\u884C\u95F4\u8DDD\u6216\u4E09\u884C\u95F4\u8DDD\uFF08\u62FC\u97F3\u5B57\u5E16\uFF09\u3002');\n  }\n  const fillMode = String(args.fillMode ?? 'row-repeat');\n  if (!['row-repeat', 'row-full', 'row-head', 'single-cell'].includes(fillMode)) {\n    throw new Error('\u4E0D\u652F\u6301\u7684\u6587\u5B57\u586B\u5199\u65B9\u5F0F\u3002');\n  }\n  const sheetTexts = normalizeSheetTexts(args);\n  const generated = [];\n  for (let index = 0; index < sheetTexts.length; index += 1) {\n    const text = Array.from(sheetTexts[index]);\n    const pinyinTexts = pinyinForSheet(args, index, sheetTexts.length, text.length);\n    const baseName = sheetTexts.length === 1\n      ? '\u63CF\u7EA2\u5B57\u5E16'\n      : copybookSheetName(sheetTexts[index], index);\n    const sheet = selectCopybookSheet(workbook, baseName, index === 0);\n    generated.push({ sheet, ...fillCopybookSheet(sheet, text, pinyinTexts, layout, fillMode) });\n  }\n  const lastGenerated = generated[generated.length - 1];\n  selectSheet(workbook, lastGenerated.sheet);\n\n  // Flush ordinary worksheet edits before adding package-backed SDK layout objects.\n  await workbook.toZip();\n  for (const item of generated) {\n    workbook.addWorksheetLines(item.sheet.name(), copybookGuideLines(layout));\n    workbook.setWorksheetPrintSetup(item.sheet.name(), {\n      paperSize: 9,\n      orientation: 'portrait',\n      fitToWidth: 1,\n      fitToHeight: 1,\n      horizontalCentered: true,\n      margins: { left: 0, right: 0, top: 0, bottom: 0, header: 0, footer: 0 },\n      // Keep one blank safety column on both sides of the copybook grid.\n      // The right outline sits on the N/O boundary; ending the print area at\n      // column N lets some spreadsheet/printer pipelines clip that line.\n      printArea: `$A$1:$O$${layout.lastRow}`,\n    });\n  }\n\n  return {\n    sheetName: lastGenerated.sheet.name(),\n    sheetNames: generated.map((item) => item.sheet.name()),\n    sheetCount: generated.length,\n    spacingMode,\n    fillMode,\n    written: generated.reduce((sum, item) => sum + item.written, 0),\n    truncated: generated.some((item) => item.truncated),\n    capacity: fillMode === 'single-cell' ? 1 : layout.gridRows.length,\n  };\n}\n\nfunction copybookLayout(spacingMode) {\n  if (spacingMode === 'none') {\n    return {\n      gridRows: range(2, 20, 1),\n      pinyinRows: [],\n      spacerRows: [],\n      lastRow: 21,\n    };\n  }\n  if (spacingMode === 'single') {\n    return {\n      // A practice gap should be visually useful without consuming another\n      // complete 39.75pt Tianzi square. Fourteen rows still fit on one A4 page.\n      gridRows: range(2, 28, 2),\n      pinyinRows: [],\n      spacerRows: range(3, 27, 2),\n      lastRow: 29,\n    };\n  }\n  if (spacingMode === 'pinyin') {\n    return {\n      // Each unit is a 24pt four-line/three-space Pinyin grid followed by a\n      // 39.75pt Tianzi grid, with only a compact separator between units.\n      pinyinRows: range(2, 29, 3),\n      gridRows: range(3, 30, 3),\n      spacerRows: range(4, 28, 3),\n      lastRow: 31,\n    };\n  }\n  return undefined;\n}\n\nfunction range(start, end, step) {\n  const values = [];\n  for (let value = start; value <= end; value += step) values.push(value);\n  return values;\n}\n\nfunction fillCopybookSheet(sheet, text, pinyinTexts, layout, fillMode) {\n  // Keep the Tianzi dimensions calibrated against WPS. The first and last rows\n  // remain fixed page margins for every layout.\n  sheet.getRange('A:O').setColumnWidth(5.889999866485596);\n  sheet.getRange(`1:${layout.lastRow}`).setRowHeight(39.75);\n  for (const row of layout.spacerRows) sheet.getRange(`${row}:${row}`).setRowHeight(8);\n  for (const row of layout.pinyinRows) sheet.getRange(`${row}:${row}`).setRowHeight(24);\n  sheet.setSheetViews([{ workbookViewId: 0, showGridLines: false, selections: [] }]);\n  const side = { style: 'thin', color: { rgb: '#2C7A69' } };\n  for (const row of layout.gridRows) {\n    const grid = sheet.getRange(`B${row}:N${row}`);\n    grid.format.border.setValue({ left: side, right: side, top: side, bottom: side });\n    grid.format.alignment.setValue({ horizontal: 'center', vertical: 'center' });\n    grid.format.font.setValue({ name: 'KaiTi', size: 26, color: { rgb: '#D49A84' } });\n    sheet.getRange(`B${row}`).format.font.setColor({ rgb: '#6A4B3B' });\n  }\n  const capacity = fillMode === 'single-cell' ? 1 : layout.gridRows.length;\n  const characters = text.slice(0, capacity);\n  for (let index = 0; index < characters.length; index += 1) {\n    const row = layout.gridRows[index];\n    sheet.getRange(`B${row}`).setValues([[characters[index]]]);\n    if (fillMode === 'row-repeat') {\n      sheet.getRange(`C${row}:H${row}`).setValues([Array(6).fill(characters[index])]);\n    } else if (fillMode === 'row-full') {\n      sheet.getRange(`C${row}:N${row}`).setValues([Array(12).fill(characters[index])]);\n    }\n    const pinyinRow = layout.pinyinRows[index];\n    const pinyin = pinyinTexts[index] ?? '';\n    if (pinyinRow !== undefined && pinyin) {\n      const pinyinGrid = sheet.getRange(`B${pinyinRow}:N${pinyinRow}`);\n      pinyinGrid.format.alignment.setValue({ horizontal: 'center', vertical: 'center' });\n      pinyinGrid.format.font.setValue({ name: 'Arial', size: 10, color: { rgb: '#D49A84' } });\n      sheet.getRange(`B${pinyinRow}`).format.font.setColor({ rgb: '#6A4B3B' });\n      sheet.getRange(`B${pinyinRow}`).setValues([[pinyin]]);\n      if (fillMode === 'row-repeat') {\n        sheet.getRange(`C${pinyinRow}:H${pinyinRow}`).setValues([Array(6).fill(pinyin)]);\n      } else if (fillMode === 'row-full') {\n        sheet.getRange(`C${pinyinRow}:N${pinyinRow}`).setValues([Array(12).fill(pinyin)]);\n      }\n    }\n  }\n\n  return {\n    written: characters.length,\n    truncated: text.length > capacity,\n  };\n}\n\nfunction pinyinForSheet(args, sheetIndex, sheetCount, characterCount) {\n  if (args.pinyinTexts === undefined || args.pinyinTexts === null) return [];\n  if (!Array.isArray(args.pinyinTexts)) throw new Error('pinyinTexts \u5FC5\u987B\u662F\u9010\u5B57\u62FC\u97F3\u6570\u7EC4\u3002');\n  const values = args.pinyinTexts.map((value) => String(value ?? '').trim());\n  if (sheetCount === 1) return values.slice(0, characterCount);\n  // The common multi-sheet form is one character per sheet. A flat array can\n  // therefore stay compatible with the manifest's string-array input type.\n  if (characterCount <= 1 && values.length === sheetCount) return [values[sheetIndex] ?? ''];\n  return [];\n}\n\nfunction normalizeSheetTexts(args) {\n  if (args.sheetTexts === undefined || args.sheetTexts === null) {\n    return [String(args.text ?? '').replace(/\\s+/g, '')];\n  }\n  if (!Array.isArray(args.sheetTexts)) throw new Error('sheetTexts \u5FC5\u987B\u662F\u6587\u5B57\u6570\u7EC4\u3002');\n  if (args.sheetTexts.length === 0) throw new Error('sheetTexts \u4E0D\u80FD\u662F\u7A7A\u6570\u7EC4\u3002');\n  if (args.sheetTexts.length > 50) throw new Error('\u4E00\u6B21\u6700\u591A\u751F\u6210 50 \u5F20\u5B57\u5E16\u3002');\n  return args.sheetTexts.map((value) => String(value ?? '').replace(/\\s+/g, ''));\n}\n\nfunction copybookSheetName(text, index) {\n  const label = Array.from(text).slice(0, 10).join('').replace(/[\\\\/*?:\\[\\]]/g, '-');\n  return `\u63CF\u7EA2\u5B57\u5E16-${label || index + 1}`.slice(0, 31);\n}\n\nfunction selectCopybookSheet(workbook, baseName, allowReuse) {\n  const sheets = workbook.worksheets.items();\n  if (sheets.length === 0) return workbook.worksheets.add(baseName);\n\n  const current = sheets.find((candidate) =>\n    candidate.sheetViews().some((view) => view.tabSelected === true),\n  ) ?? sheets[0];\n  const reusable = allowReuse && !hasSheetContent(current) ? current : undefined;\n  const name = uniqueSheetName(workbook, baseName, reusable);\n  const sheet = reusable ?? workbook.worksheets.add(name);\n  if (sheet.name() !== name) sheet.rename(name);\n  return sheet;\n}\n\nfunction hasSheetContent(sheet) {\n  const model = sheet.toModel();\n  const hasCellContent = model.cells.some((cell) =>\n    Boolean(cell.formula) || (cell.value !== null && cell.value !== ''),\n  );\n  return hasCellContent || [\n    model.tables,\n    model.hyperlinks,\n    model.comments,\n    model.threadedComments,\n    model.drawings,\n    model.charts,\n    model.images,\n  ].some((items) => items.length > 0);\n}\n\nfunction uniqueSheetName(workbook, baseName, reusableSheet) {\n  const occupied = new Set(\n    workbook.worksheets.items()\n      .filter((sheet) => sheet !== reusableSheet)\n      .map((sheet) => sheet.name()),\n  );\n  if (!occupied.has(baseName)) return baseName;\n  for (let index = 2; index < 1000; index += 1) {\n    const candidate = `${baseName} (${index})`;\n    if (!occupied.has(candidate)) return candidate;\n  }\n  throw new Error('\u65E0\u6CD5\u4E3A\u63CF\u7EA2\u5B57\u5E16\u521B\u5EFA\u552F\u4E00\u7684\u5DE5\u4F5C\u8868\u540D\u79F0\u3002');\n}\n\nfunction selectSheet(workbook, selectedSheet) {\n  for (const sheet of workbook.worksheets.items()) {\n    const views = sheet.sheetViews();\n    const nextViews = views.length > 0\n      ? views.map((view) => ({ ...view, tabSelected: sheet === selectedSheet }))\n      : [{ workbookViewId: 0, tabSelected: sheet === selectedSheet, selections: [] }];\n    sheet.setSheetViews(nextViews);\n  }\n}\n\nfunction copybookGuideLines(layout) {\n  const lines = [];\n  for (const rowNumber of layout.gridRows) {\n    const row = rowNumber - 1;\n    lines.push(...cellRowOutlineLines(`coco-tianzige-outline-${rowNumber}`, row, 504825));\n    for (let column = 1; column <= 13; column += 1) {\n      lines.push(\n        {\n          name: `coco-tianzige-horizontal-${row + 1}-${column + 1}`,\n          from: { column, columnOffset: 0, row, rowOffset: 252412 },\n          to: { column: column + 1, columnOffset: 0, row, rowOffset: 252412 },\n          width: 504000,\n          height: 0,\n          dash: 'dash',\n        },\n        {\n          name: `coco-tianzige-vertical-${row + 1}-${column + 1}`,\n          from: { column, columnOffset: 252000, row, rowOffset: 0 },\n          to: { column, columnOffset: 252000, row: row + 1, rowOffset: 0 },\n          width: 0,\n          height: 504825,\n          dash: 'dash',\n        },\n      );\n    }\n  }\n  for (const rowNumber of layout.pinyinRows) {\n    const row = rowNumber - 1;\n    const rowHeight = 304800;\n    lines.push(...cellRowOutlineLines(`coco-pinyin-outline-${rowNumber}`, row, rowHeight));\n    for (const [index, rowOffset] of [101600, 203200].entries()) {\n      lines.push({\n        name: `coco-pinyin-guide-${rowNumber}-${index + 1}`,\n        from: { column: 1, columnOffset: 0, row, rowOffset },\n        to: { column: 14, columnOffset: 0, row, rowOffset },\n        width: 6552000,\n        height: 0,\n        dash: 'dash',\n      });\n    }\n  }\n  return lines;\n}\n\nfunction cellRowOutlineLines(name, row, rowHeight) {\n  const solid = { color: '#2C7A69', alpha: 100000, dash: 'solid' };\n  const lines = [\n    {\n      name: `${name}-top`,\n      from: { column: 1, columnOffset: 0, row, rowOffset: 0 },\n      to: { column: 14, columnOffset: 0, row, rowOffset: 0 },\n      width: 6552000,\n      height: 0,\n      ...solid,\n    },\n    {\n      name: `${name}-bottom`,\n      from: { column: 1, columnOffset: 0, row: row + 1, rowOffset: 0 },\n      to: { column: 14, columnOffset: 0, row: row + 1, rowOffset: 0 },\n      width: 6552000,\n      height: 0,\n      ...solid,\n    },\n  ];\n  for (let column = 1; column <= 14; column += 1) {\n    lines.push({\n      name: `${name}-vertical-${column}`,\n      from: { column, columnOffset: 0, row, rowOffset: 0 },\n      to: { column, columnOffset: 0, row: row + 1, rowOffset: 0 },\n      width: 0,\n      height: rowHeight,\n      ...solid,\n    });\n  }\n  return lines;\n}\n\nreturn await run(workbook, args);\n" },
    document: await document?.()
  });
  const output = join(process.cwd(), fileStem + "-" + randomUUID().slice(0, 8) + "." + extension);
  await writeFile(output, await serialize(artifact), { flag: "wx" });
  const linkPath = sep === "\\" ? output.replaceAll("\\", "/") : output;
  process.stdout.write("[" + name + "\uFF08" + extension.toUpperCase() + "\uFF09](<" + linkPath + ">)\n");
}

// coco-dsh/packages/workbuddy/local-skills/src/copybook.mjs
await main({
  name: "\u63CF\u7EA2\u5B57\u5E16",
  fileStem: "coco-copybook",
  extension: "xlsx",
  runner: createExcelScriptRunner()
});
