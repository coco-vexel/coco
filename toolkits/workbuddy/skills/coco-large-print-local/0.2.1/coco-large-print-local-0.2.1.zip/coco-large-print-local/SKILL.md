---
name: coco-large-print-local
display_name: Coco 超大字打印
display_name_en: Coco Large-Print Notices
description: 在本地生成可编辑的 A4 横向超大字 Word 告示。
description_zh: 用 WorkBuddy 桌面端制作可打印的 Word 标牌和门口告示。
description_en: Make an editable landscape A4 Word sign in WorkBuddy Desktop.
examples_zh:
  - "把请勿入内做成 A4 横向超大字告示"
  - "给会议进行中做一份可以打印的 Word 标牌"
examples_en:
  - "Create an A4 landscape notice that says Please do not enter."
  - "Make a printable Word sign that says Meeting in progress."
version: 0.2.1
author: Coco Office
---

使用本技能目录中的脚本在当前任务目录创建新的 DOCX 文件。

`text` 必填，只填写用户要打印的原文，保留空格、标点和换行。缺少正文时先询问。

按当前系统选择一条命令。用 Skill 工具返回的实际 Base directory 替换示例路径。将输入编码为一行 JSON，正文里的换行用 JSON 的 `\n` 表示。

macOS 在任务目录运行下方命令，保留带单引号的 heredoc 标记。

```bash
/bin/sh "/实际技能目录/scripts/run.sh" <<'COCO_SKILL_INPUT'
{"text":"请勿入内"}
COCO_SKILL_INPUT
```

Windows 在任务目录使用 PowerShell。把 JSON 作为数据写入 UTF-8 临时文件，并保留 here-string 的单引号。

```powershell
$json = @'
{"text":"请勿入内"}
'@
$inputPath = Join-Path (Get-Location).Path ('.coco-input-' + [guid]::NewGuid() + '.json')
$workbuddy = Get-Process -Name WorkBuddy -ErrorAction SilentlyContinue |
    Where-Object Path | Select-Object -First 1 -ExpandProperty Path
$encoding = [Console]::OutputEncoding
try {
    [IO.File]::WriteAllText($inputPath, $json, [Text.UTF8Encoding]::new($false))
    [Console]::OutputEncoding = [Text.Encoding]::UTF8
    & 'C:\实际技能目录\scripts\run.cmd' $inputPath $workbuddy
    if ($LASTEXITCODE -ne 0) { throw 'Coco Skill failed.' }
} finally {
    [Console]::OutputEncoding = $encoding
    Remove-Item -LiteralPath $inputPath -ErrorAction SilentlyContinue
}
```

成功时直接把脚本输出的 Markdown 文件链接交给用户。失败时说明脚本报告的原因。
